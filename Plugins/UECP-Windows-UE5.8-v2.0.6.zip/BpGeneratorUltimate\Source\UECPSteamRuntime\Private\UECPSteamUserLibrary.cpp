// Copyright 2026, BlueprintsLab, All rights reserved
#include "Library/UECPSteamUserLibrary.h"

#include "UECPSteamAPI.h"

#if UECP_WITH_STEAM
namespace
{
	HAuthTicket GLocalAuthTicket = k_HAuthTicketInvalid;

	EUECPSteamBeginAuthResult FromNative(EBeginAuthSessionResult In)
	{
		switch (In)
		{
		case k_EBeginAuthSessionResultOK:               return EUECPSteamBeginAuthResult::OK;
		case k_EBeginAuthSessionResultInvalidTicket:    return EUECPSteamBeginAuthResult::InvalidTicket;
		case k_EBeginAuthSessionResultDuplicateRequest: return EUECPSteamBeginAuthResult::DuplicateRequest;
		case k_EBeginAuthSessionResultInvalidVersion:   return EUECPSteamBeginAuthResult::InvalidVersion;
		case k_EBeginAuthSessionResultGameMismatch:     return EUECPSteamBeginAuthResult::GameMismatch;
		case k_EBeginAuthSessionResultExpiredTicket:    return EUECPSteamBeginAuthResult::ExpiredTicket;
		default:                                        return EUECPSteamBeginAuthResult::Unavailable;
		}
	}
}
#endif

bool UUECPSteamUserLibrary::IsLoggedOn()
{
#if UECP_WITH_STEAM
	if (ISteamUser* U = UECPSteam::User()) { return U->BLoggedOn(); }
#endif
	return false;
}

FUECPSteamID UUECPSteamUserLibrary::GetLocalSteamID()
{
#if UECP_WITH_STEAM
	if (ISteamUser* U = UECPSteam::User()) { return FUECPSteamID(UECPSteam::FromSteamID(U->GetSteamID())); }
#endif
	return FUECPSteamID();
}

int32 UUECPSteamUserLibrary::GetPlayerSteamLevel()
{
#if UECP_WITH_STEAM
	if (ISteamUser* U = UECPSteam::User()) { return U->GetPlayerSteamLevel(); }
#endif
	return 0;
}

int32 UUECPSteamUserLibrary::GetGameBadgeLevel(int32 BadgeSeries, bool bFoil)
{
#if UECP_WITH_STEAM
	if (ISteamUser* U = UECPSteam::User()) { return U->GetGameBadgeLevel(BadgeSeries, bFoil); }
#endif
	return 0;
}

bool UUECPSteamUserLibrary::IsBehindNAT()
{
#if UECP_WITH_STEAM
	if (ISteamUser* U = UECPSteam::User()) { return U->BIsBehindNAT(); }
#endif
	return false;
}

bool UUECPSteamUserLibrary::IsPhoneVerified()
{
#if UECP_WITH_STEAM
	if (ISteamUser* U = UECPSteam::User()) { return U->BIsPhoneVerified(); }
#endif
	return false;
}

bool UUECPSteamUserLibrary::IsTwoFactorEnabled()
{
#if UECP_WITH_STEAM
	if (ISteamUser* U = UECPSteam::User()) { return U->BIsTwoFactorEnabled(); }
#endif
	return false;
}

FString UUECPSteamUserLibrary::GetAuthTicket()
{
#if UECP_WITH_STEAM
	ISteamUser* U = UECPSteam::User();
	if (!U)
	{
		return FString();
	}

	uint8 Buffer[1024] = {};
	uint32 Written = 0;
	GLocalAuthTicket = U->GetAuthSessionTicket(Buffer, UE_ARRAY_COUNT(Buffer), &Written, nullptr);
	if (GLocalAuthTicket == k_HAuthTicketInvalid || Written == 0)
	{
		return FString();
	}

	return FString::FromHexBlob(Buffer, Written);
#else
	return FString();
#endif
}

EUECPSteamBeginAuthResult UUECPSteamUserLibrary::BeginAuthSession(
	const FString& Ticket, FUECPSteamID PeerSteamId)
{
#if UECP_WITH_STEAM
	ISteamUser* U = UECPSteam::User();
	if (!U || Ticket.IsEmpty() || !PeerSteamId.IsValid())
	{
		return EUECPSteamBeginAuthResult::Unavailable;
	}

	TArray<uint8> Raw;
	Raw.SetNumUninitialized(Ticket.Len() / 2);
	if (!FString::ToHexBlob(Ticket, Raw.GetData(), Raw.Num()))
	{
		return EUECPSteamBeginAuthResult::InvalidTicket;
	}

	return FromNative(U->BeginAuthSession(Raw.GetData(), Raw.Num(),
		UECPSteam::ToSteamID(PeerSteamId.Value)));
#else
	return EUECPSteamBeginAuthResult::Unavailable;
#endif
}

void UUECPSteamUserLibrary::EndAuthSession(FUECPSteamID PeerSteamId)
{
#if UECP_WITH_STEAM
	if (ISteamUser* U = UECPSteam::User())
	{
		if (PeerSteamId.IsValid()) { U->EndAuthSession(UECPSteam::ToSteamID(PeerSteamId.Value)); }
	}
#endif
}

void UUECPSteamUserLibrary::CancelAuthTicket()
{
#if UECP_WITH_STEAM
	if (ISteamUser* U = UECPSteam::User())
	{
		if (GLocalAuthTicket != k_HAuthTicketInvalid)
		{
			U->CancelAuthTicket(GLocalAuthTicket);
			GLocalAuthTicket = k_HAuthTicketInvalid;
		}
	}
#endif
}

bool UUECPSteamUserLibrary::UserHasLicenseForApp(FUECPSteamID PeerSteamId, int32 AppId)
{
#if UECP_WITH_STEAM
	ISteamUser* U = UECPSteam::User();
	ISteamUtils* Utils = UECPSteam::Utils();
	if (U && Utils && PeerSteamId.IsValid())
	{
		const AppId_t Target = AppId > 0 ? static_cast<AppId_t>(AppId) : Utils->GetAppID();
		return U->UserHasLicenseForApp(UECPSteam::ToSteamID(PeerSteamId.Value), Target)
			== k_EUserHasLicenseResultHasLicense;
	}
#endif
	return false;
}

bool UUECPSteamUserLibrary::GetDurationControl(int32& SecondsThisSession, bool& bBlocked)
{
	SecondsThisSession = 0;
	bBlocked = false;

#if UECP_WITH_STEAM
	if (ISteamUser* U = UECPSteam::User())
	{
		U->GetDurationControl();
	}
#endif
	return false;
}
