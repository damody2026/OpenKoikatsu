(function () {
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  const TABS = ['all', 'builtin', 'marketplace'];
  const TAB_LABELS = { all: 'All', builtin: 'Built-in', marketplace: 'Marketplace' };

  const STATE_BADGES = {
    Disabled:              { label: 'Disabled',         bg: 'var(--ue-elev)',         fg: 'var(--ue-text-lo)' },
    PreconditionsFailed:   { label: 'Plugin missing',    bg: 'var(--ue-warn-soft)',    fg: 'var(--ue-warn)' },
    LicenseLocked:         { label: 'License required',  bg: 'var(--ue-warn-soft)',    fg: 'var(--ue-warn)' },
    Loaded:                { label: 'Loaded',            bg: 'var(--ue-success-soft)', fg: 'var(--ue-success)' },
    Failed:                { label: 'Failed to load',    bg: 'var(--ue-elev)',         fg: 'var(--ue-danger)' },
    EngineVersionMismatch: { label: 'Engine version',    bg: 'var(--ue-warn-soft)',    fg: 'var(--ue-warn)' },
  };

  function stateBadgeHtml(ext) {
    const state = ext.state || 'Disabled';
    if (state === 'EngineVersionMismatch') {
      let label = 'Requires UE';
      if (ext.minEngineVersion)      label += ' ' + ext.minEngineVersion + '+';
      else if (ext.maxEngineVersion) label += ' ≤ ' + ext.maxEngineVersion;
      const s = STATE_BADGES.EngineVersionMismatch;
      const title = window.runningEngineVersion ? ('Running UE ' + window.runningEngineVersion) : '';
      return '<span style="font-size:8.5px;font-weight:700;letter-spacing:.06em;padding:2px 6px;border-radius:5px;text-transform:uppercase;white-space:nowrap;background:' + s.bg + ';color:' + s.fg + '"'
        + (title ? ' title="' + esc(title) + '"' : '') + '>' + esc(label) + '</span>';
    }
    const s = STATE_BADGES[state] || STATE_BADGES.Disabled;
    return '<span style="font-size:8.5px;font-weight:700;letter-spacing:.06em;padding:2px 6px;border-radius:5px;text-transform:uppercase;white-space:nowrap;background:' + s.bg + ';color:' + s.fg + '">' + esc(s.label) + '</span>';
  }

  class SettingsExtensions extends HTMLElement {
    connectedCallback() {
      this.style.cssText = 'display:flex;flex-direction:column;flex:1;min-height:0';
      this._exts    = [];
      this._pending = [];
      this._tab     = 'all';
      this._query   = '';
      this._render();
      window.uecp.call('request_extensions_catalog', {});
    }

    _onSettingsInit(state) {
      if (!state) return;
      if (state.extensions && Array.isArray(state.extensions)) {
        this._exts = state.extensions;
        this._renderGrid();
      }
    }

    _onExtensions(data) {
      if (Array.isArray(data)) {
        this._exts = data;
      } else if (data && Array.isArray(data.extensions)) {
        this._exts = data.extensions;
      } else if (data && Array.isArray(data.catalog)) {
        this._exts = data.catalog;
      } else {
        this._exts = [];
      }
      this._renderGrid();
    }

    _onExtensionToggleResult(data) {
      if (!data || data.ok || data.queued) return;
      const missing = Array.isArray(data.missingPlugins) ? data.missingPlugins : [];
      let msg = data.error || 'Failed to toggle extension.';
      if (missing.length) msg += ' (missing: ' + missing.join(', ') + ')';
      window.uecp.__emit('toast', { message: msg, severity: 'error' });
    }

    _onExtensionsApplyResult(data) {
      if (!data || data.ok) return;
      window.uecp.__emit('toast', { message: data.error || 'Failed to apply extension changes.', severity: 'error' });
    }

    _onExtensionsPending(data) {
      const SF = window.SettingsFormat;
      const norm = SF && SF.parseExtensionsPending ? SF.parseExtensionsPending(data)
        : { changes: Array.isArray(data) ? data : (data && data.changes) || [], requiresRestart: !!(data && data.requiresRestart) };
      this._pending = norm.changes;
      this._requiresRestart = norm.requiresRestart;
      this._renderBanner();
      this._renderGrid();
    }

    _render() {
      this.innerHTML =
        '<div class="content-head">'
        + '<span class="crumb"><b>Extensions</b></span>'
        + '</div>'
        + '<div id="sext-banner-slot"></div>'
        + '<div class="page page-narrow" style="overflow-y:auto;flex:1">'
        + '<div class="sext-toolbar" style="display:flex;align-items:flex-end;gap:14px;margin-bottom:16px">'
        + '<div style="flex:1"><div class="page-title">Extensions</div>'
        + '<div class="page-sub">Optional tool packs. Enable to give the AI extra capabilities in specialised editors.</div>'
        + '</div>'
        + '<input id="sext-search" type="text" placeholder="Search extensions…" autocomplete="off" '
        + 'style="width:min(180px,100%);padding:6px 10px;font-size:12px;border-radius:var(--ue-r-sm);border:1px solid var(--ue-line);background:var(--ue-bg);color:var(--ue-text-hi)">'
        + '<div class="tabs">'
        + TABS.map(function (t) {
            return '<span data-tab="' + t + '">' + TAB_LABELS[t] + '</span>';
          }).join('')
        + '</div>'
        + '</div>'
        + '<div class="grid-2" id="sext-grid"></div>'
        + '</div>';

      const self = this;

      this.querySelectorAll('.tabs span[data-tab]').forEach(function (tab) {
        tab.addEventListener('click', function () {
          self._tab = tab.dataset.tab;
          self.querySelectorAll('.tabs span[data-tab]').forEach(function (t) { t.classList.remove('active'); });
          tab.classList.add('active');
          self._renderGrid();
        });
      });
      const firstTab = this.querySelector('.tabs span[data-tab="' + this._tab + '"]');
      if (firstTab) firstTab.classList.add('active');

      const searchInput = this.querySelector('#sext-search');
      if (searchInput) {
        searchInput.value = this._query;
        searchInput.addEventListener('input', function () {
          self._query = searchInput.value.trim().toLowerCase();
          self._renderGrid();
        });
      }

      this._renderBanner();
      this._renderGrid();
    }

    _renderBanner() {
      const slot = this.querySelector('#sext-banner-slot');
      if (!slot) return;
      if (!this._pending || !this._pending.length) {
        slot.innerHTML = '';
        return;
      }
      const count = this._pending.length;
      const restartMsg = this._requiresRestart ? ' — restart required to apply.' : ' pending.';
      const chips = this._pending.map(function (p) {
        const label = esc(p.name || p.id || '');
        const prefix = p.enabling ? '+' : '−';
        return '<span style="display:inline-flex;align-items:center;gap:4px;padding:3px 8px;border-radius:11px;background:rgba(0,0,0,.15);color:var(--ue-warn);font-size:11.5px">'
          + prefix + ' ' + label
          + '<a href="#" data-unqueue-id="' + esc(p.id || '') + '" style="text-decoration:none;color:inherit;opacity:.7;font-weight:600;padding:0 2px;cursor:pointer" title="Remove from queue">×</a>'
          + '</span>';
      }).join('');
      slot.innerHTML = '<div class="sext-banner" style="background:var(--ue-warn-soft);border-bottom:1px solid rgba(224,162,60,.2);padding:10px 22px;display:flex;flex-direction:column;gap:8px;font-size:12.5px;color:var(--ue-warn);flex-shrink:0">'
        + '<div style="display:flex;align-items:center;gap:12px">'
        + '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 8v4"/><circle cx="12" cy="16" r=".5" fill="currentColor"/></svg>'
        + '<span style="flex:1">' + count + ' change' + (count !== 1 ? 's' : '') + restartMsg + '</span>'
        + '<button id="sext-cancel-pending" style="font-size:11px;padding:5px 12px;border-radius:var(--ue-r-sm);border:1px solid currentColor;background:transparent;cursor:pointer;color:var(--ue-warn)">Discard</button>'
        + '<button id="sext-apply-pending" style="font-size:11px;padding:5px 12px;border-radius:var(--ue-r-sm);background:var(--ue-warn);color:#1a0e00;border:none;cursor:pointer">Apply &amp; Restart</button>'
        + '</div>'
        + '<div style="display:flex;flex-wrap:wrap;gap:6px">' + chips + '</div>'
        + '</div>';
      const self = this;
      this.querySelector('#sext-cancel-pending').addEventListener('click', function () {
        window.uecp.call('cancel_pending_extension_changes', {});
      });
      this.querySelector('#sext-apply-pending').addEventListener('click', function () {
        window.uecp.call('apply_pending_extension_changes', {});
      });
      slot.querySelectorAll('[data-unqueue-id]').forEach(function (a) {
        a.addEventListener('click', function (e) {
          e.preventDefault();
          window.uecp.call('unqueue_extension_change', { extensionId: a.dataset.unqueueId });
        });
      });
    }

    _renderGrid() {
      const grid = this.querySelector('#sext-grid');
      if (!grid) return;

      function bucketFor(e) {
        const kind = e.kind || (e.isThirdParty ? 'ThirdParty' : 'Bundled');
        if (kind === 'ThirdParty') return 'marketplace';
        if (kind === 'UserMcp') return 'builtin';
        if (e.requiresLicense || e.paid) return 'marketplace';
        return 'builtin';
      }

      const filtered = this._exts.filter(function (e) {
        if (this._tab !== 'all' && bucketFor(e) !== this._tab) return false;
        if (!this._query) return true;
        const name = (e.name || '').toLowerCase();
        const desc = (e.description || '').toLowerCase();
        return name.includes(this._query) || desc.includes(this._query);
      }, this);

      if (!filtered.length) {
        grid.innerHTML = '<div style="color:var(--ue-text-lo);font-size:var(--ue-fs-sm);padding:40px 0;text-align:center;grid-column:1/-1">No extensions found.</div>';
        return;
      }

      const pendingIds = {};
      (this._pending || []).forEach(function (p) { pendingIds[p.id || p] = true; });

      function buildCard(ext) {
        const id        = ext.id || ext.extensionId || '';
        const name      = ext.name       || id;
        const desc      = ext.description || ext.byline || '';
        const byline    = ext.byline     || '';
        const author    = ext.author     || ext.authorName || ext.publisher || '';
        const version   = ext.version    || '';
        const enabled   = ext.enabled    ? true : false;
        const isPaid    = (ext.paid || ext.requiresLicense) ? true : false;
        const isPending = pendingIds[id] ? true : false;
        const isLocked  = ext.state === 'EngineVersionMismatch';
        const initials  = (name.replace(/[^A-Z0-9]/gi, '').substring(0, 2) || name.substring(0, 2)).toUpperCase();
        const websiteUrl = ext.websiteUrl || '';

        const bylineText = byline || [(author || ''), (version ? 'v' + version : '')].filter(Boolean).join(' · ');

        const tileClass = enabled ? 'tile' : 'tile-muted';

        let iconContent;
        if (ext.iconUrl) {
          iconContent = '<img src="' + esc(ext.iconUrl) + '" width="18" height="18" style="border-radius:4px;object-fit:cover" alt="">';
        } else {
          iconContent = '<span style="font-size:12px;font-weight:700;font-family:var(--ue-font-sans)">' + esc(initials) + '</span>';
        }

        const card = document.createElement('div');
        card.className = 'card';
        card.style.cssText = 'padding:14px 15px';
        card.innerHTML =
          '<div style="display:flex;align-items:flex-start;gap:11px;margin-bottom:9px">'
          + '<span class="' + tileClass + '">' + iconContent + '</span>'
          + '<div style="flex:1;min-width:0">'
          + '<div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">'
          + '<span style="font-size:13.5px;font-weight:600">' + esc(name) + '</span>'
          + stateBadgeHtml(ext)
          + '</div>'
          + ((bylineText || websiteUrl) ? '<div class="chat-item-meta">' + esc(bylineText)
              + (websiteUrl ? (bylineText ? ' · ' : '') + '<a href="#" class="sext-website-link" style="color:inherit;text-decoration:underline">Website ↗</a>' : '')
              + '</div>' : '')
          + '</div>'
          + '<div class="toggle sm' + (enabled ? ' on' : '') + '"' + (isLocked ? ' style="opacity:.5;cursor:not-allowed" title="Cannot enable on this engine version"' : '')
          + ' data-ext-id="' + esc(id) + '" role="switch" aria-checked="' + (enabled ? 'true' : 'false') + '" tabindex="' + (isLocked ? '-1' : '0') + '"><span class="knob"></span></div>'
          + '</div>'
          + '<div class="card-desc" style="font-size:11.5px">' + esc(desc) + '</div>'
          + (isPaid ? '<div style="margin-top:7px"><span style="font-size:8.5px;font-weight:700;letter-spacing:.06em;color:var(--ue-warn);background:var(--ue-warn-soft);padding:2px 6px;border-radius:5px;text-transform:uppercase">PAID</span></div>' : '')
          + (isPending ? '<div style="margin-top:7px"><span style="font-size:8.5px;font-weight:700;letter-spacing:.06em;color:var(--ue-warn);background:var(--ue-warn-soft);padding:2px 6px;border-radius:5px;text-transform:uppercase">PENDING</span></div>' : '')
          + (ext.mcpBacked ? '<div style="margin-top:9px"><button class="btn-ghost" data-restart="' + esc(id) + '" style="font-size:11px;padding:5px 9px">Restart MCP</button></div>' : '');

        if (!isLocked) {
          card.querySelector('.toggle[data-ext-id]').addEventListener('click', function () {
            const wasOn = this.classList.contains('on');
            window.uecp.call('toggle_extension', { extensionId: id, enable: !wasOn });
          });
        }

        const rb = card.querySelector('[data-restart]');
        if (rb) rb.addEventListener('click', function (e) {
          e.stopPropagation();
          window.uecp.call('restart_extension_mcp', { extensionId: id });
        });

        const wl = card.querySelector('.sext-website-link');
        if (wl) wl.addEventListener('click', function (e) {
          e.preventDefault();
          e.stopPropagation();
          window.uecp.call('open_external_url', { url: websiteUrl });
        });

        return card;
      }

      const groups = {};
      const groupOrder = [];
      filtered.forEach(function (e) {
        const cat = e.category || 'Other';
        if (!groups[cat]) { groups[cat] = []; groupOrder.push(cat); }
        groups[cat].push(e);
      });
      groupOrder.sort(function (a, b) {
        if (a === 'Other') return 1;
        if (b === 'Other') return -1;
        return a.localeCompare(b);
      });

      grid.innerHTML = '';
      groupOrder.forEach(function (cat) {
        const header = document.createElement('div');
        header.style.cssText = 'grid-column:1/-1;display:flex;align-items:center;gap:10px;margin:14px 0 2px';
        header.innerHTML = '<span style="font-family:var(--ue-font-mono);font-size:10px;font-weight:700;letter-spacing:.13em;color:var(--ue-text-lo);text-transform:uppercase;white-space:nowrap">' + esc(cat) + '</span>'
          + '<span style="flex:1;height:1px;background:var(--ue-line-soft)"></span>';
        grid.appendChild(header);
        groups[cat].forEach(function (ext) { grid.appendChild(buildCard(ext)); });
      });
    }
  }
  customElements.define('settings-extensions', SettingsExtensions);
})();
