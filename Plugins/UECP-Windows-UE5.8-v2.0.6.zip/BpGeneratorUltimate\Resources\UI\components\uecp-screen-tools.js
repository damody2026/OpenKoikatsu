(function () {
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function t(s) { return (window.uecp && typeof window.uecp.t === 'function') ? window.uecp.t(s) : s; }

  const NARROW_ZONE = 40;

  function twinOf(zone) {
    const m = /^(.*)_([lr])$/.exec(zone);
    return m ? m[1] + (m[2] === 'l' ? '_r' : '_l') : '';
  }

  function sideMarker(label, twinLabel) {
    const a = label.split(' '), b = twinLabel.split(' ');
    if (a.length > 1 && a.length === b.length) {
      const diff = a.filter(function (w, i) { return w !== b[i]; });
      if (diff.length === 1) return diff[0];
    }
    let s = 0, e = 0;
    while (s < label.length && label[s] === twinLabel[s]) s++;
    while (e < label.length - s && label[label.length - 1 - e] === twinLabel[twinLabel.length - 1 - e]) e++;
    return label.slice(s, label.length - e) || label;
  }

  if (!document.getElementById('uecp-screen-tools-css')) {
    const s = document.createElement('style'); s.id = 'uecp-screen-tools-css';
    s.textContent = `
uecp-screen-tools{display:flex;flex:1;min-width:0;min-height:0;flex-direction:column;background:var(--ue-bg);overflow:hidden}
uecp-screen-tools .st-wrap{flex:1;min-height:0;overflow-y:auto}
uecp-screen-tools .st-sub{display:none;flex:1;min-height:0;overflow-y:auto;padding:20px;flex-direction:column}
uecp-screen-tools .st-sub.active{display:flex}
uecp-screen-tools .st-back{background:none;border:none;cursor:pointer;color:var(--ue-text-mid);font-size:12.5px;display:inline-flex;align-items:center;gap:6px;padding:0 0 12px;text-decoration:none}
uecp-screen-tools .st-back:hover{color:var(--ue-text-hi)}
uecp-screen-tools .st-sub-title{font-size:15px;font-weight:700;color:var(--ue-text-hi);display:flex;align-items:center;gap:8px;margin-bottom:4px}
uecp-screen-tools .st-sub-desc{font-size:12.5px;color:var(--ue-text-mid);margin-bottom:14px}
uecp-screen-tools .st-field{margin-bottom:12px}
uecp-screen-tools .st-label{font-size:11.5px;color:var(--ue-text-mid);margin-bottom:4px;font-weight:var(--ue-fw-semi)}
uecp-screen-tools .st-input{width:100%;background:var(--ue-bg);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm);color:var(--ue-text-hi);padding:6px 10px;font-size:12.5px;box-sizing:border-box}
uecp-screen-tools .st-input:focus{outline:none;border-color:var(--ue-accent)}
uecp-screen-tools .st-row{display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap}
uecp-screen-tools .st-btn{background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm);color:var(--ue-text-hi);padding:6px 14px;cursor:pointer;font-size:12.5px}
uecp-screen-tools .st-btn:hover{background:var(--ue-elev)}
uecp-screen-tools .st-btn-primary{background:var(--ue-accent);border-color:var(--ue-accent);color:var(--ue-on-accent)}
uecp-screen-tools .st-btn-primary:hover{opacity:.88}
uecp-screen-tools .st-result{background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm);padding:12px;font-size:12px;color:var(--ue-text-mid);min-height:60px;white-space:pre-wrap;margin-top:8px}
uecp-screen-tools .st-bone-list{max-height:220px;overflow-y:auto;background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm);margin-top:4px}
uecp-screen-tools .st-bone-row{display:flex;align-items:center;gap:8px;padding:5px 10px;font-size:12px;color:var(--ue-text-hi);cursor:pointer}
uecp-screen-tools .st-bone-row:hover{background:var(--ue-elev)}
uecp-screen-tools .st-bone-row label{cursor:pointer}
uecp-screen-tools .st-picker{display:flex;gap:12px;align-items:flex-start}
uecp-screen-tools .st-picker .st-bone-list{flex:1;margin-top:0}
uecp-screen-tools .st-body{width:170px;flex:0 0 170px;background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm);padding:8px}
uecp-screen-tools .st-body svg{display:block;width:100%;height:auto}
uecp-screen-tools .st-zone{fill:var(--ue-elev);stroke:var(--ue-line-soft);stroke-width:2;cursor:pointer}
uecp-screen-tools .st-zone:hover{fill:var(--ue-accent-soft);stroke:var(--ue-accent)}
uecp-screen-tools .st-zone.on{fill:var(--ue-accent);stroke:var(--ue-accent-bright)}
uecp-screen-tools .st-zone.off{fill:none;stroke:var(--ue-line-soft);stroke-dasharray:4 4;cursor:not-allowed;opacity:.5}
uecp-screen-tools .st-zone-label{fill:var(--ue-text-mid);font-size:15px;text-anchor:middle;pointer-events:none;user-select:none}
uecp-screen-tools .st-zone-label.on{fill:var(--ue-on-accent)}
uecp-screen-tools .st-body-hint{font-size:11px;color:var(--ue-text-lo);text-align:center;margin-top:6px;min-height:14px}
uecp-screen-tools .meshy-tabs{display:flex;gap:4px;flex-wrap:wrap;margin-bottom:14px;border-bottom:1px solid var(--ue-line-soft);padding-bottom:8px}
uecp-screen-tools .meshy-tab{background:none;border:none;color:var(--ue-text-mid);padding:5px 12px;font-size:12.5px;cursor:pointer;border-radius:var(--ue-r-sm)}
uecp-screen-tools .meshy-tab.active{background:var(--ue-accent-soft);color:var(--ue-accent-bright)}
uecp-screen-tools .meshy-form{display:none;flex-direction:column}
uecp-screen-tools .meshy-form.active{display:flex}
uecp-screen-tools .meshy-jobs{background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm);padding:10px;margin-top:14px;font-size:12px;color:var(--ue-text-mid)}
uecp-screen-tools .meshy-job-row{padding:6px 0;border-bottom:1px solid var(--ue-line-soft);display:flex;align-items:center;gap:8px}
uecp-screen-tools .meshy-job-row:last-child{border-bottom:none}
uecp-screen-tools .meshy-credits{font-size:12px;color:var(--ue-text-mid);margin-bottom:8px}
uecp-screen-tools .meshy-anim-dropdown{display:none;position:absolute;left:0;right:0;top:100%;z-index:20;max-height:240px;overflow-y:auto;background:var(--ue-panel);border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);box-shadow:0 6px 18px rgba(0,0,0,.35)}
uecp-screen-tools .meshy-anim-dropdown.open{display:block}
uecp-screen-tools .meshy-anim-cat{padding:4px 10px;font-size:10px;letter-spacing:.06em;text-transform:uppercase;color:var(--ue-text-lo);background:var(--ue-bg);position:sticky;top:0}
uecp-screen-tools .meshy-anim-item{padding:6px 10px;font-size:12.5px;color:var(--ue-text-hi);cursor:pointer;display:flex;justify-content:space-between;gap:8px}
uecp-screen-tools .meshy-anim-item:hover{background:var(--ue-accent-soft)}
uecp-screen-tools .meshy-anim-item .aid{color:var(--ue-text-lo);font-family:var(--ue-font-mono);font-size:11px}
uecp-screen-tools .meshy-anim-dropdown-empty{padding:10px;font-size:12px;color:var(--ue-text-lo)}
/* Tripo Studio reuses the Meshy tab/form/jobs chrome verbatim -- the panels are
   the same shape, and a second copy of these rules would drift on the first
   restyle. Only the task-picker row below is Tripo-specific: Tripo chains by
   task id rather than asset path, so picking a prior task IS the workflow. */
uecp-screen-tools .tripo-tabs{display:flex;gap:4px;flex-wrap:wrap;margin-bottom:14px;border-bottom:1px solid var(--ue-line-soft);padding-bottom:8px}
uecp-screen-tools .tripo-tab{background:none;border:none;color:var(--ue-text-mid);padding:5px 12px;font-size:12.5px;cursor:pointer;border-radius:var(--ue-r-sm)}
uecp-screen-tools .tripo-tab.active{background:var(--ue-accent-soft);color:var(--ue-accent-bright)}
uecp-screen-tools .tripo-form{display:none;flex-direction:column}
uecp-screen-tools .tripo-form.active{display:flex}
uecp-screen-tools .tripo-jobs{background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm);padding:10px;margin-top:14px;font-size:12px;color:var(--ue-text-mid)}
uecp-screen-tools .tripo-job-row{padding:6px 0;border-bottom:1px solid var(--ue-line-soft);display:flex;align-items:center;gap:8px}
uecp-screen-tools .tripo-job-row:last-child{border-bottom:none}
uecp-screen-tools .tripo-note{font-size:11.5px;color:var(--ue-text-lo);margin:-4px 0 10px}
uecp-screen-tools .tripo-nokey{background:var(--ue-accent-soft);border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);padding:9px 11px;font-size:12px;color:var(--ue-text-hi);margin-bottom:12px}
uecp-screen-tools .st-2col{display:grid;grid-template-columns:1fr 1fr;gap:12px}
uecp-screen-tools .imggen-preview{max-width:100%;max-height:300px;border-radius:var(--ue-r-sm);margin-top:10px}
uecp-screen-tools .st-history-table{width:100%;border-collapse:collapse;font-size:12px}
uecp-screen-tools .st-history-table th{text-align:left;color:var(--ue-text-mid);font-weight:var(--ue-fw-semi);padding:5px 8px;border-bottom:1px solid var(--ue-line-soft)}
uecp-screen-tools .st-history-table td{padding:5px 8px;color:var(--ue-text-hi);vertical-align:top}`;
    document.head.appendChild(s);
  }

  function svgIcon(id, size) {
    size = size || 15;
    return '<svg width="' + size + '" height="' + size + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><use href="#' + id + '"/></svg>';
  }

  class UecpScreenTools extends HTMLElement {
    connectedCallback() {
      this._page    = 'landing';
      this._bones   = [];
      this._profStatus = '';
      this._build();
      this._subscribe();
    }

    disconnectedCallback() {
      (this._subs || []).forEach(function (u) { u(); });
      this._subs = [];
    }

    _build() {
      this.innerHTML = '';

      this._wrap = document.createElement('div');
      this._wrap.className = 'st-wrap content';
      this._wrap.innerHTML =
        '<div class="page page-wide">' +
          '<div class="page-title">Tools</div>' +
          '<div class="page-sub">Utility tools for asset manipulation and workflow automation.</div>' +
          '<div class="grid-2" style="margin-top:22px">' +
            '<div class="card hover" data-card="mesh-splitter">' +
              '<div style="display:flex;align-items:center;gap:10px;margin-bottom:9px"><span class="tile">' + svgIcon('ic-wrench', 17) + '</span><span class="card-title">Mesh Splitter</span></div>' +
              '<div class="card-desc">Split skeletal meshes at bone boundaries for equipment and armor systems.</div>' +
            '</div>' +
            '<div class="card hover" data-card="mesh-merger">' +
              '<div style="display:flex;align-items:center;gap:10px;margin-bottom:9px"><span class="tile">' + svgIcon('ic-box', 17) + '</span><span class="card-title">Mesh Merger</span></div>' +
              '<div class="card-desc">Combine modular skeletal meshes sharing a skeleton into one asset.</div>' +
            '</div>' +
            '<div class="card hover" data-card="retarget">' +
              '<div style="display:flex;align-items:center;gap:10px;margin-bottom:9px"><span class="tile">' + svgIcon('ic-zap', 17) + '</span><span class="card-title">Retarget Studio</span></div>' +
              '<div class="card-desc">Move animations between characters with different skeletons.</div>' +
            '</div>' +
            '<div class="card hover" data-card="profiler">' +
              '<div style="display:flex;align-items:center;gap:10px;margin-bottom:9px"><span class="tile">' + svgIcon('ic-zap', 17) + '</span><span class="card-title">Performance Profiler</span></div>' +
              '<div class="card-desc">Profile CPU / GPU / frame time and get AI-powered optimization suggestions.</div>' +
            '</div>' +
          '</div>' +
        '</div>';

      const self = this;
      this._wrap.querySelectorAll('[data-card]').forEach(function (card) {
        card.addEventListener('click', function () {
          self._showPage(card.dataset.card);
        });
      });

      this.appendChild(this._wrap);

      this._subMeshSplitter = this._buildMeshSplitter();
      this._subMeshMerger   = this._buildMeshMerger();
      this._subRetarget     = this._buildRetargetStudio();
      this._subProfiler     = this._buildProfiler();
      this.appendChild(this._subMeshSplitter);
      this.appendChild(this._subMeshMerger);
      this.appendChild(this._subRetarget);
      this.appendChild(this._subProfiler);
    }

    _backBtn(label) {
      const btn = document.createElement('button');
      btn.className = 'st-back';
      btn.innerHTML = svgIcon('ic-arrow-left', 13) + ' ' + esc(label || 'Back to Tools');
      const self = this;
      btn.addEventListener('click', function () { self._showPage('landing'); });
      return btn;
    }

    _buildMeshSplitter() {
      const el = document.createElement('div');
      el.className = 'st-sub';
      el.id = 'st-sub-mesh-splitter';
      const self = this;
      el.innerHTML =
        '<div class="st-sub-title">' + svgIcon('ic-wrench', 14) + ' Mesh Splitter</div>' +
        '<div class="st-sub-desc">Split a skeletal mesh at bone boundaries into separate mesh assets.</div>' +
        '<div class="st-field"><div class="st-label">Skeletal Mesh Path</div>' +
          '<div class="st-row"><input class="st-input" id="st-ms-path" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="/Game/Characters/Meshes/SK_MyMesh" style="flex:1">' +
          '<button class="st-btn" id="st-ms-browse">Browse</button>' +
          '<button class="st-btn" id="st-ms-loadbones">Load Bones</button></div></div>' +
        '<div class="st-field"><div class="st-label">Split Points</div>' +
          '<div class="st-picker">' +
            '<div class="st-body"><div id="st-ms-body"></div><div class="st-body-hint" id="st-ms-bodyhint">Click a body part to split there.</div></div>' +
            '<div class="st-bone-list" id="st-ms-bonelist"><div style="padding:14px;text-align:center;color:var(--ue-text-lo)">Load a skeletal mesh to see bones.</div></div>' +
          '</div></div>' +
        '<div class="st-2col"><div class="st-field"><div class="st-label">Output Path (optional)</div><input class="st-input" id="st-ms-outpath" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="/Game/Characters/Meshes/Split/"></div>' +
        '<div class="st-field"><div class="st-label">Partition Names (comma-separated)</div><input class="st-input" id="st-ms-names" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="Body, Head, Torso, Legs"></div></div>' +
        '<div class="st-row"><button class="st-btn" id="st-ms-preview">Preview Split</button><button class="st-btn st-btn-primary" id="st-ms-execute">Split Mesh</button></div>' +
        '<div class="st-result" id="st-ms-result">Select a skeletal mesh and check the bones you want to split at.</div>';

      el.prepend(this._backBtn('Back to Tools'));

      el.querySelector('#st-ms-browse').addEventListener('click', function () {
        window.uecp.call('browse_skeletal_mesh', {});
      });
      el.querySelector('#st-ms-loadbones').addEventListener('click', function () {
        const path = el.querySelector('#st-ms-path').value.trim();
        window.uecp.call('load_bones', { meshPath: path });
      });
      el.querySelector('#st-ms-preview').addEventListener('click', function () {
        self._doSplitOp('preview');
      });
      el.querySelector('#st-ms-execute').addEventListener('click', function () {
        self._doSplitOp('execute');
      });

      el.querySelector('#st-ms-bonelist').addEventListener('change', function (ev) {
        if (ev.target && ev.target.hasAttribute('data-bone')) self._paintBodyZones();
      });

      this._subMeshSplitter = el;
      this._zones = [];
      this._renderBodySilhouette();
      return el;
    }

    _bodyZoneRects() {
      return [
        { zone: 'head',       label: 'Head',    x: 129,   y: 10,  w: 42,   h: 50 },
        { zone: 'torso',      label: 'Torso',   x: 111,   y: 70,  w: 78,   h: 80 },
        { zone: 'abdomen',    label: 'Abdomen', x: 111,   y: 150, w: 78,   h: 50 },
        { zone: 'upperarm_l', label: 'Arm L',   x: 63,    y: 70,  w: 42,   h: 65 },
        { zone: 'upperarm_r', label: 'Arm R',   x: 195,   y: 70,  w: 42,   h: 65 },
        { zone: 'forearm_l',  label: 'Fore L',  x: 63,    y: 135, w: 42,   h: 65 },
        { zone: 'forearm_r',  label: 'Fore R',  x: 195,   y: 135, w: 42,   h: 65 },
        { zone: 'hand_l',     label: 'Hand L',  x: 63,    y: 200, w: 42,   h: 40 },
        { zone: 'hand_r',     label: 'Hand R',  x: 195,   y: 200, w: 42,   h: 40 },
        { zone: 'thigh_l',    label: 'Thigh L', x: 111,   y: 210, w: 34.5, h: 90 },
        { zone: 'thigh_r',    label: 'Thigh R', x: 154.5, y: 210, w: 34.5, h: 90 },
        { zone: 'calf_l',     label: 'Calf L',  x: 114,   y: 300, w: 31.5, h: 90 },
        { zone: 'calf_r',     label: 'Calf R',  x: 154.5, y: 300, w: 31.5, h: 90 },
        { zone: 'foot_l',     label: 'Foot L',  x: 111,   y: 390, w: 34.5, h: 50 },
        { zone: 'foot_r',     label: 'Foot R',  x: 154.5, y: 390, w: 34.5, h: 50 }
      ];
    }

    _renderBodySilhouette() {
      const host = this._subMeshSplitter.querySelector('#st-ms-body');
      if (!host) return;
      const self = this;

      const rects = this._bodyZoneRects();
      const byZone = {};
      rects.forEach(function (r) { byZone[r.zone] = r; });

      const parts = rects.map(function (r) {
        const twin = r.w < NARROW_ZONE ? byZone[twinOf(r.zone)] : null;
        const shown = twin ? sideMarker(t(r.label), t(twin.label)) : r.label;
        return '<g data-zone="' + esc(r.zone) + '"' + (twin ? ' data-tip="' + esc(r.label) + '"' : '') + '>' +
          '<rect class="st-zone off" x="' + r.x + '" y="' + r.y + '" width="' + r.w +
            '" height="' + r.h + '" rx="6"></rect>' +
          '<text class="st-zone-label" x="' + (r.x + r.w / 2) + '" y="' + (r.y + r.h / 2 + 5) + '">' +
            esc(shown) + '</text>' +
        '</g>';
      }).join('');

      host.innerHTML = '<svg viewBox="0 0 300 500" preserveAspectRatio="xMidYMid meet" ' +
        'role="group" aria-label="Body part selector">' + parts + '</svg>';

      host.querySelectorAll('[data-zone]').forEach(function (g) {
        g.addEventListener('click', function () { self._onZoneClicked(g.dataset.zone); });
        g.addEventListener('mouseenter', function () { self._showZoneHint(g.dataset.zone); });
        g.addEventListener('mouseleave', function () { self._showZoneHint(null); });
      });

      this._paintBodyZones();
    }

    _zoneBone(zone) {
      const hit = (this._zones || []).filter(function (z) { return z.zone === zone; })[0];
      return hit && hit.bone ? hit.bone : '';
    }

    _boneCheckbox(bone) {
      if (!bone) return null;
      const rows = this._subMeshSplitter.querySelectorAll('[data-bone]');
      for (let i = 0; i < rows.length; i++) if (rows[i].value === bone) return rows[i];
      return null;
    }

    _onZoneClicked(zone) {
      const cb = this._boneCheckbox(this._zoneBone(zone));
      if (!cb) return;
      cb.checked = !cb.checked;
      this._paintBodyZones();
      this._showZoneHint(zone);
    }

    _showZoneHint(zone) {
      const hint = this._subMeshSplitter.querySelector('#st-ms-bodyhint');
      if (!hint) return;
      if (!zone) { hint.textContent = 'Click a body part to split there.'; return; }
      const bone = this._zoneBone(zone);
      hint.textContent = bone ? bone : 'No matching bone in this skeleton';
    }

    _paintBodyZones() {
      const host = this._subMeshSplitter.querySelector('#st-ms-body');
      if (!host) return;
      const self = this;
      host.querySelectorAll('[data-zone]').forEach(function (g) {
        const rect  = g.querySelector('rect');
        const label = g.querySelector('text');
        const cb    = self._boneCheckbox(self._zoneBone(g.dataset.zone));
        rect.classList.toggle('off', !cb);
        rect.classList.toggle('on', !!(cb && cb.checked));
        label.classList.toggle('on', !!(cb && cb.checked));
      });
    }

    _doSplitOp(mode) {
      const el = this._subMeshSplitter;
      const meshPath  = el.querySelector('#st-ms-path').value.trim();
      const outPath   = el.querySelector('#st-ms-outpath').value.trim();
      const names     = el.querySelector('#st-ms-names').value.trim();
      const selected  = Array.from(el.querySelectorAll('[data-bone]:checked')).map(function (cb) { return cb.value; });

      const payload = { mesh_path: meshPath, selected_bones: selected, output_path: outPath, names: names };

      if (mode === 'preview') {
        window.uecp.call('preview_split', payload);
      } else {
        window.uecp.call('execute_split', payload);
      }
    }

    _renderBones(meshPath, bones) {
      this._bones = bones || [];
      const el = this._subMeshSplitter;
      if (meshPath) el.querySelector('#st-ms-path').value = meshPath;

      const list = el.querySelector('#st-ms-bonelist');
      if (!this._bones.length) {
        list.innerHTML = '<div style="padding:14px;text-align:center;color:var(--ue-text-lo)">No bones found.</div>';
        return;
      }
      list.innerHTML = this._bones.map(function (b) {
        const name = typeof b === 'object' ? b.name : b;
        const checked = typeof b === 'object' && b.selected ? ' checked' : '';
        return '<div class="st-bone-row"><input type="checkbox" data-bone id="st-bone-' + esc(name) + '" value="' + esc(name) + '"' + checked + '><label for="st-bone-' + esc(name) + '">' + esc(name) + '</label></div>';
      }).join('');
      this._paintBodyZones();
    }

    _onBodyZones(zones) {
      this._zones = Array.isArray(zones) ? zones : [];
      this._paintBodyZones();
    }

    _renderSplitResult(json) {
      const el = this._subMeshSplitter.querySelector('#st-ms-result');
      if (!el) return;
      if (json && json.error) { el.textContent = 'Error: ' + json.error; return; }
      const parts = json && (json.partitions || json.parts);
      if (Array.isArray(parts)) {
        el.textContent = 'Partitions: ' + parts.map(function (p) {
          return (p && (p.name || p.asset_path)) || p;
        }).join(', ');
      } else if (json) {
        el.textContent = JSON.stringify(json, null, 2);
      }
    }

    _buildMeshMerger() {
      const el = document.createElement('div');
      el.className = 'st-sub';
      el.id = 'st-sub-mesh-merger';
      const self = this;
      el.innerHTML =
        '<div class="st-sub-title">' + svgIcon('ic-box', 14) + ' Mesh Merger</div>' +
        '<div class="st-sub-desc">Combine modular skeletal meshes that share a skeleton into one asset.</div>' +
        '<div class="st-field"><div class="st-label">Skeletal Meshes (one path per line)</div>' +
          '<textarea class="st-input" id="st-mm-paths" spellcheck="false" autocorrect="off" autocapitalize="off" rows="6" placeholder="/Game/Characters/SK_Head&#10;/Game/Characters/SK_Torso&#10;/Game/Characters/SK_Legs"></textarea>' +
          '<div class="st-row" style="margin-top:6px"><button class="st-btn" id="st-mm-browse">Add Meshes</button>' +
          '<button class="st-btn" id="st-mm-clear">Clear</button></div></div>' +
        '<div class="st-2col"><div class="st-field"><div class="st-label">Output Asset Path</div><input class="st-input" id="st-mm-outpath" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="/Game/Characters/SKM_Merged"></div>' +
        '<div class="st-field"><div class="st-label">Skeleton (optional — defaults to the first mesh\'s)</div><input class="st-input" id="st-mm-skeleton" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="/Game/Characters/SK_Mannequin"></div></div>' +
        '<div class="st-2col"><div class="st-field"><div class="st-label">Strip Top LODs</div><input class="st-input" id="st-mm-striplods" type="number" min="0" value="0"></div>' +
        '<div class="st-field"><div class="st-label">Options</div>' +
          '<div class="st-bone-row"><input type="checkbox" id="st-mm-morphs" checked><label for="st-mm-morphs">Merge morph targets</label></div>' +
          '<div class="st-bone-row"><input type="checkbox" id="st-mm-fullUVs"><label for="st-mm-fullUVs">Full precision UVs</label></div>' +
          '<div class="st-bone-row"><input type="checkbox" id="st-mm-cpu"><label for="st-mm-cpu">Needs CPU access</label></div>' +
          '<div class="st-bone-row"><input type="checkbox" id="st-mm-mismatch"><label for="st-mm-mismatch">Allow skeleton mismatch</label></div>' +
        '</div></div>' +
        '<div class="st-row"><button class="st-btn" id="st-mm-preview">Preview Merge</button><button class="st-btn st-btn-primary" id="st-mm-execute">Merge Meshes</button></div>' +
        '<div class="st-result" id="st-mm-result">Add at least two skeletal meshes that share a skeleton.</div>';

      el.prepend(this._backBtn('Back to Tools'));

      el.querySelector('#st-mm-browse').addEventListener('click', function () {
        window.uecp.call('browse_merge_meshes', {});
      });
      el.querySelector('#st-mm-clear').addEventListener('click', function () {
        el.querySelector('#st-mm-paths').value = '';
      });
      el.querySelector('#st-mm-preview').addEventListener('click', function () {
        window.uecp.call('preview_merge', self._mergePayload());
      });
      el.querySelector('#st-mm-execute').addEventListener('click', function () {
        window.uecp.call('execute_merge', self._mergePayload());
      });

      return el;
    }

    _mergePayload() {
      const el = this._subMeshMerger;
      const paths = el.querySelector('#st-mm-paths').value
        .split('\n').map(function (s) { return s.trim(); }).filter(Boolean);
      return {
        mesh_paths: paths,
        output_path: el.querySelector('#st-mm-outpath').value.trim(),
        skeleton_path: el.querySelector('#st-mm-skeleton').value.trim(),
        strip_top_lods: parseInt(el.querySelector('#st-mm-striplods').value, 10) || 0,
        needs_cpu_access: el.querySelector('#st-mm-cpu').checked,
        allow_skeleton_mismatch: el.querySelector('#st-mm-mismatch').checked,
        merge_morph_targets: el.querySelector('#st-mm-morphs').checked,
        full_precision_uvs: el.querySelector('#st-mm-fullUVs').checked
      };
    }

    _addMergeMeshes(paths) {
      if (!Array.isArray(paths) || !paths.length) return;
      const field = this._subMeshMerger.querySelector('#st-mm-paths');
      const existing = field.value.split('\n').map(function (s) { return s.trim(); }).filter(Boolean);
      paths.forEach(function (p) { if (existing.indexOf(p) === -1) existing.push(p); });
      field.value = existing.join('\n');
    }

    _renderMergeResult(json) {
      const el = this._subMeshMerger.querySelector('#st-mm-result');
      if (!el) return;
      if (json && json.error) { el.textContent = 'Error: ' + json.error; return; }
      if (!json) return;

      const lines = [];
      if (json.asset_path) lines.push('Merged asset:' + ' ' + json.asset_path);
      if (json.skeleton) lines.push('Skeleton:' + ' ' + json.skeleton);
      if (Array.isArray(json.meshes)) lines.push('Source meshes:' + ' ' + json.meshes.length);
      const morphs = json.morph_target_count !== undefined
        ? json.morph_target_count : json.source_morph_target_count;
      if (morphs !== undefined) lines.push('Morph targets:' + ' ' + morphs);

      const verts = json.merged_vertex_count !== undefined ? json.merged_vertex_count : json.vertex_count;
      const tris  = json.merged_triangle_count !== undefined ? json.merged_triangle_count : json.triangle_count;
      const lods  = json.merged_lod_count !== undefined ? json.merged_lod_count : json.lod_count;
      if (verts !== undefined) lines.push('Vertices:' + ' ' + verts);
      if (tris  !== undefined) lines.push('Triangles:' + ' ' + tris);
      if (lods  !== undefined) lines.push('LODs:' + ' ' + lods);
      if (json.section_count !== undefined) lines.push('Sections:' + ' ' + json.section_count);

      if (Array.isArray(json.warnings)) json.warnings.forEach(function (w) { lines.push('! ' + w); });
      if (json.note) lines.push(json.note);
      el.textContent = lines.length ? lines.join('\n') : JSON.stringify(json, null, 2);
    }

    _buildRetargetStudio() {
      const el = document.createElement('div');
      el.className = 'st-sub';
      el.id = 'st-sub-retarget';
      const self = this;
      el.innerHTML =
        '<div class="st-sub-title">' + svgIcon('ic-zap', 14) + ' Retarget Studio</div>' +
        '<div class="st-sub-desc">Move animations from one character to another when their skeletons differ.</div>' +
        '<div class="st-2col">' +
          '<div class="st-field"><div class="st-label">Source Mesh (animations come from)</div>' +
            '<div class="st-row"><input class="st-input" id="st-rt-source" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="/Game/.../SKM_Source" style="flex:1">' +
            '<button class="st-btn" id="st-rt-browse-source">Browse</button></div></div>' +
          '<div class="st-field"><div class="st-label">Target Mesh (animations go to)</div>' +
            '<div class="st-row"><input class="st-input" id="st-rt-target" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="/Game/.../SKM_Target" style="flex:1">' +
            '<button class="st-btn" id="st-rt-browse-target">Browse</button></div></div>' +
        '</div>' +
        '<div class="st-field"><div class="st-label">IK Retargeter</div>' +
          '<div class="st-row"><input class="st-input" id="st-rt-retargeter" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="/Game/.../RTG_Source_To_Target" style="flex:1">' +
          '<button class="st-btn" id="st-rt-browse-rtg">Browse</button>' +
          '<button class="st-btn" id="st-rt-inspect">Inspect</button>' +
          '<button class="st-btn" id="st-rt-align">Align Poses</button></div>' +
          '<div class="st-body-hint" id="st-rt-chains" style="text-align:left">Pick a retargeter and press Inspect to see how its chains map. Align Poses writes to the retargeter asset and saves it.</div></div>' +
        '<div class="st-field"><div class="st-label">Animations (one path per line)</div>' +
          '<textarea class="st-input" id="st-rt-anims" spellcheck="false" autocorrect="off" autocapitalize="off" rows="6" placeholder="/Game/Animations/Run&#10;/Game/Animations/Idle"></textarea>' +
          '<div class="st-row" style="margin-top:6px"><button class="st-btn" id="st-rt-browse-anims">Add Animations</button>' +
          '<button class="st-btn" id="st-rt-clear-anims">Clear</button></div></div>' +
        '<div class="st-2col"><div class="st-field"><div class="st-label">Output Folder</div><input class="st-input" id="st-rt-outpath" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="/Game/Animations/Retargeted"></div>' +
        '<div class="st-2col"><div class="st-field"><div class="st-label">Prefix</div><input class="st-input" id="st-rt-prefix" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="RT_"></div>' +
        '<div class="st-field"><div class="st-label">Suffix</div><input class="st-input" id="st-rt-suffix" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder=""></div></div></div>' +
        '<div class="st-row"><button class="st-btn st-btn-primary" id="st-rt-run">Retarget Animations</button></div>' +
        '<div class="st-result" id="st-rt-result">Pick a source mesh, a target mesh and a retargeter that links them.</div>';

      el.prepend(this._backBtn('Back to Tools'));

      const call = function (name, payload) { window.uecp.call(name, payload || {}); };
      el.querySelector('#st-rt-browse-source').addEventListener('click', function () { call('browse_retarget_asset', { kind: 'source_mesh' }); });
      el.querySelector('#st-rt-browse-target').addEventListener('click', function () { call('browse_retarget_asset', { kind: 'target_mesh' }); });
      el.querySelector('#st-rt-browse-rtg').addEventListener('click',    function () { call('browse_retarget_asset', { kind: 'retargeter' }); });
      el.querySelector('#st-rt-browse-anims').addEventListener('click',  function () { call('browse_retarget_asset', { kind: 'animations' }); });
      el.querySelector('#st-rt-clear-anims').addEventListener('click',   function () { el.querySelector('#st-rt-anims').value = ''; });
      el.querySelector('#st-rt-inspect').addEventListener('click', function () {
        call('inspect_retargeter', { retargeter_path: el.querySelector('#st-rt-retargeter').value.trim() });
      });
      el.querySelector('#st-rt-align').addEventListener('click', function () {
        call('align_retarget_poses', { retargeter_path: el.querySelector('#st-rt-retargeter').value.trim() });
      });
      el.querySelector('#st-rt-run').addEventListener('click', function () { self._runRetarget(); });

      return el;
    }

    _runRetarget() {
      const el = this._subRetarget;
      const anims = el.querySelector('#st-rt-anims').value
        .split('\n').map(function (s) { return s.trim(); }).filter(Boolean);
      window.uecp.call('run_retarget', {
        retargeter_path: el.querySelector('#st-rt-retargeter').value.trim(),
        source_mesh:     el.querySelector('#st-rt-source').value.trim(),
        target_mesh:     el.querySelector('#st-rt-target').value.trim(),
        animation_paths: anims,
        save_path:       el.querySelector('#st-rt-outpath').value.trim(),
        prefix:          el.querySelector('#st-rt-prefix').value.trim(),
        suffix:          el.querySelector('#st-rt-suffix').value.trim()
      });
    }

    _onRetargetPick(data) {
      if (!data || !Array.isArray(data.paths) || !data.paths.length) return;
      const el = this._subRetarget;
      if (data.kind === 'animations') {
        const field = el.querySelector('#st-rt-anims');
        const existing = field.value.split('\n').map(function (s) { return s.trim(); }).filter(Boolean);
        data.paths.forEach(function (p) { if (existing.indexOf(p) === -1) existing.push(p); });
        field.value = existing.join('\n');
        return;
      }
      const ids = { source_mesh: '#st-rt-source', target_mesh: '#st-rt-target', retargeter: '#st-rt-retargeter' };
      const target = ids[data.kind];
      if (target) el.querySelector(target).value = data.paths[0];
    }

    _onRetargetInfo(json) {
      const box = this._subRetarget.querySelector('#st-rt-chains');
      if (!box) return;
      if (!json || json.error) { box.textContent = 'Error: ' + ((json && json.error) || 'unknown'); return; }
      const chains = json.chain_mappings || [];
      const unmapped = chains.filter(function (c) { return !c.source_chain || c.source_chain === 'None'; });
      const lines = [(chains.length - unmapped.length) + ' of ' + chains.length + ' chains mapped'];
      if (json.source_pose) lines.push('Source pose:' + ' ' + json.source_pose);
      if (json.target_pose) lines.push('Target pose:' + ' ' + json.target_pose);
      if (unmapped.length) {
        lines.push('Unmapped:' + ' ' + unmapped.map(function (c) { return c.target_chain; }).join(', '));
      }
      box.textContent = lines.join('\n');
    }

    _onRetargetAlign(json) {
      const box = this._subRetarget.querySelector('#st-rt-result');
      if (!box) return;
      if (json && json.error) { box.textContent = 'Error: ' + json.error; return; }
      const sides = (json && json.sides) || [];
      const failed = sides.filter(function (s) { return s.result && s.result.error; });
      box.textContent = failed.length
        ? 'Align failed: ' + failed.map(function (s) { return s.side + ' - ' + s.result.error; }).join('; ')
        : 'Aligned both source and target rest poses, and saved the retargeter.';
    }

    _onRetargetResult(json) {
      const box = this._subRetarget.querySelector('#st-rt-result');
      if (!box) return;
      if (!json) return;
      if (json.error) { box.textContent = 'Error: ' + json.error; return; }
      const lines = ['Retargeted:' + ' ' + (json.created || 0) + ' / ' + (json.requested || 0)];
      (json.created_assets || []).forEach(function (p) { lines.push('  ' + p); });
      if ((json.skipped_inputs || []).length) {
        lines.push('Skipped:' + ' ' + json.skipped_inputs.join(', '));
      }
      box.textContent = lines.join('\n');
    }

    _normPath(p) {
      if (!p) return '';
      const dot = p.indexOf('.');
      return dot === -1 ? p : p.substring(0, dot);
    }

    _toast(msg, sev) {
      if (window.UECP && window.UECP.toast) window.UECP.toast(msg, sev || 'info');
    }

    _buildProfiler() {
      const el = document.createElement('div');
      el.className = 'st-sub';
      el.id = 'st-sub-profiler';
      el.innerHTML =
        '<div class="st-sub-title">' + svgIcon('ic-zap', 14) + ' Performance Profiler</div>' +
        '<div class="st-sub-desc">Profile CPU/GPU/frame time. Results are pushed to the AI in the Scanner view.</div>' +
        '<div class="st-field" style="max-width:200px"><div class="st-label">Duration</div>' +
          '<select class="st-input" id="st-prof-duration"><option value="5">5 seconds</option><option value="10" selected>10 seconds</option><option value="30">30 seconds</option><option value="60">60 seconds</option><option value="120">120 seconds</option></select></div>' +
        '<div class="st-row"><button class="st-btn st-btn-primary" id="st-prof-go">' + svgIcon('ic-zap', 13) + ' Start Profiling</button></div>' +
        '<div class="st-result" id="st-prof-result" style="display:none"></div>';

      el.prepend(this._backBtn('Back to Tools'));

      el.querySelector('#st-prof-go').addEventListener('click', function () {
        const dur = parseInt(el.querySelector('#st-prof-duration').value, 10) || 10;
        window.uecp.call('run_profiler', { durationSeconds: dur });
        const res = el.querySelector('#st-prof-result');
        res.style.display = '';
        res.textContent = 'Profiling...';
      });

      return el;
    }

    _onProfilerResult(json) {
      const res = this._subProfiler && this._subProfiler.querySelector('#st-prof-result');
      if (!res) return;
      res.style.display = '';
      res.textContent = typeof json === 'string'
        ? (window.UECP.prettyJson ? window.UECP.prettyJson(json) : json)
        : JSON.stringify(json, null, 2);
    }

    _onProfilerStatus(data) {
      const res = this._subProfiler && this._subProfiler.querySelector('#st-prof-result');
      if (!res) return;
      const state = (data && data.state) || (typeof data === 'string' ? data : '');
      if (state === 'running') { res.style.display = ''; res.textContent = 'Profiling...'; }
      else if (state === 'error') {
        res.style.display = ''; res.textContent = 'Profiler error: ' + ((data && data.error) || 'unknown');
      }
    }

    _showPage(page) {
      const subMap = {
        'mesh-splitter': this._subMeshSplitter,
        'mesh-merger':   this._subMeshMerger,
        'retarget':      this._subRetarget,
        'profiler':      this._subProfiler
      };
      if (page !== 'landing' && !subMap[page]) page = 'landing';

      this._page = page;
      const showLanding = page === 'landing';
      this._wrap.style.display = showLanding ? '' : 'none';
      Object.keys(subMap).forEach(function (k) {
        const sub = subMap[k];
        if (sub) sub.classList.toggle('active', !showLanding && k === page);
      });

    }

    _subscribe() {
      const self = this;
      this._subs = [
        window.uecp.on('tools.bonelist', function (data) {
          self._renderBones(data.meshPath, data.bones || data);
        }),
        window.uecp.on('tools.bodyzones', function (data) {
          self._onBodyZones(data && data.zones);
        }),
        window.uecp.on('tools.splitpreview', function (data) {
          self._renderSplitResult(data);
        }),
        window.uecp.on('tools.splitresult', function (data) {
          self._renderSplitResult(data);
        }),
        window.uecp.on('tools.retargetpick', function (data) {
          self._onRetargetPick(data);
        }),
        window.uecp.on('tools.retargetinfo', function (data) {
          self._onRetargetInfo(data);
        }),
        window.uecp.on('tools.retargetalign', function (data) {
          self._onRetargetAlign(data);
        }),
        window.uecp.on('tools.retargetresult', function (data) {
          self._onRetargetResult(data);
        }),
        window.uecp.on('tools.mergemeshes', function (data) {
          self._addMergeMeshes(data && data.mesh_paths);
        }),
        window.uecp.on('tools.mergepreview', function (data) {
          self._renderMergeResult(data);
        }),
        window.uecp.on('tools.mergeresult', function (data) {
          self._renderMergeResult(data);
        }),
        window.uecp.on('tools.profiler_result', function (data) {
          self._onProfilerResult(data);
        }),
        window.uecp.on('tools.profiler_status', function (data) {
          self._onProfilerStatus(data);
        }),
      ];
    }
  }

  customElements.define('uecp-screen-tools', UecpScreenTools);

  if (window.UECP && window.UECP.router) {
    window.UECP.router.register('tools', 'uecp-screen-tools');
  }
})();
