(function () {
  const routes = {};
  let outlet = null;
  let current = null;

  function register(route, tag) { routes[route] = tag; }
  function setOutlet(node) { outlet = node; }
  function active() { return current ? current.route : null; }

  function go(route) {
    if (!outlet) return;
    if (current && current.route === route) return;
    const tag = routes[route];
    if (!tag) { console.warn('[uecp] no route', route); return; }
    if (current) { outlet.removeChild(current.node); current = null; }
    let node;
    try { node = document.createElement(tag); outlet.appendChild(node); }
    catch (e) {
      console.error('[uecp] mount failed', route, e);
      node = document.createElement('div');
      node.setAttribute('data-contain', '');
      node.style.cssText = 'padding:32px;color:var(--ue-danger);font-family:var(--ue-font-mono)';
      node.textContent = 'Failed to open ' + route;
      outlet.appendChild(node);
    }
    current = { route, node };
  }

  window.uecp.on('screen.changed', function (p) { if (p && p.route) go(p.route); });

  function goSettings(sub, highlightId) {
    window.UECP = window.UECP || {};
    window.UECP._highlightSetting = highlightId || null;
    const screen = document.querySelector('uecp-screen-settings');
    if (active() === 'settings' && screen && screen._showPage) { screen._showPage(sub); return; }
    window.UECP._startupSub = sub;
    go('settings');
    window.uecp.call('switch_view', { view: 'settings' });
    window.uecp.__emit('screen.changed', { route: 'settings', title: 'Settings' });
  }

  window.UECP = window.UECP || {};
  window.UECP.router = { register, setOutlet, go, active, goSettings };
})();
