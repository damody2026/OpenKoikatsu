// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "UObject/ObjectMacros.h"
#include "UECPSteamTypes.generated.h"

USTRUCT(BlueprintType)
struct UECPSTEAMRUNTIME_API FUECPSteamID
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "UECP|Steam")
	int64 Value = 0;

	FUECPSteamID() = default;
	explicit FUECPSteamID(int64 InValue) : Value(InValue) {}

	bool IsValid() const { return Value != 0; }

	FString ToString() const { return LexToString(static_cast<uint64>(Value)); }

	bool operator==(const FUECPSteamID& Other) const { return Value == Other.Value; }
	bool operator!=(const FUECPSteamID& Other) const { return Value != Other.Value; }

	friend uint32 GetTypeHash(const FUECPSteamID& Id)
	{
		return ::GetTypeHash(Id.Value);
	}
};

UENUM(BlueprintType)
enum class EUECPSteamResult : uint8
{
	Success             UMETA(DisplayName = "Success"),
	SteamUnavailable    UMETA(DisplayName = "Steam Unavailable"),
	NotLoggedIn         UMETA(DisplayName = "Not Logged In"),
	NotFound            UMETA(DisplayName = "Not Found"),
	AccessDenied        UMETA(DisplayName = "Access Denied"),
	RateLimited         UMETA(DisplayName = "Rate Limited"),
	BackendFailure      UMETA(DisplayName = "Backend Failure"),
	InvalidParameter    UMETA(DisplayName = "Invalid Parameter"),
	InvalidState        UMETA(DisplayName = "Invalid State"),
	Timeout             UMETA(DisplayName = "Timeout"),
	Unknown             UMETA(DisplayName = "Unknown"),
};

USTRUCT(BlueprintType)
struct UECPSTEAMRUNTIME_API FUECPSteamError
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	EUECPSteamResult Result = EUECPSteamResult::Success;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	int32 RawResult = 0;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	FString Message;

	FUECPSteamError() = default;

	FUECPSteamError(EUECPSteamResult InResult, const FString& InMessage, int32 InRawResult = 0)
		: Result(InResult), RawResult(InRawResult), Message(InMessage) {}

	bool bSucceeded() const { return Result == EUECPSteamResult::Success; }

	static FUECPSteamError Unavailable()
	{
		return FUECPSteamError(EUECPSteamResult::SteamUnavailable,
			TEXT("Steam is not available. Check that the Steam client is running, that steam_appid.txt is present, and that [UECPSteam] bEnableSteamRuntime=True was set when this build was compiled."));
	}
};

UENUM(BlueprintType)
enum class EUECPSteamPersonaState : uint8
{
	Offline         UMETA(DisplayName = "Offline"),
	Online          UMETA(DisplayName = "Online"),
	Busy            UMETA(DisplayName = "Busy"),
	Away            UMETA(DisplayName = "Away"),
	Snooze          UMETA(DisplayName = "Snooze"),
	LookingToTrade  UMETA(DisplayName = "Looking To Trade"),
	LookingToPlay   UMETA(DisplayName = "Looking To Play"),
	Invisible       UMETA(DisplayName = "Invisible"),
};

UENUM(BlueprintType)
enum class EUECPSteamUniverse : uint8
{
	Invalid     UMETA(DisplayName = "Invalid"),
	Public      UMETA(DisplayName = "Public"),
	Beta        UMETA(DisplayName = "Beta"),
	Internal    UMETA(DisplayName = "Internal"),
	Dev         UMETA(DisplayName = "Dev"),
};
