// Copyright 2026, BlueprintsLab, All rights reserved
#include "Library/UECPSteamGameServerLibrary.h"

#include "UECPSteamAPI.h"

#if UECP_WITH_STEAM
namespace
{
	HAuthTicket GClientAuthTicket = k_HAuthTicketInvalid;

	EUECPSteamAuthResult FromNative(EBeginAuthSessionResult In)
	{
		switch (In)
		{
		case k_EBeginAuthSessionResultOK:                return EUECPSteamAuthResult::OK;
		case k_EBeginAuthSessionResultInvalidTicket:     return EUECPSteamAuthResult::InvalidTicket;
		case k_EBeginAuthSessionResultDuplicateRequest:  return EUECPSteamAuthResult::DuplicateRequest;
		case k_EBeginAuthSessionResultInvalidVersion:    return EUECPSteamAuthResult::InvalidTicket;
		case k_EBeginAuthSessionResultGameMismatch:      return EUECPSteamAuthResult::InvalidTicket;
		case k_EBeginAuthSessionResultExpiredTicket:     return EUECPSteamAuthResult::ExpiredTicket;
		default:                                         return EUECPSteamAuthResult::Unavailable;
		}
	}
}
#endif

bool UUECPSteamGameServerLibrary::IsGameServerAvailable()
{
#if UECP_WITH_STEAM
	return UECPSteam::IsServerAvailable() || UECPSteam::AcquireServer();
#else
	return false;
#endif
}

bool UUECPSteamGameServerLibrary::LogOnAnonymous()
{
#if UECP_WITH_STEAM
	if (IsGameServerAvailable())
	{
		if (ISteamGameServer* S = UECPSteam::GameServer())
		{
			S->LogOnAnonymous();
			return true;
		}
	}
#endif
	return false;
}

bool UUECPSteamGameServerLibrary::LogOn(const FString& Token)
{
#if UECP_WITH_STEAM
	if (IsGameServerAvailable() && !Token.IsEmpty())
	{
		if (ISteamGameServer* S = UECPSteam::GameServer())
		{
			S->LogOn(TCHAR_TO_UTF8(*Token));
			return true;
		}
	}
#endif
	return false;
}

void UUECPSteamGameServerLibrary::LogOff()
{
#if UECP_WITH_STEAM
	if (ISteamGameServer* S = UECPSteam::GameServer()) { S->LogOff(); }
#endif
}

bool UUECPSteamGameServerLibrary::IsLoggedOn()
{
#if UECP_WITH_STEAM
	if (ISteamGameServer* S = UECPSteam::GameServer()) { return S->BLoggedOn(); }
#endif
	return false;
}

bool UUECPSteamGameServerLibrary::IsSecure()
{
#if UECP_WITH_STEAM
	if (ISteamGameServer* S = UECPSteam::GameServer()) { return S->BSecure(); }
#endif
	return false;
}

FUECPSteamID UUECPSteamGameServerLibrary::GetGameServerSteamID()
{
#if UECP_WITH_STEAM
	if (ISteamGameServer* S = UECPSteam::GameServer())
	{
		return FUECPSteamID(UECPSteam::FromSteamID(S->GetSteamID()));
	}
#endif
	return FUECPSteamID();
}

void UUECPSteamGameServerLibrary::SetServerDetails(const FString& ServerName, const FString& MapName,
	int32 MaxPlayers, int32 BotCount, bool bPasswordProtected, const FString& GameTags)
{
#if UECP_WITH_STEAM
	ISteamGameServer* S = UECPSteam::GameServer();
	if (!S)
	{
		return;
	}

	S->SetServerName(TCHAR_TO_UTF8(*ServerName));
	S->SetMapName(TCHAR_TO_UTF8(*MapName));
	S->SetMaxPlayerCount(FMath::Max(0, MaxPlayers));
	S->SetBotPlayerCount(FMath::Max(0, BotCount));
	S->SetPasswordProtected(bPasswordProtected);

	if (!GameTags.IsEmpty())
	{
		S->SetGameTags(TCHAR_TO_UTF8(*GameTags));
	}
#endif
}

void UUECPSteamGameServerLibrary::SetAdvertiseServerActive(bool bActive)
{
#if UECP_WITH_STEAM
	if (ISteamGameServer* S = UECPSteam::GameServer()) { S->SetAdvertiseServerActive(bActive); }
#endif
}

EUECPSteamAuthResult UUECPSteamGameServerLibrary::BeginAuthSession(const FString& Ticket, FUECPSteamID ClientId)
{
#if UECP_WITH_STEAM
	ISteamGameServer* S = UECPSteam::GameServer();
	if (!S || Ticket.IsEmpty() || !ClientId.IsValid())
	{
		return EUECPSteamAuthResult::Unavailable;
	}

	TArray<uint8> Raw;
	Raw.SetNumUninitialized(Ticket.Len() / 2);
	const int32 Decoded = FString::ToHexBlob(Ticket, Raw.GetData(), Raw.Num()) ? Raw.Num() : 0;
	if (Decoded == 0)
	{
		return EUECPSteamAuthResult::InvalidTicket;
	}

	return FromNative(S->BeginAuthSession(Raw.GetData(), Decoded, UECPSteam::ToSteamID(ClientId.Value)));
#else
	return EUECPSteamAuthResult::Unavailable;
#endif
}

void UUECPSteamGameServerLibrary::EndAuthSession(FUECPSteamID ClientId)
{
#if UECP_WITH_STEAM
	if (ISteamGameServer* S = UECPSteam::GameServer())
	{
		if (ClientId.IsValid())
		{
			S->EndAuthSession(UECPSteam::ToSteamID(ClientId.Value));
		}
	}
#endif
}

bool UUECPSteamGameServerLibrary::UserHasLicenseForApp(FUECPSteamID ClientId)
{
#if UECP_WITH_STEAM
	ISteamGameServer* S = UECPSteam::GameServer();
	ISteamUtils* Utils = UECPSteam::Utils();
	if (S && Utils && ClientId.IsValid())
	{
		return S->UserHasLicenseForApp(UECPSteam::ToSteamID(ClientId.Value), Utils->GetAppID())
			== k_EUserHasLicenseResultHasLicense;
	}
#endif
	return false;
}

FString UUECPSteamGameServerLibrary::GetSteamAuthTicket()
{
#if UECP_WITH_STEAM
	ISteamUser* User = UECPSteam::User();
	if (!User)
	{
		return FString();
	}

	uint8 Buffer[1024] = {};
	uint32 Written = 0;

	GClientAuthTicket = User->GetAuthSessionTicket(Buffer, UE_ARRAY_COUNT(Buffer), &Written, nullptr);
	if (GClientAuthTicket == k_HAuthTicketInvalid || Written == 0)
	{
		return FString();
	}

	return FString::FromHexBlob(Buffer, Written);
#else
	return FString();
#endif
}

bool UUECPSteamGameServerLibrary::RequestUserStats(FUECPSteamID PlayerSteamId)
{
#if UECP_WITH_STEAM
	if (ISteamGameServerStats* S = UECPSteam::GameServerStats())
	{
		if (PlayerSteamId.IsValid())
		{
			return S->RequestUserStats(UECPSteam::ToSteamID(PlayerSteamId.Value)) != k_uAPICallInvalid;
		}
	}
#endif
	return false;
}

int32 UUECPSteamGameServerLibrary::GetUserStatInt(FUECPSteamID PlayerSteamId, const FString& StatApiName)
{
#if UECP_WITH_STEAM
	if (ISteamGameServerStats* S = UECPSteam::GameServerStats())
	{
		int32 Value = 0;
		if (PlayerSteamId.IsValid()
			&& S->GetUserStat(UECPSteam::ToSteamID(PlayerSteamId.Value), TCHAR_TO_UTF8(*StatApiName), &Value))
		{
			return Value;
		}
	}
#endif
	return 0;
}

float UUECPSteamGameServerLibrary::GetUserStatFloat(FUECPSteamID PlayerSteamId, const FString& StatApiName)
{
#if UECP_WITH_STEAM
	if (ISteamGameServerStats* S = UECPSteam::GameServerStats())
	{
		float Value = 0.f;
		if (PlayerSteamId.IsValid()
			&& S->GetUserStat(UECPSteam::ToSteamID(PlayerSteamId.Value), TCHAR_TO_UTF8(*StatApiName), &Value))
		{
			return Value;
		}
	}
#endif
	return 0.f;
}

bool UUECPSteamGameServerLibrary::SetUserStatInt(
	FUECPSteamID PlayerSteamId, const FString& StatApiName, int32 Value)
{
#if UECP_WITH_STEAM
	if (ISteamGameServerStats* S = UECPSteam::GameServerStats())
	{
		if (PlayerSteamId.IsValid())
		{
			return S->SetUserStat(UECPSteam::ToSteamID(PlayerSteamId.Value),
				TCHAR_TO_UTF8(*StatApiName), Value);
		}
	}
#endif
	return false;
}

bool UUECPSteamGameServerLibrary::SetUserStatFloat(
	FUECPSteamID PlayerSteamId, const FString& StatApiName, float Value)
{
#if UECP_WITH_STEAM
	if (ISteamGameServerStats* S = UECPSteam::GameServerStats())
	{
		if (PlayerSteamId.IsValid())
		{
			return S->SetUserStat(UECPSteam::ToSteamID(PlayerSteamId.Value),
				TCHAR_TO_UTF8(*StatApiName), Value);
		}
	}
#endif
	return false;
}

bool UUECPSteamGameServerLibrary::SetUserAchievement(
	FUECPSteamID PlayerSteamId, const FString& AchievementApiName)
{
#if UECP_WITH_STEAM
	if (ISteamGameServerStats* S = UECPSteam::GameServerStats())
	{
		if (PlayerSteamId.IsValid())
		{
			return S->SetUserAchievement(UECPSteam::ToSteamID(PlayerSteamId.Value),
				TCHAR_TO_UTF8(*AchievementApiName));
		}
	}
#endif
	return false;
}

bool UUECPSteamGameServerLibrary::StoreUserStats(FUECPSteamID PlayerSteamId)
{
#if UECP_WITH_STEAM
	if (ISteamGameServerStats* S = UECPSteam::GameServerStats())
	{
		if (PlayerSteamId.IsValid())
		{
			return S->StoreUserStats(UECPSteam::ToSteamID(PlayerSteamId.Value)) != k_uAPICallInvalid;
		}
	}
#endif
	return false;
}

void UUECPSteamGameServerLibrary::CancelSteamAuthTicket()
{
#if UECP_WITH_STEAM
	if (ISteamUser* User = UECPSteam::User())
	{
		if (GClientAuthTicket != k_HAuthTicketInvalid)
		{
			User->CancelAuthTicket(GClientAuthTicket);
			GClientAuthTicket = k_HAuthTicketInvalid;
		}
	}
#endif
}
