(function () {
  if (window.__uecpCefSelect) return;
  window.__uecpCefSelect = true;

  function optText(sel) { var o = sel.options[sel.selectedIndex]; return o ? o.textContent : ''; }

  var openWrap = null;
  function closeOpen() { if (openWrap) { var p = openWrap.querySelector('.uecp-csel-panel'); if (p) p.style.display = 'none'; openWrap.classList.remove('open'); openWrap = null; } }

  function roomBelow(el) {
    var bottom = window.innerHeight || 0;
    for (var p = el.parentElement; p && p !== document.body && p !== document.documentElement; p = p.parentElement) {
      var cs = window.getComputedStyle ? window.getComputedStyle(p) : null;
      if (cs && /auto|scroll|hidden|clip/.test(String(cs.overflowY || '') + ' ' + String(cs.overflow || ''))) {
        bottom = Math.min(bottom, p.getBoundingClientRect().bottom);
      }
    }
    return bottom - el.getBoundingClientRect().bottom;
  }

  function fitPanel(wrap, panel) {
    var room = roomBelow(wrap) - 12;
    panel.style.maxHeight = (room > 260 ? room : 260) + 'px';
    var cur = panel.querySelector('.uecp-csel-opt.sel');
    if (cur && panel.scrollHeight > panel.clientHeight) {
      panel.scrollTop = Math.max(0, cur.offsetTop - (panel.clientHeight - cur.offsetHeight) / 2);
    }
  }

  function tame(sel) {
    if (sel.__tamed) return;
    sel.__tamed = true;
    sel.style.display = 'none';

    var parent = sel.parentNode;
    var inField = parent && parent.classList && parent.classList.contains('input');

    if (inField) parent.style.padding = '0';

    var wrap = document.createElement('div');
    wrap.className = 'uecp-csel' + (inField ? ' uecp-csel-bare' : '');
    var btn = document.createElement('button'); btn.type = 'button'; btn.className = 'uecp-csel-btn';
    var label = document.createElement('span'); label.className = 'uecp-csel-label';
    btn.appendChild(label);
    if (!inField) {
      var caret = document.createElement('span'); caret.className = 'uecp-csel-caret';
      caret.innerHTML = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>';
      btn.appendChild(caret);
    }
    var panel = document.createElement('div'); panel.className = 'uecp-csel-panel'; panel.style.display = 'none';
    wrap.appendChild(btn); wrap.appendChild(panel);
    if (sel.parentNode) sel.parentNode.insertBefore(wrap, sel.nextSibling);

    function sync() { label.textContent = optText(sel); }
    sel.__cselSync = sync; sync();

    function build() {
      panel.innerHTML = '';
      for (var i = 0; i < sel.options.length; i++) {
        (function (opt, idx) {
          var row = document.createElement('div');
          row.className = 'uecp-csel-opt' + (idx === sel.selectedIndex ? ' sel' : '');
          row.textContent = opt.textContent;
          row.addEventListener('click', function (e) {
            e.stopPropagation();
            sel.selectedIndex = idx; sync(); closeOpen();
            sel.dispatchEvent(new Event('change', { bubbles: true }));
          });
          panel.appendChild(row);
        })(sel.options[i], i);
      }
    }
    btn.addEventListener('click', function (e) {
      e.stopPropagation();
      if (sel.disabled) return;
      var isOpen = panel.style.display === 'block';
      closeOpen();
      if (!isOpen) { build(); panel.style.display = 'block'; wrap.classList.add('open'); openWrap = wrap; fitPanel(wrap, panel); }
    });
  }

  function scan(root) {
    if (!root || root.nodeType !== 1) return;
    if (root.tagName === 'SELECT') { tame(root); return; }
    if (root.querySelectorAll) { var s = root.querySelectorAll('select'); for (var i = 0; i < s.length; i++) tame(s[i]); }
  }

  var style = document.createElement('style');
  style.textContent =
    '.uecp-csel{position:relative;display:inline-block;width:100%}' +
    '.uecp-csel-btn{width:100%;box-sizing:border-box;min-height:38px;display:flex;align-items:center;justify-content:space-between;gap:8px;background:var(--ue-bg,#14110d);border:1px solid var(--ue-line,#2a2620);color:var(--ue-text-hi,#ece6dc);border-radius:var(--ue-r,8px);padding:0 12px;font-family:var(--ue-font-sans);font-size:13px;cursor:pointer;text-align:left;transition:border-color var(--ue-dur,.16s)}' +
    '.uecp-csel-btn:hover{border-color:var(--ue-text-lo,#615a4f)}' +
    '.uecp-csel.open .uecp-csel-btn{border-color:var(--ue-accent,#e0a458)}' +
    '.uecp-csel-label{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;flex:1}' +
    '.uecp-csel-caret{display:flex;align-items:center;color:var(--ue-text-lo,#615a4f);flex-shrink:0}' +
    '.uecp-csel-caret svg{display:block;stroke:var(--ue-text-lo,#615a4f)}' +
    '.uecp-csel-bare{flex:1;min-width:0}' +
    '.uecp-csel-bare .uecp-csel-btn{background:transparent;border:none;border-radius:0;padding:9px 12px;font-size:13px}' +
    '.uecp-csel-bare .uecp-csel-btn:hover{border:none}' +
    '.uecp-csel-bare.open .uecp-csel-btn{border:none}' +
    '.uecp-csel-bare + .chev{margin-right:12px}' +
    '.uecp-csel-panel{position:absolute;top:calc(100% + 4px);left:0;right:0;background:var(--ue-panel,#191714);border:1px solid var(--ue-line,#2a2620);border-radius:var(--ue-r,8px);box-shadow:var(--ue-shadow-pop,0 12px 34px rgba(0,0,0,.45));z-index:9000;max-height:260px;overflow-y:auto;padding:4px}' +
    '.uecp-csel-opt{padding:7px 10px;border-radius:var(--ue-r-sm,6px);font-family:var(--ue-font-sans);font-size:var(--ue-fs-sm,12.5px);color:var(--ue-text-hi,#ece6dc);cursor:pointer;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}' +
    '.uecp-csel-opt:hover{background:var(--ue-accent-soft,rgba(224,164,88,.14))}' +
    '.uecp-csel-opt.sel{color:var(--ue-accent-bright,#f0bd7a)}';
  (document.head || document.documentElement).appendChild(style);

  var mo = new MutationObserver(function (muts) {
    for (var i = 0; i < muts.length; i++) {
      var ad = muts[i].addedNodes;
      for (var j = 0; j < ad.length; j++) scan(ad[j]);
    }
  });
  function start() {
    scan(document.body || document.documentElement);
    mo.observe(document.documentElement, { childList: true, subtree: true });
    document.addEventListener('click', closeOpen);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
