(function () {
  function relTime(iso) {
    if (!iso) return '';
    var t = Date.parse(iso);
    if (isNaN(t)) return '';
    var secs = Math.floor((Date.now() - t) / 1000);
    if (secs < 0) secs = 0;
    if (secs < 60)    return 'just now';
    var mins = Math.floor(secs / 60);
    if (mins < 60)    return mins + 'm ago';
    var hrs = Math.floor(mins / 60);
    if (hrs < 24)     return hrs + 'h ago';
    var days = Math.floor(hrs / 24);
    return days + 'd ago';
  }
  function chatMeta(item) {
    var parts = [];
    var n = (item && typeof item.msgCount === 'number') ? item.msgCount : null;
    if (n != null && n > 0) parts.push(n + ' msg' + (n === 1 ? '' : 's'));
    var rt = relTime(item && item.updatedAt);
    if (rt) parts.push(rt);
    return parts.join(' · ');
  }
  function planMarker(item) {
    var n = (item && typeof item.taskCount === 'number') ? item.taskCount : 0;
    var hasPlan = !!(item && item.hasPlan);
    if (!hasPlan && n <= 0) return { show: false, count: 0, label: '' };
    var parts = [];
    if (hasPlan) parts.push('Has a plan');
    if (n > 0)   parts.push(n + ' task' + (n === 1 ? '' : 's'));
    return { show: true, count: n, label: parts.join(' · ') };
  }
  function groupSubagents(list) {
    var items = Array.isArray(list) ? list : [];
    var tops = [];
    var byId = {};
    items.forEach(function (it) {
      if (it && !it.subagent) { it.children = []; tops.push(it); byId[it.id] = it; }
    });
    items.forEach(function (it) {
      if (!it || !it.subagent) return;
      var parent = it.parentChatId != null ? byId[it.parentChatId] : null;
      if (parent) { parent.children.push(it); }
      else { it.orphan = true; tops.push(it); }
    });
    return tops;
  }
  function splitSections(tops) {
    var items = Array.isArray(tops) ? tops : [];
    var pinned = [], recent = [], archived = [];
    items.forEach(function (item) {
      if (!item) return;
      if (item.archived) { archived.push(item); }
      else if (item.pinned) { pinned.push(item); }
      else { recent.push(item); }
    });
    return { pinned: pinned, recent: recent, archived: archived };
  }
  function canContextMenu(item) {
    return !(item && item.subagent === true);
  }
  function runBadgeSummary(children) {
    var kids = Array.isArray(children) ? children : [];
    var running = 0, failed = 0;
    kids.forEach(function (k) {
      var s = (k && k.subagentStatus || '').toLowerCase();
      if (s === 'running') { running++; }
      else if (s === 'failed' || s === 'error' || s === 'cancelled') { failed++; }
    });
    var parts = [];
    if (running) { parts.push(running + ' running'); }
    if (failed) { parts.push(failed + ' failed'); }
    return { running: running, failed: failed, text: parts.join(' · ') };
  }
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { relTime: relTime, chatMeta: chatMeta, planMarker: planMarker,
      groupSubagents: groupSubagents, canContextMenu: canContextMenu,
      runBadgeSummary: runBadgeSummary, splitSections: splitSections };
  }

  if (typeof document === 'undefined') return;
  if (!document.getElementById('uecp-chat-list-css')) {
    const s = document.createElement('style'); s.id = 'uecp-chat-list-css';
    s.textContent = `
uecp-chat-list{width:var(--ue-sidebar-w,220px);flex-shrink:0;background:var(--ue-panel);border-right:1px solid var(--ue-line-soft);display:flex;flex-direction:column;min-height:0}
/* Collapsed = a clean narrow rail: only the collapse toggle remains, everything else
   is hidden. Width comfortably fits the 34px toggle + the head's side padding. */
uecp-chat-list.collapsed{width:46px;min-width:46px}
uecp-chat-list.collapsed .btn-new,uecp-chat-list.collapsed .btn-icon,uecp-chat-list.collapsed .list-label,uecp-chat-list.collapsed .list{display:none}
uecp-chat-list.collapsed .sidebar-head{padding:9px 0;justify-content:center}
/* Alone in the rail, give the toggle an explicit height (no sibling stretches the row). */
uecp-chat-list.collapsed .btn-collapse{height:32px}
uecp-chat-list .sidebar-head{padding:12px;display:flex;gap:7px;border-bottom:1px solid var(--ue-line-soft);flex-shrink:0}
/* Match forge .btn-icon (34px wide, stretches to the row height) so the toggle lines up
   with New Chat / Clear-all instead of being a smaller fixed 30px square. */
uecp-chat-list .btn-collapse{width:34px;flex-shrink:0;display:flex;align-items:center;justify-content:center;background:transparent;border:1px solid var(--ue-line);color:var(--ue-text-mid);border-radius:var(--ue-r);cursor:pointer}
uecp-chat-list.collapsed .btn-collapse svg{transform:rotate(180deg)}
uecp-chat-list .btn-new{flex:1;display:flex;align-items:center;justify-content:center;gap:6px;background:var(--ue-accent-soft);border:1px solid var(--ue-accent);color:var(--ue-accent-bright);font-size:12.5px;font-weight:var(--ue-fw-semi);padding:8px;border-radius:var(--ue-r);cursor:pointer}
uecp-chat-list .btn-icon{width:34px;display:flex;align-items:center;justify-content:center;background:transparent;border:1px solid var(--ue-line);color:var(--ue-text-mid);border-radius:var(--ue-r);cursor:pointer}
uecp-chat-list .list-label{padding:12px 12px 4px;font-family:var(--ue-font-mono);font-size:10px;font-weight:var(--ue-fw-semi);letter-spacing:.13em;color:var(--ue-text-lo);flex-shrink:0}
uecp-chat-list .list{padding:6px 8px;display:flex;flex-direction:column;gap:2px;overflow-y:auto;flex:1}
uecp-chat-list .chat-item{position:relative;padding:9px 11px;border-radius:var(--ue-r);cursor:pointer}
uecp-chat-list .chat-item:hover{background:var(--ue-elev)}
uecp-chat-list .chat-item.active{background:var(--ue-elev)}
uecp-chat-list .chat-item.active::before{content:"";position:absolute;left:0;top:9px;bottom:9px;width:2.5px;border-radius:2px;background:var(--ue-accent)}
uecp-chat-list .chat-item-title{font-size:12.5px;color:var(--ue-text-mid);margin-bottom:3px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:flex;align-items:center;gap:6px}
uecp-chat-list .chat-item.active .chat-item-title{color:var(--ue-text-hi);font-weight:var(--ue-fw-medium)}
uecp-chat-list .chat-item-title .title-text{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
/* Per-row "thinking" dot — colour-only (motion-minimal), no pulse animation. */
uecp-chat-list .chat-item-think{width:6px;height:6px;border-radius:50%;background:var(--ue-accent);flex-shrink:0}
/* Per-row "needs attention" dot — a destructive-op confirmation is pending for
   this chat but it isn't the currently-viewed one (uecp-confirm-bar only shows
   the active chat's card; this is how a non-active chat surfaces the same fact). */
uecp-chat-list .chat-item-confirm{width:7px;height:7px;border-radius:50%;background:var(--ue-danger,#e06060);flex-shrink:0}
/* Per-row "needs attention" dot for a pending ask_user question — same idea as
   chat-item-confirm but info-colored so the two are visually distinguishable
   (a decision to confirm vs. a question to answer). */
uecp-chat-list .chat-item-question{width:7px;height:7px;border-radius:50%;background:var(--ue-accent);flex-shrink:0}
/* Per-row plan/tasks marker — a small clipboard glyph shown when the chat has an
   active plan brief or AI-maintained tasks (hasPlan / taskCount from C++ chat.list). */
uecp-chat-list .chat-item-plan{display:inline-flex;align-items:center;color:var(--ue-text-lo);flex-shrink:0}
uecp-chat-list .chat-item.active .chat-item-plan{color:var(--ue-accent-bright)}
uecp-chat-list .chat-item-plan svg{display:block}
/* Crew marker: only shown when a checkpoint is running or escalated (see
   _onCrewList) -- deliberately NOT shown for idle/fully-passed plans, so it
   reads as "look at this" rather than decoration. Distinct 'running' class name
   (not 'active') so it can never collide with .chat-item.active's own styling. */
uecp-chat-list .chat-item-crew{display:inline-flex;align-items:center;color:var(--ue-text-lo);flex-shrink:0}
uecp-chat-list .chat-item-crew.running{color:var(--ue-accent-bright)}
uecp-chat-list .chat-item-crew.escalated{color:var(--ue-warn,#d9a441)}
uecp-chat-list .chat-item-crew svg{display:block}
uecp-chat-list .chat-item-meta{font-family:var(--ue-font-mono);font-size:10.5px;font-weight:500;color:var(--ue-text-lo)}
/* Disclosure toggle on a parent row that has subagent children. Rotates when the
   parent is collapsed; click stops propagation so it doesn't also open the chat. */
uecp-chat-list .chat-item-disclose{display:inline-flex;align-items:center;justify-content:center;width:14px;height:14px;flex-shrink:0;color:var(--ue-text-lo);cursor:pointer}
uecp-chat-list .chat-item-disclose svg{display:block;transition:transform .12s}
uecp-chat-list .chat-item.collapsed .chat-item-disclose svg{transform:rotate(-90deg)}
/* Subagent child rows: indented under their parent, hidden when the parent row is
   collapsed. A small role+status chip rides on the title line. */
uecp-chat-list .chat-item.subagent-child{margin-left:14px}
uecp-chat-list .chat-item.subagent-child.hidden{display:none}
/* Failed/Succeeded status-group dropdowns under a parent's subagent children --
   collapsed by default so a long-lived, never-auto-pruned Crew run history doesn't
   turn into one huge flat list. Running/NeedsInput children stay flat above these
   (see appendRow) since they're the ones worth seeing without an extra click. */
uecp-chat-list .chat-subgroup-hd{display:flex;align-items:center;gap:5px;margin-left:14px;padding:5px 11px;font-family:var(--ue-font-mono);font-size:10px;font-weight:var(--ue-fw-semi);letter-spacing:.08em;text-transform:uppercase;color:var(--ue-text-lo);cursor:pointer;border-radius:var(--ue-r-sm)}
uecp-chat-list .chat-subgroup-hd:hover{background:var(--ue-elev)}
uecp-chat-list .chat-subgroup-hd.hidden{display:none}
uecp-chat-list .chat-subgroup-disclose{display:inline-flex;flex-shrink:0}
uecp-chat-list .chat-subgroup-disclose svg{display:block;transition:transform .12s}
uecp-chat-list .chat-subgroup-disclose.collapsed svg{transform:rotate(-90deg)}
uecp-chat-list .chat-sub-chip{font-family:var(--ue-font-mono);font-size:9.5px;font-weight:var(--ue-fw-semi);letter-spacing:.04em;padding:1px 5px;border-radius:8px;background:var(--ue-elev);border:1px solid var(--ue-line-soft);color:var(--ue-text-lo);flex-shrink:0;white-space:nowrap}
uecp-chat-list .chat-sub-chip.running{color:var(--ue-accent-bright);border-color:var(--ue-accent)}
uecp-chat-list .chat-sub-chip.failed{color:var(--ue-err,#cf6b5a);border-color:var(--ue-err,#cf6b5a)}
/* Parent run-state badge — count of running/failed subagent runs, visible while the
   parent is collapsed (rides on the title line like the chip). */
uecp-chat-list .chat-run-badge{font-size:9px;padding:0 6px;border-radius:8px;background:#3a4350;color:#cdd2d8;margin-left:6px}
uecp-chat-list .chat-run-badge.has-failed{background:#5a2f2e;color:#f0a8a5}
/* Per-run dismiss/cancel ✕ on a child row (pushed to the row's right edge). */
uecp-chat-list .chat-run-x{margin-left:auto;color:#6b7280;cursor:pointer;padding:0 4px}
uecp-chat-list .chat-run-x:hover{color:#e0625e}
/* Pinned marker on a row title. Muted by default so a sidebar of pinned chats does not
   turn into a wall of accent colour; the section header is what actually announces them. */
uecp-chat-list .chat-item-pinned{display:inline-flex;align-items:center;color:var(--ue-text-lo);flex-shrink:0}
uecp-chat-list .chat-item.active .chat-item-pinned{color:var(--ue-accent-bright)}
/* Chat row context menu — lives on <body> (not inside uecp-chat-list) so it isn't
   clipped; selectors must therefore be GLOBAL, not scoped to uecp-chat-list, or the
   display:none never applies and the menu renders unstyled at the bottom of the page. */
.chat-ctx-menu{position:fixed;background:var(--ue-panel);border:1px solid var(--ue-line);border-radius:var(--ue-r-md);min-width:140px;z-index:500;box-shadow:0 4px 12px rgba(0,0,0,.3);overflow:hidden;display:none}
.chat-ctx-menu.open{display:block}
.chat-ctx-menu .ctx-item{padding:8px 14px;font-family:var(--ue-font-mono);font-size:12px;cursor:pointer;color:var(--ue-text-hi)}
.chat-ctx-menu .ctx-item:hover{background:var(--ue-accent-soft);color:var(--ue-accent-bright)}
.chat-ctx-menu .ctx-item.danger{color:var(--ue-err,#cf6b5a)}
.chat-ctx-menu .ctx-item.danger:hover{background:rgba(207,107,90,.1)}`;
    document.head.appendChild(s);
  }

  class UecpChatList extends HTMLElement {
    connectedCallback() {
      this._data = [];
      this._active = null;
      this._ctxChatId = null;
      this._ctxChatName = '';
      this._ctxPinned = false;
      this._crewByConv = {};
      this._build();
      const self = this;
      this._unsub = window.uecp.on('chat.list', function (data) { self._onList(data); });
      this._unsubConfirm = window.UECP.confirmRegistry.onChange(function () { self._syncConfirmBadges(); });
      this._unsubAsk = window.UECP.askRegistry.onChange(function () { self._syncConfirmBadges(); });
      this._unsubCrewList = window.uecp.on('crew.planList', function (data) { self._onCrewList(data); });
      window.uecp.call('list_crew_plans', {});
    }

    disconnectedCallback() {
      if (this._unsub) { this._unsub(); this._unsub = null; }
      if (this._unsubConfirm) { this._unsubConfirm(); this._unsubConfirm = null; }
      if (this._unsubAsk) { this._unsubAsk(); this._unsubAsk = null; }
      if (this._unsubCrewList) { this._unsubCrewList(); this._unsubCrewList = null; }
      if (this._unBp) { this._unBp(); this._unBp = null; }
      if (this._ctxDocClick) { document.removeEventListener('click', this._ctxDocClick); this._ctxDocClick = null; }
      var menu = document.getElementById('uecp-chat-ctx-menu');
      if (menu && menu.parentNode) menu.parentNode.removeChild(menu);
    }

    _onCrewList(data) {
      const plans = (data && data.plans) || [];
      const byConv = {};
      plans.forEach(function (p) {
        if (!p || !p.convId) return;
        const active = (p.activeCheckpoints || []).length > 0;
        const escalated = (p.escalatedCheckpoints || []).length > 0;
        if (!active && !escalated) return;
        byConv[p.convId] = { active: active, escalated: escalated, paused: !!p.paused };
      });
      this._crewByConv = byConv;
      this._syncCrewBadges();
    }

    _build() {
      this.innerHTML =
        '<div class="sidebar-head">' +
          '<button class="btn-collapse" title="Collapse/expand sidebar" data-tip="Collapse/expand sidebar">' +
            '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><line x1="9" y1="3" x2="9" y2="21"/></svg>' +
          '</button>' +
          '<button class="btn-new">' + window.UECP.icon('ic-plus', 14) + 'New Chat</button>' +
          '<button class="btn-icon" title="Clear all chats" data-tip="Clear all chats">' + window.UECP.icon('ic-trash', 14) + '</button>' +
        '</div>' +
        '<div class="list"></div>';

      const self = this;
      function isNarrow() { return !!(window.UECP.bp && window.UECP.bp.isNarrow()); }
      this._syncCollapsed = function () {
        var want = isNarrow() || !!(window.UECP.sidebar && window.UECP.sidebar.isCollapsed());
        self.classList.toggle('collapsed', want);
      };
      this._syncCollapsed();
      if (window.UECP.bp) this._unBp = window.UECP.bp.onChange(this._syncCollapsed);
      this.querySelector('.btn-collapse').addEventListener('click', function () {
        var on = self.classList.toggle('collapsed');
        if (window.UECP.sidebar && !isNarrow()) window.UECP.sidebar.setCollapsed(on);
      });
      this.querySelector('.btn-new').addEventListener('click', function () {
        window.uecp.call('new_chat', {});
      });
      this.querySelector('.btn-icon').addEventListener('click', function () {
        var count = (self._data || []).length;
        if (!count) return;
        window.UECP.dialog.confirm('Clear all chats',
          'Clear all ' + count + ' conversation' + (count === 1 ? '' : 's') + '? This cannot be undone.'
          ).then(function (ok) {
            if (ok) window.uecp.call('delete_all_chats', {});
          });
      });

      if (!document.getElementById('uecp-chat-ctx-menu')) {
        var menu = document.createElement('div');
        menu.id = 'uecp-chat-ctx-menu';
        menu.className = 'chat-ctx-menu';
        menu.innerHTML =
          '<div class="ctx-item ctx-pin">Pin</div>' +
          '<div class="ctx-item ctx-rename">Rename</div>' +
          '<div class="ctx-item ctx-export-md">Export .md</div>' +
          '<div class="ctx-item ctx-export-txt">Export .txt</div>' +
          '<div class="ctx-item danger ctx-delete">Delete</div>';
        document.body.appendChild(menu);

        menu.querySelector('.ctx-rename').addEventListener('click', function () {
          var id = self._ctxChatId; var cur = self._ctxChatName; self._closeCtxMenu();
          if (id) {
            window.UECP.dialog.prompt('Rename Chat', 'Enter a new name:', cur || '').then(function (name) {
              if (name != null && name !== '') window.uecp.call('rename_chat', { chatId: id, name: name });
            });
          }
        });
        menu.querySelector('.ctx-pin').addEventListener('click', function () {
          var id = self._ctxChatId; var was = self._ctxPinned; self._closeCtxMenu();
          if (id) window.uecp.call('pin_chat', { chatId: id, pinned: !was });
        });
        menu.querySelector('.ctx-export-md').addEventListener('click', function () {
          var id = self._ctxChatId; self._closeCtxMenu();
          if (id) window.uecp.call('export', { format: 'md' });
        });
        menu.querySelector('.ctx-export-txt').addEventListener('click', function () {
          var id = self._ctxChatId; self._closeCtxMenu();
          if (id) window.uecp.call('export', { format: 'txt' });
        });
        menu.querySelector('.ctx-delete').addEventListener('click', function () {
          var id = self._ctxChatId; var nm = self._ctxChatName; self._closeCtxMenu();
          if (!id) return;
          window.UECP.dialog.confirm('Delete chat',
            'Delete "' + (nm || 'this conversation') + '"? This cannot be undone.'
            ).then(function (ok) {
              if (ok) window.uecp.call('delete_chat', { chatId: id });
            });
        });
        if (!this._ctxDocClick) {
          this._ctxDownInside = false;
          this._ctxDocDown = function (e) { self._ctxDownInside = menu.contains(e.target); };
          this._ctxDocClick = function (e) {
            var downInside = self._ctxDownInside; self._ctxDownInside = false;
            if (!downInside && !menu.contains(e.target)) self._closeCtxMenu();
          };
          document.addEventListener('mousedown', this._ctxDocDown);
          document.addEventListener('click', this._ctxDocClick);
        }
      }

      this._renderList();
    }

    _closeCtxMenu() {
      var menu = document.getElementById('uecp-chat-ctx-menu');
      if (menu) menu.classList.remove('open');
      this._ctxChatId = null;
      this._ctxPinned = false;
    }

    _openCtxMenu(chatId, x, y, chatName, item) {
      this._ctxChatId = chatId;
      this._ctxChatName = chatName || '';
      this._ctxPinned = !!(item && item.pinned);
      var menu = document.getElementById('uecp-chat-ctx-menu');
      if (!menu) return;
      var pinItem = menu.querySelector('.ctx-pin');
      if (pinItem) {
        pinItem.textContent = this._ctxPinned ? 'Unpin' : 'Pin';
        pinItem.style.display = (item && item.archived) ? 'none' : '';
      }
      var isActive = (chatId != null && chatId === this._active);
      menu.querySelectorAll('.ctx-export-md, .ctx-export-txt').forEach(function (el) {
        el.style.display = isActive ? '' : 'none';
      });
      var menuW = 150, menuH = 150;
      var left = Math.min(x, window.innerWidth  - menuW - 4);
      var top  = Math.min(y, window.innerHeight - menuH - 4);
      menu.style.left = left + 'px';
      menu.style.top  = top  + 'px';
      menu.classList.add('open');
    }

    _onList(data) {
      if (!data) return;
      if (Array.isArray(data)) {
        this._data = data;
        var act = data.find(function (it) { return it && it.active === true; });
        if (act) this._active = act.id;
      } else {
        this._data = data.chats || [];
        if (data.activeId != null) this._active = data.activeId;
      }
      this._renderList();
    }

    _renderList() {
      const list = this.querySelector('.list');
      if (!list) return;
      list.innerHTML = '';
      const self = this;
      const data = this._data || [];

      const tops = groupSubagents(data);
      const sections = splitSections(tops);
      const pinned = sections.pinned;
      const recent = sections.recent;
      const archived = sections.archived;

      if (!self._subCollapsed) self._subCollapsed = {};

      function rowInnerHtml(item, extraTitleLead, chipHtml) {
        const titleLabel = item.title || 'Untitled';
        const thinkDot = item.thinking ? '<span class="chat-item-think" title="Working..."></span>' : '';
        const pinMark = item.pinned
          ? '<span class="chat-item-pinned" data-tip="Pinned" aria-label="Pinned">' +
              '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="17" x2="12" y2="22"/><path d="M5 17h14v-1.76a2 2 0 0 0-1.11-1.79l-1.78-.9A2 2 0 0 1 15 10.76V6h1a2 2 0 0 0 0-4H8a2 2 0 0 0 0 4h1v4.76a2 2 0 0 1-1.11 1.79l-1.78.9A2 2 0 0 0 5 15.24Z"/></svg>' +
            '</span>'
          : '';
        const pm = planMarker(item);
        const planMark = pm.show
          ? '<span class="chat-item-plan" data-tip="' + window.UECP.escapeHtml(pm.label) + '" aria-label="' + window.UECP.escapeHtml(pm.label) + '">' +
              '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 5H7a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V7a2 2 0 0 0-2-2h-2"/><rect x="9" y="3" width="6" height="4" rx="1"/><path d="M9 12h6M9 16h4"/></svg>' +
            '</span>'
          : '';
        const meta = chatMeta(item);
        return '<div class="chat-item-title" data-i18n-skip>' + (extraTitleLead || '') + thinkDot +
            '<span class="title-text">' + window.UECP.escapeHtml(titleLabel) + '</span>' +
            (chipHtml || '') + pinMark + planMark +
          '</div>' +
          (meta ? '<div class="chat-item-meta">' + window.UECP.escapeHtml(meta) + '</div>' : '');
      }

      function wireRow(row, item) {
        const id = item.id;
        row.addEventListener('click', function () {
          if (id == null) return;
          self._active = id;
          self.dispatchEvent(new CustomEvent('chat-switch', { bubbles: true, detail: { chatId: id } }));
          window.uecp.call('switch_chat', { chatId: id });
          list.querySelectorAll('.chat-item').forEach(function (r) {
            r.classList.toggle('active', !!id && r.dataset.id === String(id));
          });
          if (window.UECP.bp && window.UECP.bp.isNarrow()) self.classList.add('collapsed');
        });
        if (canContextMenu(item)) {
          row.addEventListener('contextmenu', function (e) {
            e.preventDefault();
            if (id != null) self._openCtxMenu(id, e.clientX, e.clientY, item.title || '', item);
          });
        }
      }

      function appendRow(item) {
        const id = item.id;
        const isActive = (id != null && id === self._active);
        const kids = (item.children && item.children.length) ? item.children : [];
        const collapsed = !!self._subCollapsed[id];

        const row = document.createElement('div');
        row.className = 'chat-item' + (isActive ? ' active' : '') + (kids.length && collapsed ? ' collapsed' : '');
        row.dataset.id = id != null ? id : '';
        const disclose = kids.length
          ? '<span class="chat-item-disclose" title="Toggle subagent runs">' +
              '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>' +
            '</span>'
          : '';
        const badge = kids.length
          ? (function () {
              const sum = runBadgeSummary(kids);
              return sum.text
                ? '<span class="chat-run-badge' + (sum.failed ? ' has-failed' : '') + '">' + window.UECP.escapeHtml(sum.text) + '</span>'
                : '';
            })()
          : '';
        row.innerHTML = rowInnerHtml(item, disclose, badge);
        wireRow(row, item);
        if (kids.length) {
          const tog = row.querySelector('.chat-item-disclose');
          if (tog) tog.addEventListener('click', function (e) {
            e.stopPropagation();
            self._subCollapsed[id] = !self._subCollapsed[id];
            self._renderList();
          });
        }
        list.appendChild(row);

        function buildChildRow(kid, hiddenNow) {
          const krow = document.createElement('div');
          const kActive = (kid.id != null && kid.id === self._active);
          const status = (kid.subagentStatus || '').toLowerCase();
          const statusCls = (status === 'running') ? ' running'
            : (status === 'failed' || status === 'error' || status === 'cancelled') ? ' failed' : '';
          krow.className = 'chat-item subagent-child' + (kActive ? ' active' : '') + (hiddenNow ? ' hidden' : '');
          krow.dataset.id = kid.id != null ? kid.id : '';
          const chipText = [kid.subagentRole || 'subagent', kid.subagentStatus || ''].filter(Boolean).join(' · ');
          const chip = '<span class="chat-sub-chip' + statusCls + '">' + window.UECP.escapeHtml(chipText) + '</span>' +
            '<span class="chat-run-x" title="Dismiss / cancel run">&#10005;</span>';
          krow.innerHTML = rowInnerHtml(kid, '', chip);
          wireRow(krow, kid);
          const xb = krow.querySelector('.chat-run-x');
          if (xb) xb.addEventListener('click', function (e) {
            e.stopPropagation();
            window.uecp.call('dismiss_subagent_run', { chatId: kid.id });
          });
          return krow;
        }

        const activeKids = [], failedKids = [], succeededKids = [];
        kids.forEach(function (kid) {
          const status = (kid.subagentStatus || '').toLowerCase();
          if (status === 'succeeded') succeededKids.push(kid);
          else if (status === 'failed' || status === 'error' || status === 'cancelled') failedKids.push(kid);
          else activeKids.push(kid);
        });

        activeKids.forEach(function (kid) { list.appendChild(buildChildRow(kid, collapsed)); });

        if (!self._subGroupCollapsed) self._subGroupCollapsed = {};
        function appendGroup(bucket, key, label) {
          if (!bucket.length) return;
          const groupKey = id + ':' + key;
          if (!(groupKey in self._subGroupCollapsed)) self._subGroupCollapsed[groupKey] = true;
          const groupCollapsed = self._subGroupCollapsed[groupKey];
          const hdRow = document.createElement('div');
          hdRow.className = 'chat-subgroup-hd' + (collapsed ? ' hidden' : '');
          hdRow.innerHTML =
            '<span class="chat-subgroup-disclose' + (groupCollapsed ? ' collapsed' : '') + '">' +
              '<svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>' +
            '</span><span>' + label + ' (' + bucket.length + ')</span>';
          hdRow.addEventListener('click', function (e) {
            e.stopPropagation();
            self._subGroupCollapsed[groupKey] = !self._subGroupCollapsed[groupKey];
            self._renderList();
          });
          list.appendChild(hdRow);
          bucket.forEach(function (kid) { list.appendChild(buildChildRow(kid, collapsed || groupCollapsed)); });
        }
        appendGroup(failedKids, 'failed', 'Failed');
        appendGroup(succeededKids, 'succeeded', 'Succeeded');
      }

      function appendLabel(text) {
        const lbl = document.createElement('div'); lbl.className = 'list-label'; lbl.textContent = text;
        list.appendChild(lbl);
      }

      if (pinned.length) { appendLabel('PINNED'); pinned.forEach(appendRow); }
      if (recent.length) { appendLabel('RECENT'); recent.forEach(appendRow); }
      if (archived.length) { appendLabel('ARCHIVED'); archived.forEach(appendRow); }

      if (!data.length) {
        const empty = document.createElement('div');
        empty.style.cssText = 'padding:16px 12px;font-family:var(--ue-font-mono);font-size:11px;color:var(--ue-text-lo)';
        empty.textContent = 'No chats yet';
        list.appendChild(empty);
      }

      this._syncConfirmBadges();
      this._syncCrewBadges();
    }

    _syncCrewBadges() {
      const list = this.querySelector('.list');
      if (!list) return;
      const self = this;
      list.querySelectorAll('.chat-item').forEach(function (row) {
        const id = row.dataset.id;
        const title = row.querySelector('.chat-item-title');
        if (!title) return;
        const existing = title.querySelector('.chat-item-crew');
        const c = id ? self._crewByConv[id] : null;
        if (!c) { if (existing) existing.remove(); return; }
        const cls = c.escalated ? 'escalated' : (c.active ? 'running' : '');
        const parts = [];
        if (c.escalated) parts.push('needs attention');
        if (c.active) parts.push('checkpoint running');
        if (c.paused) parts.push('paused');
        const label = 'Crew: ' + parts.join(' · ');
        if (existing) {
          existing.className = 'chat-item-crew' + (cls ? ' ' + cls : '');
          existing.setAttribute('data-tip', label);
          existing.setAttribute('aria-label', label);
        } else {
          const span = document.createElement('span');
          span.className = 'chat-item-crew' + (cls ? ' ' + cls : '');
          span.setAttribute('data-tip', label);
          span.setAttribute('aria-label', label);
          span.innerHTML = window.UECP.icon('ic-crew', 12);
          const planEl = title.querySelector('.chat-item-plan');
          if (planEl) title.insertBefore(span, planEl); else title.appendChild(span);
        }
      });
    }

    _syncConfirmBadges() {
      const list = this.querySelector('.list');
      if (!list) return;
      const self = this;
      list.querySelectorAll('.chat-item').forEach(function (row) {
        const id = row.dataset.id;
        const title = row.querySelector('.chat-item-title');
        if (!title) return;
        self._syncBadge(title, id, 'chat-item-confirm', window.UECP.confirmRegistry, 'Needs attention — a confirmation is pending');
        self._syncBadge(title, id, 'chat-item-question', window.UECP.askRegistry, 'Needs attention — a question is pending');
      });
    }

    _syncBadge(title, id, className, registry, tipText) {
      const existing = title.querySelector('.' + className);
      const needsBadge = !!id && registry.has(id);
      if (needsBadge && !existing) {
        const dot = document.createElement('span');
        dot.className = className;
        dot.title = tipText;
        title.appendChild(dot);
      } else if (!needsBadge && existing) {
        existing.remove();
      }
    }
  }
  customElements.define('uecp-chat-list', UecpChatList);
})();
