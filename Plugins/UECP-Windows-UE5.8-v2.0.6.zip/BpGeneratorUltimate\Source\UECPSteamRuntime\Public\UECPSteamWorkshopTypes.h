// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "UECPSteamTypes.h"
#include "UECPSteamWorkshopTypes.generated.h"

USTRUCT(BlueprintType)
struct UECPSTEAMRUNTIME_API FUECPSteamWorkshopItemId
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "UECP|Steam")
	int64 Value = 0;

	FUECPSteamWorkshopItemId() = default;
	explicit FUECPSteamWorkshopItemId(int64 InValue) : Value(InValue) {}

	bool IsValid() const { return Value != 0; }
	FString ToString() const { return LexToString(static_cast<uint64>(Value)); }

	bool operator==(const FUECPSteamWorkshopItemId& Other) const { return Value == Other.Value; }

	friend uint32 GetTypeHash(const FUECPSteamWorkshopItemId& Id) { return ::GetTypeHash(Id.Value); }
};

UENUM(BlueprintType)
enum class EUECPSteamWorkshopVisibility : uint8
{
	Public      UMETA(DisplayName = "Public"),
	FriendsOnly UMETA(DisplayName = "Friends Only"),
	Private     UMETA(DisplayName = "Private"),
	Unlisted    UMETA(DisplayName = "Unlisted (link only)"),
};

UENUM(BlueprintType)
enum class EUECPSteamWorkshopSort : uint8
{
	Vote            UMETA(DisplayName = "Ranked by Vote"),
	PublicationDate UMETA(DisplayName = "Newest First"),
	Trend           UMETA(DisplayName = "Trending"),
	TotalSubscriptions UMETA(DisplayName = "Most Subscribed"),
	TextSearch      UMETA(DisplayName = "Text Search Relevance"),
};

UENUM(BlueprintType)
enum class EUECPSteamWorkshopListType : uint8
{
	All         UMETA(DisplayName = "All Items"),
	Subscribed  UMETA(DisplayName = "Subscribed"),
	Published   UMETA(DisplayName = "Published By Me"),
	Favorited   UMETA(DisplayName = "Favourited"),
};

USTRUCT(BlueprintType)
struct UECPSTEAMRUNTIME_API FUECPSteamWorkshopItemState
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	bool bSubscribed = false;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	bool bInstalled = false;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	bool bNeedsUpdate = false;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	bool bDownloading = false;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	bool bDownloadPending = false;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	bool bReadyToUse = false;
};

USTRUCT(BlueprintType)
struct UECPSTEAMRUNTIME_API FUECPSteamWorkshopItem
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	FUECPSteamWorkshopItemId ItemId;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	FString Title;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	FString Description;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	FUECPSteamID Owner;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	TArray<FString> Tags;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	EUECPSteamWorkshopVisibility Visibility = EUECPSteamWorkshopVisibility::Public;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	int32 UpVotes = 0;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	int32 DownVotes = 0;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	float Score = 0.f;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	int64 FileSizeBytes = 0;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	FDateTime TimeCreated;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	FDateTime TimeUpdated;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	FString PreviewUrl;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	bool bBanned = false;
};

USTRUCT(BlueprintType)
struct UECPSTEAMRUNTIME_API FUECPSteamWorkshopSubmitInfo
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "UECP|Steam")
	FString Title;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "UECP|Steam")
	FString Description;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "UECP|Steam")
	FString ContentFolder;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "UECP|Steam")
	FString PreviewImageFile;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "UECP|Steam")
	TArray<FString> Tags;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "UECP|Steam")
	EUECPSteamWorkshopVisibility Visibility = EUECPSteamWorkshopVisibility::Private;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "UECP|Steam")
	FString Metadata;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "UECP|Steam")
	FString ChangeNote;
};
