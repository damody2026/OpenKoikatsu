(function () {
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  if (!document.getElementById('uecp-gdd-overlay-css')) {
    var s = document.createElement('style'); s.id = 'uecp-gdd-overlay-css';
    s.textContent = [
'uecp-gdd-overlay{position:fixed;inset:0;z-index:1200;display:none}',
'uecp-gdd-overlay.open{display:block}',
'uecp-gdd-overlay .overlay{position:absolute;inset:0;background:rgba(0,0,0,.5);display:flex;align-items:center;justify-content:center}',
'uecp-gdd-overlay .modal{position:relative;width:720px;height:600px;display:flex;flex-direction:column;overflow:hidden}',
'uecp-gdd-overlay .gdd-drop{position:absolute;inset:10px;z-index:5;display:none;flex-direction:column;align-items:center;justify-content:center;gap:8px;padding:24px;text-align:center;background:var(--ue-panel);border:2px dashed var(--ue-accent);border-radius:var(--ue-r-sm);pointer-events:none}',
'uecp-gdd-overlay .gdd-drop.on{display:flex}',
'uecp-gdd-overlay .gdd-drop.bad{border-color:var(--ue-danger)}',
'uecp-gdd-overlay .gdd-drop svg{color:var(--ue-accent)}',
'uecp-gdd-overlay .gdd-drop.bad svg{color:var(--ue-danger)}',
'uecp-gdd-overlay .gdd-drop-title{font-size:17px;font-weight:var(--ue-fw-semi);color:var(--ue-text-hi)}',
'uecp-gdd-overlay .gdd-drop-sub{font-size:12.5px;color:var(--ue-text-mid);max-width:440px}',
'uecp-gdd-overlay .gdd-drop-files{font-family:var(--ue-font-mono);font-size:11.5px;color:var(--ue-text-lo);max-width:90%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
'uecp-gdd-overlay .gdd-hint{font-size:11.5px;color:var(--ue-text-lo)}',
'uecp-gdd-overlay .gdd-tabs-row{padding:14px 20px 0}',
'uecp-gdd-overlay .gdd-toolbar{display:flex;gap:8px;align-items:center;padding:12px 20px 10px}',
'uecp-gdd-overlay .gdd-tbtn{background:var(--ue-elev);border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);color:var(--ue-text-hi);padding:5px 10px;cursor:pointer;font-size:12px;white-space:nowrap}',
'uecp-gdd-overlay .gdd-tbtn:hover{background:var(--ue-line-soft)}',
'uecp-gdd-overlay .gdd-scroll{flex:1;min-height:0;overflow-y:auto;padding:2px 20px 14px;display:flex;flex-direction:column;gap:8px}',
'uecp-gdd-overlay .gdd-card-meta{display:flex;align-items:center;gap:8px;margin-bottom:6px}',
'uecp-gdd-overlay .gdd-name{flex:1;font-size:13px;font-weight:var(--ue-fw-semi);color:var(--ue-text-hi);cursor:pointer;word-break:break-word}',
'uecp-gdd-overlay .gdd-tokens{font-family:var(--ue-font-mono);font-size:11px;color:var(--ue-text-lo)}',
'uecp-gdd-overlay .gdd-edit{width:100%;box-sizing:border-box;min-height:160px;background:var(--ue-bg);border:1px solid var(--ue-accent);border-radius:var(--ue-r-sm);color:var(--ue-text-hi);padding:8px;font-size:12.5px;font-family:var(--ue-font-mono);resize:vertical}',
'uecp-gdd-overlay .gdd-edit-bar{display:flex;gap:8px;margin-top:6px;justify-content:flex-end}',
'uecp-gdd-overlay .gdd-empty{padding:28px 14px;text-align:center;color:var(--ue-text-lo);font-size:12.5px}',
'uecp-gdd-overlay .gdd-icon-btn{background:transparent;width:26px;height:26px;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center}',
'uecp-gdd-overlay .gdd-outline-row{padding:6px 8px;border-radius:var(--ue-r-sm);display:flex;flex-direction:column;gap:2px}',
'uecp-gdd-overlay .gdd-outline-row:hover{background:var(--ue-elev)}',
'uecp-gdd-overlay .gdd-outline-heading{font-size:12.5px;color:var(--ue-text-hi);font-weight:var(--ue-fw-semi)}',
'uecp-gdd-overlay .gdd-outline-meta{font-family:var(--ue-font-mono);font-size:10.5px;color:var(--ue-text-lo)}',
'uecp-gdd-overlay .gdd-outline-preview{font-size:11.5px;color:var(--ue-text-mid);white-space:pre-wrap}'
    ].join('\n');
    document.head.appendChild(s);
  }

  function t(key, vars) {
    if (window.uecp && typeof window.uecp.t === 'function') return window.uecp.t(key, vars);
    return String(key).replace(/\{(\w+)\}/g, function (m, k) {
      return vars && (k in vars) ? String(vars[k]) : m;
    });
  }

  var DROP_REJECTED = 'Only .txt and .md files can be attached. Save other documents as text first.';

  function dropText(d) {
    var names = (d && Array.isArray(d.names)) ? d.names : [];
    var total = names.length;
    var ok = Math.max(0, Math.min(total, Math.floor(Number(d && d.accepted) || 0)));
    if (!ok) {
      return {
        title: total > 1 ? t('These files cannot be attached') : t('This file cannot be attached'),
        sub: t(DROP_REJECTED),
        bad: true
      };
    }
    return {
      title: ok < total ? t('Attach {n} of {total} documents', { n: ok, total: total })
           : total === 1 ? t('Attach the document')
           : t('Attach {n} documents', { n: total }),
      sub: ok < total ? t(DROP_REJECTED) : t('Text and Markdown files (.txt, .md)'),
      bad: false
    };
  }

  function dropNames(names) {
    names = Array.isArray(names) ? names : [];
    var shown = names.slice(0, 3).join(', ');
    return names.length > 3 ? shown + '  ' + t('+{n} more', { n: names.length - 3 }) : shown;
  }

  class UecpGddOverlay extends HTMLElement {
    connectedCallback() {
      this._state = { files: [], enabledCount: 0, tokenCount: 0, chunkCount: 0 };
      this._filter = '';
      this._editId = null;
      this._editContent = {};
      this._view = 'files';
      this._outline = null;
      this._queryText = '';
      this._queryPreview = null;
      this._build();
      var self = this;
      this._subs = [
        window.uecp.on('gdd.state', function (st) { self._onState(st); }),
        window.uecp.on('gdd.file_content', function (d) { self._onFileContent(d); }),
        window.uecp.on('gdd.outline', function (d) { self._onOutline(d); }),
        window.uecp.on('gdd.query_preview', function (d) { self._onQueryPreview(d); }),
        window.uecp.on('gdd.filedrag', function (d) { self._onFileDrag(d); })
      ];
    }
    disconnectedCallback() {
      (this._subs || []).forEach(function (u) { u(); });
      this._subs = [];
      window.uecp.call('gdd_drop_target', { active: false });
    }

    open() {
      this.classList.add('open');
      this._editId = null;
      window.uecp.call('load_gdd', {});
      window.uecp.call('gdd_drop_target', { active: true });
      this._render();
    }
    close() {
      this.classList.remove('open');
      this._editId = null;
      window.uecp.call('gdd_drop_target', { active: false });
      if (this._dropEl) this._dropEl.classList.remove('on');
    }

    _onFileDrag(d) {
      if (!this._dropEl) return;
      if (!d || d.state !== 'enter' || !this.isOpen()) {
        this._dropEl.classList.remove('on');
        return;
      }
      var text = dropText(d);
      this._dropEl.querySelector('.gdd-drop-title').textContent = text.title;
      this._dropEl.querySelector('.gdd-drop-sub').textContent = text.sub;
      this._dropEl.querySelector('.gdd-drop-files').textContent = dropNames(d.names);
      this._dropEl.classList.toggle('bad', text.bad);
      this._dropEl.classList.add('on');
    }
    isOpen() { return this.classList.contains('open'); }

    _build() {
      var self = this;
      this.innerHTML = '';
      this._overlayEl = document.createElement('div');
      this._overlayEl.className = 'overlay open';
      window.UECP.dom.bindBackdropClose(this._overlayEl, function () { self.close(); });
      this.appendChild(this._overlayEl);

      this._box = document.createElement('div');
      this._box.className = 'modal';
      this._box.innerHTML =
        '<div class="modal-head">' +
          '<span class="tile" style="width:26px;height:26px"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><path d="M14 2v6h6"/></svg></span>' +
          '<div style="flex:1">' +
            '<div class="modal-title">Game Design Document</div>' +
            '<div class="modal-sub">Indexed for the Architect to search via query_gdd</div>' +
          '</div>' +
          '<button class="icon-btn" data-act="close" title="Close" aria-label="Close"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18M6 6l12 12"/></svg></button>' +
        '</div>' +
        '<div class="gdd-tabs-row">' +
          '<div class="tabs" data-view-tabs>' +
            '<span data-tab="files" class="active">Files</span>' +
            '<span data-tab="outline">Outline</span>' +
          '</div>' +
        '</div>' +
        '<div class="gdd-toolbar" data-files-toolbar>' +
          '<div class="input" style="gap:9px;flex:1">' +
            '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--ue-text-lo)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>' +
            '<input class="gdd-search" type="text" placeholder="Filter files…" style="border:none;outline:none;background:transparent;flex:1;font-size:13px;color:var(--ue-text-hi)">' +
          '</div>' +
          '<button class="gdd-tbtn" data-act="import">Import files</button>' +
        '</div>' +
        '<div class="gdd-toolbar" data-outline-toolbar style="display:none">' +
          '<div class="input" style="gap:9px;flex:1">' +
            '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--ue-text-lo)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>' +
            '<input class="gdd-query-input" type="text" placeholder="Try a query…" style="border:none;outline:none;background:transparent;flex:1;font-size:13px;color:var(--ue-text-hi)">' +
          '</div>' +
        '</div>' +
        '<div class="gdd-scroll" data-scroll></div>' +
        '<div style="padding:12px 20px;border-top:1px solid var(--ue-line-soft);display:flex;align-items:center;gap:10px">' +
          '<span class="gdd-hint">Drag .txt or .md files here to attach them</span>' +
          '<span class="spacer"></span>' +
          '<span class="mono chat-item-meta" data-meta></span>' +
        '</div>';
      this._overlayEl.appendChild(this._box);

      this._dropEl = document.createElement('div');
      this._dropEl.className = 'gdd-drop';
      this._dropEl.innerHTML =
        '<svg width="34" height="34" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m21.4 11.1-9.2 9.2a6 6 0 0 1-8.5-8.5l9.2-9.2a4 4 0 0 1 5.7 5.7l-9.2 9.2a2 2 0 0 1-2.8-2.8l8.5-8.5"/></svg>' +
        '<div class="gdd-drop-title"></div>' +
        '<div class="gdd-drop-sub"></div>' +
        '<div class="gdd-drop-files" data-i18n-skip></div>';
      this._box.appendChild(this._dropEl);

      this._box.querySelector('[data-act="close"]').addEventListener('click', function () { self.close(); });
      this._box.querySelector('[data-act="import"]').addEventListener('click', function () { window.uecp.call('import_gdd_files', {}); });

      this._box.querySelectorAll('[data-view-tabs] span[data-tab]').forEach(function (tab) {
        tab.addEventListener('click', function () {
          if (tab.dataset.tab === self._view) return;
          self._view = tab.dataset.tab;
          if (self._view === 'outline' && !self._outline) window.uecp.call('load_gdd_outline', {});
          self._render();
        });
      });

      var search = this._box.querySelector('.gdd-search');
      if (search) search.addEventListener('input', function (e) { self._filter = e.target.value.toLowerCase(); self._render(); });

      var queryInput = this._box.querySelector('.gdd-query-input');
      if (queryInput) queryInput.addEventListener('input', function (e) {
        self._queryText = e.target.value;
        clearTimeout(self._queryDebounce);
        self._queryDebounce = setTimeout(function () {
          if (self._queryText) {
            window.uecp.call('preview_gdd_query', { query: self._queryText });
          } else {
            self._queryPreview = null;
            self._render();
          }
        }, 250);
      });
    }

    _onState(st) {
      if (!st) return;
      this._state = {
        files: Array.isArray(st.files) ? st.files : [],
        enabledCount: st.enabledCount || 0,
        tokenCount: st.tokenCount || 0,
        chunkCount: st.chunkCount || 0
      };
      if (this._editId && !this._state.files.some(function (f) { return f.id === this._editId; })) this._editId = null;
      this._render();
    }

    _onFileContent(d) {
      if (!d || !d.id) return;
      this._editContent[d.id] = d.content != null ? d.content : '';
      if (this._editId === d.id) this._render();
    }

    _onOutline(d) {
      this._outline = d || { sections: [] };
      if (this._view === 'outline') this._render();
    }

    _onQueryPreview(d) {
      this._queryPreview = d || null;
      if (this._view === 'outline') this._render();
    }

    _render() {
      if (!this._box) return;
      var self = this;
      var scroll = this._box.querySelector('[data-scroll]');

      this._box.querySelectorAll('[data-view-tabs] span[data-tab]').forEach(function (tab) {
        tab.classList.toggle('active', tab.dataset.tab === self._view);
      });
      var filesToolbar = this._box.querySelector('[data-files-toolbar]');
      if (filesToolbar) filesToolbar.style.display = (this._view === 'files') ? 'flex' : 'none';
      var outlineToolbar = this._box.querySelector('[data-outline-toolbar]');
      if (outlineToolbar) outlineToolbar.style.display = (this._view === 'outline') ? 'flex' : 'none';

      if (this._view === 'outline') {
        scroll.innerHTML = this._outlineResultsHtml();
      } else {
        var files = this._state.files.filter(function (f) {
          return !self._filter || String(f.name || '').toLowerCase().indexOf(self._filter) !== -1;
        });
        if (!files.length) {
          scroll.innerHTML = '<div class="gdd-empty">' + (this._filter ? 'No files match your filter.' :
            'No GDD files imported. Import a .txt or .md file — design notes, lore, mechanics — and query_gdd will let the AI search them.') + '</div>';
        } else {
          scroll.innerHTML = files.map(function (f) { return self._cardHtml(f); }).join('');
          this._wireCards(scroll);
        }
      }

      var meta = this._box.querySelector('[data-meta]');
      if (meta) {
        var n = this._state.chunkCount || 0;
        meta.textContent = this._state.enabledCount + ' enabled · ' + n + ' section' + (n === 1 ? '' : 's') + ' indexed';
      }
    }

    _outlineResultsHtml() {
      var html = '';
      if (this._queryText) {
        var chunks = (this._queryPreview && Array.isArray(this._queryPreview.chunks)) ? this._queryPreview.chunks : null;
        if (chunks && chunks.length) {
          html += chunks.map(function (c) {
            var content = String(c.content || '');
            var preview = content.slice(0, 200) + (content.length > 200 ? '…' : '');
            var score = typeof c.score === 'number' ? Math.round(c.score * 100) / 100 : 0;
            return '<div class="gdd-outline-row">' +
              '<span class="gdd-outline-heading">' + esc(c.heading_path || c.file || '') + '</span>' +
              '<span class="gdd-outline-meta">score ' + score + ' · ~' + (c.tokens || 0) + ' tok</span>' +
              '<span class="gdd-outline-preview">' + esc(preview) + '</span>' +
            '</div>';
          }).join('');
        } else {
          html += '<div class="gdd-empty">' + esc((this._queryPreview && this._queryPreview.message) || 'Searching…') + '</div>';
        }
      } else if (this._outline && Array.isArray(this._outline.sections) && this._outline.sections.length) {
        html += this._outline.sections.map(function (s) {
          var indent = Math.max(0, (s.level || 0) - 1) * 14;
          var partSuffix = s.part ? (' (part ' + s.part + '/' + s.part_count + ')') : '';
          return '<div class="gdd-outline-row" style="padding-left:' + indent + 'px">' +
            '<span class="gdd-outline-heading">' + esc((s.heading_path || s.file || '') + partSuffix) + '</span>' +
            '<span class="gdd-outline-meta">' + esc(s.file || '') + ' · ~' + (s.tokens || 0) + ' tok</span>' +
          '</div>';
        }).join('');
      } else {
        html += '<div class="gdd-empty">' + (this._outline ? 'No sections indexed yet.' : 'Loading outline…') + '</div>';
      }
      return html;
    }

    _cardHtml(f) {
      var editing = this._editId === f.id;
      var trashSvg = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="var(--ue-text-mid)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>';
      var editor = '';
      if (editing) {
        var content = this._editContent[f.id];
        editor = '<textarea class="gdd-edit" data-edit-id="' + esc(f.id) + '" placeholder="Loading…">' + esc(content == null ? '' : content) + '</textarea>' +
          '<div class="gdd-edit-bar">' +
            '<button class="gdd-tbtn" data-act="cancel">Cancel</button>' +
            '<button class="btn-accent" data-act="save">Save</button>' +
          '</div>';
      }
      var n = f.chunks;
      var chunksBadge = (n != null) ? ('<span class="gdd-tokens">' + esc(String(n)) + ' section' + (n === 1 ? '' : 's') + '</span>') : '';
      return '<div class="mem-entry" data-id="' + esc(f.id) + '">' +
        '<div class="gdd-card-meta">' +
          '<span class="gdd-name" data-act="edit">' + esc(f.name || 'Untitled') + '</span>' +
          '<span class="gdd-tokens">~' + esc(String(f.tokens || 0)) + ' tok</span>' +
          chunksBadge +
          '<button class="gdd-icon-btn" data-act="del" title="Delete">' + trashSvg + '</button>' +
          '<div class="toggle' + (f.enabled ? ' on' : '') + '" data-act="toggle" title="' + (f.enabled ? 'Enabled' : 'Disabled') + '"><span class="knob"></span></div>' +
        '</div>' + editor +
      '</div>';
    }

    _wireCards(scroll) {
      var self = this;
      scroll.querySelectorAll('.mem-entry').forEach(function (card) {
        var id = card.dataset.id;
        var toggle = card.querySelector('[data-act="toggle"]');
        if (toggle) toggle.addEventListener('click', function () {
          var f = self._state.files.filter(function (x) { return x.id === id; })[0];
          window.uecp.call('toggle_gdd_file', { id: id, enabled: !(f && f.enabled) });
        });
        var del = card.querySelector('[data-act="del"]');
        if (del) del.addEventListener('click', function () {
          window.UECP.dialog.confirm('Delete GDD file', 'Delete this GDD file? This cannot be undone.').then(function (ok) {
            if (ok) window.uecp.call('delete_gdd_file', { id: id });
          });
        });
        var name = card.querySelector('[data-act="edit"]');
        if (name) name.addEventListener('click', function () {
          self._editId = id;
          if (self._editContent[id] === undefined) window.uecp.call('load_gdd_file_content', { id: id });
          self._render();
        });
        var save = card.querySelector('[data-act="save"]');
        var ta = card.querySelector('[data-edit-id]');
        if (save && ta) save.addEventListener('click', function () {
          window.uecp.call('save_gdd_file', { id: id, content: ta.value });
          self._editContent[id] = ta.value;
          self._editId = null;
          self._render();
        });
        var cancel = card.querySelector('[data-act="cancel"]');
        if (cancel) cancel.addEventListener('click', function () { self._editId = null; self._render(); });
      });
    }
  }

  UecpGddOverlay.__pure = { dropText: dropText, dropNames: dropNames };

  customElements.define('uecp-gdd-overlay', UecpGddOverlay);

  window.UECP = window.UECP || {};
  window.UECP.openGdd = function () {
    var ov = document.querySelector('uecp-gdd-overlay');
    if (!ov) { ov = document.createElement('uecp-gdd-overlay'); document.body.appendChild(ov); }
    ov.open();
    return ov;
  };
})();
