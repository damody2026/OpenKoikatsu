(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) { root.UECP = root.UECP || {}; root.UECP.createCoalescer = api.createCoalescer; }
}(typeof self !== 'undefined' ? self : null, function () {
  function createCoalescer(flush, raf) {
    const schedule = raf || (typeof requestAnimationFrame === 'function' ? requestAnimationFrame : (cb) => setTimeout(cb, 16));
    let armed = false;
    return {
      schedule() {
        if (armed) return;
        armed = true;
        schedule(() => { armed = false; flush(); });
      }
    };
  }
  return { createCoalescer };
}));
