﻿// Copyright 2026, BlueprintsLab, All rights reserved
using UnrealBuildTool;

public class UECPShell : ModuleRules
{
	public UECPShell(ReadOnlyTargetRules Target) : base(Target)
	{
		bUsePrecompiled = true;
		if (Target.Type != TargetType.Editor)
		{
			return;
		}

		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;
		bUseUnity = false;

		if (Target.Version.MinorVersion >= 6)
		{
			PrivateIncludePaths.Add(System.IO.Path.Combine(EngineDirectory, "Plugins/FX/Niagara/Source/Niagara/Internal"));
			PrivateIncludePaths.Add(System.IO.Path.Combine(EngineDirectory, "Plugins/FX/Niagara/Source/NiagaraShader/Internal"));
			PrivateDependencyModuleNames.Add("PropertyBindingUtils");
		}

		PublicDependencyModuleNames.AddRange(new string[]
		{
			"Core",
			"CoreUObject",
			"Engine",
			"HTTP",
			"Json",
			"JsonUtilities",
			"EditorScriptingUtilities",
			"UECPCore",
			"UECPTools",
			"UECPMCPBridge",
			"UECPLearning",
			"UECPAssetGen"
		});

		PrivateDependencyModuleNames.AddRange(new string[]
		{
			"Projects",
			"InputCore",
			"EditorFramework",
			"UnrealEd",
			"ToolMenus",
			"Slate",
			"SlateCore",
			"Kismet",
			"AssetRegistry",
			"KismetCompiler",
			"BlueprintGraph",
			"GraphEditor",
			"ApplicationCore",
			"UMG",
			"UMGEditor",
			"Blutility",
			"Sockets",
			"Networking",
			"ContentBrowser",
			"ContentBrowserData",
			"MaterialEditor",
			"AssetTools",
			"Foliage",
			"FoliageEdit",
			"AIModule",
			"AIGraph",
			"BehaviorTreeEditor",
			"AnimGraph",
			"AnimGraphRuntime",
			"AudioEditor",
			"IKRig",
			"IKRigEditor",
			"DesktopPlatform",
			"WebBrowser",
			"WebBrowserWidget",
			"EnhancedInput",
			"InputBlueprintNodes",
			"Niagara",
			"NiagaraEditor",
			"PCG",
			"PCGEditor",
			"Landscape",
			"LandscapeEditor",
			"NavigationSystem",
			"GameplayTags",
			"GameplayTagsEditor",
			"GameplayAbilities",
			"MetasoundEngine",
			"MetasoundFrontend",
			"MetasoundEditor",
			"StateTreeModule",
			"StateTreeEditorModule",
			"GameplayStateTreeModule",
			"LevelSequence",
			"MovieScene",
			"PhysicsUtilities",
			"PhysicsCore",
			"PoseSearch",
			"PoseSearchEditor",
			"Chooser",
			"ChooserEditor",
			"BSPUtils",
			"DataLayerEditor",
			"ClothingSystemRuntimeInterface",
			"ClothingSystemRuntimeCommon",
			"Persona",
			"AdvancedPreviewScene",
			"TraceServices",
			"TraceAnalysis",
			"TraceLog",
			"AudioModulation",
			"AudioMixer",
			"AudioCapture",
			"AudioCaptureCore",
			"HairStrandsCore",
			"CommonUI",
			"CommonInput",
			"PythonScriptPlugin",
			"SourceControl"
		});
	}
}

