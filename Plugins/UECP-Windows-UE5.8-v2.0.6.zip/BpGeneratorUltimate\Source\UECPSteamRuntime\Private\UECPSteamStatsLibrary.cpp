// Copyright 2026, BlueprintsLab, All rights reserved
#include "Library/UECPSteamStatsLibrary.h"

#include "Engine/Texture2D.h"
#include "UECPSteamAPI.h"
#include "UECPSteamImage.h"

#if UECP_WITH_STEAM
namespace
{
	FUECPSteamAchievementInfo BuildAchievement(ISteamUserStats& Stats, const FString& ApiName)
	{
		const auto Utf8Name = StringCast<UTF8CHAR>(*ApiName);
		const char* Name = reinterpret_cast<const char*>(Utf8Name.Get());

		FUECPSteamAchievementInfo Info;
		Info.ApiName = ApiName;

		bool bUnlocked = false;
		uint32 UnlockUnixTime = 0;
		if (Stats.GetAchievementAndUnlockTime(Name, &bUnlocked, &UnlockUnixTime))
		{
			Info.bUnlocked = bUnlocked;
			if (bUnlocked && UnlockUnixTime > 0)
			{
				Info.UnlockTime = FDateTime::FromUnixTimestamp(static_cast<int64>(UnlockUnixTime));
			}
		}

		Info.DisplayName = UTF8_TO_TCHAR(Stats.GetAchievementDisplayAttribute(Name, "name"));
		Info.Description = UTF8_TO_TCHAR(Stats.GetAchievementDisplayAttribute(Name, "desc"));

		const FString HiddenAttr = UTF8_TO_TCHAR(Stats.GetAchievementDisplayAttribute(Name, "hidden"));
		Info.bHidden = (HiddenAttr == TEXT("1"));

		float Percent = 0.f;
		Info.GlobalUnlockPercent = Stats.GetAchievementAchievedPercent(Name, &Percent) ? Percent : -1.f;

		return Info;
	}
}
#endif

TArray<FUECPSteamAchievementInfo> UUECPSteamStatsLibrary::GetAchievements()
{
	TArray<FUECPSteamAchievementInfo> Out;
#if UECP_WITH_STEAM
	ISteamUserStats* Stats = UECPSteam::UserStats();
	if (!Stats)
	{
		return Out;
	}

	const uint32 Count = Stats->GetNumAchievements();
	Out.Reserve(Count);

	for (uint32 Index = 0; Index < Count; ++Index)
	{
		const char* ApiName = Stats->GetAchievementName(Index);
		if (ApiName && *ApiName)
		{
			Out.Add(BuildAchievement(*Stats, UTF8_TO_TCHAR(ApiName)));
		}
	}
#endif
	return Out;
}

FUECPSteamAchievementInfo UUECPSteamStatsLibrary::GetAchievement(const FString& AchievementApiName)
{
#if UECP_WITH_STEAM
	if (ISteamUserStats* Stats = UECPSteam::UserStats())
	{
		return BuildAchievement(*Stats, AchievementApiName);
	}
#endif
	return FUECPSteamAchievementInfo();
}

bool UUECPSteamStatsLibrary::IsAchievementUnlocked(const FString& AchievementApiName)
{
#if UECP_WITH_STEAM
	if (ISteamUserStats* Stats = UECPSteam::UserStats())
	{
		bool bUnlocked = false;
		return Stats->GetAchievement(TCHAR_TO_UTF8(*AchievementApiName), &bUnlocked) && bUnlocked;
	}
#endif
	return false;
}

bool UUECPSteamStatsLibrary::UnlockAchievement(const FString& AchievementApiName, bool bStoreImmediately)
{
#if UECP_WITH_STEAM
	if (ISteamUserStats* Stats = UECPSteam::UserStats())
	{
		if (!Stats->SetAchievement(TCHAR_TO_UTF8(*AchievementApiName)))
		{
			UE_LOG(LogUECPSteam, Warning,
				TEXT("UnlockAchievement: Steam rejected '%s'. Check the API name matches the Steamworks partner site exactly."),
				*AchievementApiName);
			return false;
		}
		return bStoreImmediately ? Stats->StoreStats() : true;
	}
#endif
	return false;
}

bool UUECPSteamStatsLibrary::ClearAchievement(const FString& AchievementApiName, bool bStoreImmediately)
{
#if UECP_WITH_STEAM
	if (ISteamUserStats* Stats = UECPSteam::UserStats())
	{
		if (!Stats->ClearAchievement(TCHAR_TO_UTF8(*AchievementApiName)))
		{
			return false;
		}
		return bStoreImmediately ? Stats->StoreStats() : true;
	}
#endif
	return false;
}

bool UUECPSteamStatsLibrary::IndicateAchievementProgress(
	const FString& AchievementApiName, int32 CurrentProgress, int32 MaxProgress)
{
#if UECP_WITH_STEAM
	if (ISteamUserStats* Stats = UECPSteam::UserStats())
	{
		return Stats->IndicateAchievementProgress(TCHAR_TO_UTF8(*AchievementApiName),
			static_cast<uint32>(FMath::Max(0, CurrentProgress)),
			static_cast<uint32>(FMath::Max(0, MaxProgress)));
	}
#endif
	return false;
}

UTexture2D* UUECPSteamStatsLibrary::GetAchievementIcon(const FString& AchievementApiName)
{
#if UECP_WITH_STEAM
	if (ISteamUserStats* Stats = UECPSteam::UserStats())
	{
		return UECPSteam::CreateTextureFromImageHandle(
			Stats->GetAchievementIcon(TCHAR_TO_UTF8(*AchievementApiName)));
	}
#endif
	return nullptr;
}

int32 UUECPSteamStatsLibrary::GetStatInt(const FString& StatApiName)
{
#if UECP_WITH_STEAM
	if (ISteamUserStats* Stats = UECPSteam::UserStats())
	{
		int32 Value = 0;
		if (Stats->GetStat(TCHAR_TO_UTF8(*StatApiName), &Value))
		{
			return Value;
		}
	}
#endif
	return 0;
}

float UUECPSteamStatsLibrary::GetStatFloat(const FString& StatApiName)
{
#if UECP_WITH_STEAM
	if (ISteamUserStats* Stats = UECPSteam::UserStats())
	{
		float Value = 0.f;
		if (Stats->GetStat(TCHAR_TO_UTF8(*StatApiName), &Value))
		{
			return Value;
		}
	}
#endif
	return 0.f;
}

bool UUECPSteamStatsLibrary::SetStatInt(const FString& StatApiName, int32 Value, bool bStoreImmediately)
{
#if UECP_WITH_STEAM
	if (ISteamUserStats* Stats = UECPSteam::UserStats())
	{
		if (!Stats->SetStat(TCHAR_TO_UTF8(*StatApiName), Value))
		{
			return false;
		}
		return bStoreImmediately ? Stats->StoreStats() : true;
	}
#endif
	return false;
}

bool UUECPSteamStatsLibrary::SetStatFloat(const FString& StatApiName, float Value, bool bStoreImmediately)
{
#if UECP_WITH_STEAM
	if (ISteamUserStats* Stats = UECPSteam::UserStats())
	{
		if (!Stats->SetStat(TCHAR_TO_UTF8(*StatApiName), Value))
		{
			return false;
		}
		return bStoreImmediately ? Stats->StoreStats() : true;
	}
#endif
	return false;
}

bool UUECPSteamStatsLibrary::UpdateAvgRateStat(
	const FString& StatApiName, float CountThisSession, float SessionLengthSeconds)
{
#if UECP_WITH_STEAM
	if (ISteamUserStats* Stats = UECPSteam::UserStats())
	{
		return Stats->UpdateAvgRateStat(TCHAR_TO_UTF8(*StatApiName), CountThisSession, SessionLengthSeconds);
	}
#endif
	return false;
}

bool UUECPSteamStatsLibrary::StoreSteamStats()
{
#if UECP_WITH_STEAM
	if (ISteamUserStats* Stats = UECPSteam::UserStats())
	{
		return Stats->StoreStats();
	}
#endif
	return false;
}

bool UUECPSteamStatsLibrary::ResetAllStats(bool bAlsoResetAchievements)
{
#if UECP_WITH_STEAM
	if (ISteamUserStats* Stats = UECPSteam::UserStats())
	{
		return Stats->ResetAllStats(bAlsoResetAchievements) && Stats->StoreStats();
	}
#endif
	return false;
}

bool UUECPSteamStatsLibrary::RequestGlobalAchievementPercentages()
{
#if UECP_WITH_STEAM
	if (ISteamUserStats* Stats = UECPSteam::UserStats())
	{
		Stats->RequestGlobalAchievementPercentages();
		return true;
	}
#endif
	return false;
}
