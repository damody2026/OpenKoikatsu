"""uecp - script binding for UECP code-execution mode.

Write one script:

    import uecp
    for f in ['Attack', 'Block', 'Dodge']:
        uecp.blueprint.add_function(blueprint='BP_Player', name=f)
    uecp.blueprint.compile(blueprint='BP_Player')

Each uecp.<category>.<action>(**kwargs) routes through the in-editor C++ dispatcher
(UUECPScriptBridge) via the gated path. A failed call raises UecpToolError; pass
_soft=True to get the result dict back instead. uecp.search(query) and
uecp.docs(category, action) reflect the same registry search_tools/get_tool_docs use.

Within a chat the namespace persists across execute_uecp_script calls (REPL-style):
vars/imports/helpers defined in one call are available in the next - except World,
Level and Package handles, which are dropped at the end of each call (see
_drop_world_handles). uecp.vars() dumps what's in scope; uecp.reset() clears it.
execute_python runs each call in a fresh namespace instead (_run_isolated).

Design: docs/superpowers/specs/2026-06-21-code-execution-mode-design.md
"""
import json
import sys

import builtins as _builtins_mod

_REAL_IMPORT = _builtins_mod.__import__
_REAL_OPEN = _builtins_mod.open
_BLOCKED_MODULES = frozenset(("os", "subprocess", "shutil", "socket", "ctypes"))


def _project_dir():
    try:
        import unreal
        return _REAL_IMPORT("os").path.abspath(unreal.Paths.project_dir())
    except Exception:
        return _REAL_IMPORT("os").getcwd()


def _sandboxed_import(name, globals=None, locals=None, fromlist=(), level=0):
    if name.split(".", 1)[0] in _BLOCKED_MODULES:
        raise ImportError(
            "import of '{}' is disabled inside execute_uecp_script/execute_python for "
            "safety. Use the uecp.<category>.<action>() tool surface (or unreal.* editor "
            "APIs) for filesystem/process/network work instead.".format(name)
        )
    return _REAL_IMPORT(name, globals, locals, fromlist, level)


def _sandboxed_open(file, mode="r", *args, **kwargs):
    _os = _REAL_IMPORT("os")
    try:
        path = _os.fspath(file)
    except TypeError:
        return _REAL_OPEN(file, mode, *args, **kwargs)
    abs_path = _os.path.abspath(path)
    root = _project_dir()
    if _os.path.commonpath([abs_path, root]) != root:
        raise PermissionError(
            "open('{}') is outside the project directory ({}); execute_uecp_script/"
            "execute_python may only read/write files inside the project.".format(path, root)
        )
    return _REAL_OPEN(file, mode, *args, **kwargs)


_CRASHY_CLASSES = {
    "NiagaraPythonEmitter":
        "constructing NiagaraPythonEmitter from Python crashes the editor (it needs an "
        "emitter handle only the Niagara editor installs). To read emitters use the tools: "
        "get_niagara_summary(system_path) for the emitter list, get_emitter_modules("
        "system_path, emitter_name) for modules and renderers, and "
        "get_niagara_detailed_summary(system_path, emitter_name) for live values.",
}


def _guard_crashy_classes():
    """Wrap the constructors of editor-only classes that assert when built bare."""
    try:
        import unreal
    except Exception:
        return
    for name, advice in _CRASHY_CLASSES.items():
        cls = getattr(unreal, name, None)
        if cls is None or getattr(cls, "_uecp_guarded", False):
            continue

        def _blocked(*_a, __advice=advice, __name=name, **_kw):
            raise RuntimeError("uecp: refused to construct {} - {}".format(__name, __advice))

        try:
            blocked = type(name, (object,), {"__init__": _blocked, "_uecp_guarded": True})
            setattr(unreal, name, blocked)
        except Exception:
            pass


def _install_sandbox(ns):
    """Install a restricted __builtins__ into an exec()/script globals dict: blocks
    importing os/subprocess/shutil/socket/ctypes and confines open() to the project
    directory. See the module-level comment above for what this does and doesn't
    guarantee. Idempotent - safe to call every run on a persistent REPL namespace."""
    restricted = dict(_builtins_mod.__dict__)
    restricted["__import__"] = _sandboxed_import
    restricted["open"] = _sandboxed_open
    ns["__builtins__"] = restricted
    _guard_crashy_classes()


_WORLD_GUARD_DEPTH = 0
_WORLD_GUARD_SAVED = []

_MAP_LOAD_ADVICE = (
    "loading a level as an asset makes a second, inactive copy of it that the next map load "
    "cannot clean up while a script still holds it, and the editor stops on its 'World Memory "
    "Leaks' fatal error. Open it with the open_level tool instead, or read it without loading "
    "through the asset registry (unreal.AssetRegistryHelpers.get_asset_registry(), "
    "find_asset_by_name, query_project_index).")

_OPEN_MAP_ADVICE = (
    "the engine tears the open level down for that and requires its package to be gone, but "
    "this call's own reference to the package keeps it alive, so the editor would stop on its "
    "'World Memory Leaks' fatal error. To reload the open level from disk, call the open_level "
    "tool on another level and then open_level on this one again - it loads fresh from disk "
    "(unsaved changes to it are discarded). To close it, open another level.")


class _LibraryProxy(object):
    """Stands in for an unreal library class during a run. The guarded functions are its own
    attributes; everything else - and what dir()/repr() show when a script probes the API - is the
    real class's."""

    def __init__(self, real, **guarded):
        object.__setattr__(self, "_real", real)
        for name, fn in guarded.items():
            object.__setattr__(self, name, fn)

    def __getattr__(self, name):
        return getattr(object.__getattribute__(self, "_real"), name)

    def __dir__(self):
        return dir(object.__getattribute__(self, "_real"))

    def __repr__(self):
        return repr(object.__getattribute__(self, "_real"))


def _package_name_of(path):
    """'/Game/M', '/Game/M.M', "World'/Game/M.M'" and '/Game/M.M:PersistentLevel' -> '/Game/M'."""
    p = str(path).strip()
    if p.count("'") >= 2:
        p = p.split("'")[1]
    return p.split(".")[0].split(":")[0]


def _push_world_guards():
    global _WORLD_GUARD_DEPTH
    _WORLD_GUARD_DEPTH += 1
    if _WORLD_GUARD_DEPTH > 1:
        return
    try:
        import unreal
        bridge = unreal.UECPScriptBridge
        open_map = bridge.get_open_map_package
        is_map = bridge.is_map_asset
    except Exception:
        return

    def check_map_load(path, what):
        try:
            refuse = bool(path) and is_map(str(path)) and _package_name_of(path) != open_map()
        except Exception:
            refuse = False
        if refuse:
            raise RuntimeError("uecp: refused {}('{}') - {}".format(what, path, _MAP_LOAD_ADVICE))

    def check_open_map(packages, what):
        try:
            current = open_map()
            names = [p.get_name() for p in (packages or []) if p is not None]
        except Exception:
            return
        if current and current in names:
            raise RuntimeError("uecp: refused {} on the open level '{}' - {}".format(what, current, _OPEN_MAP_ADVICE))

    def swap(owner, attr, replacement):
        _WORLD_GUARD_SAVED.append((owner, attr, getattr(owner, attr)))
        setattr(owner, attr, replacement)

    import functools

    try:
        real_load_asset = unreal.load_asset

        @functools.wraps(real_load_asset)
        def load_asset(name, *args, **kwargs):
            check_map_load(name, "load_asset")
            return real_load_asset(name, *args, **kwargs)
        swap(unreal, "load_asset", load_asset)

        real_load_object = unreal.load_object

        @functools.wraps(real_load_object)
        def load_object(outer, name, *args, **kwargs):
            if outer is None:
                check_map_load(name, "load_object")
            return real_load_object(outer, name, *args, **kwargs)
        swap(unreal, "load_object", load_object)

        assets = unreal.EditorAssetLibrary

        @functools.wraps(assets.load_asset)
        def library_load_asset(asset_path, *args, **kwargs):
            check_map_load(asset_path, "EditorAssetLibrary.load_asset")
            return assets.load_asset(asset_path, *args, **kwargs)
        swap(unreal, "EditorAssetLibrary", _LibraryProxy(assets, load_asset=library_load_asset))

        packages = unreal.EditorLoadingAndSavingUtils

        @functools.wraps(packages.reload_packages)
        def reload_packages(packages_to_reload, *args, **kwargs):
            check_open_map(packages_to_reload, "reload_packages")
            return packages.reload_packages(packages_to_reload, *args, **kwargs)

        @functools.wraps(packages.unload_packages)
        def unload_packages(packages_to_unload, *args, **kwargs):
            check_open_map(packages_to_unload, "unload_packages")
            return packages.unload_packages(packages_to_unload, *args, **kwargs)
        swap(unreal, "EditorLoadingAndSavingUtils",
             _LibraryProxy(packages, reload_packages=reload_packages, unload_packages=unload_packages))
    except Exception:
        pass


def _pop_world_guards():
    global _WORLD_GUARD_DEPTH
    _WORLD_GUARD_DEPTH = max(0, _WORLD_GUARD_DEPTH - 1)
    if _WORLD_GUARD_DEPTH:
        return
    while _WORLD_GUARD_SAVED:
        owner, attr, original = _WORLD_GUARD_SAVED.pop()
        try:
            setattr(owner, attr, original)
        except Exception:
            pass


_DROPPED_WORLD_HANDLE = "<dropped: World/Level/Package handles are not kept between calls - re-fetch it>"


def _drop_world_handles(ns):
    """Remove the top-level names holding a World, Level or Package handle (directly, or in a
    list/tuple/set/dict) from a persistent namespace. Returns the names removed."""
    try:
        import unreal
        pinning = tuple(t for t in (getattr(unreal, "World", None), getattr(unreal, "Level", None),
                                     getattr(unreal, "Package", None)) if isinstance(t, type))
        containers = (list, tuple, set, frozenset) + tuple(
            t for t in (getattr(unreal, "Array", None),) if isinstance(t, type))
    except Exception:
        return []
    if not pinning:
        return []

    def pins(value):
        if isinstance(value, pinning):
            return True
        try:
            if isinstance(value, dict):
                return any(isinstance(v, pinning) for v in value.values())
            if isinstance(value, containers):
                return any(isinstance(v, pinning) for v in value)
        except Exception:
            pass
        return False

    dropped = [k for k, v in list(ns.items()) if not _is_hidden(k) and pins(v)]
    for k in dropped:
        del ns[k]
    return dropped


class UecpToolError(RuntimeError):
    """Raised when a uecp.<category>.<action> call reports ok=false."""
    def __init__(self, category, action, error):
        self.category = category
        self.action = action
        self.error = error
        super().__init__("uecp.{}.{} failed: {}".format(category, action, error))


def _bridge():
    import unreal
    return unreal.UECPScriptBridge


def _dispatch(category, action, soft, kwargs):
    raw = _bridge().dispatch(category, action, json.dumps(kwargs))
    result = json.loads(raw) if raw else {}
    ok = result.get("ok", result.get("success", False))
    if not ok and not soft:
        raise UecpToolError(category, action, result.get("error", "unknown error"))
    return result


class _Action:
    def __init__(self, category, action):
        self._category = category
        self._action = action

    def __call__(self, _soft=False, **kwargs):
        return _dispatch(self._category, self._action, _soft, kwargs)


class _Category:
    def __init__(self, category):
        self._category = category

    def __getattr__(self, action):
        if action.startswith("_"):
            raise AttributeError(action)
        return _Action(self._category, action)

    def __call__(self, _soft=False, **kwargs):
        return _dispatch(self._category, self._category, _soft, kwargs)


def __getattr__(name):
    if name.startswith("_"):
        raise AttributeError(name)
    return _Category(name)


def call(category, action, _soft=False, **kwargs):
    """Explicit form of uecp.<category>.<action>(**kwargs)."""
    return _dispatch(category, action, _soft, kwargs)


def search(query):
    """Find actions by intent (same backend as the top-level search_tools)."""
    return json.loads(_bridge().search_actions(query) or "[]")


def docs(category, action):
    """Params/summary for one action (same backend as get_tool_docs)."""
    return json.loads(_bridge().action_docs(category, action) or "{}")


_SESSIONS = {}
_LRU = []
_MAX_SESSIONS = 16


def _session_ns(key):
    ns = _SESSIONS.get(key)
    if ns is None:
        ns = {"__name__": "__uecp_session__", "uecp": sys.modules[__name__]}
        _SESSIONS[key] = ns
    if key in _LRU:
        _LRU.remove(key)
    _LRU.append(key)
    while len(_LRU) > _MAX_SESSIONS:
        _SESSIONS.pop(_LRU.pop(0), None)
    return ns


def _summarize(v):
    t = type(v).__name__
    try:
        if v is None or isinstance(v, (int, float, bool, str)):
            r = repr(v)
            return r if len(r) <= 60 else r[:57] + "..."
        if isinstance(v, (list, tuple, set, dict)):
            return "{}(len={})".format(t, len(v))
        mod = getattr(type(v), "__module__", "") or ""
        if mod.startswith("unreal"):
            return "<unreal.{}>".format(t)
        return "<{}>".format(t)
    except Exception:
        return "<{}>".format(t)


def _is_hidden(name):
    return name.startswith("__") or name == "uecp"


def _compute_delta(before, ns):
    out = {}
    for k, v in ns.items():
        if _is_hidden(k):
            continue
        if k not in before or before[k] is not v:
            out[k] = _summarize(v)
    return out


def _run_session():
    """Bootstrap entry: exec the pending script into its chat's persistent namespace and report
    back {namespace, error} - the delta of newly-defined/changed top-level names, plus a formatted
    traceback if the script raised.

    We catch ALL exceptions and report them explicitly rather than letting them propagate: (1) a
    traceback propagating out of the bootstrap function isn't reliably captured by UE into the
    command's log output, and (2) calling the report UFUNCTION while an exception is active makes
    UE's marshaling clear the pending error. So we format the traceback ourselves (with exact
    <uecp_script> line numbers) and hand it back."""
    import traceback
    b = _bridge()
    code = b.get_pending_script()
    key = b.get_session_key()
    ns = _session_ns(key)
    _install_sandbox(ns)
    before = dict(ns)
    error = ""
    _push_world_guards()
    try:
        exec(compile(code, "<uecp_script>", "exec"), ns)
    except BaseException as e:
        error = "".join(traceback.format_exception(type(e), e, e.__traceback__))
    finally:
        _pop_world_guards()
    dropped = _drop_world_handles(ns)
    delta = _compute_delta(before, ns)
    for name in dropped:
        delta[name] = _DROPPED_WORLD_HANDLE
    b.report_run_result(json.dumps({"namespace": delta, "error": error}))


def _run_isolated():
    """execute_python entry point: run the pending script in a namespace of its own and drop it
    afterwards, so nothing a script binds outlives the call (see PythonTools.cpp for why handing
    the engine the code directly did not do that). Exceptions propagate unchanged, so the engine
    reports a failing script exactly as it did before."""
    import gc
    ns = {"__name__": "__main__"}
    _install_sandbox(ns)
    _push_world_guards()
    try:
        exec(compile(_bridge().get_pending_script(), "<script>", "exec"), ns)
    finally:
        _pop_world_guards()
        ns.clear()
        gc.collect()


def _reset_key(key):
    """Clear a specific chat's namespace (called from C++ when a chat is discarded/compacted)."""
    _SESSIONS.pop(key, None)
    if key in _LRU:
        _LRU.remove(key)


def reset():
    """Clear the current chat's persistent namespace (fresh REPL session)."""
    _reset_key(_bridge().get_session_key())


def vars():
    """Summary of every top-level name currently in this chat's namespace."""
    ns = _SESSIONS.get(_bridge().get_session_key(), {})
    return {k: _summarize(v) for k, v in ns.items() if not _is_hidden(k)}
