// Copyright 2026, BlueprintsLab, All rights reserved
#include "Library/UECPSteamP2PLibrary.h"

#include "UECPSteamAPI.h"
#include "UECPSteamP2PInternal.h"

#if UECP_WITH_STEAM
namespace
{
	SteamNetworkingIdentity MakeIdentity(const FUECPSteamID& SteamId)
	{
		SteamNetworkingIdentity Identity;
		Identity.Clear();
		Identity.SetSteamID(UECPSteam::ToSteamID(SteamId.Value));
		return Identity;
	}
}
#endif

bool UUECPSteamP2PLibrary::OpenP2PChannel(int32 Channel)
{
#if UECP_WITH_STEAM
	if (!UECPSteam::NetworkingMessages())
	{
		return false;
	}
	UECPSteamP2P::OpenChannel(Channel);
	return true;
#else
	(void)Channel;
	return false;
#endif
}

bool UUECPSteamP2PLibrary::CloseP2PChannel(int32 Channel)
{
	UECPSteamP2P::CloseChannel(Channel);
	return true;
}

TArray<int32> UUECPSteamP2PLibrary::GetOpenP2PChannels()
{
	return UECPSteamP2P::GetOpenChannels();
}

bool UUECPSteamP2PLibrary::AcceptP2PSession(FUECPSteamID PeerSteamId)
{
#if UECP_WITH_STEAM
	if (ISteamNetworkingMessages* M = UECPSteam::NetworkingMessages())
	{
		if (PeerSteamId.IsValid())
		{
			const SteamNetworkingIdentity Identity = MakeIdentity(PeerSteamId);
			return M->AcceptSessionWithUser(Identity);
		}
	}
#endif
	return false;
}

bool UUECPSteamP2PLibrary::CloseP2PSession(FUECPSteamID PeerSteamId)
{
#if UECP_WITH_STEAM
	if (ISteamNetworkingMessages* M = UECPSteam::NetworkingMessages())
	{
		if (PeerSteamId.IsValid())
		{
			const SteamNetworkingIdentity Identity = MakeIdentity(PeerSteamId);
			return M->CloseSessionWithUser(Identity);
		}
	}
#endif
	return false;
}

bool UUECPSteamP2PLibrary::SendP2PData(FUECPSteamID PeerSteamId, const TArray<uint8>& Data,
	int32 Channel, EUECPSteamP2PSend SendType)
{
#if UECP_WITH_STEAM
	ISteamNetworkingMessages* M = UECPSteam::NetworkingMessages();
	if (!M || !PeerSteamId.IsValid() || Data.Num() == 0)
	{
		return false;
	}

	const SteamNetworkingIdentity Identity = MakeIdentity(PeerSteamId);
	const int32 Flags = (SendType == EUECPSteamP2PSend::Reliable)
		? k_nSteamNetworkingSend_Reliable
		: k_nSteamNetworkingSend_Unreliable;

	const EResult Result = M->SendMessageToUser(Identity, Data.GetData(), Data.Num(), Flags, Channel);

	return Result == k_EResultOK || Result == k_EResultNoConnection;
#else
	(void)PeerSteamId; (void)Data; (void)Channel; (void)SendType;
	return false;
#endif
}

bool UUECPSteamP2PLibrary::SendP2PString(FUECPSteamID PeerSteamId, const FString& Message,
	int32 Channel, EUECPSteamP2PSend SendType)
{
	const FTCHARToUTF8 Utf8(*Message);
	TArray<uint8> Data;
	Data.Append(reinterpret_cast<const uint8*>(Utf8.Get()), Utf8.Length());
	return SendP2PData(PeerSteamId, Data, Channel, SendType);
}

bool UUECPSteamP2PLibrary::GetP2PSessionInfo(FUECPSteamID PeerSteamId, int32& PingMs,
	float& ConnectionQuality, bool& bRelayed)
{
	PingMs = -1;
	ConnectionQuality = 0.f;
	bRelayed = false;

#if UECP_WITH_STEAM
	ISteamNetworkingMessages* M = UECPSteam::NetworkingMessages();
	if (!M || !PeerSteamId.IsValid())
	{
		return false;
	}

	const SteamNetworkingIdentity Identity = MakeIdentity(PeerSteamId);
	SteamNetConnectionInfo_t Info;
	SteamNetConnectionRealTimeStatus_t Status;
	FMemory::Memzero(Info);
	FMemory::Memzero(Status);

	const int32 State = M->GetSessionConnectionInfo(Identity, &Info, &Status);
	if (State == k_ESteamNetworkingConnectionState_None)
	{
		return false;
	}

	PingMs            = Status.m_nPing;
	ConnectionQuality = Status.m_flConnectionQualityLocal;

	bRelayed = (Info.m_idPOPRelay != 0);
	return true;
#else
	(void)PeerSteamId;
	return false;
#endif
}

FString UUECPSteamP2PLibrary::Conv_P2PDataToString(const TArray<uint8>& Data)
{
	if (Data.Num() == 0)
	{
		return FString();
	}
	TArray<uint8> Terminated(Data);
	Terminated.Add(0);
	return FString(UTF8_TO_TCHAR(reinterpret_cast<const char*>(Terminated.GetData())));
}
