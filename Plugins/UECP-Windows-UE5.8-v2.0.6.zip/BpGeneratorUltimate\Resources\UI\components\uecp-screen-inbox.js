(function () {
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function fmtWhen(iso) {
    if (!iso) return '';
    try {
      var d = new Date(iso);
      if (isNaN(d.getTime())) return '';
      var now = new Date();
      var sameDay = d.toDateString() === now.toDateString();
      return sameDay
        ? d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        : d.toLocaleDateString([], { day: 'numeric', month: 'short' });
    } catch (e) { return ''; }
  }

  function unreadCount(notices) {
    return (notices || []).filter(function (n) { return !n.read; }).length;
  }

  function rowsHtml(notices, selId) {
    return (notices || []).map(function (e) {
      return '<div class="ib-row' + (e.read ? '' : ' unread')
           + (e.notice_id === selId ? ' sel' : '')
           + '" data-id="' + esc(e.notice_id) + '">'
           + '<span class="ib-dot"></span>'
           + '<span class="ib-meta">'
           +   '<span class="ib-subj">' + esc(e.title) + '</span>'
           +   (e.personal ? '<div class="ib-tag">For you</div>' : '')
           +   '<div class="ib-when">' + esc(fmtWhen(e.released_at)) + '</div>'
           + '</span>'
           + '</div>';
    }).join('');
  }

  function readerHtml(e, sanitize) {
    if (!e) return '';
    var ctas = Array.isArray(e.cta_buttons) ? e.cta_buttons : [];
    return '<h3 class="ib-rtitle">' + esc(e.title) + '</h3>'
         + '<div class="ib-rwhen">' + esc(fmtWhen(e.released_at)) + '</div>'
         + '<div class="ib-body">' + sanitize(e.body_html || '') + '</div>'
         + (ctas.length ? '<div class="ib-ctas">' + ctas.map(function (b, i) {
             return '<button class="ib-cta' + (b && b.style === 'primary' ? ' primary' : '')
                  + '" data-i="' + i + '">'
                  + esc((b && (b.label_en || b.label)) || '') + '</button>';
           }).join('') + '</div>' : '');
  }

  if (!document.getElementById('uecp-screen-inbox-css')) {
    var s = document.createElement('style'); s.id = 'uecp-screen-inbox-css';
    s.textContent = [
'uecp-screen-inbox{flex:1;min-height:0;display:flex;flex-direction:column}',
'uecp-screen-inbox .ib-head{flex-shrink:0;padding:14px 18px 10px;border-bottom:1px solid var(--ue-line-soft);display:flex;align-items:baseline;gap:10px}',
'uecp-screen-inbox .ib-title{font-size:15px;font-weight:var(--ue-fw-semi)}',
'uecp-screen-inbox .ib-count{font-size:11.5px;color:var(--ue-text-lo)}',
'uecp-screen-inbox .ib-badge{display:inline-block;min-width:17px;padding:0 5px;height:17px;line-height:17px;text-align:center;font-size:10.5px;font-weight:var(--ue-fw-semi);border-radius:9px;background:var(--ue-danger);color:#fff}',
'uecp-screen-inbox .ib-cols{flex:1;min-height:0;display:flex}',
'uecp-screen-inbox .ib-list{width:270px;flex-shrink:0;border-right:1px solid var(--ue-line-soft);overflow-y:auto;background:var(--ue-panel)}',
'uecp-screen-inbox .ib-read{flex:1;min-width:0;overflow-y:auto;padding:18px 22px}',
'uecp-screen-inbox .ib-row{padding:9px 12px;border-bottom:1px solid var(--ue-line-soft);cursor:pointer;display:flex;gap:8px;align-items:flex-start}',
'uecp-screen-inbox .ib-row:hover{background:var(--ue-line-soft)}',
'uecp-screen-inbox .ib-row.sel{background:var(--ue-accent-soft)}',
'uecp-screen-inbox .ib-dot{width:7px;height:7px;border-radius:50%;flex-shrink:0;margin-top:5px;background:transparent}',
'uecp-screen-inbox .ib-row.unread .ib-dot{background:var(--ue-danger)}',
'uecp-screen-inbox .ib-meta{min-width:0;flex:1}',
'uecp-screen-inbox .ib-subj{font-size:12.5px;color:var(--ue-text-mid);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}',
'uecp-screen-inbox .ib-row.unread .ib-subj{color:var(--ue-text-hi);font-weight:var(--ue-fw-semi)}',
'uecp-screen-inbox .ib-when{font-size:10.5px;color:var(--ue-text-lo);margin-top:2px}',
'uecp-screen-inbox .ib-tag{font-size:9.5px;color:var(--ue-accent-bright);text-transform:uppercase;letter-spacing:.04em;margin-top:2px}',
'uecp-screen-inbox .ib-rtitle{font-size:17px;font-weight:var(--ue-fw-semi);margin:0 0 3px}',
'uecp-screen-inbox .ib-rwhen{font-size:11.5px;color:var(--ue-text-lo);margin-bottom:14px}',
'uecp-screen-inbox .ib-body{font-size:13px;line-height:1.6;color:var(--ue-text-mid)}',
'uecp-screen-inbox .ib-body p{margin:0 0 10px}',
'uecp-screen-inbox .ib-body a{color:var(--ue-accent-bright);cursor:pointer;text-decoration:underline}',
'uecp-screen-inbox .ib-body .c-accent{color:var(--ue-accent-bright)}',
'uecp-screen-inbox .ib-body .c-warn{color:var(--ue-warn)}',
'uecp-screen-inbox .ib-body .c-danger{color:var(--ue-danger)}',
'uecp-screen-inbox .ib-body .c-muted{color:var(--ue-text-lo)}',
'uecp-screen-inbox .ib-ctas{display:flex;flex-wrap:wrap;gap:8px;margin-top:16px}',
'uecp-screen-inbox .ib-cta{background:var(--ue-elev);border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);color:var(--ue-text-hi);padding:6px 12px;cursor:pointer;font-size:12px}',
'uecp-screen-inbox .ib-cta:hover{background:var(--ue-line-soft)}',
'uecp-screen-inbox .ib-cta.primary{background:var(--ue-accent);border-color:var(--ue-accent);color:#1b1710;font-weight:var(--ue-fw-semi)}',
'uecp-screen-inbox .ib-empty{padding:28px 22px;color:var(--ue-text-lo);font-size:12.5px}',
'uecp-screen-inbox .ib-menu{position:fixed;z-index:1400;background:var(--ue-panel);border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);padding:4px;box-shadow:0 6px 18px rgba(0,0,0,.35);display:none}',
'uecp-screen-inbox .ib-menu.open{display:block}',
'uecp-screen-inbox .ib-mi{padding:6px 14px;font-size:12px;color:var(--ue-text-hi);cursor:pointer;border-radius:4px;white-space:nowrap}',
'uecp-screen-inbox .ib-mi:hover{background:var(--ue-line-soft)}'
    ].join('\n');
    document.head.appendChild(s);
  }

  class InboxScreen extends HTMLElement {
    connectedCallback() {
      this._notices = [];
      this._selId = null;
      this._build();
      var self = this;
      this._subs = [window.uecp.on('inbox.state', function (d) { self._onState(d); })];

      this._renderList(0);
      this._renderReader();

      window.uecp.call('inbox_action', { verb: 'list' });
    }

    disconnectedCallback() {
      (this._subs || []).forEach(function (u) { u(); });
      this._subs = [];
      if (this._docClick) document.removeEventListener('click', this._docClick);
    }

    _build() {
      this.innerHTML =
        '<div class="ib-head">'
      +   '<span class="ib-title">Inbox</span>'
      +   '<span class="ib-count"></span>'
      + '</div>'
      + '<div class="ib-cols">'
      +   '<div class="ib-list"></div>'
      +   '<div class="ib-read"></div>'
      + '</div>'
      + '<div class="ib-menu"><div class="ib-mi" data-act="delete">Delete message</div></div>';

      var self = this;
      this._docClick = function () { self._closeMenu(); };
      document.addEventListener('click', this._docClick);

      this.querySelector('.ib-menu').addEventListener('click', function (ev) {
        ev.stopPropagation();
        if (ev.target && ev.target.dataset.act === 'delete') self._deleteMenuTarget();
      });
    }

    _onState(d) {
      if (!d) return;
      this._notices = Array.isArray(d.notices) ? d.notices : [];
      var stillThere = this._notices.some(function (n) { return n.notice_id === this._selId; }, this);
      if (!stillThere) this._selId = null;
      this._renderList(d.unread);
      this._renderReader();
    }

    _renderList(unread) {
      var list = this.querySelector('.ib-list');
      var count = this.querySelector('.ib-count');
      var n = typeof unread === 'number' ? unread : unreadCount(this._notices);
      count.innerHTML = n > 0
        ? '<span class="ib-badge" data-i18n-skip>' + esc(n) + '</span>'
        : '<span>All read</span>';

      if (this._notices.length === 0) {
        list.innerHTML = '';
        return;
      }

      var self = this;
      list.innerHTML = rowsHtml(this._notices, this._selId);

      Array.prototype.forEach.call(list.querySelectorAll('.ib-row'), function (row) {
        var id = Number(row.dataset.id);
        row.addEventListener('click', function () { self._select(id); });
        row.addEventListener('contextmenu', function (ev) {
          ev.preventDefault(); ev.stopPropagation();
          self._openMenu(ev.clientX, ev.clientY, id);
        });
      });
    }

    _select(id) {
      this._selId = id;
      var entry = this._find(id);
      if (entry && !entry.read) {
        entry.read = true;
        window.uecp.call('inbox_action', { verb: 'read', id: id });
      }
      this._renderList();
      this._renderReader();
    }

    _find(id) {
      for (var i = 0; i < this._notices.length; i++) {
        if (this._notices[i].notice_id === id) return this._notices[i];
      }
      return null;
    }

    _renderReader() {
      var pane = this.querySelector('.ib-read');
      var e = this._selId != null ? this._find(this._selId) : null;

      if (!e) {
        pane.innerHTML = '<div class="ib-empty">' + (this._notices.length
          ? 'Select a message to read it.'
          : 'No messages yet. Anything sent to you shows up here and stays.')
          + '</div>';
        return;
      }

      var sanitize = (window.UECP && window.UECP.sanitizeNoticeHtml)
        ? window.UECP.sanitizeNoticeHtml
        : esc;

      var ctas = Array.isArray(e.cta_buttons) ? e.cta_buttons : [];
      pane.innerHTML = readerHtml(e, sanitize);

      Array.prototype.forEach.call(pane.querySelectorAll('a[data-href]'), function (a) {
        a.addEventListener('click', function (ev) {
          ev.preventDefault();
          window.uecp.call('open_external_url', { url: a.getAttribute('data-href') });
        });
      });

      Array.prototype.forEach.call(pane.querySelectorAll('.ib-cta'), function (btn) {
        btn.addEventListener('click', function () {
          var b = ctas[Number(btn.dataset.i)];
          if (b && b.url) window.uecp.call('open_external_url', { url: b.url });
        });
      });
    }

    _openMenu(x, y, id) {
      var m = this.querySelector('.ib-menu');
      this._menuId = id;
      m.style.left = x + 'px';
      m.style.top = y + 'px';
      m.classList.add('open');
      var r = m.getBoundingClientRect();
      if (r.right > window.innerWidth) m.style.left = Math.max(0, x - r.width) + 'px';
      if (r.bottom > window.innerHeight) m.style.top = Math.max(0, y - r.height) + 'px';
    }

    _closeMenu() {
      var m = this.querySelector('.ib-menu');
      if (m) m.classList.remove('open');
      this._menuId = null;
    }

    _deleteMenuTarget() {
      var id = this._menuId;
      this._closeMenu();
      if (id == null) return;

      this._notices = this._notices.filter(function (n) { return n.notice_id !== id; });
      if (this._selId === id) this._selId = null;
      window.uecp.call('inbox_action', { verb: 'delete', id: id });
      this._renderList();
      this._renderReader();
    }
  }

  InboxScreen.__pure = { unreadCount: unreadCount, rowsHtml: rowsHtml, readerHtml: readerHtml, fmtWhen: fmtWhen };

  customElements.define('uecp-screen-inbox', InboxScreen);
})();
