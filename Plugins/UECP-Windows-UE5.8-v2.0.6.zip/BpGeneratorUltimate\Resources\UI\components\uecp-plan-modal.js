(function () {
  if (!document.getElementById('uecp-plan-modal-css')) {
    const s = document.createElement('style'); s.id = 'uecp-plan-modal-css';
    s.textContent = `
uecp-plan-modal{display:contents}
/* Sized off .ue-overlay (inset:0) so the box shrinks with a narrow docked tab instead
   of running past its edges; 640px is now a cap rather than the width. */
uecp-plan-modal .pm-modal{width:calc(100% - 24px);max-width:640px;max-height:calc(100% - 40px)}
uecp-plan-modal .pm-header{display:flex;align-items:center;padding:14px 18px;border-bottom:1px solid var(--ue-line)}
uecp-plan-modal .pm-header h4{margin:0;font-size:var(--ue-fs-md);font-weight:var(--ue-fw-semi);color:var(--ue-text-hi);flex:1}
uecp-plan-modal .pm-close{cursor:pointer;color:var(--ue-text-lo);font-size:16px;line-height:1;background:none;border:none;padding:0}
uecp-plan-modal .pm-close:hover{color:var(--ue-text-hi)}
uecp-plan-modal .pm-body{display:flex;max-height:70vh;overflow:hidden}
uecp-plan-modal .pm-pane-current{flex:1;min-width:0;padding:14px 16px;border-right:1px solid var(--ue-line);overflow-y:auto}
uecp-plan-modal .pm-pane-library{width:230px;flex-shrink:0;padding:14px 16px;overflow-y:auto}
uecp-plan-modal .pm-label{font-size:9.5px;letter-spacing:.06em;text-transform:uppercase;color:var(--ue-text-lo);margin:10px 0 4px}
uecp-plan-modal .pm-label:first-child{margin-top:0}
uecp-plan-modal .pm-brief{width:100%;box-sizing:border-box;min-height:70px;font-size:12px;line-height:1.5;background:var(--ue-input,var(--ue-bg));border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);padding:6px 8px;color:var(--ue-text-hi);resize:vertical;font-family:inherit}
uecp-plan-modal .pm-brief:focus{border-color:var(--ue-accent);outline:none}
uecp-plan-modal .pm-steps-row{display:flex;gap:8px;padding:4px 0;align-items:baseline;border-bottom:1px solid var(--ue-line-soft)}
uecp-plan-modal .pm-steps-row:last-child{border-bottom:none}
uecp-plan-modal .pm-step-num{font-family:var(--ue-font-mono);font-size:11px;font-weight:500;color:var(--ue-accent-bright);min-width:20px;flex-shrink:0}
uecp-plan-modal .pm-empty{font-size:11px;color:var(--ue-text-lo);font-style:italic;padding:6px 0}
uecp-plan-modal .pm-clear-btn{margin-top:10px;font-family:var(--ue-font-mono);font-size:10px;padding:4px 8px;border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);background:none;color:var(--ue-text-mid);cursor:pointer}
uecp-plan-modal .pm-clear-btn:hover{border-color:var(--ue-accent);color:var(--ue-accent-bright)}
uecp-plan-modal .pm-search{width:100%;box-sizing:border-box;background:var(--ue-input,var(--ue-bg));border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);padding:5px 8px;font-size:11px;color:var(--ue-text-hi);margin-bottom:8px}
uecp-plan-modal .pm-search:focus{border-color:var(--ue-accent);outline:none}
uecp-plan-modal .pm-lib-list{display:flex;flex-direction:column;gap:5px}
uecp-plan-modal .pm-lib-row{display:flex;align-items:center;gap:6px;padding:6px 8px;border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);cursor:pointer}
uecp-plan-modal .pm-lib-row:hover{border-color:var(--ue-accent)}
uecp-plan-modal .pm-lib-row.current{border-color:var(--ue-accent-bright);background:var(--ue-line-soft)}
uecp-plan-modal .pm-lib-main{flex:1;min-width:0}
uecp-plan-modal .pm-lib-title{font-family:var(--ue-font-mono);font-size:12px;font-weight:500;color:var(--ue-text-hi);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
uecp-plan-modal .pm-lib-meta{font-size:10.5px;color:var(--ue-text-lo);margin-top:2px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
uecp-plan-modal .pm-lib-assign{flex-shrink:0;font-family:var(--ue-font-mono);font-size:10px;padding:2px 8px;border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);color:var(--ue-text-mid);background:none;cursor:pointer}
uecp-plan-modal .pm-lib-assign:hover{border-color:var(--ue-accent);color:var(--ue-accent-bright)}
uecp-plan-modal .pm-lib-current-tag{flex-shrink:0;font-family:var(--ue-font-mono);font-size:10px;padding:2px 8px;border:1px solid var(--ue-accent-bright);border-radius:var(--ue-r-sm);color:var(--ue-accent-bright)}
uecp-plan-modal .pm-lib-del{flex-shrink:0;width:16px;height:16px;display:flex;align-items:center;justify-content:center;background:none;border:none;cursor:pointer;color:var(--ue-text-lo);font-size:13px;line-height:1;padding:0;opacity:0}
uecp-plan-modal .pm-lib-row:hover .pm-lib-del{opacity:1}
uecp-plan-modal .pm-lib-del:hover{color:var(--ue-danger,#cf6b5a)}
uecp-plan-modal .pm-preview{margin-top:10px;padding:8px;border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm);background:var(--ue-bg);display:none}`;
    document.head.appendChild(s);
  }

  class UecpPlanModal extends HTMLElement {
    connectedCallback() {
      this._isOpen = false;
      this._plan = null;
      this._library = [];
      this._preview = null;
      this._filter = '';

      const self = this;
      this._u1 = window.uecp.on('plan.state', function (d) { self._plan = d || {}; if (self._isOpen) self._renderCurrent(); });
      this._u2 = window.uecp.on('plan.list', function (d) {
        self._library = Array.isArray(d) ? d : (d && Array.isArray(d.plans) ? d.plans : []);
        if (self._isOpen) self._renderLibrary();
      });
      this._u3 = window.uecp.on('plan.preview', function (d) { self._preview = d || null; if (self._isOpen) self._renderPreview(); });
    }

    disconnectedCallback() {
      if (this._u1) { this._u1(); this._u1 = null; }
      if (this._u2) { this._u2(); this._u2 = null; }
      if (this._u3) { this._u3(); this._u3 = null; }
    }

    open() {
      this._isOpen = true;
      this._filter = '';
      this._preview = null;
      this._render();
      window.uecp.call('load_plan_picker', {});
    }

    close() {
      this._isOpen = false;
      this.innerHTML = '';
    }

    _render() {
      this.innerHTML =
        '<div class="ue-overlay" id="pm-overlay">' +
          '<div class="ue-modal pm-modal">' +
            '<div class="pm-header"><h4>Plan</h4><button class="pm-close" type="button">✕</button></div>' +
            '<div class="pm-body">' +
              '<div class="pm-pane-current"></div>' +
              '<div class="pm-pane-library"></div>' +
            '</div>' +
          '</div>' +
        '</div>';

      const self = this;
      this.querySelector('.pm-close').addEventListener('click', function () { self.close(); });
      window.UECP.dom.bindBackdropClose(this.querySelector('#pm-overlay'), function () { self.close(); });

      this._renderCurrent();
      this._renderLibrary();
    }

    _renderCurrent() {
      const pane = this.querySelector('.pm-pane-current');
      if (!pane) return;
      const E = window.UECP.escapeHtml;
      const d = this._plan || {};
      const brief = d.context || d.brief || '';
      const steps = d.steps || [];
      const hasPlan = !!(d.title || d.context);

      let html = '<div class="pm-label">Current chat’s plan</div>';
      html += '<textarea class="pm-brief" placeholder="Plan brief: goal, assets &amp; paths, conventions, key decisions">' + E(brief) + '</textarea>';
      if (steps.length) {
        html += '<div class="pm-label">Steps</div>';
        steps.forEach(function (step, i) {
          html += '<div class="pm-steps-row">' +
            '<span class="pm-step-num">' + String(i + 1).padStart(2, '0') + '</span>' +
            '<div>' + E(step.asset || '') + (step.desc ? ' — ' + E(step.desc) : '') + '</div>' +
          '</div>';
        });
      }
      if (hasPlan) {
        html += '<button class="pm-clear-btn" type="button">Clear plan</button>';
      }
      pane.innerHTML = html;

      const briefEl = pane.querySelector('.pm-brief');
      if (briefEl) {
        briefEl.addEventListener('change', function () {
          window.uecp.call('set_plan_brief', { text: (briefEl.value || '').trim() });
        });
      }
      const clearBtn = pane.querySelector('.pm-clear-btn');
      if (clearBtn) {
        clearBtn.addEventListener('click', function () { window.uecp.call('clear_plan', {}); });
      }
    }

    _libRowHtml(p) {
      const E = window.UECP.escapeHtml;
      const cur = !!p.is_current;
      const meta = p.context_snippet ? E(p.context_snippet) : (p.created_at ? E(p.created_at) : '');
      const action = cur
        ? '<span class="pm-lib-current-tag">Current</span>'
        : '<button class="pm-lib-assign" data-assign="' + E(p.conv_id) + '">Assign</button>' +
          '<button class="pm-lib-del" data-del="' + E(p.conv_id) + '" title="Delete plan">×</button>';
      return '<div class="pm-lib-row' + (cur ? ' current' : '') + '" data-conv="' + E(p.conv_id) + '">' +
        '<div class="pm-lib-main">' +
          '<div class="pm-lib-title">' + E(p.title || 'Untitled') + '</div>' +
          (meta ? '<div class="pm-lib-meta">' + meta + '</div>' : '') +
        '</div>' + action +
      '</div>';
    }

    _renderLibrary() {
      const pane = this.querySelector('.pm-pane-library');
      if (!pane) return;
      const self = this;

      pane.innerHTML =
        '<div class="pm-label">Plan library</div>' +
        '<input class="pm-search" type="text" placeholder="Search plans…" value="' + window.UECP.escapeHtml(this._filter || '') + '">' +
        '<div class="pm-lib-list"></div>' +
        '<div class="pm-preview"></div>';

      pane.querySelector('.pm-search').addEventListener('input', function (e) {
        self._filter = e.target.value || '';
        self._renderLibraryList();
      });

      this._renderLibraryList();
      this._renderPreview();
    }

    _renderLibraryList() {
      const pane = this.querySelector('.pm-pane-library');
      const listEl = pane ? pane.querySelector('.pm-lib-list') : null;
      if (!listEl) return;
      const self = this;
      const q = (this._filter || '').toLowerCase().trim();
      const all = this._library || [];
      const plans = !q ? all : all.filter(function (p) {
        return ((p.title || '').toLowerCase().indexOf(q) >= 0) ||
               ((p.context_snippet || '').toLowerCase().indexOf(q) >= 0);
      });

      if (!plans.length) {
        listEl.innerHTML = '<div class="pm-empty">No saved plans.</div>';
        return;
      }
      listEl.innerHTML = plans.map(function (p) { return self._libRowHtml(p); }).join('');

      listEl.querySelectorAll('[data-assign]').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
          e.stopPropagation();
          window.uecp.call('import_plan', { src: btn.dataset.assign });
        });
      });
      listEl.querySelectorAll('[data-del]').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
          e.stopPropagation();
          var id = btn.dataset.del;
          window.UECP.dialog.confirm('Delete plan', 'Delete this saved plan? This cannot be undone.').then(function (ok) {
            if (!ok) return;
            window.uecp.call('delete_plan', { id: id });
          });
        });
      });
      listEl.querySelectorAll('.pm-lib-row').forEach(function (row) {
        row.addEventListener('click', function () {
          window.uecp.call('preview_plan', { src: row.dataset.conv });
        });
      });
    }

    _renderPreview() {
      const pane = this.querySelector('.pm-pane-library');
      const pv = pane ? pane.querySelector('.pm-preview') : null;
      if (!pv) return;
      const E = window.UECP.escapeHtml;
      const plan = this._preview;
      const brief = (plan && plan.context) ? plan.context : '';
      if (!plan || (!brief && !plan.title)) { pv.style.display = 'none'; pv.innerHTML = ''; return; }
      pv.innerHTML = '<div class="pm-lib-title">' + E(plan.title || 'Plan') + '</div>' +
        '<div class="pm-lib-meta">' + E(brief) + '</div>';
      pv.style.display = 'block';
    }
  }

  customElements.define('uecp-plan-modal', UecpPlanModal);

  window.UECP = window.UECP || {};
  window.UECP.openPlanModal = function () {
    var ov = document.querySelector('uecp-plan-modal');
    if (!ov) { ov = document.createElement('uecp-plan-modal'); document.body.appendChild(ov); }
    ov.open();
    return ov;
  };
})();
