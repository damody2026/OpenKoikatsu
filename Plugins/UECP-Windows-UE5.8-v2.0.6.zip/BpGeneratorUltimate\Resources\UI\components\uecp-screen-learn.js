(function () {
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  const REQ_TIMEOUT_MS = 20000;
  const PORTAL = 'https://www.gamedevcore.com';

  const TABS = [
    { id: 'courses',      label: 'Courses',      native: true },
    { id: 'docs',         label: 'Docs',         path: '/docs/bpgenerator-ultimate' },
    { id: 'achievements', label: 'Achievements' },
    { id: 'leaderboard',  label: 'Leaderboard' },
    { id: 'community',    label: 'Community' },
  ];

  if (!document.getElementById('uecp-screen-learn-css')) {
    const s = document.createElement('style'); s.id = 'uecp-screen-learn-css';
    s.textContent = `
uecp-screen-learn{display:flex;flex:1;min-width:0;min-height:0;flex-direction:column;background:var(--ue-bg);overflow:hidden}
uecp-screen-learn .lr-scroll{flex:1;min-height:0;overflow-y:auto;overflow-x:hidden}
uecp-screen-learn .lr-pad{padding:20px 24px;max-width:900px;margin:0 auto}
uecp-screen-learn .lr-msg{display:flex;align-items:center;justify-content:center;flex:1;min-height:0;color:var(--ue-text-mid);font-size:13px;padding:24px;text-align:center}
uecp-screen-learn .lr-hdr{display:flex;align-items:center;gap:16px;padding:14px 24px;border-bottom:1px solid var(--ue-line);flex:0 0 auto}
uecp-screen-learn .lr-lvl{font-weight:var(--ue-fw-semi);color:var(--ue-text-hi);font-size:14px}
uecp-screen-learn .lr-xpwrap{flex:1;min-width:0;max-width:280px}
uecp-screen-learn .lr-xpbar{height:6px;border-radius:3px;background:var(--ue-line-soft);overflow:hidden}
uecp-screen-learn .lr-xpfill{height:100%;background:var(--ue-accent);border-radius:3px}
uecp-screen-learn .lr-xptxt{font-size:11px;color:var(--ue-text-lo);margin-top:4px}
uecp-screen-learn .lr-streak{font-size:12px;color:var(--ue-text-mid)}
uecp-screen-learn .lr-course{margin-bottom:28px}
uecp-screen-learn .lr-ctitle{font-size:15px;font-weight:var(--ue-fw-semi);color:var(--ue-text-hi);margin:0 0 4px}
uecp-screen-learn .lr-cdesc{font-size:12px;color:var(--ue-text-lo);margin:0 0 12px}
uecp-screen-learn .lr-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:10px}
uecp-screen-learn .lr-node{text-align:left;background:var(--ue-panel);border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);padding:12px;cursor:pointer;color:inherit;font:inherit;display:flex;flex-direction:column;gap:6px}
uecp-screen-learn .lr-node:hover:not(.is-locked){border-color:var(--ue-accent)}
uecp-screen-learn .lr-node.is-locked{opacity:.5;cursor:not-allowed}
uecp-screen-learn .lr-node.is-done{border-color:var(--ue-accent-bright)}
uecp-screen-learn .lr-ntop{display:flex;align-items:center;gap:8px}
uecp-screen-learn .lr-nemoji{font-size:16px;line-height:1}
uecp-screen-learn .lr-ntitle{font-size:13px;font-weight:var(--ue-fw-semi);color:var(--ue-text-hi);flex:1;min-width:0}
uecp-screen-learn .lr-ndesc{font-size:11px;color:var(--ue-text-lo);line-height:1.4}
uecp-screen-learn .lr-nfoot{display:flex;align-items:center;justify-content:space-between;gap:8px;font-size:11px;color:var(--ue-text-mid)}
uecp-screen-learn .lr-badge{border:1px solid var(--ue-line);border-radius:10px;padding:1px 7px;font-size:10px;color:var(--ue-text-lo)}
uecp-screen-learn .lr-badge.is-auto{border-color:var(--ue-accent);color:var(--ue-accent)}
/* Sticky so a long lesson can be left without scrolling back to the top. It is a DIRECT
   child of the scroller and carries no negative margins: sticky resolves against the
   element's margin box, so a negative top margin parks the stuck position outside the
   scrollport and the bar just scrolls away. The inner div re-applies the column width. */
uecp-screen-learn .lr-backbar{position:sticky;top:0;z-index:5;background:var(--ue-bg);border-bottom:1px solid var(--ue-line)}
uecp-screen-learn .lr-backbar-inner{max-width:900px;margin:0 auto;padding:12px 24px}
uecp-screen-learn .lr-back{background:none;border:none;color:var(--ue-text-mid);font:inherit;font-size:12px;cursor:pointer;padding:4px 8px 4px 0;display:inline-flex;align-items:center;gap:7px}
uecp-screen-learn .lr-back:hover{color:var(--ue-text-hi)}
uecp-screen-learn .lr-back .lr-arrow{font-size:15px;line-height:1}
uecp-screen-learn .lr-body{color:var(--ue-text-mid);font-size:13px;line-height:1.65}
uecp-screen-learn .lr-body h2{color:var(--ue-text-hi);font-size:19px;margin:0 0 12px}
uecp-screen-learn .lr-body h3{color:var(--ue-text-hi);font-size:14px;margin:22px 0 8px}
uecp-screen-learn .lr-body p{margin:0 0 12px}
uecp-screen-learn .lr-body ul,uecp-screen-learn .lr-body ol{margin:0 0 12px;padding-left:22px}
uecp-screen-learn .lr-body li{margin-bottom:6px}
uecp-screen-learn .lr-body strong{color:var(--ue-text-hi)}
uecp-screen-learn .lr-body code{font-family:var(--ue-font-mono);font-size:12px;background:var(--ue-elev);padding:1px 4px;border-radius:3px}
uecp-screen-learn .lr-body blockquote{margin:0 0 12px;padding:10px 14px;border-left:2px solid var(--ue-accent);background:var(--ue-elev);border-radius:0 var(--ue-r-sm) var(--ue-r-sm) 0}
uecp-screen-learn .lr-body blockquote p{margin:0}
/* Lesson art is authored with an inline width:100%, so on a wide panel a 2:1
   banner stood ~640px tall and was the entire first screen before a word of the
   lesson. Capped by WIDTH rather than height: height then follows the aspect
   ratio on its own, with no crop and no letterboxing, and a narrow panel is
   unaffected because min() already yields 100% there. 640 also stops the common
   800x400 source being upscaled past its own resolution. */
uecp-screen-learn .lr-body img{max-width:min(100%,640px);height:auto;display:block;margin-left:auto;margin-right:auto}
/* Justified prose, with hyphenation on. Justify alone in a panel this narrow
   opens rivers of white space between words whenever a long word wraps;
   hyphens:auto lets the breaks happen inside words instead. Headings and the
   action row stay ragged-right -- justifying a two-word heading just stretches
   it across the column. */
uecp-screen-learn .lr-body p,
uecp-screen-learn .lr-body li{text-align:justify;hyphens:auto;-webkit-hyphens:auto}
uecp-screen-learn .lr-actions{margin:24px 0 8px;padding-top:16px;border-top:1px solid var(--ue-line);display:flex;align-items:center;gap:12px;flex-wrap:wrap}
uecp-screen-learn .lr-btn{background:var(--ue-accent);border:none;border-radius:var(--ue-r-sm);color:#fff;font:inherit;font-size:13px;font-weight:var(--ue-fw-semi);padding:8px 16px;cursor:pointer}
uecp-screen-learn .lr-btn:disabled{opacity:.5;cursor:default}
uecp-screen-learn .lr-note{font-size:12px;color:var(--ue-text-lo);flex:1;min-width:180px}
uecp-screen-learn .lr-err{color:var(--ue-danger);font-size:12px}
uecp-screen-learn .lr-tabs{display:flex;gap:2px;padding:0 24px;border-bottom:1px solid var(--ue-line);flex:0 0 auto;overflow-x:auto}
uecp-screen-learn .lr-tab{background:none;border:none;border-bottom:2px solid transparent;color:var(--ue-text-lo);font:inherit;font-size:12.5px;padding:10px 12px;cursor:pointer;white-space:nowrap}
uecp-screen-learn .lr-tab:hover{color:var(--ue-text-mid)}
uecp-screen-learn .lr-tab.is-on{color:var(--ue-text-hi);border-bottom-color:var(--ue-accent)}
uecp-screen-learn .lr-frame{flex:1;min-height:0;border:none;width:100%;display:block}`;
    document.head.appendChild(s);
  }

  class UecpScreenLearn extends HTMLElement {
    connectedCallback() {
      this._lang = 'en';
      this._reqSeq = 0;
      this._pending = {};
      this._catalog = null;
      this._view = 'loading';
      this._detected = {};
      this._tab = 'courses';
      this._subscribe();
      this._render();
      this._loadCatalog();
    }

    disconnectedCallback() {
      (this._subs || []).forEach(function (u) { try { u(); } catch (e) {} });
      this._subs = [];
      if (this._onMsg) { window.removeEventListener('message', this._onMsg); this._onMsg = null; }
      Object.keys(this._pending || {}).forEach((id) => {
        clearTimeout(this._pending[id].timer);
      });
      this._pending = {};
    }

    _subscribe() {
      const self = this;
      this._subs = [
        window.uecp.on('learning.api_result', function (p) { self._onApiResult(p); }),
        window.uecp.on('settings.init', function (s) {
          if (s && s.language) self._setLang(s.language);
        }),
        window.uecp.on('language.changed', function (p) {
          if (p && p.lang) self._setLang(p.lang);
        }),
        window.uecp.on('learning.node_detected', function (p) {
          if (p && p.node_slug) self._onDetected(p.node_slug);
        }),
        window.uecp.on('learning.progress_changed', function () { self._loadCatalog(true); }),
      ];
    }

    _setLang(lang) {
      if (!lang || lang === this._lang) return;
      this._lang = lang;
      this._catalog = null;
      this._loadCatalog();
    }

    _identity() {
      return {
        key: (typeof window._learnLicenseKey === 'string' ? window._learnLicenseKey : '') || '',
        hw: (typeof window._learnHardwareId === 'string' ? window._learnHardwareId : '') || '',
      };
    }

    _frameUrl(tab) {
      const id = this._identity();
      let url = PORTAL + (tab.path || '/learn');
      const q = [];
      q.push('embed=true');
      if (!tab.path) { q.push('tab=' + encodeURIComponent(tab.id)); q.push('nav=hidden'); }
      if (id.key) q.push('licenseKey=' + encodeURIComponent(id.key));
      if (id.hw) q.push('hardwareId=' + encodeURIComponent(id.hw));
      if (this._lang) q.push('lang=' + encodeURIComponent(this._lang));
      return url + (q.length ? '?' + q.join('&') : '');
    }

    _bindFrameBridge() {
      if (this._onMsg) return;
      this._onMsg = function (e) {
        const d = e && e.data;
        if (!d || typeof d !== 'object') return;
        if (d.type === 'requestImageUpload') window.uecp.call('request_image_upload', {});
        else if (d.type === 'requestClipboardImage') window.uecp.call('request_clipboard_image', {});
        else if (d.type === 'openExternal' && d.url) window.uecp.call('open_external_url', { url: d.url });
      };
      window.addEventListener('message', this._onMsg);
    }

    _setTab(id) {
      if (this._tab === id) return;
      this._tab = id;
      this._render();
    }

    _tabsHtml() {
      const cur = this._tab;
      return '<div class="lr-tabs">' + TABS.map(function (t) {
        return '<button class="lr-tab' + (t.id === cur ? ' is-on' : '') + '" data-tab="' + t.id + '">'
          + esc(t.label) + '</button>';
      }).join('') + '</div>';
    }

    _bindTabs() {
      const self = this;
      this.querySelectorAll('.lr-tab').forEach(function (b) {
        b.addEventListener('click', function () { self._setTab(b.getAttribute('data-tab')); });
      });
    }

    _api(endpoint, body) {
      const self = this;
      return new Promise(function (resolve, reject) {
        const reqId = 'lr' + (++self._reqSeq);
        const timer = setTimeout(function () {
          delete self._pending[reqId];
          reject(new Error('timeout'));
        }, REQ_TIMEOUT_MS);
        self._pending[reqId] = { resolve: resolve, reject: reject, timer: timer };
        window.uecp.call('learning_api', {
          endpoint: endpoint,
          req_id: reqId,
          body: Object.assign({ lang: self._lang }, body || {}),
        });
      });
    }

    _onApiResult(p) {
      if (!p || !p.req_id) return;
      const entry = this._pending[p.req_id];
      if (!entry) return;
      clearTimeout(entry.timer);
      delete this._pending[p.req_id];
      if (p.ok) entry.resolve(p.data || {});
      else entry.reject(new Error(p.error || 'request_failed'));
    }

    _loadCatalog(quiet) {
      const self = this;
      if (!quiet) { this._view = 'loading'; this._render(); }
      this._api('v2/catalog', {}).then(function (data) {
        self._catalog = data;
        if (self._view !== 'lesson') self._view = 'catalog';
        self._render();
      }).catch(function (err) {
        if (quiet) return;
        self._error = err && err.message;
        self._view = 'error';
        self._render();
      });
    }

    _openLesson(slug) {
      const self = this;
      this._view = 'lesson';
      this._lesson = null;
      this._lessonErr = '';
      this._render();
      this._api('v2/lesson', { nodeSlug: slug }).then(function (data) {
        self._lesson = data;
        self._render();
      }).catch(function (err) {
        self._lessonErr = (err && err.message) || 'request_failed';
        self._render();
      });
    }

    _complete(slug, btn) {
      const self = this;
      if (btn) btn.disabled = true;
      this._lessonErr = '';
      this._api('v2/complete', { nodeSlug: slug }).then(function () {
        self._loadCatalog(true);
        self._openLesson(slug);
      }).catch(function (err) {
        const code = (err && err.message) || '';
        self._lessonErr = code === 'requires_auto_detect'
          ? 'This step completes on its own once you do it in the editor. If nothing happens, enable usage data sharing in Settings, which is what lets the check run.'
          : code === 'milestone_auto_only'
            ? 'Milestones unlock once the lessons they depend on are complete.'
            : 'Could not complete this step. Please try again.';
        if (btn) btn.disabled = false;
        self._render();
      });
    }

    _onDetected(slug) {
      this._detected[slug] = true;
      this._render();
    }

    _render() {
      const tabs = this._tabsHtml();
      const tab = TABS.filter(function (t) { return t.id === this._tab; }, this)[0] || TABS[0];

      if (!tab.native) {
        this.innerHTML = tabs + '<iframe class="lr-frame" src="' + esc(this._frameUrl(tab))
          + '" allow="clipboard-read; clipboard-write"></iframe>';
        this._bindTabs();
        this._bindFrameBridge();
        return;
      }

      if (this._view === 'loading') { this.innerHTML = tabs + '<div class="lr-msg">Loading...</div>'; this._bindTabs(); return; }
      if (this._view === 'error') {
        this.innerHTML = tabs + '<div class="lr-msg">Could not load your courses.<br>'
          + esc(this._error || '') + '</div>';
        this._bindTabs();
        return;
      }
      if (this._view === 'lesson') { this._renderLesson(tabs); this._bindTabs(); return; }
      this._renderCatalog(tabs);
      this._bindTabs();
    }

    _renderHeader() {
      const u = (this._catalog && this._catalog.user) || {};
      const into = Number(u.xpIntoLevel || 0);
      const need = Number(u.xpForNextLevel || 0);
      const pct = need > 0 ? Math.max(0, Math.min(100, (into / need) * 100)) : 0;
      return '<div class="lr-hdr">'
        + '<div class="lr-lvl">Level ' + esc(u.level == null ? 1 : u.level) + '</div>'
        + '<div class="lr-xpwrap"><div class="lr-xpbar"><div class="lr-xpfill" style="width:' + pct.toFixed(1) + '%"></div></div>'
        + '<div class="lr-xptxt">' + esc(into) + ' / ' + esc(need) + ' XP</div></div>'
        + (u.currentStreak ? '<div class="lr-streak">' + esc(u.currentStreak) + ' day streak</div>' : '')
        + '</div>';
    }

    _renderCatalog(tabs) {
      const courses = (this._catalog && this._catalog.courses) || [];
      let html = (tabs || '') + this._renderHeader() + '<div class="lr-scroll"><div class="lr-pad">';
      if (!courses.length) html += '<div class="lr-msg">No courses available yet.</div>';

      courses.forEach(function (c) {
        html += '<div class="lr-course"><h3 class="lr-ctitle">' + esc(c.title) + '</h3>';
        if (c.description) html += '<p class="lr-cdesc">' + esc(c.description) + '</p>';
        html += '<div class="lr-grid">';
        (c.nodes || []).forEach(function (n) {
          const locked = n.status === 'locked';
          const done = n.status === 'completed';
          const cls = 'lr-node' + (locked ? ' is-locked' : '') + (done ? ' is-done' : '');
          html += '<button class="' + cls + '" data-slug="' + esc(n.slug) + '"'
            + (locked ? ' disabled' : '') + '>'
            + '<div class="lr-ntop">'
            + (n.iconEmoji ? '<span class="lr-nemoji">' + esc(n.iconEmoji) + '</span>' : '')
            + '<span class="lr-ntitle">' + esc(n.title) + '</span></div>'
            + (n.shortDescription ? '<div class="lr-ndesc">' + esc(n.shortDescription) + '</div>' : '')
            + '<div class="lr-nfoot"><span>' + (done ? 'Completed' : esc(n.xpReward || 0) + ' XP') + '</span>'
            + (n.autoDetectable ? '<span class="lr-badge is-auto">auto</span>'
                                : (n.nodeType === 'milestone' ? '<span class="lr-badge">milestone</span>' : ''))
            + '</div></button>';
        });
        html += '</div></div>';
      });

      html += '</div></div>';
      this.innerHTML = html;

      const self = this;
      this.querySelectorAll('.lr-node').forEach(function (b) {
        b.addEventListener('click', function () {
          const slug = b.getAttribute('data-slug');
          if (slug) self._openLesson(slug);
        });
      });
    }

    _renderLesson(tabs) {
      const l = this._lesson;
      let html = (tabs || '') + '<div class="lr-scroll">'
        + '<div class="lr-backbar"><div class="lr-backbar-inner"><button class="lr-back">'
        + '<span class="lr-arrow" aria-hidden="true">&larr;</span>All courses</button></div></div>'
        + '<div class="lr-pad">';

      if (!l && !this._lessonErr) {
        html += '<div class="lr-msg">Loading lesson...</div>';
      } else if (!l) {
        html += '<div class="lr-err">' + esc(this._lessonErr) + '</div>';
      } else {
        html += '<div class="lr-body">' + (l.contentHtml || '<p>This lesson has no content yet.</p>') + '</div>';

        const done = l.status === 'completed';
        const detected = !!this._detected[l.slug];
        html += '<div class="lr-actions">';
        if (done) {
          html += '<span class="lr-note">Completed. ' + esc(l.xpReward || 0) + ' XP earned.</span>';
        } else if (l.autoDetectable) {
          html += '<span class="lr-note">'
            + (detected ? 'Nice one, that counted. Confirming with the server...'
                        : 'This step completes on its own once you do it in the editor.')
            + '</span>';
        } else {
          html += '<button class="lr-btn" data-complete="' + esc(l.slug) + '">Mark complete</button>'
            + '<span class="lr-note">' + esc(l.xpReward || 0) + ' XP</span>';
        }
        html += '</div>';
        if (this._lessonErr) html += '<div class="lr-err">' + esc(this._lessonErr) + '</div>';
      }

      html += '</div></div>';
      this.innerHTML = html;

      const self = this;
      const back = this.querySelector('.lr-back');
      if (back) back.addEventListener('click', function () {
        self._view = 'catalog'; self._lesson = null; self._lessonErr = ''; self._render();
      });
      const btn = this.querySelector('[data-complete]');
      if (btn) btn.addEventListener('click', function () {
        self._complete(btn.getAttribute('data-complete'), btn);
      });
    }
  }

  customElements.define('uecp-screen-learn', UecpScreenLearn);
})();
