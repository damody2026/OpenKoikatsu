(function () {
  var W = [['xs', 520], ['sm', 720], ['md', 980]];
  var LTE = ['xs', 'sm', 'md'];
  var H_SHORT = 560;

  var _w = 0, _h = 0, _name = '', _short = null;
  var subs = [];
  var ro = null;

  function bucket(px) {
    for (var i = 0; i < W.length; i++) if (px < W[i][1]) return W[i][0];
    return 'lg';
  }

  function host() { return document.querySelector('uecp-app'); }

  function apply(w, h) {
    _w = w; _h = h;
    var name = bucket(w);
    var isShort = h > 0 && h < H_SHORT;
    if (name === _name && isShort === _short) return;
    _name = name; _short = isShort;

    var root = document.documentElement;
    root.setAttribute('data-w', name);
    var from = LTE.indexOf(name);
    for (var i = 0; i < LTE.length; i++) {
      root.classList.toggle('uw-lte-' + LTE[i], from >= 0 && i >= from);
    }
    root.classList.toggle('uh-short', isShort);

    var detail = { name: name, width: w, height: h, short: isShort };
    var list = subs.slice();
    for (var j = 0; j < list.length; j++) {
      try { list[j](detail); } catch (e) { console.error('[uecp] breakpoint handler', e); }
    }
  }

  function measure() {
    var el = host();
    var de = document.documentElement;
    var w = (el && el.clientWidth) || (de && de.clientWidth) || 0;
    var h = (el && el.clientHeight) || (de && de.clientHeight) || 0;
    if (w > 0) apply(w, h);
  }

  function start() {
    var el = host();
    if (el && typeof ResizeObserver === 'function' && !ro) {
      ro = new ResizeObserver(function () { measure(); });
      ro.observe(el);
    }
    measure();
  }

  window.UECP = window.UECP || {};
  window.UECP.bp = {
    name: function () { return _name || 'lg'; },
    width: function () { return _w; },
    height: function () { return _h; },
    isNarrow: function () { return _name === 'xs' || _name === 'sm'; },
    isShort: function () { return !!_short; },
    onChange: function (fn) {
      subs.push(fn);
      return function () { var i = subs.indexOf(fn); if (i >= 0) subs.splice(i, 1); };
    },
    refresh: measure,
  };

  window.addEventListener('resize', measure);
  start();
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', start);
  }
})();
