(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) { root.UECP = root.UECP || {}; root.UECP.createI18n = api.createI18n; }
}(typeof self !== 'undefined' ? self : null, function () {
  function createI18n(dicts, lang) {
    let cur = lang || 'en';
    function lookup(l, key) { return dicts[l] && Object.prototype.hasOwnProperty.call(dicts[l], key) ? dicts[l][key] : undefined; }
    function t(key, vars) {
      let s = lookup(cur, key);
      if (s === undefined) s = lookup('en', key);
      if (s === undefined) s = key;
      if (vars) s = s.replace(/\{(\w+)\}/g, (m, k) => (k in vars ? String(vars[k]) : m));
      return s;
    }
    return {
      t,
      setLang(l) { cur = l; },
      getLang() { return cur; },
      merge(l, table) { dicts[l] = Object.assign(dicts[l] || {}, table); }
    };
  }
  return { createI18n };
}));
