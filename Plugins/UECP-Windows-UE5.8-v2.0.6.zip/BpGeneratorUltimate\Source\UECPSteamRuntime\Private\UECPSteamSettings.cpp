// Copyright 2026, BlueprintsLab, All rights reserved
#include "UECPSteamSettings.h"

UUECPSteamSettings::UUECPSteamSettings()
{
	CategoryName = TEXT("Plugins");
	SectionName  = TEXT("UECP Steam");
}

FName UUECPSteamSettings::GetCategoryName() const
{
	return TEXT("Plugins");
}

const UUECPSteamSettings* UUECPSteamSettings::Get()
{
	return GetDefault<UUECPSteamSettings>();
}
