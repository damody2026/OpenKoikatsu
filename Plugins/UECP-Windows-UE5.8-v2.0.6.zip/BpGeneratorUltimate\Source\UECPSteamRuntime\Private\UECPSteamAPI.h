// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "UECPSteamRuntimeModule.h"
#include "UECPSteamTypes.h"

#if UECP_WITH_STEAM

THIRD_PARTY_INCLUDES_START
#include "steam/steam_api.h"
#include "steam/steam_gameserver.h"
THIRD_PARTY_INCLUDES_END

#endif

namespace UECPSteam
{
	bool AcquireClient();

	void ReleaseClient();

	bool IsClientAvailable();

	bool IsOssSteamActive();

	void PumpCallbacks();

	EUECPSteamResult MapResult(int32 RawResult);

	FUECPSteamError MakeError(int32 RawResult, const FString& Context);

	void RunOnGameThread(TFunction<void()> Work);

#if UECP_WITH_STEAM
	ISteamApps*             Apps();
	ISteamUser*             User();
	ISteamFriends*          Friends();
	ISteamUserStats*        UserStats();
	ISteamUtils*            Utils();
	ISteamRemoteStorage*    RemoteStorage();
	ISteamUGC*              UGC();
	ISteamInput*            Input();
	ISteamInventory*        Inventory();
	ISteamMatchmaking*      Matchmaking();
	ISteamMatchmakingServers* MatchmakingServers();
	ISteamScreenshots*      Screenshots();
	ISteamMusic*            Music();
	ISteamParentalSettings* ParentalSettings();
	ISteamRemotePlay*       RemotePlay();
	ISteamNetworkingUtils*  NetworkingUtils();
	ISteamNetworkingSockets* NetworkingSockets();
	ISteamNetworkingMessages* NetworkingMessages();
	ISteamHTTP*             HTTP();

#if UECP_STEAM_SDK_VER >= 161
	ISteamTimeline*         Timeline();
#endif

	bool                    AcquireServer();
	void                    ReleaseServer();
	bool                    IsServerAvailable();
	ISteamGameServer*       GameServer();
	ISteamGameServerStats*  GameServerStats();
	void                    PumpServerCallbacks();

	FORCEINLINE CSteamID ToSteamID(int64 Raw) { return CSteamID(static_cast<uint64>(Raw)); }
	FORCEINLINE int64    FromSteamID(const CSteamID& Id) { return static_cast<int64>(Id.ConvertToUint64()); }
#endif
}
