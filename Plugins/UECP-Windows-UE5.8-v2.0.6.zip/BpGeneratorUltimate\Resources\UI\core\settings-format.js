(function (root, factory) {
  if (typeof module !== 'undefined' && module.exports) {
    module.exports = factory();
  } else {
    root.SettingsFormat = factory();
  }
}(typeof globalThis !== 'undefined' ? globalThis : this, function () {

  function derivePresentSlots(slots) {
    if (!Array.isArray(slots)) return [];
    return slots.filter(function (sl, i) {
      if (i === 0) return true;
      if (sl.bAdded || sl.added) return true;
      var prov = (sl.provider || '').toLowerCase();
      if (prov && prov !== 'free') return true;
      if (sl.apiKey) return true;
      return false;
    }).map(function (sl, _, arr) {
      var originalIdx = slots.indexOf(sl);
      return Object.assign({}, sl, { idx: originalIdx >= 0 ? originalIdx : (sl.index != null ? sl.index : sl.SlotIndex) });
    });
  }

  function parseKeybind(str) {
    if (!str || typeof str !== 'string') return null;
    str = str.trim();
    if (!str) return null;

    var modifiers = ['Ctrl', 'Alt', 'Shift', 'Meta', 'Win'];
    for (var i = 0; i < modifiers.length; i++) {
      var mod = modifiers[i];
      var prefix = mod + '+';
      if (str.indexOf(prefix) === 0) {
        return { modifier: mod, key: str.slice(prefix.length) };
      }
    }
    return { modifier: '', key: str };
  }

  function formatKeybind(obj) {
    if (!obj || typeof obj !== 'object') return '';
    var mod = (obj.modifier || '').trim();
    var key = (obj.key || '').trim();
    if (!key) return '';
    return mod ? mod + '+' + key : key;
  }

  function mapGitStatus(raw) {
    raw = raw || {};
    return {
      connected: raw.git_found === true && raw.is_repo === true,
      gitFound:  raw.git_found === true,
      isRepo:    raw.is_repo === true,
      branch:    raw.branch || '',
      remote:    raw.remote || '',
      modified:  raw.modified || 0,
      untracked: raw.untracked || 0,
      ahead:     raw.ahead || 0,
      behind:    raw.behind || 0,
      incoming:  Array.isArray(raw.incoming) ? raw.incoming : [],
    };
  }

  function mapBranches(raw) {
    var arr = Array.isArray(raw) ? raw : (raw && Array.isArray(raw.branches) ? raw.branches : []);
    var current = '';
    var list = [];
    arr.forEach(function (b) {
      if (!b || !b.name || b.name.indexOf('->') > -1) return;
      if (b.current) current = b.name;
      if (!b.remote) list.push(b.name);
    });
    return { current: current, list: list, all: arr };
  }

  function mapGitLog(raw) {
    if (Array.isArray(raw)) return raw;
    if (raw && Array.isArray(raw.commits)) return raw.commits;
    return [];
  }

  function parseExtensionsPending(data) {
    if (Array.isArray(data)) return { changes: data, requiresRestart: false };
    if (data && Array.isArray(data.changes)) {
      return { changes: data.changes, requiresRestart: data.requiresRestart === true };
    }
    return { changes: [], requiresRestart: false };
  }

  function mapUpstreamServer(srv) {
    srv = srv || {};
    const id = srv.id || '';
    const name = srv.displayName || srv.name || id;
    const state = String(srv.state || srv.status || '').toLowerCase();
    const ok = (state === 'loaded' || state === 'ok');
    const failed = (state === 'failed' || state === 'error' || state === 'preconditionsfailed' ||
                    state === 'licenselocked' || state === 'engineversionmismatch');
    const statusLabel = ok ? 'connected' : failed ? 'error' : (state === 'connecting' ? 'connecting' : (state || 'idle'));
    const transport = srv.transport || (srv.url ? 'http' : 'stdio');
    const toolCount = srv.toolCount || 0;
    const meta = srv.url ? (transport + ' · ' + toolCount + ' tools imported')
                         : (transport + (toolCount ? ' · ' + toolCount + ' tools imported' : ''));
    return {
      id: id, name: name, enabled: srv.enabled !== false,
      ok: ok, failed: failed, statusLabel: statusLabel,
      meta: meta, url: srv.url || '',
      useOAuth: srv.useOAuth === true, hasOAuthGrant: srv.hasOAuthGrant === true,
      lastError: srv.lastError || '',
    };
  }

  var API_PROVIDERS = { Gemini: 1, OpenAI: 1, Claude: 1, DeepSeek: 1, Custom: 1 };

  function modeForProvider(prov) {
    if (!prov || prov === 'Free') return 'Free';
    if (API_PROVIDERS[prov]) return 'API Key';
    return 'AI Agent';
  }

  function agentNameForId(id, catalog) {
    if (!id) return '';
    var list = Array.isArray(catalog) ? catalog
             : (catalog && Array.isArray(catalog.agents) ? catalog.agents : []);
    for (var i = 0; i < list.length; i++) {
      if (list[i] && list[i].id === id) return list[i].name || id;
    }
    return id;
  }

  function slotSummary(slot, catalog) {
    slot = slot || {};
    var prov = slot.provider || '';
    var mode = modeForProvider(prov);
    if (mode === 'Free') return 'Free';
    if (mode === 'AI Agent') return 'Runs ' + agentNameForId(prov, catalog);
    var mk = modelKeyForProvider(prov);
    var model = mk ? (slot[mk] || '') : '';
    return model ? (prov + ' · ' + model) : prov;
  }

  function slotModelName(slot, idx) {
    if (slot && slot.provider === 'Free') return 'BpLabs Standard';
    if (slot && slot.isAcp && slot.provider) return slot.provider;
    if (slot && slot.model) return slot.model;
    if (slot && slot.name) return slot.name;
    return (typeof idx === 'number' && idx >= 0) ? ('Slot ' + (idx + 1)) : 'Default';
  }

  function modelKeyForProvider(prov) {
    if (prov === 'Gemini')   return 'geminiModel';
    if (prov === 'OpenAI')   return 'openAIModel';
    if (prov === 'Claude')   return 'claudeModel';
    if (prov === 'DeepSeek') return 'deepseekModel';
    if (prov === 'Custom')   return 'customModelName';
    return '';
  }

  function modelForProvider(slot, prov, modelLists, defaultModels) {
    slot = slot || {};
    if (prov === 'Custom') return slot.customModelName || '';
    var mk = modelKeyForProvider(prov);
    if (mk && slot.provider === prov && slot[mk]) return slot[mk];
    var lower = String(prov || '').toLowerCase();
    var list = (modelLists && modelLists[lower]) || [];
    var def = (defaultModels && defaultModels[lower]) || '';
    if (def && (list.length === 0 || list.indexOf(def) !== -1)) return def;
    return list[0] || def;
  }

  function buildSaveSlotPayload(fields) {
    fields = fields || {};
    var idx  = fields.index || 0;
    var name = fields.name || '';
    var mode = fields.mode || 'Free';
    var payload = { index: idx, name: name };
    var freeTierSlotArg = null;

    if (mode === 'Free') {
      payload.provider = 'Free';
      var ft = fields.freeTierBackend || 'slot1';
      freeTierSlotArg = ft;
      if (ft === 'slot2' && fields.freeTierModel) {
        freeTierSlotArg = 'slot2:' + fields.freeTierModel;
      }
    } else if (mode === 'AI Agent') {
      var agentId = fields.agentId || '';
      if (agentId) payload.provider = agentId;
    } else {
      var prov = fields.provider || 'Gemini';
      payload.provider = prov;
      payload.apiKey   = fields.apiKey || '';
      var mk = modelKeyForProvider(prov);
      if (mk) payload[mk] = fields.model || '';
      if (prov === 'Custom') {
        payload.customBaseURL   = fields.endpoint || '';
        payload.customParams    = fields.customParams || '';
        payload.authHeaderStyle = fields.authHeaderStyle || '';
        payload.contextWindowOverrideTokens = fields.contextWindowOverrideTokens || 0;
      }
    }
    return { payload: payload, freeTierSlotArg: freeTierSlotArg };
  }

  var MODIFIER_KEYS = { Control: 1, Alt: 1, Shift: 1, Meta: 1, AltGraph: 1, OS: 1 };

  function isModifierKey(key) {
    return !!MODIFIER_KEYS[key];
  }

  function rebindCaptureStep(e) {
    e = e || {};
    if (e.key === 'Escape') return { status: 'cancel' };
    var modifier = e.ctrlKey ? 'Ctrl' : e.altKey ? 'Alt' : e.shiftKey ? 'Shift' : '';
    if (isModifierKey(e.key)) {
      return { status: 'progress', modifier: modifier, key: '', display: (modifier ? modifier + ' + ' : '') + '…' };
    }
    var key = (typeof e.key === 'string' && e.key.length === 1) ? e.key.toUpperCase() : e.key;
    return {
      status: 'commit',
      modifier: modifier,
      key: key,
      display: (modifier ? modifier + ' + ' : '') + key,
    };
  }

  return {
    derivePresentSlots:     derivePresentSlots,
    parseKeybind:           parseKeybind,
    formatKeybind:          formatKeybind,
    isModifierKey:          isModifierKey,
    rebindCaptureStep:      rebindCaptureStep,
    mapGitStatus:           mapGitStatus,
    mapBranches:            mapBranches,
    mapGitLog:              mapGitLog,
    parseExtensionsPending: parseExtensionsPending,
    mapUpstreamServer:      mapUpstreamServer,
    modeForProvider:        modeForProvider,
    modelKeyForProvider:    modelKeyForProvider,
    modelForProvider:       modelForProvider,
    agentNameForId:         agentNameForId,
    slotSummary:            slotSummary,
    slotModelName:          slotModelName,
    buildSaveSlotPayload:   buildSaveSlotPayload,
  };
}));
