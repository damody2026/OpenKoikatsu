// Copyright 2026, BlueprintsLab, All rights reserved
#include "UECPSteamP2PInternal.h"

#include "Engine/Engine.h"
#include "Engine/GameInstance.h"
#include "Engine/World.h"
#include "UECPSteamAPI.h"
#include "UECPSteamSubsystem.h"

namespace
{
	TSet<int32> GOpenChannels;

	constexpr int32 MaxMessagesPerChannelPerTick = 64;

	void ForEachSubsystem(TFunctionRef<void(UUECPSteamSubsystem&)> Work)
	{
		if (!GEngine)
		{
			return;
		}
		for (const FWorldContext& Context : GEngine->GetWorldContexts())
		{
			if (Context.WorldType != EWorldType::Game && Context.WorldType != EWorldType::PIE)
			{
				continue;
			}
			if (UGameInstance* GI = Context.OwningGameInstance)
			{
				if (UUECPSteamSubsystem* S = GI->GetSubsystem<UUECPSteamSubsystem>())
				{
					Work(*S);
				}
			}
		}
	}
}

void UECPSteamP2P::OpenChannel(int32 Channel)
{
	GOpenChannels.Add(Channel);
}

void UECPSteamP2P::CloseChannel(int32 Channel)
{
	GOpenChannels.Remove(Channel);
}

TArray<int32> UECPSteamP2P::GetOpenChannels()
{
	return GOpenChannels.Array();
}

bool UECPSteamP2P::HasOpenChannels()
{
	return GOpenChannels.Num() > 0;
}

void UECPSteamP2P::Reset()
{
	GOpenChannels.Empty();
}

void UECPSteamP2P::PumpMessages()
{
#if UECP_WITH_STEAM
	if (GOpenChannels.Num() == 0)
	{
		return;
	}

	ISteamNetworkingMessages* Messages = UECPSteam::NetworkingMessages();
	if (!Messages)
	{
		return;
	}

	for (const int32 Channel : GOpenChannels)
	{
		SteamNetworkingMessage_t* Batch[MaxMessagesPerChannelPerTick] = {};
		const int32 Count = Messages->ReceiveMessagesOnChannel(Channel, Batch, MaxMessagesPerChannelPerTick);

		for (int32 Index = 0; Index < Count; ++Index)
		{
			SteamNetworkingMessage_t* Msg = Batch[Index];
			if (!Msg)
			{
				continue;
			}

			const int64 Sender = UECPSteam::FromSteamID(Msg->m_identityPeer.GetSteamID());

			TArray<uint8> Data;
			if (Msg->m_pData && Msg->m_cbSize > 0)
			{
				Data.Append(static_cast<const uint8*>(Msg->m_pData), Msg->m_cbSize);
			}

			Msg->Release();

			ForEachSubsystem([Sender, &Data, Channel](UUECPSteamSubsystem& S)
			{
				S.HandleP2PMessage(Sender, Data, Channel);
			});
		}
	}
#endif
}
