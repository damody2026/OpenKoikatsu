(function () {
  var MENU_ID = 'uecp-text-ctx-menu';
  var STYLE_ID = 'uecp-text-ctx-style';
  var CSS =
    '.uecp-text-ctx{position:fixed;background:var(--ue-panel);border:1px solid var(--ue-line);' +
    'border-radius:var(--ue-r-md);min-width:150px;z-index:10000;box-shadow:0 4px 12px rgba(0,0,0,.3);' +
    'overflow:hidden;display:none;padding:4px 0}' +
    '.uecp-text-ctx.open{display:block}' +
    '.uecp-text-ctx .ctx-item{display:flex;justify-content:space-between;gap:18px;padding:7px 14px;' +
    'font-family:var(--ue-font-mono);font-size:12px;cursor:pointer;color:var(--ue-text-hi)}' +
    '.uecp-text-ctx .ctx-item:hover{background:var(--ue-accent-soft);color:var(--ue-accent-bright)}' +
    '.uecp-text-ctx .ctx-item.disabled{opacity:.4;pointer-events:none}' +
    '.uecp-text-ctx .ctx-key{opacity:.55}';

  function t(s) { return (window.uecp && typeof window.uecp.t === 'function') ? window.uecp.t(s) : s; }

  function shortcut(letter) { return ['Ctrl', letter].join('+'); }

  var NON_TEXT_INPUTS = ['checkbox', 'radio', 'range', 'color', 'file', 'button', 'submit', 'reset', 'image', 'hidden'];

  function editableOf(target) {
    var el = target && target.closest ? target.closest('textarea, input, [contenteditable=""], [contenteditable="true"]') : null;
    if (!el) return null;
    if (el.tagName === 'INPUT' && NON_TEXT_INPUTS.indexOf((el.type || 'text').toLowerCase()) >= 0) return null;
    return el;
  }

  function isTextControl(el) {
    return el && (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT');
  }

  function isLinux() {
    var ua = (typeof navigator !== 'undefined' && navigator.userAgent) || '';
    return /Linux|X11/.test(ua) && !/Android/.test(ua);
  }

  function isPasteKey(e) {
    if (e.altKey || e.metaKey) return false;
    if (e.ctrlKey && (e.key === 'v' || e.key === 'V')) return true;
    return e.shiftKey && !e.ctrlKey && /^Insert$/.test(e.key);
  }

  function selectedText(el) {
    if (isTextControl(el)) {
      try { return el.value.substring(el.selectionStart, el.selectionEnd); } catch (e) { return ''; }
    }
    var sel = window.getSelection ? window.getSelection() : null;
    return sel ? String(sel) : '';
  }

  function insertText(el, text) {
    if (isTextControl(el)) {
      var start = el.selectionStart, end = el.selectionEnd;
      if (typeof el.setRangeText === 'function') {
        el.setRangeText(text, start, end, 'end');
      } else {
        el.value = el.value.slice(0, start) + text + el.value.slice(end);
        el.selectionStart = el.selectionEnd = start + text.length;
      }
    } else if (document.execCommand) {
      document.execCommand('insertText', false, text);
      return;
    }
    el.dispatchEvent(new Event('input', { bubbles: true }));
  }

  var pending = null;
  var nextId = 1;

  function paste(el) {
    var id = nextId++;
    pending = { el: el, id: id };
    window.uecp.call('clipboard_read', { requestId: id });
  }

  function ensureMenu() {
    if (!document.getElementById(STYLE_ID)) {
      var st = document.createElement('style');
      st.id = STYLE_ID;
      st.textContent = CSS;
      document.head.appendChild(st);
    }
    var menu = document.getElementById(MENU_ID);
    if (!menu) {
      menu = document.createElement('div');
      menu.id = MENU_ID;
      menu.className = 'uecp-text-ctx';
      document.body.appendChild(menu);
    }
    return menu;
  }

  function hideMenu() {
    var menu = document.getElementById(MENU_ID);
    if (menu) menu.classList.remove('open');
  }

  function openMenu(x, y, el, text) {
    var menu = ensureMenu();
    var canEdit = !!el && !el.readOnly && !el.disabled;
    var items = [];
    if (el) items.push({ label: t('Cut'), key: shortcut('X'), on: canEdit && !!text, act: function () {
      window.uecp.call('clipboard_write', { text: text });
      el.focus();
      insertText(el, '');
    } });
    items.push({ label: t('Copy'), key: shortcut('C'), on: !!text, act: function () {
      window.uecp.call('clipboard_write', { text: text });
    } });
    if (el) items.push({ label: t('Paste'), key: shortcut('V'), on: canEdit, act: function () {
      el.focus();
      paste(el);
    } });
    if (el) items.push({ label: t('Select all'), key: shortcut('A'), on: true, act: function () {
      el.focus();
      if (isTextControl(el)) el.select(); else document.execCommand('selectAll');
    } });

    menu.innerHTML = '';
    items.forEach(function (it) {
      var row = document.createElement('div');
      row.className = 'ctx-item' + (it.on ? '' : ' disabled');
      var label = document.createElement('span');
      label.textContent = it.label;
      var key = document.createElement('span');
      key.className = 'ctx-key';
      key.textContent = it.key;
      row.appendChild(label);
      row.appendChild(key);
      row.addEventListener('mousedown', function (ev) {
        ev.preventDefault();
        ev.stopPropagation();
        hideMenu();
        if (it.on) it.act();
      });
      menu.appendChild(row);
    });

    menu.classList.add('open');
    var w = menu.offsetWidth || 160, h = menu.offsetHeight || 140;
    menu.style.left = Math.max(4, Math.min(x, window.innerWidth - w - 4)) + 'px';
    menu.style.top = Math.max(4, Math.min(y, window.innerHeight - h - 4)) + 'px';
  }

  function install() {
    document.addEventListener('contextmenu', function (e) {
      if (e.defaultPrevented) return;
      var el = editableOf(e.target);
      var text = selectedText(el);
      if (!el && !text) return;
      e.preventDefault();
      openMenu(e.clientX, e.clientY, el, text);
    });
    document.addEventListener('mousedown', function (e) {
      var menu = document.getElementById(MENU_ID);
      if (menu && !menu.contains(e.target)) hideMenu();
    });
    document.addEventListener('keydown', function (e) { if (e.key === 'Escape') hideMenu(); });
    window.addEventListener('blur', hideMenu);

    if (isLinux()) {
      document.addEventListener('keydown', function (e) {
        if (!isPasteKey(e)) return;
        var el = editableOf(e.target);
        if (!el || el.readOnly || el.disabled) return;
        e.preventDefault();
        paste(el);
      }, true);
    }

    window.uecp.on('clipboard.text', function (d) {
      if (!pending || !d || (d.requestId != null && d.requestId !== pending.id)) return;
      var el = pending.el;
      pending = null;
      if (el && d.text) insertText(el, String(d.text));
    });
  }

  window.UECP = window.UECP || {};
  window.UECP.textContextMenu = { editableOf: editableOf, insertText: insertText };

  if (window.uecp && typeof window.uecp.on === 'function') install();
  else document.addEventListener('DOMContentLoaded', install);
})();
