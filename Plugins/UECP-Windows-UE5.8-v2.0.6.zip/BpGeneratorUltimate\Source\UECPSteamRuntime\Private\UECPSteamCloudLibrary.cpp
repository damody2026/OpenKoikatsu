// Copyright 2026, BlueprintsLab, All rights reserved
#include "Library/UECPSteamCloudLibrary.h"

#include "UECPSteamAPI.h"

bool UUECPSteamCloudLibrary::IsCloudEnabledForApp()
{
#if UECP_WITH_STEAM
	if (ISteamRemoteStorage* R = UECPSteam::RemoteStorage()) { return R->IsCloudEnabledForApp(); }
#endif
	return false;
}

bool UUECPSteamCloudLibrary::IsCloudEnabledForAccount()
{
#if UECP_WITH_STEAM
	if (ISteamRemoteStorage* R = UECPSteam::RemoteStorage()) { return R->IsCloudEnabledForAccount(); }
#endif
	return false;
}

TArray<FUECPSteamCloudFile> UUECPSteamCloudLibrary::GetCloudFiles()
{
	TArray<FUECPSteamCloudFile> Out;
#if UECP_WITH_STEAM
	ISteamRemoteStorage* R = UECPSteam::RemoteStorage();
	if (!R)
	{
		return Out;
	}

	const int32 Count = R->GetFileCount();
	Out.Reserve(Count);

	for (int32 Index = 0; Index < Count; ++Index)
	{
		int32 SizeBytes = 0;
		const char* Name = R->GetFileNameAndSize(Index, &SizeBytes);
		if (!Name || !*Name)
		{
			continue;
		}

		FUECPSteamCloudFile File;
		File.FileName   = UTF8_TO_TCHAR(Name);
		File.SizeBytes  = SizeBytes;
		File.Timestamp  = FDateTime::FromUnixTimestamp(R->GetFileTimestamp(Name));
		File.bPersisted = R->FilePersisted(Name);
		Out.Add(MoveTemp(File));
	}
#endif
	return Out;
}

bool UUECPSteamCloudLibrary::FileExists(const FString& FileName)
{
#if UECP_WITH_STEAM
	if (ISteamRemoteStorage* R = UECPSteam::RemoteStorage())
	{
		return R->FileExists(TCHAR_TO_UTF8(*FileName));
	}
#endif
	return false;
}

bool UUECPSteamCloudLibrary::IsFilePersisted(const FString& FileName)
{
#if UECP_WITH_STEAM
	if (ISteamRemoteStorage* R = UECPSteam::RemoteStorage())
	{
		return R->FilePersisted(TCHAR_TO_UTF8(*FileName));
	}
#endif
	return false;
}

int32 UUECPSteamCloudLibrary::GetFileSize(const FString& FileName)
{
#if UECP_WITH_STEAM
	if (ISteamRemoteStorage* R = UECPSteam::RemoteStorage())
	{
		return R->GetFileSize(TCHAR_TO_UTF8(*FileName));
	}
#endif
	return 0;
}

bool UUECPSteamCloudLibrary::WriteStringToCloud(const FString& FileName, const FString& Contents)
{
#if UECP_WITH_STEAM
	if (ISteamRemoteStorage* R = UECPSteam::RemoteStorage())
	{
		const FTCHARToUTF8 Utf8(*Contents);
		return R->FileWrite(TCHAR_TO_UTF8(*FileName), Utf8.Get(), Utf8.Length());
	}
#endif
	return false;
}

FString UUECPSteamCloudLibrary::ReadStringFromCloud(const FString& FileName)
{
	const TArray<uint8> Bytes = ReadBytesFromCloud(FileName);
	if (Bytes.Num() == 0)
	{
		return FString();
	}

	TArray<uint8> Terminated(Bytes);
	Terminated.Add(0);
	return FString(UTF8_TO_TCHAR(reinterpret_cast<const char*>(Terminated.GetData())));
}

bool UUECPSteamCloudLibrary::WriteBytesToCloud(const FString& FileName, const TArray<uint8>& Data)
{
#if UECP_WITH_STEAM
	if (ISteamRemoteStorage* R = UECPSteam::RemoteStorage())
	{
		return R->FileWrite(TCHAR_TO_UTF8(*FileName), Data.GetData(), Data.Num());
	}
#endif
	return false;
}

TArray<uint8> UUECPSteamCloudLibrary::ReadBytesFromCloud(const FString& FileName)
{
	TArray<uint8> Out;
#if UECP_WITH_STEAM
	ISteamRemoteStorage* R = UECPSteam::RemoteStorage();
	if (!R)
	{
		return Out;
	}

	const auto Utf8Name = StringCast<UTF8CHAR>(*FileName);
	const char* Name = reinterpret_cast<const char*>(Utf8Name.Get());

	const int32 Size = R->GetFileSize(Name);
	if (Size <= 0)
	{
		return Out;
	}

	Out.SetNumUninitialized(Size);
	const int32 Read = R->FileRead(Name, Out.GetData(), Size);
	Out.SetNum(FMath::Clamp(Read, 0, Size), EAllowShrinking::No);
#endif
	return Out;
}

bool UUECPSteamCloudLibrary::DeleteCloudFile(const FString& FileName)
{
#if UECP_WITH_STEAM
	if (ISteamRemoteStorage* R = UECPSteam::RemoteStorage())
	{
		return R->FileDelete(TCHAR_TO_UTF8(*FileName));
	}
#endif
	return false;
}

bool UUECPSteamCloudLibrary::ForgetCloudFile(const FString& FileName)
{
#if UECP_WITH_STEAM
	if (ISteamRemoteStorage* R = UECPSteam::RemoteStorage())
	{
		return R->FileForget(TCHAR_TO_UTF8(*FileName));
	}
#endif
	return false;
}

bool UUECPSteamCloudLibrary::ShareCloudFile(const FString& FileName)
{
#if UECP_WITH_STEAM
	if (ISteamRemoteStorage* R = UECPSteam::RemoteStorage())
	{
		if (!FileName.IsEmpty())
		{
			return R->FileShare(TCHAR_TO_UTF8(*FileName)) != k_uAPICallInvalid;
		}
	}
#endif
	return false;
}

bool UUECPSteamCloudLibrary::DownloadSharedFile(int64 UgcHandle, int32 Priority)
{
#if UECP_WITH_STEAM
	if (ISteamRemoteStorage* R = UECPSteam::RemoteStorage())
	{
		if (UgcHandle != 0)
		{
			return R->UGCDownload(static_cast<UGCHandle_t>(UgcHandle), FMath::Max(0, Priority))
				!= k_uAPICallInvalid;
		}
	}
#endif
	return false;
}

bool UUECPSteamCloudLibrary::ReadSharedFile(int64 UgcHandle, TArray<uint8>& OutData)
{
	OutData.Reset();
#if UECP_WITH_STEAM
	ISteamRemoteStorage* R = UECPSteam::RemoteStorage();
	if (!R || UgcHandle == 0)
	{
		return false;
	}

	const UGCHandle_t Handle = static_cast<UGCHandle_t>(UgcHandle);
	AppId_t AppId = 0;
	char* NamePtr = nullptr;
	int32 SizeBytes = 0;
	CSteamID Owner;
	if (!R->GetUGCDetails(Handle, &AppId, &NamePtr, &SizeBytes, &Owner) || SizeBytes <= 0)
	{
		return false;
	}

	OutData.SetNumUninitialized(SizeBytes);
	const int32 Read = R->UGCRead(Handle, OutData.GetData(), SizeBytes, 0,
		k_EUGCRead_ContinueReadingUntilFinished);
	OutData.SetNum(FMath::Clamp(Read, 0, SizeBytes), EAllowShrinking::No);
	return Read > 0;
#else
	return false;
#endif
}

bool UUECPSteamCloudLibrary::GetSharedFileInfo(int64 UgcHandle, FString& FileName,
	int32& SizeBytes, FUECPSteamID& Owner)
{
	FileName.Reset();
	SizeBytes = 0;
	Owner = FUECPSteamID();

#if UECP_WITH_STEAM
	ISteamRemoteStorage* R = UECPSteam::RemoteStorage();
	if (!R || UgcHandle == 0)
	{
		return false;
	}

	AppId_t AppId = 0;
	char* NamePtr = nullptr;
	CSteamID OwnerId;
	if (R->GetUGCDetails(static_cast<UGCHandle_t>(UgcHandle), &AppId, &NamePtr, &SizeBytes, &OwnerId))
	{
		if (NamePtr)
		{
			FileName = UTF8_TO_TCHAR(NamePtr);
		}
		Owner = FUECPSteamID(UECPSteam::FromSteamID(OwnerId));
		return true;
	}
#endif
	return false;
}

bool UUECPSteamCloudLibrary::GetCloudQuota(int64& TotalBytes, int64& AvailableBytes)
{
	TotalBytes     = 0;
	AvailableBytes = 0;
#if UECP_WITH_STEAM
	if (ISteamRemoteStorage* R = UECPSteam::RemoteStorage())
	{
		uint64 Total = 0;
		uint64 Available = 0;
		if (R->GetQuota(&Total, &Available))
		{
			TotalBytes     = static_cast<int64>(Total);
			AvailableBytes = static_cast<int64>(Available);
			return true;
		}
	}
#endif
	return false;
}
