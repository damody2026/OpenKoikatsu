// Copyright 2026, BlueprintsLab, All rights reserved
#include "Library/UECPSteamInputLibrary.h"

#include "Engine/Texture2D.h"
#include "ImageUtils.h"
#include "Misc/FileHelper.h"
#include "UECPSteamAPI.h"

#if UECP_WITH_STEAM
namespace
{
	ISteamInput* EnsureInput()
	{
		static bool bInitAttempted = false;
		static bool bInitOk = false;

		ISteamInput* Input = UECPSteam::Input();
		if (!Input)
		{
			return nullptr;
		}
		if (!bInitAttempted)
		{
			bInitAttempted = true;
			bInitOk = Input->Init(false);
			UE_LOG(LogUECPSteam, Log, TEXT("Steam Input init %s."), bInitOk ? TEXT("succeeded") : TEXT("FAILED"));
		}
		return bInitOk ? Input : nullptr;
	}

	TMap<FString, uint64> GActionSetHandles;
	TMap<FString, uint64> GDigitalHandles;
	TMap<FString, uint64> GAnalogHandles;

	template <typename TResolver>
	uint64 CachedHandle(TMap<FString, uint64>& Cache, const FString& Name, TResolver Resolve)
	{
		if (const uint64* Found = Cache.Find(Name))
		{
			return *Found;
		}
		const uint64 Handle = Resolve(TCHAR_TO_UTF8(*Name));
		Cache.Add(Name, Handle);
		return Handle;
	}

	InputHandle_t ToNative(const FUECPSteamInputHandle& In)
	{
		return static_cast<InputHandle_t>(static_cast<uint64>(In.Value));
	}

	ESteamInputGlyphSize ToNative(EUECPSteamGlyphSize In)
	{
		switch (In)
		{
		case EUECPSteamGlyphSize::Small: return k_ESteamInputGlyphSize_Small;
		case EUECPSteamGlyphSize::Large: return k_ESteamInputGlyphSize_Large;
		case EUECPSteamGlyphSize::Medium:
		default:                         return k_ESteamInputGlyphSize_Medium;
		}
	}

	EUECPSteamInputType FromNative(ESteamInputType In)
	{
		switch (In)
		{
		case k_ESteamInputType_SteamController:  return EUECPSteamInputType::SteamController;
		case k_ESteamInputType_XBox360Controller: return EUECPSteamInputType::XBox360;
		case k_ESteamInputType_XBoxOneController: return EUECPSteamInputType::XBoxOne;
		case k_ESteamInputType_GenericGamepad:   return EUECPSteamInputType::GenericGamepad;
		case k_ESteamInputType_PS4Controller:    return EUECPSteamInputType::PS4;
		case k_ESteamInputType_PS5Controller:    return EUECPSteamInputType::PS5;
		case k_ESteamInputType_SwitchProController: return EUECPSteamInputType::SwitchPro;
		case k_ESteamInputType_SteamDeckController: return EUECPSteamInputType::SteamDeck;
		case k_ESteamInputType_MobileTouch:      return EUECPSteamInputType::Mobile;
		default:                                 return EUECPSteamInputType::Unknown;
		}
	}

	TMap<FString, TWeakObjectPtr<UTexture2D>> GGlyphCache;

	EInputActionOrigin FirstOrigin(ISteamInput& Input, InputHandle_t Controller,
		const FString& ActionName, bool bDigital)
	{
		EInputActionOrigin Origins[STEAM_INPUT_MAX_ORIGINS] = {};
		int32 Count = 0;

		if (bDigital)
		{
			const uint64 Action = CachedHandle(GDigitalHandles, ActionName,
				[&Input](const char* N) { return static_cast<uint64>(Input.GetDigitalActionHandle(N)); });
			if (Action == 0)
			{
				return k_EInputActionOrigin_None;
			}
			Count = Input.GetDigitalActionOrigins(Controller,
				Input.GetCurrentActionSet(Controller),
				static_cast<InputDigitalActionHandle_t>(Action), Origins);
		}
		else
		{
			const uint64 Action = CachedHandle(GAnalogHandles, ActionName,
				[&Input](const char* N) { return static_cast<uint64>(Input.GetAnalogActionHandle(N)); });
			if (Action == 0)
			{
				return k_EInputActionOrigin_None;
			}
			Count = Input.GetAnalogActionOrigins(Controller,
				Input.GetCurrentActionSet(Controller),
				static_cast<InputAnalogActionHandle_t>(Action), Origins);
		}

		return Count > 0 ? Origins[0] : k_EInputActionOrigin_None;
	}
}
#endif

TArray<FUECPSteamInputHandle> UUECPSteamInputLibrary::GetConnectedControllers()
{
	TArray<FUECPSteamInputHandle> Out;
#if UECP_WITH_STEAM
	ISteamInput* Input = EnsureInput();
	if (!Input)
	{
		return Out;
	}

	InputHandle_t Handles[STEAM_INPUT_MAX_COUNT] = {};
	const int32 Count = Input->GetConnectedControllers(Handles);
	Out.Reserve(Count);
	for (int32 Index = 0; Index < Count; ++Index)
	{
		Out.Add(FUECPSteamInputHandle(static_cast<int64>(Handles[Index])));
	}
#endif
	return Out;
}

EUECPSteamInputType UUECPSteamInputLibrary::GetControllerType(FUECPSteamInputHandle Controller)
{
#if UECP_WITH_STEAM
	if (ISteamInput* Input = EnsureInput())
	{
		if (Controller.IsValid())
		{
			return FromNative(Input->GetInputTypeForHandle(ToNative(Controller)));
		}
	}
#endif
	return EUECPSteamInputType::Unknown;
}

bool UUECPSteamInputLibrary::ActivateActionSet(FUECPSteamInputHandle Controller, const FString& ActionSetName)
{
#if UECP_WITH_STEAM
	ISteamInput* Input = EnsureInput();
	if (!Input || !Controller.IsValid())
	{
		return false;
	}
	const uint64 Handle = CachedHandle(GActionSetHandles, ActionSetName,
		[Input](const char* N) { return static_cast<uint64>(Input->GetActionSetHandle(N)); });
	if (Handle == 0)
	{
		return false;
	}
	Input->ActivateActionSet(ToNative(Controller), static_cast<InputActionSetHandle_t>(Handle));
	return true;
#else
	return false;
#endif
}

bool UUECPSteamInputLibrary::ActivateActionSetLayer(FUECPSteamInputHandle Controller, const FString& ActionSetLayerName)
{
#if UECP_WITH_STEAM
	ISteamInput* Input = EnsureInput();
	if (!Input || !Controller.IsValid())
	{
		return false;
	}
	const uint64 Handle = CachedHandle(GActionSetHandles, ActionSetLayerName,
		[Input](const char* N) { return static_cast<uint64>(Input->GetActionSetHandle(N)); });
	if (Handle == 0)
	{
		return false;
	}
	Input->ActivateActionSetLayer(ToNative(Controller), static_cast<InputActionSetHandle_t>(Handle));
	return true;
#else
	return false;
#endif
}

bool UUECPSteamInputLibrary::DeactivateActionSetLayer(FUECPSteamInputHandle Controller, const FString& ActionSetLayerName)
{
#if UECP_WITH_STEAM
	ISteamInput* Input = EnsureInput();
	if (!Input || !Controller.IsValid())
	{
		return false;
	}
	const uint64 Handle = CachedHandle(GActionSetHandles, ActionSetLayerName,
		[Input](const char* N) { return static_cast<uint64>(Input->GetActionSetHandle(N)); });
	if (Handle == 0)
	{
		return false;
	}
	Input->DeactivateActionSetLayer(ToNative(Controller), static_cast<InputActionSetHandle_t>(Handle));
	return true;
#else
	return false;
#endif
}

bool UUECPSteamInputLibrary::DeactivateAllActionSetLayers(FUECPSteamInputHandle Controller)
{
#if UECP_WITH_STEAM
	if (ISteamInput* Input = EnsureInput())
	{
		if (Controller.IsValid())
		{
			Input->DeactivateAllActionSetLayers(ToNative(Controller));
			return true;
		}
	}
#endif
	return false;
}

FUECPSteamDigitalAction UUECPSteamInputLibrary::GetDigitalAction(
	FUECPSteamInputHandle Controller, const FString& ActionName)
{
	FUECPSteamDigitalAction Out;
#if UECP_WITH_STEAM
	ISteamInput* Input = EnsureInput();
	if (!Input || !Controller.IsValid())
	{
		return Out;
	}
	const uint64 Action = CachedHandle(GDigitalHandles, ActionName,
		[Input](const char* N) { return static_cast<uint64>(Input->GetDigitalActionHandle(N)); });
	if (Action == 0)
	{
		return Out;
	}

	const InputDigitalActionData_t Data = Input->GetDigitalActionData(
		ToNative(Controller), static_cast<InputDigitalActionHandle_t>(Action));
	Out.bPressed = Data.bState;
	Out.bActive  = Data.bActive;
#endif
	return Out;
}

FUECPSteamAnalogAction UUECPSteamInputLibrary::GetAnalogAction(
	FUECPSteamInputHandle Controller, const FString& ActionName)
{
	FUECPSteamAnalogAction Out;
#if UECP_WITH_STEAM
	ISteamInput* Input = EnsureInput();
	if (!Input || !Controller.IsValid())
	{
		return Out;
	}
	const uint64 Action = CachedHandle(GAnalogHandles, ActionName,
		[Input](const char* N) { return static_cast<uint64>(Input->GetAnalogActionHandle(N)); });
	if (Action == 0)
	{
		return Out;
	}

	const InputAnalogActionData_t Data = Input->GetAnalogActionData(
		ToNative(Controller), static_cast<InputAnalogActionHandle_t>(Action));
	Out.X       = Data.x;
	Out.Y       = Data.y;
	Out.bActive = Data.bActive;
#endif
	return Out;
}

FString UUECPSteamInputLibrary::GetActionOriginText(
	FUECPSteamInputHandle Controller, const FString& ActionName, bool bDigital)
{
#if UECP_WITH_STEAM
	ISteamInput* Input = EnsureInput();
	if (!Input || !Controller.IsValid())
	{
		return FString();
	}
	const EInputActionOrigin Origin = FirstOrigin(*Input, ToNative(Controller), ActionName, bDigital);
	if (Origin == k_EInputActionOrigin_None)
	{
		return FString();
	}
	return UTF8_TO_TCHAR(Input->GetStringForActionOrigin(Origin));
#else
	return FString();
#endif
}

UTexture2D* UUECPSteamInputLibrary::GetActionGlyph(
	FUECPSteamInputHandle Controller, const FString& ActionName,
	EUECPSteamGlyphSize Size, bool bDigital)
{
#if UECP_WITH_STEAM
	ISteamInput* Input = EnsureInput();
	if (!Input || !Controller.IsValid())
	{
		return nullptr;
	}

	const EInputActionOrigin Origin = FirstOrigin(*Input, ToNative(Controller), ActionName, bDigital);
	if (Origin == k_EInputActionOrigin_None)
	{
		return nullptr;
	}

	const char* PathUtf8 = Input->GetGlyphPNGForActionOrigin(Origin, ToNative(Size), 0);
	if (!PathUtf8 || !*PathUtf8)
	{
		return nullptr;
	}

	const FString Path = UTF8_TO_TCHAR(PathUtf8);
	if (const TWeakObjectPtr<UTexture2D>* Cached = GGlyphCache.Find(Path))
	{
		if (UTexture2D* Existing = Cached->Get())
		{
			return Existing;
		}
		GGlyphCache.Remove(Path);
	}

	TArray<uint8> Png;
	if (!FFileHelper::LoadFileToArray(Png, *Path))
	{
		UE_LOG(LogUECPSteam, Warning, TEXT("Could not read Steam Input glyph '%s'."), *Path);
		return nullptr;
	}

	UTexture2D* Texture = FImageUtils::ImportBufferAsTexture2D(Png);
	if (Texture)
	{
		GGlyphCache.Add(Path, Texture);
	}
	return Texture;
#else
	return nullptr;
#endif
}

void UUECPSteamInputLibrary::TriggerVibration(FUECPSteamInputHandle Controller, int32 LeftSpeed, int32 RightSpeed)
{
#if UECP_WITH_STEAM
	if (ISteamInput* Input = EnsureInput())
	{
		if (Controller.IsValid())
		{
			Input->TriggerVibration(ToNative(Controller),
				static_cast<unsigned short>(FMath::Clamp(LeftSpeed, 0, 65535)),
				static_cast<unsigned short>(FMath::Clamp(RightSpeed, 0, 65535)));
		}
	}
#endif
}

void UUECPSteamInputLibrary::SetLEDColor(FUECPSteamInputHandle Controller, FLinearColor Color)
{
#if UECP_WITH_STEAM
	if (ISteamInput* Input = EnsureInput())
	{
		if (Controller.IsValid())
		{
			const FColor Rgb = Color.ToFColor(true);
			Input->SetLEDColor(ToNative(Controller), Rgb.R, Rgb.G, Rgb.B, k_ESteamInputLEDFlag_SetColor);
		}
	}
#endif
}

bool UUECPSteamInputLibrary::ShowBindingPanel(FUECPSteamInputHandle Controller)
{
#if UECP_WITH_STEAM
	if (ISteamInput* Input = EnsureInput())
	{
		if (Controller.IsValid())
		{
			return Input->ShowBindingPanel(ToNative(Controller));
		}
	}
#endif
	return false;
}

void UUECPSteamInputLibrary::GetMotionData(FUECPSteamInputHandle Controller,
	FVector& RotationVelocity, FVector& Acceleration, FQuat& Orientation)
{
	RotationVelocity = FVector::ZeroVector;
	Acceleration     = FVector::ZeroVector;
	Orientation      = FQuat::Identity;

#if UECP_WITH_STEAM
	ISteamInput* Input = EnsureInput();
	if (!Input || !Controller.IsValid())
	{
		return;
	}

	const InputMotionData_t Data = Input->GetMotionData(ToNative(Controller));
	RotationVelocity = FVector(Data.rotVelX, Data.rotVelY, Data.rotVelZ);
	Acceleration     = FVector(Data.posAccelX, Data.posAccelY, Data.posAccelZ);
	Orientation      = FQuat(Data.rotQuatX, Data.rotQuatY, Data.rotQuatZ, Data.rotQuatW);
#endif
}
