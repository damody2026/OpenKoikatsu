// Copyright 2026, BlueprintsLab, All rights reserved
#include "Library/UECPSteamWorkshopLibrary.h"

#include "UECPSteamAPI.h"

#if UECP_WITH_STEAM
namespace
{
	PublishedFileId_t ToNativeId(const FUECPSteamWorkshopItemId& In)
	{
		return static_cast<PublishedFileId_t>(static_cast<uint64>(In.Value));
	}

	TArray<PublishedFileId_t> ToNativeIds(const TArray<FUECPSteamWorkshopItemId>& In)
	{
		TArray<PublishedFileId_t> Out;
		Out.Reserve(In.Num());
		for (const FUECPSteamWorkshopItemId& Id : In)
		{
			Out.Add(ToNativeId(Id));
		}
		return Out;
	}
}
#endif

TArray<FUECPSteamWorkshopItemId> UUECPSteamWorkshopLibrary::GetSubscribedItems()
{
	TArray<FUECPSteamWorkshopItemId> Out;
#if UECP_WITH_STEAM
	ISteamUGC* UGC = UECPSteam::UGC();
	if (!UGC)
	{
		return Out;
	}

	const uint32 Count = UGC->GetNumSubscribedItems();
	if (Count == 0)
	{
		return Out;
	}

	TArray<PublishedFileId_t> Native;
	Native.SetNumZeroed(Count);
	const uint32 Written = UGC->GetSubscribedItems(Native.GetData(), Count);

	Out.Reserve(Written);
	for (uint32 Index = 0; Index < Written; ++Index)
	{
		Out.Add(FUECPSteamWorkshopItemId(static_cast<int64>(Native[Index])));
	}
#endif
	return Out;
}

FUECPSteamWorkshopItemState UUECPSteamWorkshopLibrary::GetWorkshopItemState(FUECPSteamWorkshopItemId ItemId)
{
	FUECPSteamWorkshopItemState Out;
#if UECP_WITH_STEAM
	ISteamUGC* UGC = UECPSteam::UGC();
	if (!UGC || !ItemId.IsValid())
	{
		return Out;
	}

	const uint32 Flags = UGC->GetItemState(ToNativeId(ItemId));
	Out.bSubscribed      = (Flags & k_EItemStateSubscribed) != 0;
	Out.bInstalled       = (Flags & k_EItemStateInstalled) != 0;
	Out.bNeedsUpdate     = (Flags & k_EItemStateNeedsUpdate) != 0;
	Out.bDownloading     = (Flags & k_EItemStateDownloading) != 0;
	Out.bDownloadPending = (Flags & k_EItemStateDownloadPending) != 0;

	Out.bReadyToUse = Out.bInstalled && !Out.bNeedsUpdate;
#endif
	return Out;
}

bool UUECPSteamWorkshopLibrary::GetWorkshopItemInstallInfo(FUECPSteamWorkshopItemId ItemId,
	FString& InstallFolder, int64& SizeOnDisk, FDateTime& TimeStamp)
{
	InstallFolder.Reset();
	SizeOnDisk = 0;
	TimeStamp  = FDateTime();

#if UECP_WITH_STEAM
	ISteamUGC* UGC = UECPSteam::UGC();
	if (!UGC || !ItemId.IsValid())
	{
		return false;
	}

	uint64 Size = 0;
	char Folder[1024] = {};
	uint32 Punchcard = 0;

	if (UGC->GetItemInstallInfo(ToNativeId(ItemId), &Size, Folder, UE_ARRAY_COUNT(Folder), &Punchcard))
	{
		InstallFolder = UTF8_TO_TCHAR(Folder);
		SizeOnDisk    = static_cast<int64>(Size);
		TimeStamp     = FDateTime::FromUnixTimestamp(static_cast<int64>(Punchcard));
		return true;
	}
#endif
	return false;
}

bool UUECPSteamWorkshopLibrary::GetWorkshopDownloadProgress(FUECPSteamWorkshopItemId ItemId,
	float& ProgressPercent, int64& BytesDownloaded, int64& BytesTotal)
{
	ProgressPercent = 0.f;
	BytesDownloaded = 0;
	BytesTotal      = 0;

#if UECP_WITH_STEAM
	ISteamUGC* UGC = UECPSteam::UGC();
	if (!UGC || !ItemId.IsValid())
	{
		return false;
	}

	uint64 Downloaded = 0;
	uint64 Total = 0;
	if (UGC->GetItemDownloadInfo(ToNativeId(ItemId), &Downloaded, &Total))
	{
		BytesDownloaded = static_cast<int64>(Downloaded);
		BytesTotal      = static_cast<int64>(Total);
		ProgressPercent = Total > 0 ? (static_cast<float>(Downloaded) / static_cast<float>(Total)) * 100.f : 0.f;
		return true;
	}
#endif
	return false;
}

bool UUECPSteamWorkshopLibrary::StartWorkshopItemDownload(FUECPSteamWorkshopItemId ItemId, bool bHighPriority)
{
#if UECP_WITH_STEAM
	if (ISteamUGC* UGC = UECPSteam::UGC())
	{
		if (ItemId.IsValid())
		{
			return UGC->DownloadItem(ToNativeId(ItemId), bHighPriority);
		}
	}
#endif
	return false;
}

bool UUECPSteamWorkshopLibrary::SetWorkshopItemVote(FUECPSteamWorkshopItemId ItemId, bool bVoteUp)
{
#if UECP_WITH_STEAM
	if (ISteamUGC* UGC = UECPSteam::UGC())
	{
		if (ItemId.IsValid())
		{
			return UGC->SetUserItemVote(ToNativeId(ItemId), bVoteUp) != k_uAPICallInvalid;
		}
	}
#endif
	return false;
}

bool UUECPSteamWorkshopLibrary::AddWorkshopItemToFavorites(FUECPSteamWorkshopItemId ItemId)
{
#if UECP_WITH_STEAM
	ISteamUGC* UGC = UECPSteam::UGC();
	ISteamUtils* Utils = UECPSteam::Utils();
	if (UGC && Utils && ItemId.IsValid())
	{
		return UGC->AddItemToFavorites(Utils->GetAppID(), ToNativeId(ItemId)) != k_uAPICallInvalid;
	}
#endif
	return false;
}

bool UUECPSteamWorkshopLibrary::RemoveWorkshopItemFromFavorites(FUECPSteamWorkshopItemId ItemId)
{
#if UECP_WITH_STEAM
	ISteamUGC* UGC = UECPSteam::UGC();
	ISteamUtils* Utils = UECPSteam::Utils();
	if (UGC && Utils && ItemId.IsValid())
	{
		return UGC->RemoveItemFromFavorites(Utils->GetAppID(), ToNativeId(ItemId)) != k_uAPICallInvalid;
	}
#endif
	return false;
}

bool UUECPSteamWorkshopLibrary::ShowWorkshopItemPage(FUECPSteamWorkshopItemId ItemId)
{
#if UECP_WITH_STEAM
	if (ISteamFriends* F = UECPSteam::Friends())
	{
		if (ItemId.IsValid())
		{
			F->ActivateGameOverlayToWebPage(
				TCHAR_TO_UTF8(*FString::Printf(
					TEXT("https://steamcommunity.com/sharedfiles/filedetails/?id=%s"), *ItemId.ToString())));
			return true;
		}
	}
#endif
	return false;
}

bool UUECPSteamWorkshopLibrary::ShowWorkshopHub()
{
#if UECP_WITH_STEAM
	ISteamFriends* F = UECPSteam::Friends();
	ISteamUtils* Utils = UECPSteam::Utils();
	if (F && Utils)
	{
		F->ActivateGameOverlayToWebPage(
			TCHAR_TO_UTF8(*FString::Printf(
				TEXT("https://steamcommunity.com/app/%u/workshop/"), Utils->GetAppID())));
		return true;
	}
#endif
	return false;
}

bool UUECPSteamWorkshopLibrary::StartTrackingWorkshopPlaytime(const TArray<FUECPSteamWorkshopItemId>& ItemIds)
{
#if UECP_WITH_STEAM
	ISteamUGC* UGC = UECPSteam::UGC();
	if (UGC && ItemIds.Num() > 0)
	{
		TArray<PublishedFileId_t> Native = ToNativeIds(ItemIds);
		return UGC->StartPlaytimeTracking(Native.GetData(), Native.Num()) != k_uAPICallInvalid;
	}
#endif
	return false;
}

bool UUECPSteamWorkshopLibrary::StopTrackingWorkshopPlaytime(const TArray<FUECPSteamWorkshopItemId>& ItemIds)
{
#if UECP_WITH_STEAM
	ISteamUGC* UGC = UECPSteam::UGC();
	if (UGC && ItemIds.Num() > 0)
	{
		TArray<PublishedFileId_t> Native = ToNativeIds(ItemIds);
		return UGC->StopPlaytimeTracking(Native.GetData(), Native.Num()) != k_uAPICallInvalid;
	}
#endif
	return false;
}

FString UUECPSteamWorkshopLibrary::Conv_WorkshopItemIdToString(const FUECPSteamWorkshopItemId& ItemId)
{
	return ItemId.ToString();
}

FUECPSteamWorkshopItemId UUECPSteamWorkshopLibrary::MakeWorkshopItemIdFromString(const FString& ItemIdString)
{
	uint64 Parsed = 0;
	LexFromString(Parsed, *ItemIdString);
	return FUECPSteamWorkshopItemId(static_cast<int64>(Parsed));
}

bool UUECPSteamWorkshopLibrary::AddWorkshopDependency(
	FUECPSteamWorkshopItemId ParentItemId, FUECPSteamWorkshopItemId ChildItemId)
{
#if UECP_WITH_STEAM
	if (ISteamUGC* UGC = UECPSteam::UGC())
	{
		if (ParentItemId.IsValid() && ChildItemId.IsValid())
		{
			return UGC->AddDependency(ToNativeId(ParentItemId), ToNativeId(ChildItemId)) != k_uAPICallInvalid;
		}
	}
#endif
	return false;
}

bool UUECPSteamWorkshopLibrary::RemoveWorkshopDependency(
	FUECPSteamWorkshopItemId ParentItemId, FUECPSteamWorkshopItemId ChildItemId)
{
#if UECP_WITH_STEAM
	if (ISteamUGC* UGC = UECPSteam::UGC())
	{
		if (ParentItemId.IsValid() && ChildItemId.IsValid())
		{
			return UGC->RemoveDependency(ToNativeId(ParentItemId), ToNativeId(ChildItemId)) != k_uAPICallInvalid;
		}
	}
#endif
	return false;
}

bool UUECPSteamWorkshopLibrary::AddWorkshopPreview(
	int64 UpdateHandle, const FString& PreviewFileOrUrl, bool bIsVideo)
{
#if UECP_WITH_STEAM
	ISteamUGC* UGC = UECPSteam::UGC();
	if (!UGC || UpdateHandle == 0 || PreviewFileOrUrl.IsEmpty())
	{
		return false;
	}

	const UGCUpdateHandle_t Handle = static_cast<UGCUpdateHandle_t>(UpdateHandle);

	return bIsVideo
		? UGC->AddItemPreviewVideo(Handle, TCHAR_TO_UTF8(*PreviewFileOrUrl))
		: UGC->AddItemPreviewFile(Handle, TCHAR_TO_UTF8(*PreviewFileOrUrl),
			k_EItemPreviewType_Image);
#else
	return false;
#endif
}

bool UUECPSteamWorkshopLibrary::AddWorkshopKeyValueTag(
	int64 UpdateHandle, const FString& Key, const FString& Value)
{
#if UECP_WITH_STEAM
	if (ISteamUGC* UGC = UECPSteam::UGC())
	{
		if (UpdateHandle != 0 && !Key.IsEmpty())
		{
			return UGC->AddItemKeyValueTag(static_cast<UGCUpdateHandle_t>(UpdateHandle),
				TCHAR_TO_UTF8(*Key), TCHAR_TO_UTF8(*Value));
		}
	}
#endif
	return false;
}
