(function () {
  if (!document.getElementById('uecp-message-css')) {
    const s = document.createElement('style'); s.id = 'uecp-message-css';
    s.textContent = `
uecp-message{display:block;margin-bottom:24px}
uecp-message[data-contain]{contain:content}
/* Breathing room before a SPEAKER block, so a question and its answer read as separate
   turns. Applied to the user and model rows themselves rather than to an adjacent-sibling
   pair, because a turn frequently has tool / thinking / context rows between the question
   and the reply -- with a sibling selector the gap silently vanishes exactly when the turn
   is busiest. Those in-turn rows keep the plain 24px, so a turn still reads as one block.
   uecp-thread is display:flex, so these margins SUM with the one above rather than
   collapsing into it. */
uecp-message.user{margin-top:34px;margin-bottom:28px}
uecp-message[data-role="model"]{margin-top:34px}
uecp-message .msg-head{display:flex;align-items:center;gap:9px;margin-bottom:9px}
uecp-message .msg-rule{height:1px;flex:1;background:var(--ue-line-soft)}
uecp-message .msg-label{font-family:var(--ue-font-mono);font-size:10px;font-weight:var(--ue-fw-semi);letter-spacing:.13em}
uecp-message .msg-label.you{color:var(--ue-accent-bright)}
uecp-message .msg-label.arch{color:var(--ue-text-mid)}
uecp-message .msg-dot{width:7px;height:7px;border-radius:50%;background:var(--ue-accent)}
uecp-message .msg-body{font-size:var(--ue-fs-base);line-height:1.62;color:var(--ue-text-hi)}
uecp-message .msg-body img{max-width:100%;border-radius:var(--ue-r);margin-top:6px}
uecp-message .msg-thumb{display:flex;flex-wrap:wrap;gap:6px;margin-top:6px}
uecp-message .msg-thumb img{max-height:120px;max-width:200px;border-radius:var(--ue-r);border:1px solid var(--ue-line);cursor:zoom-in}
uecp-message .think-wrap{background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r);margin-bottom:8px}
uecp-message .think-head{display:flex;align-items:center;gap:7px;padding:7px 11px;cursor:pointer;font-family:var(--ue-font-mono);font-size:10px;font-weight:var(--ue-fw-semi);letter-spacing:.1em;color:var(--ue-text-lo)}
uecp-message .think-body{padding:8px 13px;font-family:var(--ue-font-mono);font-size:12px;color:var(--ue-text-mid);line-height:1.55;white-space:pre-wrap;display:none}
uecp-message .think-wrap.open .think-body{display:block}
uecp-message .ctx-wrap{background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r);margin-bottom:8px}
uecp-message .ctx-head{display:flex;align-items:center;gap:7px;padding:7px 11px;cursor:pointer;font-family:var(--ue-font-mono);font-size:10px;font-weight:var(--ue-fw-semi);letter-spacing:.1em;color:var(--ue-text-lo)}
uecp-message .ctx-body{padding:8px 13px;font-family:var(--ue-font-mono);font-size:11.5px;color:var(--ue-text-mid);white-space:pre-wrap;max-height:200px;overflow:auto;display:none}
uecp-message .ctx-wrap.open .ctx-body{display:block}
uecp-message .compact-wrap{border-top:1px dashed var(--ue-line-soft);border-bottom:1px dashed var(--ue-line-soft);padding:4px 0;margin:8px 0;text-align:center}
uecp-message .compact-label{font-family:var(--ue-font-mono);font-size:10px;font-weight:var(--ue-fw-semi);letter-spacing:.1em;color:var(--ue-text-lo);cursor:pointer}
uecp-message .compact-body{font-size:12px;color:var(--ue-text-mid);padding:6px 0;display:none}
uecp-message .compact-wrap.open .compact-body{display:block}
uecp-message .sys-wrap{background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r);margin-bottom:8px}
uecp-message .sys-head{display:flex;align-items:center;gap:7px;padding:6px 11px;cursor:pointer;font-family:var(--ue-font-mono);font-size:10px;font-weight:var(--ue-fw-semi);letter-spacing:.1em;color:var(--ue-text-lo)}
uecp-message .sys-body{padding:8px 13px;font-size:12px;color:var(--ue-text-mid);display:none}
uecp-message .sys-wrap.open .sys-body{display:block}
uecp-message .fallback-text{font-family:var(--ue-font-mono);font-size:12px;color:var(--ue-text-lo);padding:4px 0}
uecp-message .retry-row{margin-top:8px}
uecp-message .btn-retry{font-family:var(--ue-font-mono);font-size:11px;font-weight:500;color:var(--ue-accent-bright);background:none;border:1px solid var(--ue-accent);border-radius:var(--ue-r-sm);padding:4px 10px;cursor:pointer}
/* Budget pause: carry on (or raise the limit) in one click. Hidden once the user has replied
   past the pause (uecp-thread adds .bp-answered), so an old pause cannot resume a chat twice. */
uecp-message .budget-row{margin-top:12px;display:flex;flex-wrap:wrap;gap:8px;align-items:center}
uecp-message.bp-answered .budget-row{display:none}
uecp-message .btn-budget{font-size:12px;font-weight:500;color:var(--ue-accent-bright);background:none;border:1px solid var(--ue-accent);border-radius:var(--ue-r-sm);padding:6px 12px;cursor:pointer}
uecp-message .btn-budget.primary{background:var(--ue-accent);border-color:var(--ue-accent);color:var(--ue-on-accent);font-weight:var(--ue-fw-semi)}
uecp-message .btn-budget:hover:not(:disabled){filter:brightness(1.12)}
uecp-message .btn-budget:disabled{opacity:.45;cursor:default}
uecp-message .budget-note{flex-basis:100%;font-size:11px;color:var(--ue-text-lo)}
/* Play-test offer: opt-in PIE after a logic change. Same button style as the budget pause; the
   whole row goes once the user has answered it (uecp-thread adds .bp-answered). */
uecp-message.bp-answered[data-kind="playtest"]{display:none}
/* Premium offer (a failed play test, warnings left in the graph, a halt): same row and rules. A row
   with nothing to offer -- no premium tier, suggestions off, or already on it -- is not shown. */
uecp-message.bp-answered[data-kind="premium"],uecp-message[data-kind="premium-none"]{display:none}
uecp-message .playtest-text{flex-basis:100%;font-size:12.5px;color:var(--ue-text-mid)}
/* Per-message delete affordance (shown on hover) */
uecp-message{position:relative}
/* Delete affordance — a proper icon button (not a bare glyph) that fades in on hover.
   It carries a solid background so it stays legible over the message head / timestamp,
   and turns red on hover to signal the destructive action. */
uecp-message .msg-actions{position:absolute;top:-2px;right:0;display:none;gap:5px}
uecp-message:hover .msg-actions{display:inline-flex}
uecp-message .msg-act{display:inline-flex;align-items:center;justify-content:center;width:24px;height:24px;background:var(--ue-elev);border:1px solid var(--ue-line);cursor:pointer;color:var(--ue-text-lo);border-radius:var(--ue-r-sm)}
uecp-message .msg-act svg{width:13px;height:13px;display:block}
uecp-message .msg-act:hover{color:var(--ue-text-hi)}
uecp-message .msg-act.danger:hover{color:var(--ue-err,#cf6b5a);border-color:var(--ue-err,#cf6b5a)}
uecp-message .msg-act.copied{color:var(--ue-ok,#5bb98c);border-color:var(--ue-ok,#5bb98c)}
/* Per-message timestamp — hidden by default; the thread reveals it via .show-timestamps
   (Settings > Preferences > Show timestamps) so toggling never re-renders messages. */
uecp-message .msg-ts{display:none;font-family:var(--ue-font-mono);font-size:10px;color:var(--ue-text-lo);margin-left:auto;flex-shrink:0}
uecp-thread.show-timestamps uecp-message .msg-ts{display:inline-block}`;
    document.head.appendChild(s);
  }

  function copyToClipboard(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).catch(function () {});
    } else {
      var ta = document.createElement('textarea');
      ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select();
      try { document.execCommand('copy'); } catch (e) {}
      document.body.removeChild(ta);
    }
  }

  const t = function (key, vars) {
    if (window.uecp && typeof window.uecp.t === 'function') return window.uecp.t(key, vars);
    let out = String(key);
    if (vars) Object.keys(vars).forEach(function (k) {
      out = out.replace(new RegExp('\\{' + k + '\\}', 'g'), String(vars[k]));
    });
    return out;
  };

  function budgetValue(n) {
    if (n >= 1000000) {
      const m = String(Math.round(n / 10000) / 100);
      return { label: m + 'M', cmd: m + 'm' };
    }
    const k = String(Math.round(n / 1000));
    return { label: k + 'K', cmd: k + 'k' };
  }

  var COPY_SVG = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="9" width="13" height="13" rx="2"/><path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"/></svg>';

  class UecpMessage extends HTMLElement {
    connectedCallback() {
      this.setAttribute('data-contain', '');
    }

    render(msg) {
      const info = window.UECP.classifyMessage(msg);
      this.className = '';
      this.innerHTML = '';
      if (info && (info.kind === 'playtest' || info.kind === 'premium')) this.dataset.kind = info.kind;
      else delete this.dataset.kind;
      this._offerMsg = (info && (info.kind === 'playtest' || info.kind === 'premium')) ? msg : null;
      switch (info.kind) {
        case 'user':      this._renderUser(info);      break;
        case 'model':     this._renderModel(info);     break;
        case 'tool':      this._renderTool(info);      break;
        case 'thinking':  this._renderThinking(info);  break;
        case 'context':   this._renderContext(info);   break;
        case 'compaction':this._renderCompaction(info);break;
        case 'system':    this._renderSystem(info);    break;
        case 'diff':      this._renderDiff(info);      break;
        case 'playtest':  this._renderPlayTestOffer(); break;
        case 'premium':   if (!this._renderPremiumOffer(info)) this.dataset.kind = 'premium-none'; break;
        default:          this._renderFallback(info);  break;
      }
      if (msg && typeof msg.ts === 'number' && isFinite(msg.ts)) {
        const tsEl = document.createElement('span');
        tsEl.className = 'msg-ts';
        try { tsEl.textContent = new Date(msg.ts).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }); }
        catch (e) { tsEl.textContent = ''; }
        const head = this.querySelector('.msg-head');
        (head || this).appendChild(tsEl);
      }

      let copyText = '';
      if (info) {
        if (info.kind === 'model' && window.UECP.normalizeModel) {
          const n = window.UECP.normalizeModel(info.text || '');
          copyText = (n && n.text) ? n.text : (info.text || '');
        } else {
          copyText = info.text || '';
        }
      }
      const absIdx = this.dataset.idx;
      const canCopy = !!(copyText && copyText.trim());
      const canDelete = absIdx != null;
      if (canCopy || canDelete) {
        const actions = document.createElement('div');
        actions.className = 'msg-actions';

        if (canCopy) {
          const copyBtn = document.createElement('button');
          copyBtn.className = 'msg-act';
          copyBtn.setAttribute('data-tip', 'Copy message');
          copyBtn.innerHTML = COPY_SVG;
          const text = copyText;
          copyBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            copyToClipboard(text);
            copyBtn.classList.add('copied');
            copyBtn.innerHTML = (window.UECP.icon ? window.UECP.icon('ic-check', 13) : 'OK');
            copyBtn.setAttribute('data-tip', 'Copied');
            setTimeout(function () {
              copyBtn.classList.remove('copied');
              copyBtn.innerHTML = COPY_SVG;
              copyBtn.setAttribute('data-tip', 'Copy message');
            }, 1200);
          });
          actions.appendChild(copyBtn);
        }

        if (canDelete) {
          const idx = parseInt(absIdx, 10);
          const delBtn = document.createElement('button');
          delBtn.className = 'msg-act danger msg-delete';
          delBtn.setAttribute('data-tip', 'Delete message');
          delBtn.innerHTML = (window.UECP.icon ? window.UECP.icon('ic-trash', 13) : '&times;');
          delBtn.addEventListener('click', function (e) {
            e.stopPropagation();
            if (window.UECP.dialog && window.UECP.dialog.confirm) {
              window.UECP.dialog.confirm('Delete message', "Delete this message from the conversation? This can't be undone.")
                .then(function (ok) { if (ok) window.uecp.call('delete_message', { index: idx }); });
            } else {
              window.uecp.call('delete_message', { index: idx });
            }
          });
          actions.appendChild(delBtn);
        }

        this.appendChild(actions);
      }
    }

    _renderUser(info) {
      this.classList.add('user');
      const head = this._makeHead('YOU', false);
      const body = document.createElement('div'); body.className = 'msg-body';
      body.setAttribute('data-i18n-skip', '');
      const render = window.UECP.renderMarkdown;
      if (render) {
        body.innerHTML = render(info.text || '');
      } else {
        body.textContent = info.text || '';
      }
      this.appendChild(head);
      this.appendChild(body);
      if (info.images && info.images.length) {
        const thumbs = document.createElement('div'); thumbs.className = 'msg-thumb';
        info.images.forEach(function (im) {
          const img = document.createElement('img');
          img.src = 'data:' + (im.mime_type || 'image/png') + ';base64,' + (im.data || '');
          img.alt = 'attached image';
          img.addEventListener('click', function () {
            window.UECP.openLightbox({ kind: 'image', src: img.src });
          });
          thumbs.appendChild(img);
        });
        this.appendChild(thumbs);
      }
    }

    _renderModel(info) {
      this.dataset.role = 'model';
      const normalized = window.UECP.normalizeModel(info.text || '');
      const head = this._makeHead('ARCHITECT', true);
      this.appendChild(head);
      if (normalized.toolCalls && normalized.toolCalls.length) {
        const tc = document.createElement('uecp-toolcall');
        tc.setToolCalls(normalized.toolCalls);
        this.appendChild(tc);
      }
      if (normalized.text) {
        const body = document.createElement('div'); body.className = 'msg-body';
      body.setAttribute('data-i18n-skip', '');
        const render = window.UECP.renderMarkdown;
        if (render) {
          body.innerHTML = render(normalized.text);
        } else {
          body.textContent = normalized.text;
        }
        this.appendChild(body);
      }
      if (info.isError) {
        const row = document.createElement('div'); row.className = 'retry-row';
        const btn = document.createElement('button'); btn.className = 'btn-retry';
        btn.textContent = 'Retry';
        btn.addEventListener('click', function () { window.uecp.call('retry', {}); });
        row.appendChild(btn);
        this.appendChild(row);
      }
      if (info.budgetPause) this._renderBudgetActions(info.budgetLimit);
    }

    _renderBudgetActions(limit) {
      const next = budgetValue(limit > 0 ? limit * 2 : 2000000);
      const opts = [
        { label: t('Continue'), cmd: 'continue', primary: true },
        { label: t('Continue with a {n} limit', { n: next.label }), cmd: 'continue ' + next.cmd },
        { label: t('Continue with no limit'), cmd: 'continue off' },
      ];
      const row = document.createElement('div'); row.className = 'budget-row';
      opts.forEach(function (o) {
        const btn = document.createElement('button');
        btn.className = 'btn-budget' + (o.primary ? ' primary' : '');
        btn.textContent = o.label;
        btn.addEventListener('click', function () {
          row.querySelectorAll('button').forEach(function (b) { b.disabled = true; });
          const hook = window.UECP && window.UECP.compactFirstArgs;
          window.uecp.call('send_message', Object.assign({ text: o.cmd }, hook ? hook() : {}));
        });
        row.appendChild(btn);
      });
      const note = document.createElement('div'); note.className = 'budget-note';
      note.textContent = t('A new limit is kept for your next messages too. Change it any time in Settings → AI Behaviour.');
      row.appendChild(note);
      this.appendChild(row);
    }

    refreshOffer() {
      if (!this._offerMsg) return;
      const cls = this.className;
      const spent = !!this.querySelector('.budget-row button:disabled');
      this.render(this._offerMsg);
      this.className = cls;
      if (spent) this.querySelectorAll('.budget-row button').forEach(function (b) { b.disabled = true; });
    }

    _renderPlayTestOffer() {
      const REQUEST = 'Run the automated play test for what you just built.';
      const row = document.createElement('div'); row.className = 'budget-row';
      const text = document.createElement('div'); text.className = 'playtest-text';
      text.textContent = t('Logic is done. Run automated play tests? (Experimental)');
      row.appendChild(text);

      const composer = document.querySelector('uecp-composer');
      const tier = composer && composer.premiumTier ? composer.premiumTier() : null;
      const prem = tier ? { index: tier.index, name: tier.name } : null;
      const onPrem = !!(tier && tier.active);

      const send = function (slotIdx) {
        row.querySelectorAll('button').forEach(function (b) { b.disabled = true; });
        if (slotIdx != null && composer && composer.useSlotForOneTurn) composer.useSlotForOneTurn(slotIdx);
        window.uecp.call('send_message', { text: REQUEST });
      };
      const add = function (label, primary, slotIdx) {
        const btn = document.createElement('button');
        btn.className = 'btn-budget' + (primary ? ' primary' : '');
        btn.textContent = label;
        btn.addEventListener('click', function () { send(slotIdx); });
        row.appendChild(btn);
      };
      if (prem && !onPrem) {
        add(t('Run with {name} (recommended, about 3x tokens)', { name: prem.name || 'BpLabs Premium' }), true, prem.index);
        add(t('Run play test'), false, null);
      } else {
        add(t('Run play test'), true, null);
      }
      this.appendChild(row);
    }

    _renderPremiumOffer(info) {
      const composer = document.querySelector('uecp-composer');
      const tier = composer && composer.premiumTier ? composer.premiumTier() : null;
      const prem = (tier && !tier.active) ? { index: tier.index, name: tier.name || 'BpLabs Premium' } : null;
      const name = prem ? prem.name : '';
      let text, request, premLabel, plainLabel = '';
      if (info.reason === 'play_test_fail') {
        text = t('The play test failed.');
        request = 'Fix what the play test found, then run the play test again to confirm the fix.';
        premLabel = t('Fix it with {name} (recommended, about 3x tokens)', { name: name });
        plainLabel = t('Fix it');
      } else if (info.reason === 'warnings') {
        text = info.count === 1
          ? t('1 build warning is still in the graph. It usually means the logic will not do what was asked.')
          : t('{n} build warnings are still in the graph. They usually mean the logic will not do what was asked.', { n: info.count });
        request = 'Fix the build warnings that are still in the graph. Treat each as a bug unless you can point to evidence that it is wrong.';
        const quoted = (info.warnings || []).slice(0, 5);
        if (quoted.length) request += '\n\n' + quoted.map(function (w) { return '- ' + w; }).join('\n');
        premLabel = t('Fix with {name} (recommended, about 3x tokens)', { name: name });
        plainLabel = t('Fix them');
      } else if (info.reason === 'halt') {
        text = t('The agent was stopped because it was not making progress.');
        request = 'Continue the task. The last attempt was stopped because it was not making progress, so take a different approach.';
        premLabel = t('Continue with {name} (recommended, about 3x tokens)', { name: name });
      } else {
        return false;
      }
      if (!prem && !plainLabel) return false;

      const row = document.createElement('div'); row.className = 'budget-row';
      const note = document.createElement('div'); note.className = 'playtest-text';
      note.textContent = text;
      row.appendChild(note);
      const add = function (label, primary, slotIdx) {
        const btn = document.createElement('button');
        btn.className = 'btn-budget' + (primary ? ' primary' : '');
        btn.textContent = label;
        btn.addEventListener('click', function () {
          row.querySelectorAll('button').forEach(function (b) { b.disabled = true; });
          if (slotIdx != null && composer && composer.useSlotForOneTurn) composer.useSlotForOneTurn(slotIdx);
          window.uecp.call('send_message', { text: request });
        });
        row.appendChild(btn);
      };
      if (prem) add(premLabel, true, prem.index);
      if (plainLabel) add(plainLabel, !prem, null);
      this.appendChild(row);
      return true;
    }

    _renderTool(info) {
      const parsed = window.UECP.parseToolResult(info.text || '');
      const tc = document.createElement('uecp-toolcall');
      tc.setSingle(parsed);
      this.appendChild(tc);
    }

    renderToolBatch(msgs) {
      this.className = '';
      this.innerHTML = '';
      const parse = window.UECP.parseToolResult;
      const calls = (msgs || []).map(function (m) {
        const t = (m && m.parts && m.parts[0] && m.parts[0].text) || '';
        return parse(t);
      });
      const tc = document.createElement('uecp-toolcall');
      tc.setMany(calls);
      this.appendChild(tc);
    }

    _renderThinking(info) {
      const wrap = document.createElement('div'); wrap.className = 'think-wrap';
      if (info.blockId) wrap.dataset.blockId = info.blockId;
      const head = document.createElement('div'); head.className = 'think-head';
      head.innerHTML = window.UECP.icon('ic-architect', 12) + '<span>REASONING</span><span style="flex:1"></span>' + window.UECP.icon('ic-chevron', 12);
      head.addEventListener('click', function () { wrap.classList.toggle('open'); });
      const body = document.createElement('div'); body.className = 'think-body';
      body.setAttribute('data-i18n-skip', '');
      body.textContent = info.text || '';
      wrap.appendChild(head); wrap.appendChild(body);
      this.appendChild(wrap);
    }

    _renderContext(info) {
      const wrap = document.createElement('div'); wrap.className = 'ctx-wrap';
      const head = document.createElement('div'); head.className = 'ctx-head';
      const name = info.fileName || 'context';
      const chars = info.charCount ? ' · ' + window.UECP.escapeHtml(String(info.charCount)) + ' chars' : '';
      head.innerHTML = window.UECP.icon('ic-learn', 12) + '<span>' + window.UECP.escapeHtml(name) + chars + '</span><span style="flex:1"></span>' + window.UECP.icon('ic-chevron', 12);
      head.addEventListener('click', function () { wrap.classList.toggle('open'); });
      const body = document.createElement('div'); body.className = 'ctx-body';
      body.setAttribute('data-i18n-skip', '');
      body.textContent = info.content || '';
      wrap.appendChild(head); wrap.appendChild(body);
      this.appendChild(wrap);
    }

    _renderCompaction(info) {
      const wrap = document.createElement('div'); wrap.className = 'compact-wrap';
      const label = document.createElement('div'); label.className = 'compact-label';
      label.textContent = '··· CONTEXT COMPACTED ···';
      label.addEventListener('click', function () { wrap.classList.toggle('open'); });
      const body = document.createElement('div'); body.className = 'compact-body';
      body.setAttribute('data-i18n-skip', '');
      body.textContent = info.text || '';
      wrap.appendChild(label); wrap.appendChild(body);
      this.appendChild(wrap);
    }

    _renderSystem(info) {
      const wrap = document.createElement('div'); wrap.className = 'sys-wrap';
      const head = document.createElement('div'); head.className = 'sys-head';
      const preview = (info.text || '').slice(0, 60);
      head.innerHTML = window.UECP.icon('ic-tools', 12) + '<span>' + window.UECP.escapeHtml(preview) + (info.text && info.text.length > 60 ? '…' : '') + '</span><span style="flex:1"></span>' + window.UECP.icon('ic-chevron', 12);
      head.addEventListener('click', function () { wrap.classList.toggle('open'); });
      const body = document.createElement('div'); body.className = 'sys-body';
      body.setAttribute('data-i18n-skip', '');
      body.textContent = info.text || '';
      wrap.appendChild(head); wrap.appendChild(body);
      this.appendChild(wrap);
    }

    _renderDiff(info) {
      const bar = document.createElement('uecp-diff-bar');
      if (typeof bar.setDiff === 'function') bar.setDiff(info.diff);
      this.appendChild(bar);
    }

    _renderFallback(info) {
      const d = document.createElement('div'); d.className = 'fallback-text';
      d.setAttribute('data-i18n-skip', '');
      d.textContent = info.text || '';
      this.appendChild(d);
    }

    _makeHead(label, isArch) {
      const head = document.createElement('div'); head.className = 'msg-head';
      if (isArch) {
        const dot = document.createElement('span'); dot.className = 'msg-dot'; head.appendChild(dot);
      }
      const lbl = document.createElement('span');
      lbl.className = 'msg-label mono ' + (isArch ? 'arch' : 'you');
      lbl.textContent = label;
      head.appendChild(lbl);
      const rule = document.createElement('span'); rule.className = 'msg-rule';
      head.appendChild(rule);
      return head;
    }
  }
  customElements.define('uecp-message', UecpMessage);
})();
