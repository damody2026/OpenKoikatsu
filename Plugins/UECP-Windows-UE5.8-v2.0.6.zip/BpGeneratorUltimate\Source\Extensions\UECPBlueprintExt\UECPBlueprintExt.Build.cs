﻿// Copyright 2026, BlueprintsLab, All rights reserved
using UnrealBuildTool;

public class UECPBlueprintExt : ModuleRules
{
	public UECPBlueprintExt(ReadOnlyTargetRules Target) : base(Target)
	{
		bUsePrecompiled = true;
		if (Target.Type != TargetType.Editor) return;
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;
		bUseUnity = false;

		PublicDependencyModuleNames.AddRange(new string[]
		{
			"Core", "CoreUObject", "Engine", "Json", "JsonUtilities",
			"UECPCore",
		});

		PrivateDependencyModuleNames.AddRange(new string[]
		{
			"Projects", "UnrealEd", "AssetTools", "AssetRegistry", "EditorScriptingUtilities",
			"Slate", "SlateCore", "InputCore", "EditorFramework", "ToolMenus",
			"ApplicationCore", "ContentBrowser", "ContentBrowserData", "DesktopPlatform",
			"ImageWrapper",

			"Kismet", "KismetCompiler", "BlueprintGraph", "GraphEditor",
			"AnimGraph", "UMG", "UMGEditor", "Blutility",
			"EnhancedInput", "InputBlueprintNodes",

			"AIModule",

			"GameplayTags", "GameplayTagsEditor",
		});
	}
}

