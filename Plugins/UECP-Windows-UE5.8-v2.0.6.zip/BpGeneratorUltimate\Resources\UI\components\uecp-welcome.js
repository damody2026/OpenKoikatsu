(function () {
  if (!document.getElementById('uecp-welcome-css')) {
    const s = document.createElement('style'); s.id = 'uecp-welcome-css';
    s.textContent = `
uecp-welcome{display:flex;flex-direction:column;align-items:center;justify-content:center;flex:1;min-height:0;padding:40px 24px;gap:28px}
uecp-welcome .welcome-brand{display:flex;flex-direction:column;align-items:center;gap:10px}
uecp-welcome .welcome-logo{width:48px;height:48px;border-radius:var(--ue-r-md);background:linear-gradient(150deg,var(--ue-accent),var(--ue-accent-deep));display:flex;align-items:center;justify-content:center}
uecp-welcome .welcome-logo svg{stroke:var(--ue-on-accent)}
uecp-welcome .welcome-title{font-size:22px;font-weight:var(--ue-fw-semi);color:var(--ue-text-hi);text-align:center}
uecp-welcome .welcome-sub{font-size:13.5px;color:var(--ue-text-mid);text-align:center}
uecp-welcome .welcome-chips{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;max-width:560px}
uecp-welcome .chip{font-size:12.5px;color:var(--ue-text-mid);background:var(--ue-panel);border:1px solid var(--ue-line);border-radius:var(--ue-r);padding:8px 14px;cursor:pointer;text-align:center}
uecp-welcome .chip:hover{border-color:var(--ue-accent);color:var(--ue-accent-bright)}
uecp-welcome .welcome-scan{display:none;align-items:center;gap:10px;max-width:560px;padding:10px 14px;border:1px solid var(--ue-accent);border-radius:var(--ue-r);background:var(--ue-accent-soft);font-size:12.5px;color:var(--ue-text-hi)}
uecp-welcome.needs-index .welcome-scan{display:flex}
uecp-welcome .welcome-scan .grow{flex:1}`;
    document.head.appendChild(s);
  }

  const CHIPS = [
    'Build a character inventory system in Blueprint',
    'Create a GOAP AI with goals and actions',
    'Set up a damage/health component with UI'
  ];

  class UecpWelcome extends HTMLElement {
    connectedCallback() {
      this.innerHTML =
        '<div class="welcome-brand">' +
          '<div class="welcome-logo">' + window.UECP.icon('ic-architect', 24) + '</div>' +
          '<div class="welcome-title">What should I build?</div>' +
          '<div class="welcome-sub">Describe a system, component, or Blueprint — I\'ll build it end-to-end.</div>' +
        '</div>' +
        '<div class="welcome-scan">' +
          '<span class="grow">This project has not been indexed yet. Scanning lets me find assets instead of browsing folders.</span>' +
          '<button class="chip act-scan-now">Scan now</button>' +
        '</div>' +
        '<div class="welcome-chips">' +
          CHIPS.map(function (c) {
            return '<div class="chip">' + window.UECP.escapeHtml(c) + '</div>';
          }).join('') +
        '</div>';

      const self = this;
      this.querySelectorAll('.welcome-chips .chip').forEach(function (el, i) {
        el.addEventListener('click', function () {
          self._prefill(CHIPS[i]);
        });
      });

      const scanNow = this.querySelector('.act-scan-now');
      if (scanNow) scanNow.addEventListener('click', function () {
        if (window.uecp && typeof window.uecp.call === 'function') window.uecp.call('scan_project', {});
        self.classList.remove('needs-index');
      });

      if (window.uecp && typeof window.uecp.on === 'function') {
        this._uIndex = window.uecp.on('scan.index_state', function (d) {
          self.classList.toggle('needs-index', !!(d && d.exists === false));
        });
      }
      if (window.UECP && window.UECP._indexExists === false) this.classList.add('needs-index');
    }

    disconnectedCallback() {
      if (typeof this._uIndex === 'function') { try { this._uIndex(); } catch (e) {} }
      this._uIndex = null;
    }

    _prefill(text) {
      let el = this;
      while (el && el !== document.body) {
        const c = el.querySelector ? el.querySelector('uecp-composer') : null;
        if (c && c.prefill) { c.prefill(text); return; }
        el = el.parentElement;
      }
      this.dispatchEvent(new CustomEvent('welcome-prefill', { bubbles: true, detail: { text: text } }));
    }
  }
  customElements.define('uecp-welcome', UecpWelcome);
})();
