(function () {
  class Placeholder extends HTMLElement {
    connectedCallback() {
      this.setAttribute('data-contain', '');
      this.style.cssText = 'flex:1;min-width:0;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:10px;background:var(--ue-bg)';
      this._render({ name: window.uecp.t('placeholder_default') });
      this._u = window.uecp.on('screen.state', (p) => { if (p && p.route === 'placeholder') this._render(p); });
    }
    disconnectedCallback() { if (this._u) this._u(); }
    _render(p) {
      this.innerHTML = '';
      const brand = document.createElement('div');
      brand.className = 'mono ue-eyebrow';
      brand.textContent = 'ULTIMATE ENGINE COPILOT';
      const h = document.createElement('div');
      h.style.cssText = 'font-size:var(--ue-fs-xl);font-weight:var(--ue-fw-semi);color:var(--ue-text-hi)';
      h.textContent = (p && p.name) || 'Foundation OK';
      this.appendChild(brand); this.appendChild(h);
    }
  }
  customElements.define('uecp-screen-placeholder', Placeholder);
})();
