// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "UECPSteamTypes.h"
#include "UECPSteamFriendsLibrary.generated.h"

class UTexture2D;

UENUM(BlueprintType)
enum class EUECPSteamAvatarSize : uint8
{
	Small   UMETA(DisplayName = "Small (32x32)"),
	Medium  UMETA(DisplayName = "Medium (64x64)"),
	Large   UMETA(DisplayName = "Large (184x184)"),
};

USTRUCT(BlueprintType)
struct UECPSTEAMRUNTIME_API FUECPSteamFriendInfo
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	FUECPSteamID SteamId;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	FString PersonaName;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	FString Nickname;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	EUECPSteamPersonaState PersonaState = EUECPSteamPersonaState::Offline;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	bool bIsPlayingThisGame = false;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	int32 PlayingAppId = 0;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	FUECPSteamID LobbyId;
};

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamFriendsLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Friends")
	static TArray<FUECPSteamFriendInfo> GetFriends();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Friends")
	static TArray<FUECPSteamFriendInfo> GetFriendsInGame();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Friends")
	static FUECPSteamFriendInfo GetFriendInfo(FUECPSteamID SteamId);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Friends")
	static FString GetPersonaName(FUECPSteamID SteamId);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Friends")
	static UTexture2D* GetAvatar(FUECPSteamID SteamId, EUECPSteamAvatarSize Size = EUECPSteamAvatarSize::Medium);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Friends")
	static bool IsFriend(FUECPSteamID SteamId);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Friends")
	static bool SetRichPresence(const FString& Key, const FString& Value);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Friends")
	static void ClearRichPresence();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Friends")
	static FString GetFriendRichPresence(FUECPSteamID SteamId, const FString& Key);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Friends")
	static void SetPlayedWith(FUECPSteamID SteamId);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Friends")
	static TMap<FUECPSteamID, FString> GetClans();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Friends")
	static FString GetClanTag(FUECPSteamID ClanId);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Friends")
	static bool GetClanActivityCounts(FUECPSteamID ClanId, int32& Online, int32& InGame, int32& Chatting);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Friends")
	static int32 GetFollowerCount();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Friends")
	static TArray<FUECPSteamID> GetRecentPlayers();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Friends")
	static int64 GetCoplayTime(FUECPSteamID SteamId);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Friends")
	static bool ShowInviteDialogWithConnectString(const FString& ConnectString);
};
