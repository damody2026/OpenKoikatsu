// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "UECPSteamTypes.h"
#include "UECPSteamPlatformLibrary.generated.h"

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamPlatformLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Screenshots")
	static bool TriggerScreenshot();

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Screenshots")
	static bool SetScreenshotHookEnabled(bool bHooked);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Screenshots")
	static int32 AddScreenshotToLibrary(const FString& ImageFilePath, int32 Width, int32 Height);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Screenshots")
	static bool TagUserInScreenshot(int32 ScreenshotId, FUECPSteamID SteamId);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Screenshots")
	static bool TagLocationInScreenshot(int32 ScreenshotId, const FString& LocationName);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Music")
	static bool IsMusicEnabled();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Music")
	static bool IsMusicPlaying();

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Music")
	static void PauseMusic();

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Music")
	static void PlayMusic();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Music")
	static float GetMusicVolume();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Parental")
	static bool IsParentalLockEnabled();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Parental")
	static bool IsParentalChatBlocked();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Parental")
	static bool IsParentalStoreBlocked();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|RemotePlay")
	static int32 GetRemotePlaySessionCount();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|RemotePlay")
	static bool IsPlayingOnRemoteDevice();

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|RemotePlay")
	static bool ShowRemotePlayTogetherInvite(FUECPSteamID FriendId);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Networking")
	static int32 GetPingToDataCenter(const FString& DataCenterCode);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Networking")
	static bool IsPingDataReady();

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Networking")
	static void RefreshPingData();
};
