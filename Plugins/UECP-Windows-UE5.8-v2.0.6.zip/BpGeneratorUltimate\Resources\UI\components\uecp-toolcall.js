(function () {
  if (!document.getElementById('uecp-toolcall-css')) {
    const s = document.createElement('style'); s.id = 'uecp-toolcall-css';
    s.textContent = `
uecp-toolcall{display:block;margin-bottom:8px}
uecp-toolcall .tools{display:flex;align-items:center;gap:11px;padding:9px 13px;background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r);cursor:pointer}
uecp-toolcall .tools-check{width:17px;height:17px;border-radius:50%;display:flex;align-items:center;justify-content:center;flex-shrink:0}
uecp-toolcall .tools-check.ok{background:var(--ue-success-soft)}
uecp-toolcall .tools-check.ok svg{stroke:var(--ue-success)}
/* Failure states are amber, both of them. A tool call that fails and is retried is
   ordinary here rather than exceptional, so red on the collapsed row would fire on
   nearly every turn -- which stops it meaning anything AND makes working software
   look broken to someone watching it run.
   The some/all distinction is still worth drawing, so it is carried by the ICON
   (exclamation vs cross) rather than by hue. That also survives being colour-blind,
   which hue alone never did. */
uecp-toolcall .tools-check.warn{background:var(--ue-warn-soft)}
uecp-toolcall .tools-check.warn svg{stroke:var(--ue-warn)}
uecp-toolcall .tools-check.err{background:var(--ue-warn-soft)}
uecp-toolcall .tools-check.err svg{stroke:var(--ue-warn)}
uecp-toolcall .tools-count{font-family:var(--ue-font-mono);font-size:12px;font-weight:500;color:var(--ue-text-mid);white-space:nowrap}
/* Failure count carries the same colour as the circle, so the ok/partial/total
   distinction survives without relying on hue alone. */
uecp-toolcall .tools-fail.warn{color:var(--ue-warn)}
uecp-toolcall .tools-fail.err{color:var(--ue-warn)}
uecp-toolcall .tools-names{font-family:var(--ue-font-mono);font-size:11.5px;color:var(--ue-text-lo);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;flex:1;min-width:0}
uecp-toolcall .tools-chevron{flex-shrink:0;transition:transform .18s}
uecp-toolcall.open .tools-chevron{transform:rotate(90deg)}
uecp-toolcall .tools-detail{display:none;background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-top:none;border-radius:0 0 var(--ue-r) var(--ue-r);padding:8px 13px;max-height:340px;overflow-y:auto}
uecp-toolcall.open .tools-detail{display:block}
uecp-toolcall .tool-entry{padding:6px 0;border-bottom:1px solid var(--ue-line-soft)}
uecp-toolcall .tool-entry:last-child{border-bottom:none}
uecp-toolcall .tool-name{font-family:var(--ue-font-mono);font-size:11.5px;font-weight:500;color:var(--ue-accent-bright);margin-bottom:4px}
uecp-toolcall .tool-status-ok{color:var(--ue-success)}
uecp-toolcall .tool-status-err{color:var(--ue-warn,#e0a54a)}
uecp-toolcall .tool-status-pending{color:var(--ue-text-lo)}
uecp-toolcall .tool-json{font-family:var(--ue-font-mono);font-size:11px;color:var(--ue-text-mid);white-space:pre-wrap;word-break:break-all;margin-top:3px}`;
    document.head.appendChild(s);
  }

  class UecpToolcall extends HTMLElement {
    connectedCallback() {
      this._calls = this._calls || [];
      if (!this.innerHTML) this._build();
    }

    setSingle(parsed) {
      this._calls = [parsed];
      this._build();
    }

    setMany(parsedArr) {
      this._calls = Array.isArray(parsedArr) ? parsedArr.slice() : [];
      this._build();
    }

    setToolCalls(arr) {
      this._calls = (arr || []).map(function (tc) {
        const argsStr = tc.arguments
          ? (typeof tc.arguments === 'string' ? tc.arguments : JSON.stringify(tc.arguments, null, 2))
          : '';
        return { tool: tc.name || '', status: 'pending', args: argsStr, result: '' };
      });
      this._build();
    }

    _build() {
      const calls = this._calls || [];
      if (!calls.length) { this.innerHTML = ''; return; }

      const errCount = calls.filter(function (c) { return c.status === 'error'; }).length;
      const statusClass = errCount === 0 ? 'ok' : (errCount === calls.length ? 'err' : 'warn');
      const ICONS = {
        ok:   window.UECP.icon('ic-check', 11),
        warn: '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M12 7v6"/><path d="M12 17h.01"/></svg>',
        err:  '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>'
      };
      const label = calls.length === 1 ? '1 tool call' : calls.length + ' tool calls';
      const failHtml = errCount
        ? '<span class="tools-fail ' + statusClass + '"> · ' + errCount + ' failed</span>'
        : '';
      const names = calls.map(function (c) { return c.tool; }).filter(Boolean).join(' · ');

      this.innerHTML =
        '<div class="tools">' +
          '<span class="tools-check ' + statusClass + '">' + ICONS[statusClass] + '</span>' +
          '<span class="tools-count">' + window.UECP.escapeHtml(label) + failHtml + '</span>' +
          '<span class="tools-names">' + window.UECP.escapeHtml(names) + '</span>' +
          '<svg class="tools-chevron" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--ue-text-lo)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>' +
        '</div>' +
        '<div class="tools-detail">' +
          calls.map(function (c) {
            const statusLabel = c.status === 'error'
              ? '<span class="tool-status-err">error</span>'
              : (c.status === 'pending'
                ? '<span class="tool-status-pending">pending</span>'
                : '<span class="tool-status-ok">success</span>');
            const fmt = function (s) {
              const pretty = window.UECP.prettyJson ? window.UECP.prettyJson(s) : s;
              const esc = window.UECP.escapeHtml(pretty);
              return window.UECP.hlJson ? window.UECP.hlJson(esc) : esc;
            };
            const argsHtml = c.args
              ? '<div class="tool-json" data-i18n-skip>' + fmt(c.args) + '</div>'
              : '';
            const resultHtml = c.result
              ? '<div class="tool-json" data-i18n-skip>' + fmt(c.result) + '</div>'
              : '';
            return '<div class="tool-entry">' +
              '<div class="tool-name">' + window.UECP.escapeHtml(c.tool || '(unknown)') + ' — ' + statusLabel + '</div>' +
              argsHtml + resultHtml +
            '</div>';
          }).join('') +
        '</div>';

      const self = this;
      this.querySelector('.tools').addEventListener('click', function () {
        self.classList.toggle('open');
      });
    }
  }
  customElements.define('uecp-toolcall', UecpToolcall);
})();
