(function () {
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  if (typeof document !== 'undefined' && document.head && !document.getElementById('uecp-dialog-css')) {
    var st = document.createElement('style'); st.id = 'uecp-dialog-css';
    st.textContent = [
      'uecp-dialog{position:fixed;inset:0;z-index:100001;display:none}',
      'uecp-dialog.open{display:block}',
      'uecp-dialog .ud-backdrop{position:absolute;inset:0;background:radial-gradient(120% 90% at 50% 0%,rgba(0,0,0,.45),rgba(0,0,0,.7));display:flex;align-items:center;justify-content:center}',
      'uecp-dialog .ud-box{width:min(440px,calc(100vw - 48px));background:var(--ue-panel);border:1px solid var(--ue-line);border-radius:var(--ue-r-xl);box-shadow:var(--ue-shadow-pop);display:flex;flex-direction:column;overflow:hidden}',
      'uecp-dialog .ud-title{font-size:14.5px;font-weight:var(--ue-fw-semi,600);color:var(--ue-text-hi);padding:16px 20px 0}',
      'uecp-dialog .ud-msg{font-size:12.5px;line-height:1.5;color:var(--ue-text-mid);padding:8px 20px 4px;white-space:pre-line}',
      'uecp-dialog .ud-input{margin:10px 20px 2px;background:var(--ue-bg);border:1px solid var(--ue-line);border-radius:var(--ue-r);color:var(--ue-text-hi);font-family:var(--ue-font-sans);font-size:13px;padding:9px 12px;box-sizing:border-box;outline:none}',
      'uecp-dialog .ud-input:focus{border-color:var(--ue-accent)}',
      'uecp-dialog .ud-btns{display:flex;gap:8px;justify-content:flex-end;padding:14px 20px 16px}',
      'uecp-dialog .ud-cancel{font-size:12.5px;font-weight:500;color:var(--ue-text-mid);background:var(--ue-elev);border:1px solid var(--ue-line);padding:8px 14px;border-radius:var(--ue-r);cursor:pointer}',
      'uecp-dialog .ud-cancel:hover{background:var(--ue-line-soft)}',
      'uecp-dialog .ud-ok{font-size:12.5px;font-weight:var(--ue-fw-semi,600);color:var(--ue-on-accent);background:var(--ue-accent);border:none;padding:8px 14px;border-radius:var(--ue-r);cursor:pointer}',
      'uecp-dialog .ud-ok:hover{filter:brightness(1.06)}'
    ].join('\n');
    document.head.appendChild(st);
  }

  var _host = null;
  var _active = null;

  function _ensureHost() {
    if (_host && _host.isConnected !== false) return _host;
    _host = document.querySelector('uecp-dialog');
    if (!_host) { _host = document.createElement('uecp-dialog'); document.body.appendChild(_host); }
    return _host;
  }

  function _finish(value) {
    if (!_active) return;
    var resolve = _active.resolve;
    _active = null;
    if (_host) { _host.classList.remove('open'); _host.innerHTML = ''; }
    resolve(value);
  }

  function _open(type, title, message, defaultValue) {
    var host = _ensureHost();
    if (_active) _finish(_active.def);

    var isPrompt = (type === 'prompt');
    var isAlert = (type === 'alert');
    var def = isPrompt ? null : (isAlert ? undefined : false);

    return new Promise(function (resolve) {
      _active = { resolve: resolve, isPrompt: isPrompt, def: def };

      host.innerHTML =
        '<div class="ud-backdrop">' +
          '<div class="ud-box" role="dialog" aria-modal="true">' +
            '<div class="ud-title">' + esc(title || '') + '</div>' +
            (message ? '<div class="ud-msg">' + esc(message) + '</div>' : '') +
            (isPrompt ? '<input class="ud-input" type="text">' : '') +
            '<div class="ud-btns">' +
              (isAlert ? '' : '<button class="ud-cancel" type="button">Cancel</button>') +
              '<button class="ud-ok" type="button">' + (isAlert ? 'OK' : (isPrompt ? 'OK' : 'Proceed')) + '</button>' +
            '</div>' +
          '</div>' +
        '</div>';
      host.classList.add('open');

      var backdrop = host.querySelector('.ud-backdrop');
      var input = host.querySelector('.ud-input');
      var okBtn = host.querySelector('.ud-ok');
      var cancelBtn = host.querySelector('.ud-cancel');

      function onOk() {
        if (isPrompt) { _finish((input ? input.value : '').trim()); }
        else if (isAlert) { _finish(undefined); }
        else { _finish(true); }
      }
      function onCancel() { _finish(isPrompt ? null : (isAlert ? undefined : false)); }

      okBtn.addEventListener('click', onOk);
      if (cancelBtn) cancelBtn.addEventListener('click', onCancel);
      window.UECP.dom.bindBackdropClose(backdrop, onCancel);

      host._keyHandler = function (e) {
        if (!host.classList.contains('open')) return;
        if (e.key === 'Enter') { e.preventDefault(); onOk(); }
        else if (e.key === 'Escape') { e.preventDefault(); onCancel(); }
      };
      document.addEventListener('keydown', host._keyHandler);

      setTimeout(function () {
        if (isPrompt && input) {
          input.value = defaultValue != null ? String(defaultValue) : '';
          input.focus(); input.select();
        } else if (okBtn) {
          okBtn.focus();
        }
      }, 0);
    }).then(function (v) {
      if (host._keyHandler) { document.removeEventListener('keydown', host._keyHandler); host._keyHandler = null; }
      return v;
    });
  }

  window.UECP = window.UECP || {};
  window.UECP.dialog = {
    confirm: function (title, message) { return _open('confirm', title, message); },
    prompt:  function (title, message, defaultValue) { return _open('prompt', title, message, defaultValue); },
    alert:   function (title, message) { return _open('alert', title, message); }
  };

  if (typeof customElements !== 'undefined' && !customElements.get('uecp-dialog')) {
    customElements.define('uecp-dialog', class extends HTMLElement {});
  }
})();
