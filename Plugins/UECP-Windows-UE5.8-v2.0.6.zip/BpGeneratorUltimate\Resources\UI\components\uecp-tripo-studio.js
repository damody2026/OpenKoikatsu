(function () {
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function svgIcon(n, sz) {
    return (window.UECP && window.UECP.icon) ? window.UECP.icon(n, sz) : '';
  }
  function toast(msg, kind) {
    if (window.UECP && window.UECP.toast) window.UECP.toast(msg, kind || 'info');
  }

  if (!document.getElementById('uecp-tripo-studio-css')) {
    const st = document.createElement('style');
    st.id = 'uecp-tripo-studio-css';
    st.textContent = `
uecp-tripo-studio .st-wrap{flex:1;min-height:0;overflow-y:auto}
uecp-tripo-studio .st-sub{display:none;flex:1;min-height:0;overflow-y:auto;padding:20px;flex-direction:column}
uecp-tripo-studio .st-sub.active{display:flex}
uecp-tripo-studio .st-back{background:none;border:none;cursor:pointer;color:var(--ue-text-mid);font-size:12.5px;display:inline-flex;align-items:center;gap:6px;padding:0 0 12px;text-decoration:none}
uecp-tripo-studio .st-back:hover{color:var(--ue-text-hi)}
uecp-tripo-studio .st-sub-title{font-size:15px;font-weight:700;color:var(--ue-text-hi);display:flex;align-items:center;gap:8px;margin-bottom:4px}
uecp-tripo-studio .st-sub-desc{font-size:12.5px;color:var(--ue-text-mid);margin-bottom:14px}
uecp-tripo-studio .st-field{margin-bottom:12px}
uecp-tripo-studio .st-label{font-size:11.5px;color:var(--ue-text-mid);margin-bottom:4px;font-weight:var(--ue-fw-semi)}
uecp-tripo-studio .st-input{width:100%;background:var(--ue-bg);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm);color:var(--ue-text-hi);padding:6px 10px;font-size:12.5px;box-sizing:border-box}
uecp-tripo-studio .st-input:focus{outline:none;border-color:var(--ue-accent)}
uecp-tripo-studio .st-row{display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap}
uecp-tripo-studio .st-btn{background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm);color:var(--ue-text-hi);padding:6px 14px;cursor:pointer;font-size:12.5px}
uecp-tripo-studio .st-btn:hover{background:var(--ue-elev)}
uecp-tripo-studio .st-btn-primary{background:var(--ue-accent);border-color:var(--ue-accent);color:var(--ue-on-accent)}
uecp-tripo-studio .st-btn-primary:hover{opacity:.88}
uecp-tripo-studio .st-result{background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm);padding:12px;font-size:12px;color:var(--ue-text-mid);min-height:60px;white-space:pre-wrap;margin-top:8px}
uecp-tripo-studio .st-bone-list{max-height:220px;overflow-y:auto;background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm);margin-top:4px}
uecp-tripo-studio .st-bone-row{display:flex;align-items:center;gap:8px;padding:5px 10px;font-size:12px;color:var(--ue-text-hi);cursor:pointer}
uecp-tripo-studio .st-bone-row:hover{background:var(--ue-elev)}
uecp-tripo-studio .st-bone-row label{cursor:pointer}
uecp-tripo-studio .st-picker{display:flex;gap:12px;align-items:flex-start}
uecp-tripo-studio .st-picker .st-bone-list{flex:1;margin-top:0}
uecp-tripo-studio .st-body{width:170px;flex:0 0 170px;background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm);padding:8px}
uecp-tripo-studio .st-body svg{display:block;width:100%;height:auto}
uecp-tripo-studio .st-zone{fill:var(--ue-elev);stroke:var(--ue-line-soft);stroke-width:2;cursor:pointer}
uecp-tripo-studio .st-zone:hover{fill:var(--ue-accent-soft);stroke:var(--ue-accent)}
uecp-tripo-studio .st-zone.on{fill:var(--ue-accent);stroke:var(--ue-accent-bright)}
uecp-tripo-studio .st-zone.off{fill:none;stroke:var(--ue-line-soft);stroke-dasharray:4 4;cursor:not-allowed;opacity:.5}
uecp-tripo-studio .st-zone-label{fill:var(--ue-text-mid);font-size:15px;text-anchor:middle;pointer-events:none;user-select:none}
uecp-tripo-studio .st-zone-label.on{fill:var(--ue-on-accent)}
uecp-tripo-studio .st-body-hint{font-size:11px;color:var(--ue-text-lo);text-align:center;margin-top:6px;min-height:14px}
uecp-tripo-studio .tripo-tabs{display:flex;gap:4px;flex-wrap:wrap;margin-bottom:14px;border-bottom:1px solid var(--ue-line-soft);padding-bottom:8px}
uecp-tripo-studio .tripo-tab{background:none;border:none;color:var(--ue-text-mid);padding:5px 12px;font-size:12.5px;cursor:pointer;border-radius:var(--ue-r-sm)}
uecp-tripo-studio .tripo-tab.active{background:var(--ue-accent-soft);color:var(--ue-accent-bright)}
uecp-tripo-studio .tripo-form{display:none;flex-direction:column}
uecp-tripo-studio .tripo-form.active{display:flex}
uecp-tripo-studio .tripo-jobs{background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm);padding:10px;margin-top:14px;font-size:12px;color:var(--ue-text-mid)}
uecp-tripo-studio .tripo-job-row{padding:6px 0;border-bottom:1px solid var(--ue-line-soft);display:flex;align-items:center;gap:8px}
uecp-tripo-studio .tripo-job-row:last-child{border-bottom:none}
uecp-tripo-studio .tripo-note{font-size:11.5px;color:var(--ue-text-lo);margin:-4px 0 10px}
uecp-tripo-studio .tripo-nokey{background:var(--ue-accent-soft);border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);padding:9px 11px;font-size:12px;color:var(--ue-text-hi);margin-bottom:12px}
uecp-tripo-studio .st-2col{display:grid;grid-template-columns:1fr 1fr;gap:12px}
uecp-tripo-studio .st-history-table{width:100%;border-collapse:collapse;font-size:12px}
uecp-tripo-studio .st-history-table th{text-align:left;color:var(--ue-text-mid);font-weight:var(--ue-fw-semi);padding:5px 8px;border-bottom:1px solid var(--ue-line-soft)}
uecp-tripo-studio .st-history-table td{padding:5px 8px;color:var(--ue-text-hi);vertical-align:top}

/* ---- v2 polish -------------------------------------------------------------
   Appended after the inherited rules so it overrides them, and scoped to this
   element so nothing else on the Tools screen shifts. */
/* Visibility is the HOST's call, signalled the same way in both places: it
   toggles '.active' on this element. The Tools screen hides subpages behind a
   landing grid, so an element that is always visible renders inline underneath
   it -- which is exactly what happened when only the inner content was made
   visible. Cloud Studio marks it active on mount, because a tab IS the page. */
uecp-tripo-studio{display:none}
uecp-tripo-studio.active{display:flex;flex-direction:column;flex:1;min-height:0}
uecp-tripo-studio .st-sub-title{font-size:17px;letter-spacing:.2px;margin-bottom:2px}
uecp-tripo-studio .st-sub-desc{margin-bottom:16px}

/* Tabs read as a segmented control rather than plain words. */
uecp-tripo-studio .tripo-tabs{gap:2px;border-bottom:1px solid var(--ue-line-soft);padding-bottom:0;margin-bottom:16px}
uecp-tripo-studio .tripo-tab{padding:8px 14px;font-size:12.5px;font-weight:var(--ue-fw-semi);
  color:var(--ue-text-mid);border-radius:var(--ue-r-sm) var(--ue-r-sm) 0 0;
  border-bottom:2px solid transparent;transition:color .12s,border-color .12s}
uecp-tripo-studio .tripo-tab:hover{color:var(--ue-text-hi);background:var(--ue-elev)}
uecp-tripo-studio .tripo-tab.active{background:transparent;color:var(--ue-accent-bright);
  border-bottom-color:var(--ue-accent)}

/* Each pane becomes a card, which is what the newer screens do and what makes a
   form look deliberate instead of dumped on the page. */
uecp-tripo-studio .tripo-form.active{display:flex;border:1px solid var(--ue-line-soft);
  border-radius:var(--ue-r-md);background:var(--ue-bg-raise);padding:16px;gap:0}

uecp-tripo-studio .st-field{margin-bottom:14px}
uecp-tripo-studio .st-label{font-size:11px;text-transform:uppercase;letter-spacing:.6px;
  color:var(--ue-text-mid);margin-bottom:6px;font-weight:var(--ue-fw-semi)}
uecp-tripo-studio .st-input{background:var(--ue-bg-sink);padding:8px 10px;font-size:13px;
  border-radius:var(--ue-r-sm);transition:border-color .12s}
uecp-tripo-studio .st-input:focus{outline:none;border-color:var(--ue-accent)}
uecp-tripo-studio textarea.st-input{min-height:64px;resize:vertical;font-family:inherit}

uecp-tripo-studio .st-btn{padding:8px 16px;font-weight:var(--ue-fw-semi);border-radius:var(--ue-r-sm);
  transition:background .12s,border-color .12s}
uecp-tripo-studio .st-btn-primary{background:var(--ue-accent);border-color:var(--ue-accent);
  color:#1a1206}
uecp-tripo-studio .st-btn-primary:hover{filter:brightness(1.08)}

/* Cost and credit lines are money, so they read as a warning rather than as
   another grey paragraph. */
uecp-tripo-studio .tripo-note,
uecp-tripo-studio .meshy-credits{font-size:12px;color:var(--ue-warn,#e0a54a);
  background:var(--ue-elev);border-radius:var(--ue-r-sm);padding:8px 10px;margin:4px 0 12px}

uecp-tripo-studio .meshy-jobs,uecp-tripo-studio .tripo-jobs{margin-top:14px;border-top:1px solid var(--ue-line-soft);
  padding-top:12px}
uecp-tripo-studio .meshy-job-row,uecp-tripo-studio .tripo-job-row{padding:8px 0}
uecp-tripo-studio .st-history-table th{font-size:11px;text-transform:uppercase;letter-spacing:.5px}

/* While a job runs the form folds away, leaving the job list at the top of the
   panel. Without this the user has pressed Generate, sees the same form, and
   presses it again -- and each press is a paid call. */
uecp-tripo-studio.busy .tripo-form.active{display:none}
uecp-tripo-studio .studio-busy{display:none}
uecp-tripo-studio.busy .studio-busy{display:flex;align-items:center;gap:10px;
  border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-md);
  background:var(--ue-bg-raise);padding:12px 14px;margin-bottom:12px}
uecp-tripo-studio .studio-busy-text{flex:1;font-size:12.5px;color:var(--ue-text-hi)}
`;
    document.head.appendChild(st);
  }

  const TRIPOJOBS = [];
  const TRIPOTASKS = [];

  class UecpTripoStudio extends HTMLElement {
    connectedCallback() {
      if (!this._initialised) {
        this._initialised = true;
      this._tripoTab = 'text';
      this._tripoReqs = {};
      this._tripoReqN = 0;
      }
      if (!this.firstChild) this._render();
      this._subscribe();
      if (this._renderTripoJobs) this._renderTripoJobs();
    }

    disconnectedCallback() {
      (this._subs || []).forEach(function (u) { try { u(); } catch (e) {} });
      this._subs = [];
    }

    _subscribe() {
      if (!window.uecp || !window.uecp.on) return;
      const self = this;
      this._subs = [
        window.uecp.on('tools.tripo_result', function (d) { self._onTripoResult(d); }),
        window.uecp.on('tools.tripo_job_added', function (d) { self._onTripoJobAdded(d); }),
        window.uecp.on('tools.tripo_job_progress', function (d) { self._onTripoJobProgress(d); }),
        window.uecp.on('tools.tripo_phase', function (d) { self._onTripoPhase(d); }),
        window.uecp.on('tools.tripo_image_picked', function (d) {
          if (!d) return;
          const f = self.querySelector('#st-t-img-path');
          if (f) f.value = d.path || '';
        }),
      ];
    }

    _toast(msg, sev) {
      if (window.UECP && window.UECP.toast) window.UECP.toast(msg, sev || 'info');
    }

    _backBtn(label) {
      if (typeof this.backButtonFactory === 'function') return this.backButtonFactory(label);
      const span = document.createElement('span');
      span.style.display = 'none';
      return span;
    }

    _syncBusy() {
      const running = TRIPOJOBS.some(function (j) { return j && !j.finished; });
      if (running) this.classList.add('busy');
      else this.classList.remove('busy');

      let banner = this.querySelector('.studio-busy');
      if (!banner) {
        const host = this.querySelector('.tripo-tabs');
        if (!host || !host.parentNode) return;
        banner = document.createElement('div');
        banner.className = 'studio-busy';
        banner.innerHTML = '<span class="studio-busy-text">Working&hellip; the form is hidden '
          + 'so you can watch progress below.</span>'
          + '<button class="st-btn" data-show-form="1">Show the form</button>';
        host.parentNode.insertBefore(banner, host.nextSibling);
        const self = this;
        banner.querySelector('[data-show-form]').addEventListener('click', function () {
          self.classList.remove('busy');
        });
      }
    }

    onOpened() {
      this._renderTripoTasks();
    }

    _render() {
      const built = this._buildTripo();
      while (this.firstChild) this.removeChild(this.firstChild);

      built.classList.add('active');
      this.appendChild(built);
    }

    _buildTripo() {
      const el = document.createElement('div');
      el.className = 'st-sub';
      el.id = 'st-sub-tripo';
      el.innerHTML =
        '<div class="st-sub-head">' +
          '<div class="st-sub-title" style="margin-bottom:0">' + svgIcon('ic-box', 14) + ' Tripo Studio</div>' +
        '</div>' +
        '<div class="st-sub-desc">Generate, rig, animate, and segment 3D assets with Tripo3D.</div>' +
        '<div class="tripo-nokey" id="st-t-nokey" style="display:none">No Tripo API key is set. Add one under <b>Settings &rsaquo; Image &amp; 3D &rsaquo; Tripo3D</b> before generating.</div>' +
        '<div class="tripo-tabs" id="st-tripo-tabs">' +
          '<button class="tripo-tab active" data-tab="text">Text&rarr;3D</button>' +
          '<button class="tripo-tab" data-tab="image">Image&rarr;3D</button>' +
          '<button class="tripo-tab" data-tab="rig">Rig</button>' +
          '<button class="tripo-tab" data-tab="animate">Animate</button>' +
          '<button class="tripo-tab" data-tab="segment">Segment</button>' +
          '<button class="tripo-tab" data-tab="tasks">Tasks</button>' +
        '</div>' +

        '<div class="tripo-form active" data-tripo-form="text">' +
          '<div class="st-field"><div class="st-label">Prompt</div><textarea class="st-input" id="st-t-text-prompt" rows="3" placeholder="a weathered bronze temple bell"></textarea></div>' +
          '<div class="st-field"><div class="st-label">Negative Prompt</div><input class="st-input" id="st-t-text-neg" placeholder="low poly, blurry"></div>' +
          '<div class="st-2col">' +
            '<div class="st-field"><div class="st-label">Asset Name</div><input class="st-input" id="st-t-text-asset" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="derived from the prompt"></div>' +
            '<div class="st-field"><div class="st-label">Save Path</div><input class="st-input" id="st-t-text-savepath" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="/Game/TripoGen/"></div>' +
          '</div>' +
          '<div class="st-field"><div class="st-label">Seed</div><input class="st-input" id="st-t-text-seed" placeholder="blank = random"></div>' +
          '<div class="tripo-note">Tripo has no separate preview/refine pass: one call produces the final textured mesh. Roughly 10-20 credits.</div>' +
          '<div class="st-row"><button class="st-btn st-btn-primary" id="st-t-text-go">Generate</button></div>' +
        '</div>' +

        '<div class="tripo-form" data-tripo-form="image">' +
          '<div class="st-field"><div class="st-label">Source Image</div><div class="st-row"><input class="st-input" id="st-t-img-path" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="C:\\path\\to\\image.png" style="flex:1"><button class="st-btn" id="st-t-img-browse">Browse</button></div></div>' +
          '<div class="st-field"><div class="st-label">Prompt (optional steer)</div><input class="st-input" id="st-t-img-prompt" placeholder="leave blank to follow the image"></div>' +
          '<div class="st-2col">' +
            '<div class="st-field"><div class="st-label">Asset Name</div><input class="st-input" id="st-t-img-asset" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="TripoFromImage"></div>' +
            '<div class="st-field"><div class="st-label">Save Path</div><input class="st-input" id="st-t-img-savepath" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="/Game/TripoGen/"></div>' +
          '</div>' +
          '<div class="tripo-note">Roughly 20-30 credits.</div>' +
          '<div class="st-row"><button class="st-btn st-btn-primary" id="st-t-img-go">Generate</button></div>' +
        '</div>' +

        '<div class="tripo-form" data-tripo-form="rig">' +
          '<div class="st-sub-desc" style="margin-top:0">Rigs a model Tripo generated. A mesh from anywhere else cannot be rigged here &mdash; use Meshy Studio, which takes a project asset.</div>' +
          '<div class="st-field"><div class="st-label">Source Task</div><select class="st-input" id="st-t-rig-task"></select></div>' +
          '<div class="st-row" style="margin-bottom:10px"><button class="st-btn" id="st-t-rig-check">Check if riggable (free)</button><span id="st-t-rig-checkout" style="font-size:12px;color:var(--ue-text-mid);align-self:center"></span></div>' +
          '<div class="st-2col">' +
            '<div class="st-field"><div class="st-label">Rig Type</div><select class="st-input" id="st-t-rig-type"><option value="biped">Biped</option><option value="quadruped">Quadruped</option></select></div>' +
            '<div class="st-field"><div class="st-label">Spec</div><select class="st-input" id="st-t-rig-spec"><option value="tripo">Tripo</option><option value="mixamo">Mixamo</option></select></div>' +
          '</div>' +
          '<div class="st-2col">' +
            '<div class="st-field"><div class="st-label">Asset Name</div><input class="st-input" id="st-t-rig-asset" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="SK_TripoRig"></div>' +
            '<div class="st-field"><div class="st-label">Save Path</div><input class="st-input" id="st-t-rig-savepath" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="/Game/TripoGen/"></div>' +
          '</div>' +
          '<div class="tripo-note">Rigging is charged even when the mesh turns out not to be riggable, so run the free check first. Imports as SkeletalMesh + Skeleton.</div>' +
          '<div class="st-row"><button class="st-btn st-btn-primary" id="st-t-rig-go">Rig</button></div>' +
        '</div>' +

        '<div class="tripo-form" data-tripo-form="animate">' +
          '<div class="st-sub-desc" style="margin-top:0">Retargets an animation onto a <b>rigged</b> task. Pick a task produced by Rig, not the original generation.</div>' +
          '<div class="st-field"><div class="st-label">Rigged Task</div><select class="st-input" id="st-t-anim-task"></select></div>' +
          '<div class="st-field"><div class="st-label">Animation</div><select class="st-input" id="st-t-anim-preset">' +
            '<option value="preset:idle">Idle</option>' +
            '<option value="preset:walk">Walk</option>' +
            '<option value="preset:run">Run</option>' +
            '<option value="preset:dive">Dive</option>' +
            '<option value="preset:climb">Climb</option>' +
            '<option value="preset:jump">Jump</option>' +
            '<option value="preset:slash">Slash</option>' +
            '<option value="preset:shoot">Shoot</option>' +
            '<option value="preset:hurt">Hurt</option>' +
            '<option value="preset:fall">Fall</option>' +
            '<option value="preset:turn">Turn</option>' +
          '</select></div>' +
          '<div class="st-2col">' +
            '<div class="st-field"><div class="st-label">Asset Name</div><input class="st-input" id="st-t-anim-asset" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="SK_TripoAnim"></div>' +
            '<div class="st-field"><div class="st-label">Save Path</div><input class="st-input" id="st-t-anim-savepath" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="/Game/TripoGen/"></div>' +
          '</div>' +
          '<div class="st-row"><button class="st-btn st-btn-primary" id="st-t-anim-go">Animate</button></div>' +
        '</div>' +

        '<div class="tripo-form" data-tripo-form="segment">' +
          '<div class="st-sub-desc" style="margin-top:0">Splits a model into parts. They arrive as one mesh with separate sections, not as separate assets.</div>' +
          '<div class="st-field"><div class="st-label">Source Task</div><select class="st-input" id="st-t-seg-task"></select></div>' +
          '<div class="st-2col">' +
            '<div class="st-field"><div class="st-label">Model</div><select class="st-input" id="st-t-seg-model"><option value="">Default</option><option value="v2.0-20240919">v2</option></select></div>' +
            '<div class="st-field"><div class="st-label">Granularity</div><select class="st-input" id="st-t-seg-gran"><option value="">Default</option><option value="simple">Simple</option><option value="balanced">Balanced</option><option value="detailed">Detailed</option></select></div>' +
          '</div>' +
          '<div class="tripo-note">Granularity applies to the v2 model only and is ignored otherwise.</div>' +
          '<div class="st-2col">' +
            '<div class="st-field"><div class="st-label">Asset Name</div><input class="st-input" id="st-t-seg-asset" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="SM_TripoParts"></div>' +
            '<div class="st-field"><div class="st-label">Save Path</div><input class="st-input" id="st-t-seg-savepath" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="/Game/TripoGen/"></div>' +
          '</div>' +
          '<div class="st-row"><button class="st-btn st-btn-primary" id="st-t-seg-go">Segment</button></div>' +
        '</div>' +

        '<div class="tripo-form" data-tripo-form="tasks">' +
          '<div class="st-sub-desc" style="margin-top:0">Tasks completed this session. These ids are what Rig, Animate and Segment chain from; they are not kept across editor restarts.</div>' +
          '<table class="st-history-table"><thead><tr><th>Asset</th><th>Kind</th><th>Task ID</th></tr></thead><tbody id="st-t-tasks-body"><tr><td colspan="3" style="padding:14px;text-align:center;color:var(--ue-text-lo)">Nothing generated yet this session.</td></tr></tbody></table>' +
        '</div>' +

        '<div class="tripo-jobs" id="st-tripo-jobs"><div style="font-size:11px;font-weight:var(--ue-fw-semi);color:var(--ue-text-mid);margin-bottom:6px">Active Jobs</div><div id="st-tripo-jobs-list" style="color:var(--ue-text-lo);font-size:12px">No active jobs.</div></div>';

      el.prepend(this._backBtn('Back to Tools'));

      const self = this;
      const q = function (id) { return el.querySelector(id); };
      const v = function (id) { const n = el.querySelector(id); return n ? n.value.trim() : ''; };

      el.querySelector('#st-tripo-tabs').addEventListener('click', function (e) {
        const btn = e.target.closest('.tripo-tab');
        if (!btn) return;
        const tab = btn.dataset.tab;
        el.querySelectorAll('.tripo-tab').forEach(function (t) { t.classList.remove('active'); });
        btn.classList.add('active');
        el.querySelectorAll('.tripo-form').forEach(function (f) { f.classList.remove('active'); });
        const form = el.querySelector('[data-tripo-form="' + tab + '"]');
        if (form) form.classList.add('active');
        self._tripoTab = tab;
      });

      q('#st-t-text-go').addEventListener('click', function () {
        const prompt = v('#st-t-text-prompt');
        if (!prompt) { self._toast('A prompt is required.', 'error'); return; }
        const args = {
          prompt:          prompt,
          negative_prompt: v('#st-t-text-neg'),
          asset_name:      v('#st-t-text-asset'),
          save_path:       v('#st-t-text-savepath')
        };
        const seed = parseInt(v('#st-t-text-seed'), 10);
        if (!isNaN(seed)) args.seed = seed;
        self._tripoSubmit('tripo_create_3d_from_text', args, 'Text\u21923D');
      });

      q('#st-t-img-browse').addEventListener('click', function () {
        window.uecp.call('tripo_browse_image', {});
      });
      q('#st-t-img-go').addEventListener('click', function () {
        const path = v('#st-t-img-path');
        if (!path) { self._toast('Pick a source image first.', 'error'); return; }
        self._tripoSubmit('tripo_create_3d_from_image', {
          image_path: path,
          prompt:     v('#st-t-img-prompt'),
          asset_name: v('#st-t-img-asset'),
          save_path:  v('#st-t-img-savepath')
        }, 'Image\u21923D');
      });

      q('#st-t-rig-check').addEventListener('click', function () {
        const task = v('#st-t-rig-task');
        if (!task) { self._toast('Generate something first \u2014 there is no task to check.', 'error'); return; }
        const out = q('#st-t-rig-checkout');
        if (out) out.textContent = 'Checking\u2026';
        self._tripoSubmit('tripo_check_riggable', { task_id: task }, 'Rig check');
      });
      q('#st-t-rig-go').addEventListener('click', function () {
        const task = v('#st-t-rig-task');
        if (!task) { self._toast('Generate something first \u2014 there is no task to rig.', 'error'); return; }
        self._tripoSubmit('tripo_rig_model', {
          task_id:    task,
          rig_type:   v('#st-t-rig-type'),
          spec:       v('#st-t-rig-spec'),
          asset_name: v('#st-t-rig-asset'),
          save_path:  v('#st-t-rig-savepath')
        }, 'Rig');
      });

      q('#st-t-anim-go').addEventListener('click', function () {
        const task = v('#st-t-anim-task');
        if (!task) { self._toast('Rig a model first \u2014 animation needs a rigged task.', 'error'); return; }
        self._tripoSubmit('tripo_animate_model', {
          task_id:    task,
          animation:  v('#st-t-anim-preset'),
          asset_name: v('#st-t-anim-asset'),
          save_path:  v('#st-t-anim-savepath')
        }, 'Animate');
      });

      q('#st-t-seg-go').addEventListener('click', function () {
        const task = v('#st-t-seg-task');
        if (!task) { self._toast('Generate something first \u2014 there is no task to segment.', 'error'); return; }
        self._tripoSubmit('tripo_segment_model', {
          task_id:     task,
          model:       v('#st-t-seg-model'),
          granularity: v('#st-t-seg-gran'),
          asset_name:  v('#st-t-seg-asset'),
          save_path:   v('#st-t-seg-savepath')
        }, 'Segment');
      });

      return el;
    }
    _tripoSubmit(tool, args, label) {
      this._lastTripoErr = null;
      const reqId = 'tripo-' + (++this._tripoReqN);
      this._tripoReqs[reqId] = { kind: 'submit', tool: tool, label: label };
      window.uecp.call('tripo_action', { tool: tool, request_id: reqId, args: args });
    }
    _onTripoResult(msg) {
      msg = msg || {};
      const req = this._tripoReqs[msg.request_id];
      delete this._tripoReqs[msg.request_id];

      if (!msg.ok) {
        this._tripoErrToast(msg.error || 'Tripo call failed.');
        this._tripoFinishByJob(req && req.jobId, 'failed');
        return;
      }
      const data = msg.data || {};

      if (req && req.kind === 'poll') {
        if (data.status === 'completed') {
          this._onTripoJobDone(req, data.result || {}, data.succeeded !== false);
        } else if (data.status === 'unknown') {
          this._tripoFinishByJob(req.jobId, 'elsewhere');
        } else {
          this._tripoSchedulePoll(req);
        }
        return;
      }

      if (!data.job_id) { this._toast('Tripo accepted the call but returned no job id.', 'error'); return; }
      const job = {
        jobId: data.job_id, tool: req ? req.tool : (msg.tool || ''),
        label: req ? req.label : (msg.tool || 'Tripo'),
        taskId: '', name: '', progress: 0, status: 'queued', finished: false
      };
      TRIPOJOBS.push(job);
      this._renderTripoJobs();
      this._syncBusy();
      this._toast((req ? req.label : 'Tripo') + ' submitted \u2014 usually 1-3 minutes.', 'info');
      this._tripoSchedulePoll({ kind: 'poll', jobId: data.job_id, tool: job.tool, label: job.label });
    }
    _tripoSchedulePoll(req) {
      const self = this;
      setTimeout(function () {
        const reqId = 'tripo-' + (++self._tripoReqN);
        self._tripoReqs[reqId] = req;
        window.uecp.call('tripo_action', {
          tool: 'tripo_get_task_status', request_id: reqId, args: { job_id: req.jobId }
        });
      }, 3000);
    }
    _onTripoJobDone(req, body, ok) {
      const job = (TRIPOJOBS || []).find(function (j) { return j && j.jobId === req.jobId; });
      if (job) { job.finished = true; job.status = ok ? 'done' : 'failed'; job.progress = 100; }

      if (!ok) {
        this._tripoErrToast(body.error || (req.label + ' failed.'));
        this._renderTripoJobs();
      this._syncBusy();
        return;
      }

      if (req.tool === 'tripo_check_riggable') {
        const out = this && this.querySelector('#st-t-rig-checkout');
        if (out) out.textContent = body.detail || (body.riggable ? 'Riggable.' : 'Not riggable.');
        this._toast(body.detail || 'Rig check complete.', body.riggable ? 'success' : 'error');
        this._renderTripoJobs();
      this._syncBusy();
        return;
      }

      if (body.task_id) {
        TRIPOTASKS.unshift({
          taskId: body.task_id,
          name:   body.asset_name || req.label,
          kind:   req.label,
          assetPath: body.asset_path || '',
          rigged: req.tool === 'tripo_rig_model'
        });
        this._renderTripoTasks();
      }
      this._toast((body.asset_name || req.label) + ' imported.', 'success');
      this._renderTripoJobs();
      this._syncBusy();
    }
    _tripoErrToast(err) {
      if (!err) return;
      if (this._lastTripoErr === err) return;
      this._lastTripoErr = err;
      this._toast(err, 'error');
      this._tripoNoKey(err);
    }
    _tripoNoKey(err) {
      if (!err || !/api key/i.test(err)) return;
      const el = this; if (!el) return;
      const b = el.querySelector('#st-t-nokey');
      if (b) b.style.display = '';
    }
    _tripoFinishByJob(jobId, status) {
      if (!jobId) return;
      const job = (TRIPOJOBS || []).find(function (j) { return j && j.jobId === jobId; });
      if (job) { job.finished = true; job.status = status; }
      this._renderTripoJobs();
      this._syncBusy();
    }
    _onTripoJobAdded(info) {
      info = info || {};
      const job = (TRIPOJOBS || []).find(function (j) { return j && !j.taskId && !j.finished; });
      if (!job) return;
      job.taskId = info.task_id || '';
      job.name   = info.asset_name || '';
      this._renderTripoJobs();
      this._syncBusy();
    }
    _onTripoJobProgress(info) {
      info = info || {};
      const job = (TRIPOJOBS || []).find(function (j) { return j && j.taskId === info.task_id; });
      if (!job) return;
      job.progress = info.progress || 0;
      job.status   = 'running';
      this._renderTripoJobs();
      this._syncBusy();
    }
    _onTripoPhase(info) {
      info = info || {};
      if (info.phase === 'failed' && info.error) this._tripoErrToast(info.error);
      const job = (TRIPOJOBS || []).find(function (j) {
        return j && !j.finished && (j.name === info.asset_name || !j.name);
      });
      if (!job) return;
      if (info.phase === 'importing') { job.status = 'importing'; job.progress = 100; }
      else if (info.phase === 'generating' || info.phase === 'submitting') { job.status = info.phase; }
      this._renderTripoJobs();
      this._syncBusy();
    }
    _renderTripoJobs() {
      const el = this; if (!el) return;
      const list = el.querySelector('#st-tripo-jobs-list'); if (!list) return;
      const live = (TRIPOJOBS || []).filter(function (j) { return j && !j.finished; });
      if (!live.length) { list.textContent = 'No active jobs.'; return; }
      list.innerHTML = live.map(function (j) {
        return '<div class="tripo-job-row"><span style="flex:1">' + esc(j.name || j.label) + '</span>' +
               '<span style="color:var(--ue-text-lo)">' + esc(j.status) + '</span>' +
               '<span style="font-family:var(--ue-font-mono);font-size:11px">' + (j.progress || 0) + '%</span></div>';
      }).join('');
    }
    _renderTripoTasks() {
      const el = this; if (!el) return;
      const body = el.querySelector('#st-t-tasks-body');
      const tasks = TRIPOTASKS || [];
      if (body) {
        body.innerHTML = tasks.length
          ? tasks.map(function (t) {
              var view = t.assetPath
                ? ' <button class="st-btn" data-view="' + esc(t.assetPath) + '" ' +
                  'style="padding:2px 8px;font-size:11px">View</button>'
                : '';
              return '<tr><td>' + esc(t.name) + view + '</td><td>' + esc(t.kind) + '</td>' +
                     '<td style="font-family:var(--ue-font-mono);font-size:11px">' + esc(t.taskId) + '</td></tr>';
            }).join('')
          : '<tr><td colspan="3" style="padding:14px;text-align:center;color:var(--ue-text-lo)">Nothing generated yet this session.</td></tr>';
      }

      if (body) {
        body.querySelectorAll('[data-view]').forEach(function (b) {
          b.addEventListener('click', function () {
            window.uecp.call('reveal_asset', { asset_path: b.getAttribute('data-view') });
          });
        });
      }

      const fill = function (sel, rows, empty) {
        if (!sel) return;
        const keep = sel.value;
        sel.innerHTML = rows.length
          ? rows.map(function (t) { return '<option value="' + esc(t.taskId) + '">' + esc(t.name) + ' \u2014 ' + esc(t.kind) + '</option>'; }).join('')
          : '<option value="">' + empty + '</option>';
        if (keep && rows.some(function (t) { return t.taskId === keep; })) sel.value = keep;
      };
      fill(el.querySelector('#st-t-rig-task'),  tasks, 'Generate a model first');
      fill(el.querySelector('#st-t-seg-task'),  tasks, 'Generate a model first');
      fill(el.querySelector('#st-t-anim-task'), tasks.filter(function (t) { return t.rigged; }), 'Rig a model first');
    }
  }

  UecpTripoStudio.JOBS = TRIPOJOBS;
  UecpTripoStudio.TASKS = TRIPOTASKS;

  customElements.define('uecp-tripo-studio', UecpTripoStudio);
})();
