// Copyright 2026, BlueprintsLab, All rights reserved
#include "Library/UECPSteamSessionLibrary.h"

#include "Engine/Engine.h"
#include "Engine/World.h"
#include "GameFramework/PlayerController.h"
#include "Kismet/GameplayStatics.h"
#include "UECPSteamOSS.h"
#include "UECPSteamRuntimeModule.h"

namespace
{
	FName ResolveSessionName(FName In)
	{
		return In.IsNone() ? NAME_GameSession : In;
	}

	EUECPSteamSessionState Convert(EOnlineSessionState::Type In)
	{
		switch (In)
		{
		case EOnlineSessionState::Creating:   return EUECPSteamSessionState::Creating;
		case EOnlineSessionState::Pending:    return EUECPSteamSessionState::Pending;
		case EOnlineSessionState::Starting:   return EUECPSteamSessionState::Starting;
		case EOnlineSessionState::InProgress: return EUECPSteamSessionState::InProgress;
		case EOnlineSessionState::Ending:     return EUECPSteamSessionState::Ending;
		case EOnlineSessionState::Ended:      return EUECPSteamSessionState::Ended;
		case EOnlineSessionState::Destroying: return EUECPSteamSessionState::Destroying;
		case EOnlineSessionState::NoSession:
		default:                              return EUECPSteamSessionState::NoSession;
		}
	}

	APlayerController* FirstLocalController(const UObject* WorldContextObject)
	{
		const UWorld* World = WorldContextObject
			? GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::ReturnNull)
			: nullptr;
		return World ? World->GetFirstPlayerController() : nullptr;
	}
}

EUECPSteamSessionState UUECPSteamSessionLibrary::GetSteamSessionState(
	const UObject* WorldContextObject, FName SessionName)
{
	const IOnlineSessionPtr Sessions = UECPSteamOSS::Session(WorldContextObject);
	return Sessions.IsValid()
		? Convert(Sessions->GetSessionState(ResolveSessionName(SessionName)))
		: EUECPSteamSessionState::NoSession;
}

bool UUECPSteamSessionLibrary::IsInSteamSession(const UObject* WorldContextObject, FName SessionName)
{
	const IOnlineSessionPtr Sessions = UECPSteamOSS::Session(WorldContextObject);
	return Sessions.IsValid() && Sessions->GetNamedSession(ResolveSessionName(SessionName)) != nullptr;
}

FString UUECPSteamSessionLibrary::GetSteamResolvedConnectString(
	const UObject* WorldContextObject, FName SessionName)
{
	const IOnlineSessionPtr Sessions = UECPSteamOSS::Session(WorldContextObject);
	if (!Sessions.IsValid())
	{
		return FString();
	}

	FString ConnectInfo;
	return Sessions->GetResolvedConnectString(ResolveSessionName(SessionName), ConnectInfo)
		? ConnectInfo
		: FString();
}

bool UUECPSteamSessionLibrary::TravelToSteamSession(const UObject* WorldContextObject, FName SessionName)
{
	const FString ConnectString = GetSteamResolvedConnectString(WorldContextObject, SessionName);
	if (ConnectString.IsEmpty())
	{
		UE_LOG(LogUECPSteam, Warning,
			TEXT("TravelToSteamSession: no connect string for session '%s'. Join the session before travelling."),
			*ResolveSessionName(SessionName).ToString());
		return false;
	}

	APlayerController* PC = FirstLocalController(WorldContextObject);
	if (!PC)
	{
		UE_LOG(LogUECPSteam, Warning, TEXT("TravelToSteamSession: no local player controller to travel."));
		return false;
	}

	PC->ClientTravel(ConnectString, ETravelType::TRAVEL_Absolute);
	return true;
}

bool UUECPSteamSessionLibrary::HostTravelToMap(const UObject* WorldContextObject, const FString& MapName)
{
	if (MapName.IsEmpty())
	{
		UE_LOG(LogUECPSteam, Warning, TEXT("HostTravelToMap: no map name given."));
		return false;
	}

	UWorld* World = WorldContextObject
		? GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::ReturnNull)
		: nullptr;
	if (!World)
	{
		return false;
	}

	FString Url = MapName;
	if (!Url.Contains(TEXT("?listen"), ESearchCase::IgnoreCase))
	{
		Url += TEXT("?listen");
	}

	return World->ServerTravel(Url);
}

int32 UUECPSteamSessionLibrary::GetSteamSessionOpenSlots(const UObject* WorldContextObject, FName SessionName)
{
	const IOnlineSessionPtr Sessions = UECPSteamOSS::Session(WorldContextObject);
	if (!Sessions.IsValid())
	{
		return 0;
	}
	const FNamedOnlineSession* Named = Sessions->GetNamedSession(ResolveSessionName(SessionName));
	return Named ? Named->NumOpenPublicConnections : 0;
}

bool UUECPSteamSessionLibrary::RegisterSteamSessionPlayer(
	const UObject* WorldContextObject, FUECPSteamID PlayerSteamId, FName SessionName, bool bWasInvited)
{
	const IOnlineSessionPtr Sessions = UECPSteamOSS::Session(WorldContextObject);
	const IOnlineIdentityPtr Identity = UECPSteamOSS::Identity(WorldContextObject);
	if (!Sessions.IsValid() || !Identity.IsValid() || !PlayerSteamId.IsValid())
	{
		return false;
	}

	const FUniqueNetIdPtr PlayerId = Identity->CreateUniquePlayerId(PlayerSteamId.ToString());
	return PlayerId.IsValid()
		&& Sessions->RegisterPlayer(ResolveSessionName(SessionName), *PlayerId, bWasInvited);
}

bool UUECPSteamSessionLibrary::UnregisterSteamSessionPlayer(
	const UObject* WorldContextObject, FUECPSteamID PlayerSteamId, FName SessionName)
{
	const IOnlineSessionPtr Sessions = UECPSteamOSS::Session(WorldContextObject);
	const IOnlineIdentityPtr Identity = UECPSteamOSS::Identity(WorldContextObject);
	if (!Sessions.IsValid() || !Identity.IsValid() || !PlayerSteamId.IsValid())
	{
		return false;
	}

	const FUniqueNetIdPtr PlayerId = Identity->CreateUniquePlayerId(PlayerSteamId.ToString());
	return PlayerId.IsValid()
		&& Sessions->UnregisterPlayer(ResolveSessionName(SessionName), *PlayerId);
}

bool UUECPSteamSessionLibrary::SendSteamSessionInvite(
	const UObject* WorldContextObject, FUECPSteamID FriendSteamId, FName SessionName)
{
	const IOnlineSessionPtr Sessions = UECPSteamOSS::Session(WorldContextObject);
	const IOnlineIdentityPtr Identity = UECPSteamOSS::Identity(WorldContextObject);
	if (!Sessions.IsValid() || !Identity.IsValid() || !FriendSteamId.IsValid())
	{
		return false;
	}

	const FUniqueNetIdPtr FriendId = Identity->CreateUniquePlayerId(FriendSteamId.ToString());
	return FriendId.IsValid()
		&& Sessions->SendSessionInviteToFriend(0, ResolveSessionName(SessionName), *FriendId);
}
