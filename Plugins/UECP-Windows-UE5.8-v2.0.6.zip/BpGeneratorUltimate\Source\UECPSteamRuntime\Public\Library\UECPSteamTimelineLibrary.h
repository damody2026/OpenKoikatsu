// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "UECPSteamTimelineLibrary.generated.h"

UENUM(BlueprintType)
enum class EUECPSteamTimelineGameMode : uint8
{
	Playing       UMETA(DisplayName = "Playing"),
	Staging       UMETA(DisplayName = "Staging (lobby / pre-match)"),
	Menus         UMETA(DisplayName = "Menus"),
	LoadingScreen UMETA(DisplayName = "Loading Screen"),
};

UENUM(BlueprintType)
enum class EUECPSteamTimelineClipPriority : uint8
{
	None     UMETA(DisplayName = "None (marker only)"),
	Standard UMETA(DisplayName = "Standard"),
	Featured UMETA(DisplayName = "Featured"),
};

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamTimelineLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Timeline")
	static bool IsTimelineAvailable();

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Timeline")
	static bool SetTimelineGameMode(EUECPSteamTimelineGameMode Mode);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Timeline",
		meta = (AdvancedDisplay = "TimeDeltaSeconds"))
	static bool SetTimelineTooltip(const FString& Description, float TimeDeltaSeconds = 0.f);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Timeline",
		meta = (AdvancedDisplay = "TimeDeltaSeconds"))
	static bool ClearTimelineTooltip(float TimeDeltaSeconds = 0.f);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Timeline",
		meta = (AdvancedDisplay = "Priority,StartOffsetSeconds,ClipPriority"))
	static int64 AddTimelineEvent(const FString& Title, const FString& Description,
		const FString& Icon, int32 Priority = 0, float StartOffsetSeconds = 0.f,
		EUECPSteamTimelineClipPriority ClipPriority = EUECPSteamTimelineClipPriority::None);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Timeline",
		meta = (AdvancedDisplay = "Priority,StartOffsetSeconds,ClipPriority"))
	static int64 AddTimelineRangeEvent(const FString& Title, const FString& Description,
		const FString& Icon, float DurationSeconds, int32 Priority = 0,
		float StartOffsetSeconds = 0.f,
		EUECPSteamTimelineClipPriority ClipPriority = EUECPSteamTimelineClipPriority::None);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Timeline",
		meta = (AdvancedDisplay = "Priority,ClipPriority"))
	static int64 StartTimelineRangeEvent(const FString& Title, const FString& Description,
		const FString& Icon, int32 Priority = 0,
		EUECPSteamTimelineClipPriority ClipPriority = EUECPSteamTimelineClipPriority::None);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Timeline",
		meta = (AdvancedDisplay = "EndOffsetSeconds"))
	static bool EndTimelineRangeEvent(int64 EventHandle, float EndOffsetSeconds = 0.f);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Timeline")
	static bool RemoveTimelineEvent(int64 EventHandle);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Timeline")
	static bool StartGamePhase();

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Timeline")
	static bool EndGamePhase();

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Timeline")
	static bool SetGamePhaseID(const FString& PhaseId);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Timeline",
		meta = (AdvancedDisplay = "TagIcon,TagGroup,Priority"))
	static bool AddGamePhaseTag(const FString& TagName, const FString& TagIcon,
		const FString& TagGroup, int32 Priority = 0);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Timeline",
		meta = (AdvancedDisplay = "Priority"))
	static bool SetGamePhaseAttribute(const FString& AttributeGroup,
		const FString& AttributeValue, int32 Priority = 0);
};
