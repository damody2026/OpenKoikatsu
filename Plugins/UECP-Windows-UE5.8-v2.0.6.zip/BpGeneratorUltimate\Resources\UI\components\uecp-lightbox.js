(function () {
  if (!document.getElementById('uecp-lightbox-css')) {
    const s = document.createElement('style'); s.id = 'uecp-lightbox-css';
    s.textContent = `
uecp-lightbox{display:contents}
uecp-lightbox .lb-overlay{background:rgba(0,0,0,.88);cursor:zoom-out;z-index:1300}
uecp-lightbox .lb-body{position:relative;max-width:92vw;max-height:92vh;cursor:default}
uecp-lightbox .lb-body img{display:block;max-width:92vw;max-height:92vh;border-radius:var(--ue-r);box-shadow:0 8px 40px rgba(0,0,0,.8)}
uecp-lightbox .lb-body svg{display:block;max-width:92vw;max-height:92vh}
uecp-lightbox .lb-close{position:absolute;top:-32px;right:0;background:none;border:none;color:var(--ue-text-hi);font-size:22px;line-height:1;cursor:pointer;padding:4px}
uecp-lightbox .lb-close:hover{color:var(--ue-accent-bright)}`;
    document.head.appendChild(s);
  }

  class UecpLightbox extends HTMLElement {
    connectedCallback() { this._keyHandler = null; }
    disconnectedCallback() { this._unbindKey(); }

    open(opts) {
      opts = opts || {};
      const self = this;
      const content = opts.kind === 'svg'
        ? (opts.html || '')
        : '<img src="' + window.UECP.escapeHtml(opts.src || '') + '" alt="">';
      this.innerHTML =
        '<div class="ue-overlay lb-overlay" id="lb-overlay">' +
          '<div class="lb-body">' +
            '<button class="lb-close" type="button" aria-label="Close">✕</button>' +
            content +
          '</div>' +
        '</div>';
      window.UECP.dom.bindBackdropClose(this.querySelector('#lb-overlay'), function () { self.close(); });
      this.querySelector('.lb-close').addEventListener('click', function () { self.close(); });
      this._bindKey();
    }

    close() {
      this.innerHTML = '';
      this._unbindKey();
    }

    _bindKey() {
      this._unbindKey();
      const self = this;
      this._keyHandler = function (e) { if (e.key === 'Escape') self.close(); };
      document.addEventListener('keydown', this._keyHandler);
    }
    _unbindKey() {
      if (this._keyHandler) { document.removeEventListener('keydown', this._keyHandler); this._keyHandler = null; }
    }
  }

  customElements.define('uecp-lightbox', UecpLightbox);

  window.UECP = window.UECP || {};
  window.UECP.openLightbox = function (opts) {
    var ov = document.querySelector('uecp-lightbox');
    if (!ov) { ov = document.createElement('uecp-lightbox'); document.body.appendChild(ov); }
    ov.open(opts);
    return ov;
  };
})();
