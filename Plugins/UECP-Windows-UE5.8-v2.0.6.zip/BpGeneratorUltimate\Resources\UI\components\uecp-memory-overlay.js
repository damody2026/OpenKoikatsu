(function () {
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  var t = function (key, vars) {
    if (window.uecp && typeof window.uecp.t === 'function') return window.uecp.t(key, vars);
    var out = String(key);
    if (vars) Object.keys(vars).forEach(function (k) {
      out = out.replace(new RegExp('\\{' + k + '\\}', 'g'), String(vars[k]));
    });
    return out;
  };

  var CATEGORIES = ['Project Info', 'Recent Work', 'Preferences', 'Patterns', 'Asset Relations', 'Decisions'];

  if (!document.getElementById('uecp-memory-overlay-css')) {
    var s = document.createElement('style'); s.id = 'uecp-memory-overlay-css';
    s.textContent = [
'uecp-memory-overlay{position:fixed;inset:0;z-index:1200;display:none}',
'uecp-memory-overlay.open{display:block}',
'uecp-memory-overlay .overlay{position:absolute;inset:0;display:flex;align-items:center;justify-content:center}',
'uecp-memory-overlay .overlay.open{display:flex}',
'uecp-memory-overlay .modal{width:720px;height:600px;display:flex;flex-direction:column;overflow:hidden}',
'uecp-memory-overlay .mem-body{display:flex;flex:1;min-height:0;flex-direction:column;overflow:hidden}',
'uecp-memory-overlay .mem-toolbar{display:flex;gap:8px;align-items:center;padding:14px 20px 10px}',
'uecp-memory-overlay .mem-tbtn{background:var(--ue-elev);border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);color:var(--ue-text-hi);padding:5px 10px;cursor:pointer;font-size:12px;white-space:nowrap}',
'uecp-memory-overlay .mem-tbtn:hover{background:var(--ue-line-soft)}',
'uecp-memory-overlay .mem-tbtn.danger{display:flex;align-items:center;gap:6px}',
'uecp-memory-overlay .mem-tbtn.danger:hover{color:var(--ue-err,#cf6b5a);border-color:var(--ue-err,#cf6b5a)}',
'uecp-memory-overlay .mem-scroll{flex:1;min-height:0;overflow-y:auto;padding:2px 20px 14px;display:flex;flex-direction:column;gap:8px}',
'uecp-memory-overlay .mem-group-label{font-size:10px;font-weight:700;letter-spacing:.5px;text-transform:uppercase;color:var(--ue-text-lo);margin:12px 0 4px}',
'uecp-memory-overlay .mem-card-content{font-size:13px;line-height:1.5;color:var(--ue-text-hi);word-break:break-word;cursor:text;white-space:pre-wrap}',
'uecp-memory-overlay .mem-edit{width:100%;background:var(--ue-bg);border:1px solid var(--ue-accent);border-radius:var(--ue-r-sm);color:var(--ue-text-hi);padding:6px 8px;font-size:12.5px;font-family:inherit;box-sizing:border-box;resize:vertical}',
'uecp-memory-overlay .mem-icon-btn-sm{background:transparent;width:26px;height:26px;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center}',
'uecp-memory-overlay .mem-icon-btn-sm svg{stroke:var(--ue-text-mid)}',
'uecp-memory-overlay .mem-empty{padding:28px 14px;text-align:center;color:var(--ue-text-lo);font-size:12.5px}',
'uecp-memory-overlay .mem-cat-select{background:var(--ue-bg);border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);color:var(--ue-text-hi);padding:4px 6px;font-size:11.5px}'
    ].join('\n');
    document.head.appendChild(s);
  }

  function svgIcon(id, size) {
    size = size || 15;
    return '<svg width="' + size + '" height="' + size + '" aria-hidden="true"><use href="#' + id + '"/></svg>';
  }

  class UecpMemoryOverlay extends HTMLElement {
    connectedCallback() {
      this._state = { memories: [], pending: [], enabledCount: 0, tokenCount: 0 };
      this._filter = '';
      this._sortNewest = true;
      this._editId = null;
      this._build();
      this._subscribe();
    }

    disconnectedCallback() {
      (this._subs || []).forEach(function (u) { u(); });
      this._subs = [];
    }

    open() {
      this.classList.add('open');
      this._editId = null;
      window.uecp.call('load_memories', {});
      this._render();
    }
    close() { this.classList.remove('open'); this._editId = null; }
    isOpen() { return this.classList.contains('open'); }

    _build() {
      var self = this;
      this.innerHTML = '';

      this._overlayEl = document.createElement('div');
      this._overlayEl.className = 'overlay open';
      this._overlayEl.setAttribute('id', 'memory-overlay-inner');
      window.UECP.dom.bindBackdropClose(this._overlayEl, function () { self.close(); });
      this.appendChild(this._overlayEl);

      this._box = document.createElement('div');
      this._box.className = 'modal';
      this._overlayEl.appendChild(this._box);

      this._box.innerHTML =
        '<div class="modal-head">' +
          '<span class="tile" style="width:26px;height:26px">' + svgIcon('ic-architect', 15) + '</span>' +
          '<div style="flex:1">' +
            '<div class="modal-title">AI Memory</div>' +
            '<div class="modal-sub">What the Architect remembers across every chat — view, disable, or remove any entry</div>' +
          '</div>' +
          '<button class="icon-btn" data-act="close" title="Close" aria-label="Close">' +
            '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18M6 6l12 12"/></svg>' +
          '</button>' +
        '</div>' +
        '<div style="padding:14px 20px 10px">' +
          '<div class="input" style="gap:9px">' +
            '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--ue-text-lo)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>' +
            '<input class="mem-search" type="text" placeholder="Search memory…" style="border:none;outline:none;background:transparent;flex:1;font-size:13px;color:var(--ue-text-hi)">' +
          '</div>' +
        '</div>' +
        '<div class="mem-body" data-panel="memories">' +
          '<div class="mem-toolbar">' +
            '<button class="mem-tbtn" data-act="sort">↓ Newest</button>' +
            '<span class="spacer"></span>' +
            '<button class="mem-tbtn danger" data-act="delete-all" style="display:none">' +
              '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>' +
              'Delete all' +
            '</button>' +
          '</div>' +
          '<div class="mem-pending" data-scroll="pending" style="display:none"></div>' +
          '<div class="mem-scroll" data-scroll="memories"></div>' +
        '</div>' +
        '<div style="padding:12px 20px;border-top:1px solid var(--ue-line-soft);display:flex;align-items:center;gap:10px">' +
          '<button class="btn-accent mem-add" data-act="add" style="display:flex;align-items:center;gap:7px">' +
            '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5v14"/></svg>' +
            'Add memory' +
          '</button>' +
          '<span class="spacer"></span>' +
          '<span class="mono chat-item-meta" data-meta="memories"></span>' +
        '</div>';
      this._overlayEl.appendChild(this._box);

      this._box.querySelector('[data-act="close"]').addEventListener('click', function () { self.close(); });
      var searchInput = this._box.querySelector('.mem-search');
      if (searchInput) searchInput.addEventListener('input', function (e) {
        self._filter = e.target.value.toLowerCase(); self._renderMemories();
      });
      this._box.querySelector('[data-act="add"]').addEventListener('click', function () { window.uecp.call('save_memory', {}); });
      var delAll = this._box.querySelector('[data-act="delete-all"]');
      if (delAll) delAll.addEventListener('click', function () { self._deleteAll(); });
      var sortBtn = this._box.querySelector('[data-act="sort"]');
      if (sortBtn) sortBtn.addEventListener('click', function () {
        self._sortNewest = !self._sortNewest;
        sortBtn.textContent = self._sortNewest ? '↓ Newest' : '↑ Oldest';
        self._renderMemories();
      });
    }

    _subscribe() {
      var self = this;
      this._subs = [
        window.uecp.on('memory.state', function (st) { self._onState(st); }),
        window.uecp.on('memory.open', function () { self.open(); })
      ];
    }

    _onState(st) {
      if (!st) return;
      this._state = {
        memories:  Array.isArray(st.memories) ? st.memories : [],
        pending:   Array.isArray(st.pending)  ? st.pending  : [],
        enabledCount: st.enabledCount || 0,
        tokenCount:   st.tokenCount || 0
      };
      if (this._editId && !this._state.memories.some(function (m) { return m.id === this._editId; })) this._editId = null;
      this._render();
    }

    _render() {
      if (!this._box) return;
      this._renderPending();
      this._renderMemories();
      var delAll = this._box.querySelector('[data-act="delete-all"]');
      if (delAll) delAll.style.display = this._totalCount() ? '' : 'none';
    }

    _totalCount() {
      return (this._state.memories || []).length + (this._state.pending || []).length;
    }

    _deleteAll() {
      var n = this._totalCount();
      if (!n) return;
      window.UECP.dialog.confirm(t('Delete all memories'),
        t('Permanently delete all {n} memories, including any waiting for review? This cannot be undone.', { n: n }))
        .then(function (ok) { if (ok) window.uecp.call('delete_all_memories', {}); });
    }

    _renderPending() {
      var host = this._box.querySelector('[data-scroll="pending"]');
      if (!host) return;
      var self = this;
      var list = this._state.pending || [];

      if (!list.length) { host.innerHTML = ''; host.style.display = 'none'; return; }
      host.style.display = '';

      var html = '<div class="mem-group-label">NEEDS YOUR REVIEW (' + list.length + ')</div>';
      list.forEach(function (m) {
        html += '<div class="mem-entry" data-pid="' + esc(m.id) + '">' +
                  '<div class="mem-cat">' + esc(String(m.kind || 'rule')).toUpperCase() +
                    (String(m.scope || '').toLowerCase() === 'engine'
                      ? ' · ' + esc(String(m.scope)).toUpperCase() : '') + '</div>' +
                  '<div class="mem-text">' + esc(m.content || '') + '</div>' +
                  (m.evidence ? '<div class="mem-evidence">' + esc(m.evidence) + '</div>' : '') +
                  '<div class="mem-actions">' +
                    '<button class="btn-accent" data-act="approve">Save</button>' +
                    '<button class="mem-tbtn" data-act="reject">Discard</button>' +
                  '</div>' +
                '</div>';
      });
      host.innerHTML = html;

      host.querySelectorAll('[data-pid]').forEach(function (card) {
        var id = card.getAttribute('data-pid');
        var ok = card.querySelector('[data-act="approve"]');
        if (ok) ok.addEventListener('click', function () { window.uecp.call('approve_memory', { id: id }); });
        var no = card.querySelector('[data-act="reject"]');
        if (no) no.addEventListener('click', function () { window.uecp.call('reject_memory', { id: id }); });
      });
    }

    _matchesFilter(m) {
      if (!this._filter) return true;
      return String(m.content || '').toLowerCase().indexOf(this._filter) !== -1 ||
             String(m.category || '').toLowerCase().indexOf(this._filter) !== -1;
    }

    _renderMemories() {
      var scroll = this._box.querySelector('[data-scroll="memories"]');
      if (!scroll) return;
      var self = this;

      var list = this._state.memories.filter(function (m) { return self._matchesFilter(m); });
      list = list.slice().sort(function (a, b) {
        var av = String(a.createdAt || ''), bv = String(b.createdAt || '');
        return self._sortNewest ? (av < bv ? 1 : av > bv ? -1 : 0) : (av < bv ? -1 : av > bv ? 1 : 0);
      });

      if (!list.length) {
        scroll.innerHTML = '<div class="mem-empty">' + (this._filter ? 'No memories match your filter.' : 'No memories yet. The Architect adds these as it works, or you can add one.') + '</div>';
      } else {
        var html = '';
        CATEGORIES.forEach(function (cat) {
          var inCat = list.filter(function (m) { return (m.category || 'Project Info') === cat; });
          if (!inCat.length) return;
          html += '<div class="mem-group-label">' + esc(cat) + '</div>';
          inCat.forEach(function (m) { html += self._cardHtml(m); });
        });
        scroll.innerHTML = html;
        this._wireMemoryCards(scroll);
      }

      var meta = this._box.querySelector('[data-meta="memories"]');
      if (meta) meta.textContent = this._state.enabledCount + ' enabled · ~' + this._state.tokenCount + ' tokens';
    }

    _cardHtml(m) {
      var isAlways = m.category === 'always' || m.alwaysLoaded;
      var pinClass = isAlways ? ' pinned' : '';
      var catClass = isAlways ? ' always' : '';
      var catLabel = isAlways ? 'ALWAYS LOADED' : esc(m.category || 'FACT').toUpperCase();
      var scopeTag = (m.scope && String(m.scope).toLowerCase() === 'engine')
        ? '<span class="mem-cat" style="margin-left:6px">' + esc(m.scope).toUpperCase() + '</span>'
        : '';
      var kindTag = (m.kind && String(m.kind).toLowerCase() !== 'fact')
        ? '<span class="mem-cat" style="margin-left:6px">' + esc(m.kind).toUpperCase() + '</span>'
        : '';
      var editing = this._editId === m.id;
      var trashSvg = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="var(--ue-text-mid)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M3 6h18M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>';
      var bodyHtml;
      if (editing) {
        var opts = CATEGORIES.map(function (c) {
          return '<option value="' + esc(c) + '"' + ((m.category || 'Project Info') === c ? ' selected' : '') + '>' + esc(c) + '</option>';
        }).join('');
        bodyHtml = '<textarea class="mem-edit" data-edit-id="' + esc(m.id) + '" rows="3">' + esc(m.content) + '</textarea>' +
          '<select class="mem-cat-select mem-edit-cat" data-edit-cat="' + esc(m.id) + '" style="margin-top:6px">' + opts + '</select>';
      } else {
        bodyHtml = esc(m.content);
      }
      return '<div class="mem-entry' + pinClass + '" data-id="' + esc(m.id) + '">' +
        '<div style="display:flex;align-items:center;gap:8px;margin-bottom:6px">' +
          '<span class="mem-cat' + catClass + '">' + catLabel + '</span>' + kindTag + scopeTag +
          '<span class="spacer"></span>' +
          '<button class="mem-icon-btn-sm" data-act="del" title="Delete">' + trashSvg + '</button>' +
          '<div class="toggle' + (m.enabled ? ' on' : '') + '" data-act="toggle" title="' + (m.enabled ? 'Enabled' : 'Disabled') + '"><span class="knob"></span></div>' +
        '</div>' +
        '<div class="mem-card-content" data-i18n-skip data-edit-target="' + esc(m.id) + '">' + bodyHtml + '</div>' +
      '</div>';
    }

    _wireMemoryCards(scroll) {
      var self = this;
      scroll.querySelectorAll('.mem-entry').forEach(function (card) {
        var id = card.dataset.id;
        var toggle = card.querySelector('[data-act="toggle"]');
        if (toggle) toggle.addEventListener('click', function () {
          var m = self._state.memories.filter(function (x) { return x.id === id; })[0];
          window.uecp.call('toggle_memory', { id: id, enabled: !(m && m.enabled) });
        });
        var del = card.querySelector('[data-act="del"]');
        if (del) del.addEventListener('click', function () {
          window.UECP.dialog.confirm('Delete memory', 'Permanently delete this memory? This cannot be undone.').then(function (ok) {
            if (ok) window.uecp.call('delete_memory', { id: id });
          });
        });

        var target = card.querySelector('[data-edit-target]');
        if (target) target.addEventListener('click', function (e) {
          if (e.target.closest('.mem-edit, .mem-edit-cat')) return;
          self._editId = id; self._renderMemories();
        });

        var ta = card.querySelector('[data-edit-id]');
        var catSel = card.querySelector('[data-edit-cat]');
        if (ta) {
          ta.focus();
          var committing = false;
          var commit = function () {
            if (committing) return; committing = true;
            var m = self._state.memories.filter(function (x) { return x.id === id; })[0];
            var val = ta.value;
            var newCat = catSel ? catSel.value : (m && m.category) || '';
            self._editId = null;
            if (m && (val !== m.content || newCat !== (m.category || ''))) {
              window.uecp.call('update_memory', { id: id, content: val, category: newCat });
            } else self._renderMemories();
          };
          if (catSel) catSel.addEventListener('change', commit);
          ta.addEventListener('blur', function () {
            setTimeout(function () { if (self._editId === id) commit(); }, 120);
          });
          ta.addEventListener('keydown', function (e) {
            if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) { e.preventDefault(); commit(); }
            else if (e.key === 'Escape') { e.preventDefault(); self._editId = null; self._renderMemories(); }
          });
        }
      });
    }
  }

  customElements.define('uecp-memory-overlay', UecpMemoryOverlay);

  window.UECP = window.UECP || {};
  window.UECP.openMemory = function () {
    var ov = document.querySelector('uecp-memory-overlay');
    if (!ov) { ov = document.createElement('uecp-memory-overlay'); document.body.appendChild(ov); }
    ov.open();
    return ov;
  };
})();
