(function () {
  if (!document.getElementById('settings-project-index-css')) {
    const s = document.createElement('style'); s.id = 'settings-project-index-css';
    s.textContent = `
settings-project-index{display:block;flex:1;min-width:0;min-height:0;overflow-y:auto}
settings-project-index .pi-head{display:flex;align-items:flex-start;gap:12px}
settings-project-index .pi-head .grow{flex:1;min-width:0}
settings-project-index .pi-state{display:flex;align-items:center;gap:10px;margin-top:18px}
settings-project-index .pi-dot{width:8px;height:8px;border-radius:50%;background:var(--ue-text-lo);flex-shrink:0}
settings-project-index.has-index .pi-dot{background:var(--ue-ok,#5fa86a)}
settings-project-index.scanning .pi-dot{background:var(--ue-accent);animation:pi-pulse 1.1s ease-in-out infinite}
@keyframes pi-pulse{0%,100%{opacity:1}50%{opacity:.35}}
settings-project-index .pi-state-text{font-size:13px;color:var(--ue-text-hi)}
settings-project-index .pi-state-sub{font-size:12px;color:var(--ue-text-mid);margin-top:2px}
settings-project-index .pi-warn{display:flex;gap:10px;align-items:flex-start;margin-top:14px;padding:10px 12px;border:1px solid var(--ue-warn);background:var(--ue-warn-soft);border-radius:6px}
settings-project-index .pi-warn b{display:block;font-size:12px;color:var(--ue-warn);margin-bottom:2px}
settings-project-index .pi-warn span{font-size:12px;color:var(--ue-text-mid);line-height:1.45}
settings-project-index .pi-tiles{display:grid;grid-template-columns:repeat(auto-fill,minmax(118px,1fr));gap:8px;margin-top:14px}
settings-project-index .pi-tile{background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r);padding:10px 12px}
settings-project-index .pi-tile b{display:block;font-size:17px;font-weight:var(--ue-fw-semi);color:var(--ue-text-hi);line-height:1.2}
settings-project-index .pi-tile span{display:block;font-size:11px;color:var(--ue-text-mid);margin-top:3px;text-transform:capitalize}
settings-project-index .pi-folders{margin-top:10px}
settings-project-index .pi-folder{display:flex;align-items:center;gap:10px;font-size:12px;padding:5px 0;border-bottom:1px solid var(--ue-line-soft)}
settings-project-index .pi-folder:last-child{border-bottom:0}
settings-project-index .pi-folder .p{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-family:var(--ue-font-mono);color:var(--ue-text-mid)}
settings-project-index .pi-folder .n{color:var(--ue-text-lo);flex-shrink:0}
settings-project-index .pi-bar{width:74px;height:4px;border-radius:2px;background:var(--ue-line);flex-shrink:0;overflow:hidden}
settings-project-index .pi-bar i{display:block;height:100%;background:var(--ue-accent-soft)}
settings-project-index .pi-actions{display:flex;flex-wrap:wrap;gap:8px;margin-top:12px}
settings-project-index .pi-report{margin-top:16px;background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-lg);overflow:hidden}
settings-project-index .pi-report-head{display:flex;align-items:center;gap:10px;padding:10px 14px;border-bottom:1px solid var(--ue-line-soft)}
settings-project-index .pi-report-title{flex:1;font-weight:var(--ue-fw-semi);color:var(--ue-text-hi);font-size:13px}
settings-project-index .pi-report-body{padding:4px 16px 16px;overflow-x:auto}
settings-project-index .pi-report-body>*:first-child{margin-top:10px}
settings-project-index .pi-report h1,settings-project-index .pi-report h2,settings-project-index .pi-report h3{margin:14px 0 6px}
settings-project-index .pi-report table{border-collapse:collapse;margin:10px 0;font-size:12px}
settings-project-index .pi-report th{text-align:left;color:var(--ue-text-mid);font-weight:var(--ue-fw-semi);background:var(--ue-elev)}
settings-project-index .pi-report td,settings-project-index .pi-report th{border:1px solid var(--ue-line-soft);padding:5px 10px}
settings-project-index .pi-report tr:hover td{background:var(--ue-elev)}
settings-project-index .pi-report pre{overflow-x:auto;background:var(--ue-elev);padding:8px 10px;border-radius:var(--ue-r-sm)}
settings-project-index .pi-report ul{margin:8px 0 8px 18px;line-height:1.6}
settings-project-index .pi-hint{font-size:12px;color:var(--ue-text-mid);margin-top:14px;line-height:1.55}`;
    document.head.appendChild(s);
  }

  function t(key, vars) {
    if (window.uecp && typeof window.uecp.t === 'function') return window.uecp.t(key, vars);
    return String(key).replace(/\{(\w+)\}/g, function (m, k) {
      return (vars && vars[k] != null) ? String(vars[k]) : m;
    });
  }

  function esc(v) {
    return String(v == null ? '' : v)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function num(n) {
    return String(n == null ? 0 : n).replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  }

  class SettingsProjectIndex extends HTMLElement {
    connectedCallback() {
      if (this._built) return;
      this._built = true;
      this._state = (window.UECP && window.UECP._indexSummary) || null;
      this._render();
      this._subscribe();
    }

    disconnectedCallback() {
      [this._uState, this._uStatus, this._uScan, this._uReport].forEach(function (u) {
        if (typeof u === 'function') { try { u(); } catch (e) {} }
      });
      this._uState = this._uStatus = this._uScan = this._uReport = null;
      this._built = false;
    }

    _render() {
      const st = this._state;
      const has = !!(st && st.exists);
      this.classList.toggle('has-index', has);

      let stateText, stateSub;
      if (this._scanning)      { stateText = t('Scanning…');
                                 stateSub  = this._status || t('Walking the asset registry.'); }
      else if (has)            { stateText = st.total === 1
                                   ? t('1 asset indexed')
                                   : t('{n} assets indexed', { n: num(st.total) });
                                 stateSub  = t('Updated {age}.', { age: st.ageText || t('recently') }); }
      else if (st && st.corrupt) { stateText = t('Index unreadable');
                                 stateSub  = t('It was written by an older version. Re-scan to rebuild it.'); }
      else                     { stateText = t('No index yet');
                                 stateSub  = t('The Architect has to browse folders to find anything until you scan.'); }

      let warn = '';
      if (has && !this._scanning && st.mismatch) {
        warn = '<div class="pi-warn"><div>' +
          '<b>' + esc(t('This index does not match the project')) + '</b>' +
          '<span>' + esc(t('{missing} of {sampled} assets checked no longer exist. It was most likely built against different content. Re-scan to rebuild it.',
                           { missing: num(st.missing), sampled: num(st.sampled) })) + '</span>' +
        '</div></div>';
      }

      let body = '';
      if (has && !this._scanning) {
        const cats = (st.categories || []).slice(0, 6).map(function (c) {
          return '<div class="pi-tile"><b>' + num(c.count) + '</b><span>' + esc(c.label) + '</span></div>';
        }).join('');
        if (cats) body += '<div class="pi-tiles">' + cats + '</div>';

        const folders = st.folders || [];
        if (folders.length) {
          const top = folders[0].count || 1;
          body += '<div class="section-label">Busiest folders</div><div class="pi-folders">' +
            folders.slice(0, 6).map(function (f) {
              const pct = Math.max(4, Math.round((f.count / top) * 100));
              return '<div class="pi-folder">' +
                '<span class="p">' + esc(f.label) + '</span>' +
                '<span class="pi-bar"><i style="width:' + pct + '%"></i></span>' +
                '<span class="n">' + num(f.count) + '</span>' +
              '</div>';
            }).join('') + '</div>';
        }
      }

      this.innerHTML =
        '<div class="page page-wide">' +
          '<div class="pi-head">' +
            '<div class="grow">' +
              '<div class="page-title">Project Index</div>' +
              '<div class="page-sub">A searchable map of this project, so the Architect can find assets instead of browsing folders.</div>' +
            '</div>' +
            '<button class="btn-accent act-scan">' + (has ? 'Re-scan' : 'Scan project') + '</button>' +
          '</div>' +

          '<div class="pi-state">' +
            '<span class="pi-dot"></span>' +
            '<div><div class="pi-state-text">' + esc(stateText) + '</div>' +
                 '<div class="pi-state-sub">' + esc(stateSub) + '</div></div>' +
          '</div>' +
          warn +

          body +

          '<div class="section-label">Reports</div>' +
          '<div class="pi-actions">' +
            '<button class="btn-ghost act-overview"' + (has ? '' : ' disabled') + '>Overview</button>' +
            '<button class="btn-ghost act-perf"' + (has ? '' : ' disabled') + '>Performance</button>' +
            '<button class="btn-ghost act-scope">What gets indexed</button>' +
          '</div>' +

          (this._reportHtml
            ? '<div class="pi-report">' +
                '<div class="pi-report-head">' +
                  '<span class="pi-report-title">' + esc(this._reportTitle || '') + '</span>' +
                  '<button class="btn-ghost act-close-report">Close</button>' +
                '</div>' +
                '<div class="pi-report-body">' + this._reportHtml + '</div>' +
              '</div>'
            : '') +
          '<div class="pi-hint">To ask questions about the project, use the Architect — it searches this index and can act on what it finds.</div>' +
        '</div>';

      this._wireButtons();
    }

    _startScan() {
      this._scanning = true;
      this._status = '';
      this.classList.add('scanning');
      this._render();
      if (window.uecp && typeof window.uecp.call === 'function') window.uecp.call('scan_project', {});
    }

    _showReport(title, markdown) {
      let md = String(markdown || '');
      md = md.replace(/```chart[\s\S]*?```/g, '');
      if (md.charAt(0) === '#') md = md.slice(md.indexOf('\n') + 1);
      const render = window.UECP && window.UECP.renderMarkdown;
      const inner = (typeof render === 'function') ? render(md) : '<pre>' + esc(md) + '</pre>';
      this._reportTitle = title;
      this._reportHtml = inner;
      this._render();
    }

    _wireButtons() {
      const self = this;
      const call = function (name) {
        return function () {
          if (window.uecp && typeof window.uecp.call === 'function') window.uecp.call(name, {});
        };
      };
      const on = function (sel, fn) {
        const el = self.querySelector(sel);
        if (el) el.addEventListener('click', fn);
      };
      on('.act-scan', function () { self._startScan(); });
      on('.act-overview', call('get_project_overview'));
      on('.act-perf', call('get_performance_report'));
      on('.act-close-report', function () {
        self._reportHtml = null; self._reportTitle = null; self._render();
      });
      on('.act-scope', function () {
        if (window.UECP && typeof window.UECP.openScannerSettings === 'function') {
          window.UECP.openScannerSettings();
        }
      });
    }

    _subscribe() {
      const self = this;
      if (!window.uecp || typeof window.uecp.on !== 'function') return;

      this._uState = window.uecp.on('scan.index_state', function (d) {
        if (!d) return;
        self._state = d;
        self._render();
      });
      this._uStatus = window.uecp.on('scan.status', function (d) {
        if (!d || d.text == null) return;
        self._status = String(d.text);
        if (self._scanning) self._render();
      });
      this._uScan = window.uecp.on('scan.state', function (d) {
        self._scanning = !!(d && d.scanning);
        self.classList.toggle('scanning', self._scanning);
        self._render();
      });
      this._uReport = window.uecp.on('scan.report', function (d) {
        if (d && d.markdown != null) self._showReport(d.title || 'Report', d.markdown);
      });
    }
  }

  customElements.define('settings-project-index', SettingsProjectIndex);
})();
