(function () {
  if (!document.getElementById('uecp-dash-css')) {
    const s = document.createElement('style'); s.id = 'uecp-dash-css';
    s.textContent = `
uecp-screen-dashboard .dash-kpi-row{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:14px}
uecp-screen-dashboard .dash-kpi{flex:1;min-width:120px;background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm);padding:14px 16px}
uecp-screen-dashboard .dash-kpi-val{font-size:26px;font-weight:700;color:var(--ue-text-hi);font-variant-numeric:tabular-nums;line-height:1}
uecp-screen-dashboard .dash-kpi-label{font-size:11.5px;color:var(--ue-text-mid);margin-top:5px}
uecp-screen-dashboard .dash-bar-row{display:flex;align-items:center;gap:8px;padding:5px 0;font-size:12px}
uecp-screen-dashboard .dash-bar-name{flex:0 0 auto;max-width:52%;color:var(--ue-text-hi);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
uecp-screen-dashboard .dash-bar-name.link{cursor:pointer}
uecp-screen-dashboard .dash-bar-name.link:hover{color:var(--ue-accent-bright,var(--ue-accent))}
uecp-screen-dashboard .dash-bar-track{flex:1;height:6px;background:var(--ue-elev);border-radius:3px;overflow:hidden}
uecp-screen-dashboard .dash-bar-fill{display:block;height:100%;background:var(--ue-accent);border-radius:3px}
uecp-screen-dashboard .dash-bar-val{flex:0 0 auto;color:var(--ue-text-mid);font-variant-numeric:tabular-nums}
uecp-screen-dashboard .dash-empty{padding:22px;text-align:center;color:var(--ue-text-lo);font-size:12.5px}
uecp-screen-dashboard .dash-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:10px}
uecp-screen-dashboard .dash-metric{background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm);padding:12px 14px}
uecp-screen-dashboard .dash-metric-val{font-size:22px;font-weight:700;color:var(--ue-text-hi);font-variant-numeric:tabular-nums;line-height:1.1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
uecp-screen-dashboard .dash-metric-label{font-size:11.5px;color:var(--ue-text-mid);margin-top:4px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;word-break:break-word;line-height:1.35;min-height:2em}
uecp-screen-dashboard .dash-grid.wide{grid-template-columns:repeat(auto-fill,minmax(178px,1fr))}
uecp-screen-dashboard .dash-badge{display:inline-block;font-size:10.5px;font-weight:var(--ue-fw-semi);padding:2px 8px;border-radius:999px}
uecp-screen-dashboard .dash-badge.ok{background:rgba(79,184,122,.16);color:var(--ue-ok,#4fb87a)}
uecp-screen-dashboard .dash-badge.warn{background:rgba(214,170,72,.16);color:var(--ue-warn,#d6aa48)}
uecp-screen-dashboard .dash-badge.bad{background:rgba(207,107,90,.16);color:var(--ue-danger,#cf6b5a)}
uecp-screen-dashboard .dash-badge.na{background:var(--ue-elev);color:var(--ue-text-lo)}
uecp-screen-dashboard .dash-cx-note{font-size:11.5px;color:var(--ue-text-lo);margin-bottom:10px;line-height:1.5}
uecp-screen-dashboard .dash-cx-row{display:flex;align-items:center;gap:10px;padding:5px 0;font-size:12px;border-bottom:1px solid var(--ue-line-soft)}
uecp-screen-dashboard .dash-cx-row:last-child{border-bottom:none}
uecp-screen-dashboard .dash-cx-head{font-size:10.5px;text-transform:uppercase;letter-spacing:.05em;color:var(--ue-text-lo);border-bottom:1px solid var(--ue-line-soft)}
uecp-screen-dashboard .dash-cx-name{flex:1 1 auto;min-width:0;color:var(--ue-text-hi);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
uecp-screen-dashboard .dash-cx-name.link{cursor:pointer}
uecp-screen-dashboard .dash-cx-name.link:hover{color:var(--ue-accent-bright,var(--ue-accent))}
uecp-screen-dashboard .dash-cx-n{flex:0 0 78px;text-align:right;color:var(--ue-text-mid);font-variant-numeric:tabular-nums}
uecp-screen-dashboard .dash-cx-bar{flex:0 0 110px;height:6px;background:var(--ue-elev);border-radius:3px;overflow:hidden}
uecp-screen-dashboard .dash-cx-tag{flex:0 0 58px;text-align:right}
uecp-screen-dashboard .dash-motion{display:flex;align-items:center;gap:9px;margin-bottom:8px;font-size:11.5px;color:var(--ue-text-mid)}
uecp-screen-dashboard .dash-motion input[type=range]{width:150px;accent-color:var(--ue-accent)}
uecp-screen-dashboard .dash-motion .val{font-variant-numeric:tabular-nums;color:var(--ue-text-lo);min-width:52px}
uecp-screen-dashboard .dash-panel{display:none}
uecp-screen-dashboard .dash-panel.active{display:block}
uecp-screen-dashboard .dash-canvas{height:440px;background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm);overflow:hidden;position:relative}
uecp-screen-dashboard .dash-svg-wrap{background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm);padding:14px;overflow:auto;max-height:520px}
uecp-screen-dashboard .dash-svg-wrap svg{max-width:100%}
uecp-screen-dashboard .dash-legend{display:flex;flex-wrap:wrap;gap:10px;margin-top:12px}
uecp-screen-dashboard .dash-leg{display:inline-flex;align-items:center;gap:6px;font-size:11.5px;color:var(--ue-text-mid)}
uecp-screen-dashboard .dash-swatch{width:10px;height:10px;border-radius:2px;flex:0 0 auto}
uecp-screen-dashboard .dash-chart{background:var(--ue-bg);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm);padding:6px}
uecp-screen-dashboard .dash-table{width:100%;border-collapse:collapse;font-size:12px;table-layout:fixed}
uecp-screen-dashboard .dash-table th{text-align:left;color:var(--ue-text-lo);font-weight:var(--ue-fw-semi);padding:5px 8px;border-bottom:1px solid var(--ue-line-soft);font-size:10.5px;text-transform:uppercase;letter-spacing:.04em}
uecp-screen-dashboard .dash-table td{padding:5px 8px;color:var(--ue-text-hi);border-bottom:1px solid var(--ue-line-soft);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
uecp-screen-dashboard .dash-table .n{text-align:right;font-variant-numeric:tabular-nums;white-space:nowrap;width:88px}
uecp-screen-dashboard .dash-table tr.bp td{color:var(--ue-accent-bright,var(--ue-accent))}
uecp-screen-dashboard .dash-table tr.bp{background:rgba(91,141,214,.08)}
uecp-screen-dashboard .dash-hint{font-size:11px;color:var(--ue-text-lo);margin-top:8px}
uecp-screen-dashboard .dash-trace{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:7px 10px;border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm);margin-bottom:6px;font-size:12px}
uecp-screen-dashboard .dash-trace-name{color:var(--ue-text-hi);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
uecp-screen-dashboard .dash-trace[data-trace]{cursor:pointer}
uecp-screen-dashboard .dash-trace[data-trace]:hover{border-color:var(--ue-accent);color:var(--ue-text-hi)}
uecp-screen-dashboard .dash-trace-size{color:var(--ue-text-lo);font-variant-numeric:tabular-nums;flex:0 0 auto}`;
    document.head.appendChild(s);
  }

  function icon(id, sz) {
    return (window.UECP && window.UECP.icon) ? window.UECP.icon(id, sz || 14) : '';
  }

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function fmtNum(n) {
    if (n == null || isNaN(n)) return '—';
    return Math.round(Number(n)).toLocaleString('en-US');
  }
  function fmtMs(n) {
    if (n == null || isNaN(n)) return '—';
    return Number(n).toFixed(1) + ' ms';
  }
  function fmtFps(n) {
    if (n == null || isNaN(n)) return '—';
    return Math.round(Number(n)) + ' fps';
  }
  function healthFromFps(fps) {
    if (fps == null || isNaN(fps)) return { label: 'No data', key: 'na' };
    if (fps >= 60) return { label: 'Good', key: 'ok' };
    if (fps >= 30) return { label: 'Fair', key: 'warn' };
    return { label: 'Poor', key: 'bad' };
  }

  function overviewHtml(info) {
    info = info || {};
    const rows = [
      { label: 'Plugin',         val: info.name || 'Ultimate Engine CoPilot' },
      { label: 'Plugin version', val: info.version || '—' },
      { label: 'Unreal Engine',  val: info.ue_version || '—' },
      { label: 'Build config',   val: info.build_config || '—' },
      { label: 'Platform',       val: info.platform || '—' },
      { label: 'Tier',           val: info.tier || '—' }
    ];
    return rows.map(function (r) {
      return '<div class="dash-metric"><div class="dash-metric-val" style="font-size:15px">' + esc(r.val) +
        '</div><div class="dash-metric-label">' + esc(r.label) + '</div></div>';
    }).join('');
  }

  function assetsHtml(payload) {
    payload = payload || {};
    if (payload.available === false) {
      return '<div class="dash-empty">' +
        esc(payload.reason || 'Project not scanned yet. Run a Project Scan first.') + '</div>';
    }
    const c = payload.counts || {};
    const issues = payload.assets_with_issues;
    const kpi = '<div class="dash-kpi-row">' +
      '<div class="dash-kpi"><div class="dash-kpi-val">' + fmtNum(c.total) + '</div><div class="dash-kpi-label">Indexed assets</div></div>' +
      '<div class="dash-kpi"><div class="dash-kpi-val">' + fmtNum(c.cpp_files) + '</div><div class="dash-kpi-label">C++ files</div></div>' +
      '<div class="dash-kpi"><div class="dash-kpi-val">' + fmtNum(issues) + '</div><div class="dash-kpi-label">Assets with issues</div></div>' +
      '</div>';
    const defs = [
      { key: 'actors',          label: 'Actor BPs',      always: true },
      { key: 'widgets',         label: 'Widgets',        always: true },
      { key: 'anim_bps',        label: 'Anim BPs' },
      { key: 'behavior_trees',  label: 'Behavior Trees' },
      { key: 'interfaces',      label: 'Interfaces' },
      { key: 'enums',           label: 'Enums' },
      { key: 'structs',         label: 'Structs' },
      { key: 'data_assets',     label: 'Data Assets' },
      { key: 'data_tables',     label: 'Data Tables',    always: true },
      { key: 'materials',       label: 'Materials' },
      { key: 'textures',        label: 'Textures' },
      { key: 'static_meshes',   label: 'Static Meshes' },
      { key: 'skeletal_meshes', label: 'Skeletal Meshes' },
      { key: 'levels',          label: 'Levels' }
    ];
    const tiles = defs.filter(function (d) {
      return d.always || (Number(c[d.key]) || 0) > 0;
    }).map(function (d) {
      return '<div class="dash-metric"><div class="dash-metric-val">' + fmtNum(c[d.key]) +
        '</div><div class="dash-metric-label">' + esc(d.label) + '</div></div>';
    }).join('');
    return kpi + '<div class="dash-grid">' +
      (tiles || '<div class="dash-empty" style="grid-column:1/-1">No assets indexed.</div>') + '</div>';
  }

  function frameChartHtml(fs) {
    const ft = fs && fs.frame_times_ms;
    if (!ft || !ft.length) return '';
    const W = 1000, H = 220;
    const maxMs = Math.max.apply(null, ft) || 1;
    const yScale = H / (maxMs * 1.1);
    const xStep = W / ft.length;
    let bars = '';
    for (let i = 0; i < ft.length; i++) {
      const ms = Number(ft[i]) || 0;
      const h = Math.max(0.5, ms * yScale);
      const col = ms < 16.67 ? '#4fb87a' : ms < 33.33 ? '#d6aa48' : '#cf6b5a';
      bars += '<rect x="' + (i * xStep).toFixed(2) + '" y="' + (H - h).toFixed(2) +
        '" width="' + Math.max(0.6, xStep - 0.2).toFixed(2) + '" height="' + h.toFixed(2) +
        '" fill="' + col + '"/>';
    }
    const line = function (ms, col, label) {
      const y = H - ms * yScale;
      if (y < 8) return '';
      return '<line x1="0" y1="' + y.toFixed(1) + '" x2="' + W + '" y2="' + y.toFixed(1) +
        '" stroke="' + col + '" stroke-dasharray="5 4" opacity=".65"/>' +
        '<text x="' + (W - 4) + '" y="' + (y - 4).toFixed(1) + '" text-anchor="end" fill="' + col +
        '" font-size="11">' + label + '</text>';
    };
    return '<div class="section-label" style="margin:16px 0 6px">Frame times</div>' +
      '<div class="dash-chart"><svg viewBox="0 0 ' + W + ' ' + H + '" preserveAspectRatio="none" ' +
        'width="100%" height="220" role="img">' +
        bars + line(16.67, '#4fb87a', '60 fps') + line(33.33, '#cf6b5a', '30 fps') +
      '</svg></div>';
  }

  function isBlueprintFn(name) {
    return /BP_|Blueprint|Receive|ExecuteUbergraph|K2_/.test(String(name || ''));
  }

  function fnTableHtml(title, fns) {
    if (!fns || !fns.length) return '';
    const rows = fns.slice(0, 12).map(function (f) {
      const bp = isBlueprintFn(f.name);
      return '<tr' + (bp ? ' class="bp"' : '') + '>' +
        '<td>' + esc(f.name) + '</td>' +
        '<td class="n">' + fmtMs(f.total_ms) + '</td>' +
        '<td class="n">' + fmtMs(f.avg_ms) + '</td>' +
        '<td class="n">' + fmtNum(f.count) + '</td></tr>';
    }).join('');
    return '<div class="section-label" style="margin:16px 0 6px">' + esc(title) + '</div>' +
      '<table class="dash-table"><tr><th>Function</th><th class="n">Total</th>' +
      '<th class="n">Avg</th><th class="n">Calls</th></tr>' + rows + '</table>';
  }

  function countersHtml(counters) {
    if (!counters || typeof counters !== 'object') return '';
    const keys = Object.keys(counters).sort();
    if (!keys.length) return '';
    const cells = keys.map(function (k) {
      const v = counters[k];
      const disp = typeof v === 'number'
        ? (v > 1e6 ? (v / 1e6).toFixed(1) + 'M' : v > 1e3 ? (v / 1e3).toFixed(1) + 'K' : String(Math.round(v)))
        : String(v);
      return '<div class="dash-metric" title="' + esc(k) + '">' +
        '<div class="dash-metric-val" style="font-size:16px">' + esc(disp) + '</div>' +
        '<div class="dash-metric-label">' + esc(k) + '</div></div>';
    }).join('');
    return '<div class="section-label" style="margin:16px 0 6px">Counters</div>' +
      '<div class="dash-grid wide">' + cells + '</div>';
  }

  function memoryHtml(mem) {
    if (!mem || typeof mem.total_mb !== 'number') return '';
    const tags = mem.tags || [];
    const max = tags.length ? (Number(tags[0].mb) || 1) : 1;
    const rows = tags.slice(0, 12).map(function (t) {
      const pct = Math.max(2, Math.round((Number(t.mb) || 0) / max * 100));
      return '<div class="dash-bar-row"><span class="dash-bar-name">' + esc(t.name) + '</span>' +
        '<span class="dash-bar-track"><span class="dash-bar-fill" style="width:' + pct + '%"></span></span>' +
        '<span class="dash-bar-val">' + Number(t.mb).toFixed(1) + ' MB</span></div>';
    }).join('');
    return '<div class="section-label" style="margin:16px 0 6px">Memory · ' +
      Number(mem.total_mb).toFixed(1) + ' MB total</div>' + rows;
  }

  function traceFootHtml(json) {
    const bits = [];
    if (json.trace_path) bits.push(esc(json.trace_path));
    if (typeof json.trace_size_mb === 'number') bits.push(Number(json.trace_size_mb).toFixed(1) + ' MB');
    if (typeof json.gameplay_seconds === 'number') bits.push(Number(json.gameplay_seconds).toFixed(1) + 's gameplay');
    else if (typeof json.duration_seconds === 'number') bits.push(Number(json.duration_seconds).toFixed(1) + 's trace');
    if (!bits.length) return '';
    return '<div class="dash-cx-note" style="margin:16px 0 0">' + bits.join(' · ') + '</div>';
  }

  function perfHtml(json) {
    if (!json) return '<div class="dash-empty">Run a profile to capture frame time, CPU, and GPU metrics.</div>';
    if (typeof json === 'string') { try { json = JSON.parse(json); } catch (e) { json = {}; } }
    if (json.error) return '<div class="dash-empty">Profiler error: ' + esc(json.error) + '</div>';

    const f = json.frame_stats || {};
    const health = healthFromFps(f.avg_fps);
    const kpi = '<div class="dash-kpi-row">' +
      '<div class="dash-kpi"><div class="dash-kpi-val">' + fmtFps(f.avg_fps) + '</div>' +
        '<div class="dash-kpi-label">Avg FPS <span class="dash-badge ' + health.key + '">' + esc(health.label) + '</span></div></div>' +
      '<div class="dash-kpi"><div class="dash-kpi-val">' + fmtMs(f.avg_ms) + '</div><div class="dash-kpi-label">Avg frame</div></div>' +
      '<div class="dash-kpi"><div class="dash-kpi-val">' + fmtMs(f.p99_ms) + '</div><div class="dash-kpi-label">P99 frame</div></div>' +
      '<div class="dash-kpi"><div class="dash-kpi-val">' + fmtMs(f.max_ms) + '</div><div class="dash-kpi-label">Worst frame</div></div>' +
      '</div>';

    return kpi + frameChartHtml(f) +
      fnTableHtml('CPU hotspots', json.top_cpu_functions) +
      fnTableHtml('GPU hotspots', json.top_gpu_functions) +
      countersHtml(json.counters) + memoryHtml(json.memory) + traceFootHtml(json);
  }

  const TYPE_COLORS = {
    blueprint: '#5b8dd6', actor: '#3f6fc4', character: '#8f6fd0', component_bp: '#4fb87a',
    anim_bp: '#d18fb0', game_mode: '#d6aa48', hud: '#e08a5a', widget: '#4fb0b8',
    material: '#c77dbb', texture: '#c9a227', mesh: '#57a06a', sound: '#a2653f',
    level: '#7a83d6', interface: '#7fbf7f', struct: '#b08cc9', enum: '#8a6f3a',
    data_asset: '#5aa7a0', data_table: '#3f8f8a', external: '#6b7a85'
  };
  function colorFor(type) {
    const key = String(type || '').toLowerCase();
    if (TYPE_COLORS[key]) return TYPE_COLORS[key];
    let h = 0;
    for (let i = 0; i < key.length; i++) h = (h * 31 + key.charCodeAt(i)) % 360;
    return 'hsl(' + h + ',42%,58%)';
  }

  function deriveComplexity(graph, limit) {
    const nodes = (graph && graph.nodes) || [];
    const edges = (graph && graph.edges) || [];
    const out = {}, inn = {};
    edges.forEach(function (e) {
      if (!e) return;
      if (e.from != null) out[e.from] = (out[e.from] || 0) + 1;
      if (e.to   != null) inn[e.to]   = (inn[e.to]   || 0) + 1;
    });

    const rows = nodes
      .filter(function (n) { return n && n.type !== 'external'; })
      .map(function (n) {
        const dependsOn = out[n.id] || 0;
        const usedBy    = inn[n.id] || 0;
        return { name: n.label || n.id, path: n.path || '', type: n.type || '',
                 dependsOn: dependsOn, usedBy: usedBy, score: dependsOn + usedBy };
      });

    const hi = function (vals) {
      const v = vals.filter(function (x) { return x > 0; }).sort(function (a, b) { return a - b; });
      if (!v.length) return Infinity;
      return v[Math.floor(v.length * 0.8)] || v[v.length - 1];
    };
    const usedHi = hi(rows.map(function (r) { return r.usedBy; }));
    const depHi  = hi(rows.map(function (r) { return r.dependsOn; }));
    rows.forEach(function (r) {
      const bigIn  = r.usedBy    >= usedHi && r.usedBy    > 1;
      const bigOut = r.dependsOn >= depHi  && r.dependsOn > 1;
      r.risk  = bigIn && bigOut ? 'core' : bigIn ? 'hub' : bigOut ? 'heavy' : '';
      r.riskLabel = r.risk === 'core'  ? 'Core'
                  : r.risk === 'hub'   ? 'Hub'
                  : r.risk === 'heavy' ? 'Heavy' : '';
    });

    return rows.sort(function (a, b) { return b.score - a.score; }).slice(0, limit || 15);
  }

  function deriveDistribution(graph) {
    const nodes = (graph && graph.nodes) || [];
    const counts = {};
    let external = 0;
    nodes.forEach(function (n) {
      const t = (n && n.type) || 'unknown';
      if (t === 'external') { external++; return; }
      counts[t] = (counts[t] || 0) + 1;
    });
    let total = 0;
    Object.keys(counts).forEach(function (t) { total += counts[t]; });
    const rows = Object.keys(counts)
      .map(function (t) { return { type: t, count: counts[t], pct: counts[t] / (total || 1) * 100 }; })
      .sort(function (a, b) { return b.count - a.count; });
    rows.external = external;
    return rows;
  }

  function renderBars(rows) {
    if (!rows.length) return '<div class="dash-empty">Nothing to show yet.</div>';
    const max = Math.max.apply(null, rows.map(function (r) { return r.score; })) || 1;
    const head =
      '<div class="dash-cx-note">Used by = how many assets break if you change this. ' +
      'Depends on = how much it drags in.</div>' +
      '<div class="dash-cx-row dash-cx-head"><span class="dash-cx-name"></span>' +
        '<span class="dash-cx-n">Used by</span><span class="dash-cx-n">Depends on</span>' +
        '<span class="dash-cx-bar"></span><span class="dash-cx-tag"></span></div>';
    return head + rows.map(function (r) {
      const pct = Math.max(3, Math.round(r.score / max * 100));
      const cls = 'dash-cx-name' + (r.path ? ' link' : '');
      const attr = r.path ? ' data-asset="' + esc(r.path) + '"' : '';
      const tag = r.riskLabel
        ? '<span class="dash-badge ' + (r.risk === 'core' ? 'bad' : r.risk === 'hub' ? 'warn' : 'na') +
            '">' + esc(r.riskLabel) + '</span>'
        : '';
      return '<div class="dash-cx-row">' +
        '<span class="' + cls + '"' + attr + ' title="' + esc(r.name) + '">' + esc(r.name) + '</span>' +
        '<span class="dash-cx-n">' + fmtNum(r.usedBy) + '</span>' +
        '<span class="dash-cx-n">' + fmtNum(r.dependsOn) + '</span>' +
        '<span class="dash-cx-bar"><span class="dash-bar-fill" style="width:' + pct + '%;background:' +
          colorFor(r.type) + '"></span></span>' +
        '<span class="dash-cx-tag">' + tag + '</span></div>';
    }).join('');
  }

  function parseInheritance(src) {
    const seen = {}, nodes = [], edges = [];
    const add = function (n) { if (!seen[n]) { seen[n] = true; nodes.push(n); } };
    String(src || '').split('\n').forEach(function (line) {
      const m = line.match(/^\s*\[\s*(?:<[a-z]+>)?\s*([^\]|]+?)\s*\]\s*(->|<:--)\s*\[\s*(?:<[a-z]+>)?\s*([^\]|]+?)\s*\]\s*$/);
      if (!m) return;
      const a = m[1].trim(), b = m[3].trim();
      if (!a || !b) return;
      add(a); add(b);
      edges.push({ from: a, to: b, iface: m[2] === '<:--' });
    });
    return { nodes: nodes, edges: edges };
  }

  function renderDonut(rows) {
    if (!rows.length) return '<div class="dash-empty">No assets indexed yet.</div>';
    const R = 60, C = 2 * Math.PI * R;
    let offset = 0;
    const arcs = rows.map(function (r) {
      const len = C * (r.pct / 100);
      const seg = '<circle cx="80" cy="80" r="' + R + '" fill="none" stroke="' + colorFor(r.type) +
        '" stroke-width="26" stroke-dasharray="' + len.toFixed(2) + ' ' + (C - len).toFixed(2) +
        '" stroke-dashoffset="' + (-offset).toFixed(2) + '" transform="rotate(-90 80 80)">' +
        '<title>' + esc(r.type) + ': ' + fmtNum(r.count) + '</title></circle>';
      offset += len;
      return seg;
    }).join('');
    const total = rows.reduce(function (a, r) { return a + r.count; }, 0);
    const legend = rows.map(function (r) {
      return '<span class="dash-leg"><span class="dash-swatch" style="background:' + colorFor(r.type) +
        '"></span>' + esc(r.type) + ' · ' + fmtNum(r.count) + ' (' + r.pct.toFixed(1) + '%)</span>';
    }).join('');
    const foot = rows.external
      ? '<div class="dash-cx-note" style="margin:12px 0 0">Plus ' + fmtNum(rows.external) +
        ' engine and external references, not counted here.</div>'
      : '';
    return '<div style="display:flex;gap:22px;align-items:center;flex-wrap:wrap">' +
      '<svg viewBox="0 0 160 160" width="170" height="170" role="img">' + arcs +
      '<text x="80" y="76" text-anchor="middle" font-size="20" font-weight="700" fill="currentColor">' +
        fmtNum(total) + '</text>' +
      '<text x="80" y="94" text-anchor="middle" font-size="9" fill="currentColor" opacity=".6">YOUR ASSETS</text>' +
      '</svg><div class="dash-legend" style="flex:1;min-width:180px">' + legend + '</div></div>' + foot;
  }

  function renderTraces(list) {
    if (!list || !list.length) return '<div class="dash-empty">No captured traces yet.</div>';
    return list.map(function (t) {
      const p = t && t.path ? ' data-trace="' + esc(t.path) + '"' : '';
      return '<div class="dash-trace"' + p + ' title="Analyze this capture">' +
        '<span class="dash-trace-name">' + esc(t.name) + '</span><span class="dash-trace-size">' +
        (t.size_mb != null ? Number(t.size_mb).toFixed(1) + ' MB' : '') + '</span></div>';
    }).join('');
  }

  const TABS = [
    { key: 'overview', label: 'Overview' },
    { key: 'deps',    label: 'Dependencies' },
    { key: 'complex', label: 'Complexity' },
    { key: 'dist',    label: 'Distribution' },
    { key: 'inherit', label: 'Inheritance' },
    { key: 'perf',    label: 'Performance' }
  ];

  function renderTabs(active) {
    return TABS.map(function (t) {
      return '<span data-tab="' + t.key + '"' + (t.key === active ? ' class="active"' : '') + '>' +
        t.label + '</span>';
    }).join('');
  }

  let REQ = 0;

  class UecpScreenDashboard extends HTMLElement {
    connectedCallback() {
      this.style.cssText = 'display:flex;flex-direction:column;flex:1;min-width:0;min-height:0;background:var(--ue-bg)';
      this._pending = {};
      this._tab = 'overview';
      this._graph = null;
      this._network = null;

      const self = this;
      this._subs = [
        window.uecp.on('dashboard.result', function (p) { self._onResult(p); }),
        window.uecp.on('tools.dashboard_stats', function (d) { self._onStats(d); }),
        window.uecp.on('tools.profiler_result', function (d) { self._onProfile(d); }),
        window.uecp.on('tools.profiler_status', function (d) { self._onProfileStatus(d); }),
        window.uecp.on('settings.info', function (d) { self._onInfo(d); }),
        window.uecp.on('dashboard.traces', function (d) { self._onTraces(d); })
      ];

      this._build();
      this.refresh();
    }

    disconnectedCallback() {
      (this._subs || []).forEach(function (u) { u(); });
      this._subs = [];
      this._pending = {};
      if (this._network) { try { this._network.destroy(); } catch (e) {} this._network = null; }
      if (this._inheritNet) { try { this._inheritNet.destroy(); } catch (e) {} this._inheritNet = null; }
    }

    _call(tool, args) {
      const id = 'dash' + (++REQ);
      const self = this;
      return new Promise(function (resolve) {
        self._pending[id] = resolve;
        window.uecp.call('dashboard_action', { tool: tool, args: args || {}, request_id: id });
      });
    }

    _onResult(p) {
      if (!p || !p.request_id) return;
      const done = this._pending[p.request_id];
      if (!done) return;
      delete this._pending[p.request_id];
      done(p);
    }

    _build() {
      this.innerHTML =
        '<div class="content"><div class="page page-wide">' +
          '<div class="page-title">Project Dashboard</div>' +
          '<div class="page-sub">Dependencies, complexity and performance for this project.</div>' +
          '<div class="tabs" id="dash-tabs">' + renderTabs(this._tab) + '</div>' +
          '<div class="dash-panel active" data-panel="overview">' +
            '<div class="card" style="margin-bottom:12px">' +
              '<div class="row" style="justify-content:space-between;align-items:center;margin-bottom:11px">' +
                '<div class="section-label" style="margin:0">ASSETS</div>' +
                '<span id="dash-scan-time" style="font-size:11px;color:var(--ue-text-lo)"></span>' +
              '</div>' +
              '<div id="dash-assets"><div class="dash-empty">Loading asset counts…</div></div>' +
            '</div>' +
            '<div class="card">' +
              '<div class="section-label" style="margin:0 0 11px">PROJECT</div>' +
              '<div id="dash-overview" class="dash-grid">' +
                '<div class="dash-empty" style="grid-column:1/-1">Loading project info…</div>' +
              '</div>' +
            '</div>' +
          '</div>' +
          '<div class="dash-panel" data-panel="deps">' +
            '<div class="dash-motion">' +
              '<label for="dash-motion">Motion</label>' +
              '<input type="range" id="dash-motion" min="0" max="100" step="5">' +
              '<span class="val" id="dash-motion-val"></span>' +
            '</div>' +
            '<div class="dash-canvas" id="dash-graph"><div class="dash-empty">Loading dependency graph…</div></div>' +
            '<div class="dash-hint">Drag to pan, scroll to zoom, click a node to open the asset.</div>' +
          '</div>' +
          '<div class="dash-panel" data-panel="complex"><div class="card"><div id="dash-complex">' +
            '<div class="dash-empty">Loading…</div></div></div></div>' +
          '<div class="dash-panel" data-panel="dist"><div class="card"><div id="dash-dist">' +
            '<div class="dash-empty">Loading…</div></div></div></div>' +
          '<div class="dash-panel" data-panel="inherit">' +
            '<div class="dash-canvas" id="dash-inherit">' +
              '<div class="dash-empty">Loading inheritance tree…</div></div>' +
            '<div class="dash-hint">Solid = parent class, dashed = interface. Drag to pan, scroll to zoom.</div>' +
          '</div>' +
          '<div class="dash-panel" data-panel="perf">' +
            '<div class="card" style="margin-bottom:12px">' +
              '<div class="section-label" style="margin:0 0 11px">LAST PROFILE</div>' +
              '<div id="dash-perf"><div class="dash-empty">Nothing profiled yet.</div></div>' +
              '<div class="row" style="margin-top:12px;gap:8px;align-items:center">' +
                '<label class="field-label" for="dash-prof-dur" style="margin:0">Duration</label>' +
                '<select class="input" id="dash-prof-dur" style="width:auto">' +
                  '<option value="5">5 seconds</option>' +
                  '<option value="10" selected>10 seconds</option>' +
                  '<option value="30">30 seconds</option>' +
                  '<option value="60">60 seconds</option>' +
                  '<option value="120">120 seconds</option>' +
                '</select>' +
                '<button class="btn-accent" id="dash-profile">' + icon('ic-zap', 13) + ' Start profiling</button>' +
                '<button class="btn-soft" id="dash-analyze" disabled>Analyze with AI</button>' +
              '</div>' +
            '</div>' +
            '<div class="card"><div class="section-label" style="margin:0 0 11px">CAPTURED TRACES</div>' +
              '<div id="dash-traces"><div class="dash-empty">No captured traces yet.</div></div></div>' +
          '</div>' +
        '</div></div>';

      const self = this;
      this.querySelector('#dash-tabs').addEventListener('click', function (e) {
        const t = e.target && e.target.getAttribute && e.target.getAttribute('data-tab');
        if (t) self._showTab(t);
      });
      this.addEventListener('click', function (e) {
        const el = e.target && e.target.closest && e.target.closest('[data-asset]');
        if (el) { window.uecp.call('open_asset_link', { ref: el.getAttribute('data-asset') }); return; }
        const tr = e.target && e.target.closest && e.target.closest('[data-trace]');
        if (tr) {
          window.uecp.call('dashboard_analyze_trace', { path: tr.getAttribute('data-trace') });
          self._setProfiling(true);
        }
      });
      const motion = this.querySelector('#dash-motion');
      if (motion) {
        motion.value = String(this._motion());
        const out = this.querySelector('#dash-motion-val');
        if (out) out.textContent = this._motion() === 0 ? 'Off' : this._motion() + '%';
        motion.addEventListener('input', function () { self._setMotion(motion.value); });
      }
      this.querySelector('#dash-profile').addEventListener('click', function () {
        const sel = self.querySelector('#dash-prof-dur');
        const dur = sel ? (parseInt(sel.value, 10) || 10) : 10;
        window.uecp.call('run_profiler', { durationSeconds: dur });
        self._setProfiling(true);
      });
      this.querySelector('#dash-analyze').addEventListener('click', function () {
        window.uecp.call('dashboard_analyze_perf', {});
        if (window.UECP && window.UECP.router) {
          window.UECP.router.go('architect');
          window.uecp.call('switch_view', { view: 'architect' });
          window.uecp.__emit('screen.changed', { route: 'architect', title: 'Architect' });
        }
      });
    }

    _motion() {
      if (this._motionVal != null) return this._motionVal;
      let v = 35;
      try {
        const s = window.localStorage.getItem('uecp.dash.motion');
        if (s != null && !isNaN(parseInt(s, 10))) v = Math.max(0, Math.min(100, parseInt(s, 10)));
      } catch (e) {  }
      this._motionVal = v;
      return v;
    }

    _setMotion(v) {
      this._motionVal = Math.max(0, Math.min(100, Number(v) || 0));
      try { window.localStorage.setItem('uecp.dash.motion', String(this._motionVal)); } catch (e) {}
      const out = this.querySelector('#dash-motion-val');
      if (out) out.textContent = this._motionVal === 0 ? 'Off' : this._motionVal + '%';
      if (this._network) this._applyMotion(this._network);
    }

    _applyMotion(net) {
      const m = this._motion();
      if (!net) return;
      if (m <= 0) { try { net.setOptions({ physics: false }); } catch (e) {} return; }
      try {
        net.setOptions({ physics: { enabled: true,
          timestep: 0.15 + (m / 100) * 0.65,
          minVelocity: Math.max(0.01, 0.75 - (m / 100) * 0.74),
          stabilization: false,
          forceAtlas2Based: { damping: 0.85 - (m / 100) * 0.45 } } });
        net.startSimulation();
      } catch (e) {  }
    }

    _tameNetwork(net, box) {

      net.once('afterDrawing', function () { try { net.fit({ animation: false }); } catch (e) {} });
    }

    _showTab(key) {
      this._tab = key;
      const tabs = this.querySelector('#dash-tabs');
      if (tabs) tabs.innerHTML = renderTabs(key);
      this.querySelectorAll('.dash-panel').forEach(function (p) {
        p.classList.toggle('active', p.getAttribute('data-panel') === key);
      });
      if (key === 'deps' && this._network) { try { this._network.redraw(); } catch (e) {} }
    }

    refresh() {
      window.uecp.call('get_dashboard_stats', {});
      window.uecp.call('request_plugin_info', {});
      window.uecp.call('dashboard_traces', {});
      const self = this;
      this._call('get_dependency_graph', { root_path: '', max_depth: 3, include_engine: false })
        .then(function (p) { self._onGraph(p); });
      this._call('get_inheritance_tree', { root_class: '' })
        .then(function (p) { self._onInherit(p); });
    }

    _onGraph(p) {
      if (!p || !p.ok || !p.data) {
        const msg = '<div class="dash-empty">' +
          esc((p && p.error) || 'Could not build the dependency graph.') + '</div>';
        ['#dash-graph', '#dash-complex', '#dash-dist'].forEach(function (sel) {
          const el = this.querySelector(sel);
          if (el) el.innerHTML = msg;
        }, this);
        return;
      }
      this._graph = p.data;

      const cmp = this.querySelector('#dash-complex');
      if (cmp) cmp.innerHTML = renderBars(deriveComplexity(this._graph, 15));
      const dist = this.querySelector('#dash-dist');
      if (dist) dist.innerHTML = renderDonut(deriveDistribution(this._graph));

      this._drawGraph();
    }

    _drawGraph() {
      const box = this.querySelector('#dash-graph');
      if (!box) return;
      if (typeof vis === 'undefined' || !vis.Network) {
        box.innerHTML = '<div class="dash-empty">Graph library unavailable.</div>';
        return;
      }
      const g = this._graph || {};
      const nodes = (g.nodes || []).map(function (n) {
        const c = colorFor(n.type);
        return { id: n.id, label: n.label, path: n.path || '', shape: 'box',
                 title: n.label + (n.type ? ' [' + n.type + ']' : ''),
                 font: { color: '#e6e6e6', size: 12 },
                 color: { background: c, border: '#3a3a3a',
                          highlight: { background: c, border: '#ffffff' } } };
      });
      const edges = (g.edges || []).map(function (e) {
        return { from: e.from, to: e.to, arrows: 'to', dashes: e.type === 'soft_ref',
                 color: { color: e.type === 'inherits' ? '#4fb87a' : '#5a5a5a', highlight: '#ffffff' } };
      });
      if (!nodes.length) { box.innerHTML = '<div class="dash-empty">No dependencies found.</div>'; return; }

      box.innerHTML = '';
      if (this._network) { try { this._network.destroy(); } catch (e) {} this._network = null; }
      const net = new vis.Network(box,
        { nodes: new vis.DataSet(nodes), edges: new vis.DataSet(edges) },
        { physics: { solver: 'forceAtlas2Based',
                     forceAtlas2Based: { gravitationalConstant: -80, springLength: 120, springConstant: 0.04 },
                     stabilization: { iterations: 150 } },
          interaction: { hover: true, zoomView: true, dragView: true },
          nodes: { borderWidth: 1 }, edges: { smooth: { type: 'continuous' } },
          layout: { improvedLayout: true } });

      const self = this;
      net.once('stabilizationIterationsDone', function () { self._applyMotion(net); });
      this._tameNetwork(net, box);
      net.on('click', function (params) {
        if (!params.nodes.length) return;
        const hit = nodes.find(function (n) { return n.id === params.nodes[0]; });
        if (hit && hit.path) window.uecp.call('open_asset_link', { ref: hit.path });
      });
      this._network = net;
    }

    _onInherit(p) {
      const box = this.querySelector('#dash-inherit');
      if (!box) return;
      const src = p && p.ok && p.data ? (p.data.nomnoml || p.data.raw || '') : '';
      if (!src) {
        box.innerHTML = '<div class="dash-empty">' +
          esc((p && p.error) || 'No inheritance data.') + '</div>';
        return;
      }
      if (typeof vis === 'undefined' || !vis.Network) {
        box.innerHTML = '<div class="dash-empty">Graph library unavailable.</div>';
        return;
      }
      const tree = parseInheritance(src);
      if (!tree.edges.length) {
        box.innerHTML = '<div class="dash-empty">No inheritance data.</div>';
        return;
      }

      const nodes = tree.nodes.map(function (n) {
        const isBp = /^(BP_|ABP_|WBP_|BPI_|I_)/.test(n);
        return { id: n, label: n, shape: 'box',
                 font: { color: '#e6e6e6', size: 12 },
                 color: { background: isBp ? '#5b8dd6' : '#4a4a4a', border: '#3a3a3a',
                          highlight: { background: isBp ? '#5b8dd6' : '#4a4a4a', border: '#ffffff' } } };
      });
      const edges = tree.edges.map(function (e) {
        return { from: e.from, to: e.to, arrows: 'to', dashes: !!e.iface,
                 color: { color: e.iface ? '#c77dbb' : '#4fb87a', highlight: '#ffffff' } };
      });

      box.innerHTML = '';
      if (this._inheritNet) { try { this._inheritNet.destroy(); } catch (e) {} this._inheritNet = null; }
      this._inheritNet = new vis.Network(box,
        { nodes: new vis.DataSet(nodes), edges: new vis.DataSet(edges) },
        { layout: { hierarchical: { enabled: true, direction: 'LR', sortMethod: 'directed',
                                    levelSeparation: 220, nodeSpacing: 46, treeSpacing: 90 } },
          physics: false,
          interaction: { hover: true, zoomView: true, dragView: true, dragNodes: false },
          nodes: { borderWidth: 1, margin: 7 },
          edges: { smooth: { type: 'cubicBezier', forceDirection: 'horizontal', roundness: 0.4 } } });
      this._tameNetwork(this._inheritNet, box);
    }

    _onStats(payload) {
      const box = this.querySelector('#dash-assets');
      if (box) box.innerHTML = assetsHtml(payload);
      const ts = this.querySelector('#dash-scan-time');
      if (ts) {
        ts.textContent = (payload && payload.available !== false && payload.scan_timestamp)
          ? ('Indexed ' + payload.scan_timestamp) : '';
      }
    }

    _onInfo(info) {
      const box = this.querySelector('#dash-overview');
      if (box) box.innerHTML = overviewHtml(info);
    }

    _setProfiling(on) {
      const btn = this.querySelector('#dash-profile');
      if (!btn) return;
      btn.disabled = !!on;
      btn.innerHTML = on ? 'Profiling…' : icon('ic-zap', 13) + ' Start profiling';
      const sel = this.querySelector('#dash-prof-dur');
      if (sel) sel.disabled = !!on;
    }

    _onProfile(json) {
      const box = this.querySelector('#dash-perf');
      if (box) box.innerHTML = perfHtml(json);
      this._setProfiling(false);
      const btn = this.querySelector('#dash-analyze');
      if (btn && json && !json.error) btn.disabled = false;
      window.uecp.call('dashboard_traces', {});
    }

    _onProfileStatus(d) {
      const state = (d && d.state) || (typeof d === 'string' ? d : '');
      if (state === 'running') { this._setProfiling(true); return; }
      this._setProfiling(false);
      if (state === 'error') {
        const box = this.querySelector('#dash-perf');
        if (box) box.innerHTML = perfHtml({ error: (d && d.error) || 'unknown' });
      }
    }

    _onTraces(p) {
      const box = this.querySelector('#dash-traces');
      if (box) box.innerHTML = renderTraces(p && p.traces);
    }
  }

  UecpScreenDashboard.__pure = {
    deriveComplexity, deriveDistribution, parseInheritance, renderBars, renderDonut,
    renderTabs, renderTraces, fmtNum, fmtMs, fmtFps, healthFromFps, colorFor,
    overviewHtml, assetsHtml, perfHtml
  };

  customElements.define('uecp-screen-dashboard', UecpScreenDashboard);

  if (window.UECP && window.UECP.router) {
    window.UECP.router.register('dashboard', 'uecp-screen-dashboard');
  }
})();
