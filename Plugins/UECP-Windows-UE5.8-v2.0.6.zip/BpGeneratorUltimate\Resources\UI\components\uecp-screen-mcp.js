(function () {
  class UecpScreenMcp extends HTMLElement {
    connectedCallback() {
      this.style.cssText = 'display:flex;flex-direction:column;flex:1;min-width:0;min-height:0;background:var(--ue-bg)';
      this.innerHTML = '';

      const self = this;
      this._host = window.UECP.settingsHost.create(function () { return self._page; });

      this._page = document.createElement('settings-mcp');
      this.appendChild(this._page);
      this._host.prime(this._page);

      window.uecp.call('request_settings', {});
    }

    disconnectedCallback() {
      if (this._host) { this._host.dispose(); this._host = null; }
      this._page = null;
    }
  }

  customElements.define('uecp-screen-mcp', UecpScreenMcp);

  if (window.UECP && window.UECP.router) {
    window.UECP.router.register('mcp', 'uecp-screen-mcp');
  }
})();
