﻿// Copyright 2026, BlueprintsLab, All rights reserved
using UnrealBuildTool;

public class UECPAIExt : ModuleRules
{
	public UECPAIExt(ReadOnlyTargetRules Target) : base(Target)
	{
		bUsePrecompiled = true;
		if (Target.Type != TargetType.Editor) return;
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;
		bUseUnity = false;

		if (Target.Version.MinorVersion >= 6)
		{
			PrivateDependencyModuleNames.Add("PropertyBindingUtils");
		}

		if (Target.Version.MinorVersion < 5)
		{
			PrivateDependencyModuleNames.Add("StructUtils");
		}

		PublicDependencyModuleNames.AddRange(new string[]
		{
			"Core", "CoreUObject", "Engine", "Json", "JsonUtilities",
			"UECPCore",
		});

		PrivateDependencyModuleNames.AddRange(new string[]
		{
			"UnrealEd", "AssetTools", "AssetRegistry", "EditorScriptingUtilities",
			"Slate", "SlateCore", "Kismet", "KismetCompiler", "BlueprintGraph", "GraphEditor",

			"AIModule", "AIGraph", "BehaviorTreeEditor",

			"NavigationSystem",

			"StateTreeModule", "StateTreeEditorModule", "GameplayStateTreeModule",

			"GameplayTags",
			"SmartObjectsModule",

			"BSPUtils",
		});
	}
}

