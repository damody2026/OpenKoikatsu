(function () {
  if (typeof document === 'undefined') return;

  if (!document.getElementById('uecp-screen-crew-css')) {
    const s = document.createElement('style'); s.id = 'uecp-screen-crew-css';
    s.textContent = `
uecp-screen-crew{display:flex;flex-direction:column;flex:1;min-width:0;min-height:0}
uecp-screen-crew .cw-tabs{display:flex;gap:2px;padding:8px 14px 0;border-bottom:1px solid var(--ue-line-soft);flex-shrink:0}
uecp-screen-crew .cw-tab{font-size:12.5px;font-weight:var(--ue-fw-semi,600);color:var(--ue-text-mid);padding:8px 14px;cursor:pointer;border-bottom:2px solid transparent;border-radius:var(--ue-r-sm) var(--ue-r-sm) 0 0}
uecp-screen-crew .cw-tab:hover{background:var(--ue-line-soft)}
uecp-screen-crew .cw-tab.on{color:var(--ue-accent-bright);border-bottom-color:var(--ue-accent)}
uecp-screen-crew .cw-tab-content{flex:1;display:flex;min-height:0;min-width:0}
uecp-screen-crew .cw-tab-content.hidden{display:none}
uecp-screen-crew .cw-split{flex:1;display:flex;min-height:0;min-width:0}
uecp-screen-crew .cw-picker{width:280px;flex-shrink:0;border-right:1px solid var(--ue-line-soft);display:flex;flex-direction:column;min-height:0}
uecp-screen-crew .cw-picker-hd{display:flex;align-items:center;justify-content:space-between;font-size:11px;text-transform:uppercase;letter-spacing:.4px;color:var(--ue-text-lo);padding:12px 14px 6px}
uecp-screen-crew .cw-picker-new{font-size:15px;line-height:1;color:var(--ue-text-lo);cursor:pointer;background:none;border:none;padding:0 4px}
uecp-screen-crew .cw-picker-new:hover{color:var(--ue-accent-bright)}
uecp-screen-crew .cw-strips{padding:0 10px}
uecp-screen-crew .cw-strip{margin-bottom:8px}
uecp-screen-crew .cw-strip-hd{font-size:10px;text-transform:uppercase;letter-spacing:.4px;padding:4px 4px 3px;display:flex;align-items:center;gap:5px}
uecp-screen-crew .cw-strip-hd.active{color:var(--ue-accent-bright)}
uecp-screen-crew .cw-strip-hd.escalated{color:var(--ue-danger,#e0625e)}
uecp-screen-crew .cw-strip-item{font-size:11px;padding:5px 7px;border-radius:var(--ue-r-sm);cursor:pointer;color:var(--ue-text-mid);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;border:1px solid var(--ue-line-soft);margin-bottom:3px;background:var(--ue-elev)}
uecp-screen-crew .cw-strip-item:hover{border-color:var(--ue-line)}
uecp-screen-crew .cw-strip-item.escalated{border-color:var(--ue-danger,#e0625e);color:var(--ue-text-hi)}
uecp-screen-crew .cw-strip-item .dot{display:inline-block;width:6px;height:6px;border-radius:50%;margin-right:6px;background:var(--ue-accent)}
uecp-screen-crew .cw-strip-item.escalated .dot{background:var(--ue-danger,#e0625e)}
uecp-screen-crew .cw-picker-list{flex:1;overflow-y:auto;padding:0 6px 6px}
uecp-screen-crew .cw-picker-empty{color:var(--ue-text-lo);font-size:11.5px;padding:10px 8px}
uecp-screen-crew .cw-prow{padding:8px 9px;border-radius:var(--ue-r);cursor:pointer;border:1px solid transparent;margin-bottom:3px}
uecp-screen-crew .cw-prow:hover{background:var(--ue-line-soft)}
uecp-screen-crew .cw-prow.sel{background:var(--ue-accent-soft);border-color:var(--ue-accent)}
uecp-screen-crew .cw-prow .pg{font-size:12px;color:var(--ue-text-hi);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:flex;justify-content:space-between;gap:6px}
uecp-screen-crew .pw-paused{font-size:9.5px;text-transform:uppercase;letter-spacing:.3px;color:var(--ue-warn,#d9a441);border:1px solid var(--ue-warn,#d9a441);border-radius:7px;padding:0 5px;vertical-align:1px}
/* The goal has to be allowed to shrink. A flex child defaults to min-width:auto, so a
   long goal kept its full intrinsic width and pushed Copy out past .pg's overflow:hidden
   -- the duplicate-plan action was invisible and unclickable for every plan whose goal ran
   past the row, which is most of them. The ellipsis belongs on this span too: .pg is a flex
   container, and text-overflow does nothing on one. */
uecp-screen-crew .cw-prow .pg > .pgt{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
uecp-screen-crew .cw-prow .pcopy{flex-shrink:0;color:var(--ue-text-lo);cursor:pointer}
uecp-screen-crew .cw-prow .pcopy:hover{color:var(--ue-accent-bright)}
uecp-screen-crew .cw-prow .pbar{display:flex;height:3px;border-radius:2px;overflow:hidden;margin-top:6px;background:var(--ue-line-soft)}
uecp-screen-crew .cw-prow .pbar span{height:100%}
uecp-screen-crew .cw-prow .psum{font-size:10px;color:var(--ue-text-lo);font-family:var(--ue-font-mono);margin-top:4px}
uecp-screen-crew .cw-main{flex:1;min-width:0;min-height:0;overflow-y:auto;padding:18px 22px}
uecp-screen-crew .cw-empty{color:var(--ue-text-lo);font-size:12.5px;padding:12px 0 20px}
/* Empty state. A bare line of grey text gave no idea what Crew even does, so this
   mirrors uecp-welcome: mark, one-line pitch, and chips that fill the goal box. */
uecp-screen-crew .cw-hero{display:flex;flex-direction:column;align-items:center;justify-content:center;gap:22px;padding:56px 24px;text-align:center}
uecp-screen-crew .cw-hero-logo{width:48px;height:48px;border-radius:var(--ue-r-md);background:linear-gradient(150deg,var(--ue-accent),var(--ue-accent-deep));display:flex;align-items:center;justify-content:center}
uecp-screen-crew .cw-hero-logo svg{stroke:var(--ue-on-accent)}
uecp-screen-crew .cw-hero-title{font-size:22px;font-weight:var(--ue-fw-semi);color:var(--ue-text-hi)}
uecp-screen-crew .cw-hero-sub{font-size:13.5px;color:var(--ue-text-mid);max-width:520px;line-height:1.5}
uecp-screen-crew .cw-hero-chips{display:flex;flex-wrap:wrap;gap:8px;justify-content:center;max-width:560px}
uecp-screen-crew .cw-hero-chips .chip{font-size:12.5px;color:var(--ue-text-mid);background:var(--ue-panel);border:1px solid var(--ue-line);border-radius:var(--ue-r);padding:8px 14px;cursor:pointer}
uecp-screen-crew .cw-hero-chips .chip:hover{border-color:var(--ue-accent);color:var(--ue-accent-bright)}
uecp-screen-crew .cw-hero .cw-gen-row{width:100%;max-width:560px}
uecp-screen-crew .cw-header{display:flex;align-items:center;gap:10px;margin-bottom:10px}
uecp-screen-crew .cw-goal{flex:1;font-size:14px;color:var(--ue-text-hi);min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;cursor:text;border-radius:var(--ue-r-sm);padding:3px 6px;margin:-3px -6px}
uecp-screen-crew .cw-goal:hover{background:var(--ue-line-soft)}
uecp-screen-crew .cw-goal-input{flex:1;font-size:14px;color:var(--ue-text-hi);background:var(--ue-elev);border:1px solid var(--ue-accent);border-radius:var(--ue-r-sm);padding:3px 6px;font-family:inherit}
uecp-screen-crew .cw-add-btn{font-size:12px;border:1px solid var(--ue-line);background:var(--ue-elev);color:var(--ue-text-mid);border-radius:var(--ue-r);padding:6px 12px;cursor:pointer;flex-shrink:0;white-space:nowrap}
uecp-screen-crew .cw-add-btn:hover{border-color:var(--ue-accent);color:var(--ue-accent-bright)}
uecp-screen-crew .cw-add-btn.danger:hover{border-color:var(--ue-danger,#e0625e);color:var(--ue-danger,#e0625e)}
uecp-screen-crew .cw-progress{display:flex;align-items:center;gap:8px;margin-bottom:16px}
uecp-screen-crew .cw-progress .pbar{flex:1;display:flex;height:6px;border-radius:3px;overflow:hidden;background:var(--ue-line-soft)}
uecp-screen-crew .cw-progress .pbar span{height:100%}
uecp-screen-crew .cw-progress .psum{font-size:10.5px;color:var(--ue-text-lo);font-family:var(--ue-font-mono);white-space:nowrap}
uecp-screen-crew .cw-err{color:var(--ue-danger,#e0625e);font-size:12px;margin-bottom:12px;padding:8px 10px;background:var(--ue-danger-soft,rgba(224,98,94,.1));border-radius:var(--ue-r-sm)}
uecp-screen-crew .cw-add-btn.pri{background:var(--ue-accent-soft);border-color:var(--ue-accent);color:var(--ue-accent-bright)}
uecp-screen-crew .cw-paused-banner{font-size:11.5px;color:var(--ue-warn,#d9a441);background:var(--ue-warn-soft,rgba(217,164,65,.1));border:1px solid var(--ue-warn,#d9a441);border-radius:var(--ue-r-sm);padding:6px 10px;margin-bottom:10px}
uecp-screen-crew .cw-cp{border:1px solid var(--ue-line-soft);border-radius:var(--ue-r);padding:11px 13px;margin-bottom:8px;cursor:pointer}
uecp-screen-crew .cw-cp:hover{border-color:var(--ue-line)}
uecp-screen-crew .cw-cp.escalated{border-color:var(--ue-danger,#e0625e);background:var(--ue-danger-soft,rgba(224,98,94,.06))}
uecp-screen-crew .cw-cp.editing{cursor:default;border-color:var(--ue-accent)}
uecp-screen-crew .cw-cp-head{display:flex;align-items:center;gap:8px}
uecp-screen-crew .cw-chip{font-family:var(--ue-font-mono);font-size:9.5px;font-weight:600;letter-spacing:.04em;padding:1px 6px;border-radius:8px;background:var(--ue-elev);border:1px solid var(--ue-line-soft);color:var(--ue-text-lo);flex-shrink:0;white-space:nowrap;text-transform:uppercase}
uecp-screen-crew .cw-chip.pending{color:var(--ue-text-lo)}
uecp-screen-crew .cw-chip.retrying{color:var(--ue-warn,#d9a441);border-color:var(--ue-warn,#d9a441)}
uecp-screen-crew .cw-chip.in_progress{color:var(--ue-accent-bright);border-color:var(--ue-accent)}
uecp-screen-crew .cw-chip.passed{color:var(--ue-success,#5cb85c);border-color:var(--ue-success,#5cb85c)}
uecp-screen-crew .cw-chip.failed{color:var(--ue-danger,#e0625e);border-color:var(--ue-danger,#e0625e)}
uecp-screen-crew .cw-chip.skipped{color:var(--ue-text-lo);text-decoration:line-through}
uecp-screen-crew .cw-cp-desc{flex:1;font-size:12.5px;color:var(--ue-text-hi);min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
uecp-screen-crew .cw-attempts{font-size:10.5px;color:var(--ue-text-lo);font-family:var(--ue-font-mono);flex-shrink:0}
uecp-screen-crew .cw-meta{display:flex;flex-wrap:wrap;gap:4px;margin-top:6px;align-items:center}
uecp-screen-crew .cw-roles{font-size:9.5px;font-family:var(--ue-font-mono);color:var(--ue-text-lo);padding:1px 6px;border-radius:8px;background:var(--ue-elev);border:1px solid var(--ue-line-soft)}
uecp-screen-crew .cw-dep-pill{font-size:9.5px;padding:1px 6px;border-radius:8px;background:var(--ue-elev);color:var(--ue-text-lo);border:1px solid var(--ue-line-soft)}
uecp-screen-crew .cw-dep-pill.met{color:var(--ue-success,#5cb85c);border-color:var(--ue-success,#5cb85c);text-decoration:line-through}
uecp-screen-crew .cw-run-chip{font-family:var(--ue-font-mono);font-size:9px;padding:1px 5px;border-radius:7px;background:var(--ue-elev);border:1px solid var(--ue-line-soft);color:var(--ue-text-lo)}
uecp-screen-crew .cw-run-chip.running{color:var(--ue-accent-bright);border-color:var(--ue-accent)}
uecp-screen-crew .cw-run-chip.failed{color:var(--ue-danger,#e0625e);border-color:var(--ue-danger,#e0625e)}
uecp-screen-crew .cw-run-chip.succeeded{color:var(--ue-success,#5cb85c);border-color:var(--ue-success,#5cb85c)}
uecp-screen-crew .cw-escalation{margin-top:8px;padding:8px 10px;border-radius:var(--ue-r-sm);background:var(--ue-danger-soft,rgba(224,98,94,.1));border:1px solid var(--ue-danger,#e0625e)}
uecp-screen-crew .cw-escalation-hd{font-size:10.5px;font-weight:600;color:var(--ue-danger,#e0625e);text-transform:uppercase;letter-spacing:.3px;margin-bottom:4px}
uecp-screen-crew .cw-escalation-reason{font-size:12px;color:var(--ue-text-hi);white-space:pre-wrap}
/* Same block, amber not red: a checkpoint with attempts left is not yet a problem the
   user must act on, but WHY it failed still has to be on the row — the counter alone
   ('1/3') says it failed without saying what went wrong. */
uecp-screen-crew .cw-escalation.retry{background:var(--ue-warn-soft,rgba(217,164,65,.1));border-color:var(--ue-warn,#d9a441)}
uecp-screen-crew .cw-escalation-hd.retry{color:var(--ue-warn,#d9a441)}
uecp-screen-crew .cw-actions{display:flex;gap:6px;margin-top:8px;flex-wrap:wrap}
uecp-screen-crew .cw-actions button{font-size:11px;border:1px solid var(--ue-line);background:var(--ue-elev);color:var(--ue-text-mid);border-radius:var(--ue-r-sm);padding:4px 10px;cursor:pointer}
uecp-screen-crew .cw-actions button.pri{background:var(--ue-accent-soft);border-color:var(--ue-accent);color:var(--ue-accent-bright)}
uecp-screen-crew .cw-actions button.danger:hover{border-color:var(--ue-danger,#e0625e);color:var(--ue-danger,#e0625e)}
uecp-screen-crew .cw-actions button:disabled{opacity:.4;cursor:not-allowed}
uecp-screen-crew .cw-actions button.pri:disabled{background:var(--ue-elev);border-color:var(--ue-line);color:var(--ue-text-lo)}
uecp-screen-crew .cw-ef{display:flex;flex-direction:column;gap:5px;margin-top:8px}
uecp-screen-crew .cw-ef > label{font-size:10.5px;text-transform:uppercase;letter-spacing:.4px;color:var(--ue-text-lo)}
uecp-screen-crew .cw-ef input[type=text],uecp-screen-crew .cw-ef textarea,uecp-screen-crew .cw-ef select{font-size:12.5px;color:var(--ue-text-hi);background:var(--ue-elev);border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);padding:6px 8px;font-family:inherit;box-sizing:border-box;width:100%}
uecp-screen-crew .cw-ef textarea{resize:vertical;min-height:56px}
uecp-screen-crew .cw-ef-row{display:flex;gap:10px}
uecp-screen-crew .cw-ef-row .cw-ef{flex:1}
uecp-screen-crew .cw-deps-pick{display:flex;flex-wrap:wrap;gap:6px}
uecp-screen-crew .cw-deps-pick label{font-size:11px;color:var(--ue-text-mid);display:flex;align-items:center;gap:4px;background:var(--ue-elev);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm);padding:3px 8px}
uecp-screen-crew .cw-adv-toggle{align-self:flex-start;font-size:11px;border:1px solid var(--ue-line);background:var(--ue-elev);color:var(--ue-text-mid);border-radius:var(--ue-r-sm);padding:4px 9px;cursor:pointer;margin-top:4px}
uecp-screen-crew .cw-gen-row{display:flex;gap:8px;align-items:center;margin-bottom:14px}
uecp-screen-crew .cw-gen-input{flex:1;font-size:13px;color:var(--ue-text-hi);background:var(--ue-elev);border:1px solid var(--ue-accent);border-radius:var(--ue-r);padding:7px 10px;font-family:inherit}
uecp-screen-crew .cw-gen-status{display:flex;align-items:center;gap:7px;font-size:12px;color:var(--ue-accent-bright);margin-bottom:14px}
uecp-screen-crew .cw-gen-status .dot{width:6px;height:6px;border-radius:50%;background:var(--ue-accent)}
/* The roster: V1's three agents, back on the screen. A model per agent was the part users
   built their crews around, and 2.0 had moved it into Roles where nobody looked. */
uecp-screen-crew .cw-roster{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:8px;margin-bottom:16px}
uecp-screen-crew .cw-agent{border:1px solid var(--ue-line-soft);border-radius:var(--ue-r);padding:10px 11px;display:flex;flex-direction:column;gap:6px;min-width:0;background:var(--ue-panel)}
uecp-screen-crew .cw-agent.busy{border-color:var(--ue-accent)}
uecp-screen-crew .cw-agent-hd{display:flex;align-items:center;justify-content:space-between;gap:6px}
uecp-screen-crew .cw-agent-role{font-size:10.5px;text-transform:uppercase;letter-spacing:.5px;font-weight:var(--ue-fw-semi);color:var(--ue-text-hi)}
uecp-screen-crew .cw-agent-state{font-size:9.5px;font-family:var(--ue-font-mono);padding:1px 6px;border-radius:8px;border:1px solid var(--ue-line-soft);color:var(--ue-text-lo);white-space:nowrap}
uecp-screen-crew .cw-agent.busy .cw-agent-state{color:var(--ue-accent-bright);border-color:var(--ue-accent)}
uecp-screen-crew .cw-agent select{font-size:12px;color:var(--ue-text-hi);background:var(--ue-elev);border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);padding:5px 7px;font-family:inherit;width:100%;min-width:0}
uecp-screen-crew .cw-agent-note{font-size:11px;color:var(--ue-text-lo);line-height:1.4;min-width:0}
uecp-screen-crew .cw-agent-task{display:block;color:var(--ue-text-mid);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
uecp-screen-crew .cw-agent-open{align-self:flex-start;font-size:11px;padding:0;background:none;border:none;color:var(--ue-accent);cursor:pointer}
uecp-screen-crew .cw-activity{margin-top:18px}
uecp-screen-crew .cw-activity-hd{font-size:10.5px;text-transform:uppercase;letter-spacing:.4px;color:var(--ue-text-lo);margin-bottom:6px}
uecp-screen-crew .cw-act{display:flex;gap:10px;align-items:baseline;font-size:11.5px;padding:5px 6px;border-radius:var(--ue-r-sm);cursor:pointer;min-width:0}
uecp-screen-crew .cw-act:hover{background:var(--ue-line-soft)}
uecp-screen-crew .cw-act .tm{font-family:var(--ue-font-mono);font-size:10px;color:var(--ue-text-lo);flex-shrink:0}
uecp-screen-crew .cw-act .who{color:var(--ue-text-hi);flex-shrink:0}
uecp-screen-crew .cw-act .what{color:var(--ue-text-mid);flex-shrink:0}
uecp-screen-crew .cw-act .what.pass{color:var(--ue-success,#5cb85c)}
uecp-screen-crew .cw-act .what.fail{color:var(--ue-danger,#e0625e)}
uecp-screen-crew .cw-act .on{color:var(--ue-text-lo);min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}`;
    document.head.appendChild(s);
  }

  const CREW_CHIPS = [
    'A pickup item: mesh, overlap trigger, and a score event',
    'A health component with damage, death, and a UI bar',
    'A main menu: widget, buttons, and level load'
  ];

  const STATE_LABEL = { pending: 'Pending', in_progress: 'Dispatching', passed: 'Passed', failed: 'Failed', skipped: 'Skipped' };
  const STATE_COLOR_VAR = { pending: 'var(--ue-line)', in_progress: 'var(--ue-accent)', passed: 'var(--ue-success,#5cb85c)', failed: 'var(--ue-danger,#e0625e)', skipped: 'var(--ue-text-lo)' };
  const RUN_STATUS_CLASS = { running: 'running', succeeded: 'succeeded', failed: 'failed', 'needs-input': 'running', cancelled: 'failed' };

  let _roles = null;
  function fetchRoles(cb) {
    if (_roles) { cb(_roles); return; }
    window.uecp.on('subagent.roles', function (d) { _roles = (d && d.roles) || []; cb(_roles); });
    window.uecp.call('list_subagent_roles', {});
  }
  function roleOpts(selected, fallback) {
    return (_roles || []).map(function (r) {
      const v = r.id;
      return '<option value="' + esc(v) + '"' + (v === (selected || fallback) ? ' selected' : '') + '>' + esc(r.name || r.id) + '</option>';
    }).join('');
  }

  function esc(s) { return window.UECP.escapeHtml(s == null ? '' : String(s)); }

  function progressBarHtml(counts, total) {
    if (!total) return '';
    const order = ['passed', 'failed', 'skipped', 'in_progress', 'pending'];
    return order.map(function (k) {
      const n = counts[k] || 0;
      if (!n) return '';
      return '<span style="width:' + (100 * n / total) + '%;background:' + STATE_COLOR_VAR[k] + '"></span>';
    }).join('');
  }

  class UecpScreenCrew extends HTMLElement {
    connectedCallback() {
      this._plan = null;
      this._planList = [];
      this._editingGoal = false;
      this._editingId = null;
      this._newDraft = null;
      this._tab = 'plans';
      this._genPrompting = false;
      this._generating = false;
      this._genTimeoutHandle = null;
      this._pollHandle = null;

      this.innerHTML =
        '<div class="cw-tabs">'
        + '<div class="cw-tab on" data-tab="plans">Plans</div>'
        + '<div class="cw-tab" data-tab="roles">Roles</div>'
        + '</div>'
        + '<div class="cw-tab-content" id="cw-plans-pane">'
        + '<div class="cw-split">'
        + '<div class="cw-picker"><div class="cw-picker-hd"><span>Plans</span><button class="cw-picker-new" id="cw-picker-new" title="New checkpoint in the active chat">+</button></div>'
        + '<div id="cw-strips"></div>'
        + '<div class="cw-picker-list" id="cw-picker-list"><div class="cw-picker-empty">Loading…</div></div></div>'
        + '<div class="cw-main" id="cw-main"><div class="cw-empty">Loading…</div></div>'
        + '</div>'
        + '</div>'
        + '<div class="cw-tab-content hidden" id="cw-roles-pane"></div>';

      const self = this;
      this._offPlan = window.uecp.on('crew.plan', function (d) {
        self._plan = d; self._editingGoal = false; self._editingId = null;
        if (self._generating) { self._generating = false; if (self._genTimeoutHandle) { clearTimeout(self._genTimeoutHandle); self._genTimeoutHandle = null; } }
        self._render(); self._renderPicker();
      });
      this._offList = window.uecp.on('crew.planList', function (d) { self._planList = (d && d.plans) || []; self._renderPicker(); });
      this._offErr = window.uecp.on('crew.planError', function (d) { self._lastError = (d && d.error) || ''; self._render(); });
      this._slots = []; this._slotActiveIdx = -1;
      this._offSlots = window.uecp.on('slots.list', function (d) {
        self._slots = (d && d.slots) || [];
        self._slotActiveIdx = (d && typeof d.activeIdx === 'number') ? d.activeIdx : -1;
        if (self._editingId === null && !self._editingGoal) self._render();
      });
      window.uecp.call('list_slots', {});
      window.uecp.call('crew_get_plan', {});
      window.uecp.call('list_crew_plans', {});
      fetchRoles(function () { if (self._plan) self._render(); });

      this.querySelector('#cw-picker-new').addEventListener('click', function () { self._startNewCheckpoint(); });
      this.querySelectorAll('.cw-tab').forEach(function (t) {
        t.addEventListener('click', function () { self._switchTab(t.getAttribute('data-tab')); });
      });
    }
    disconnectedCallback() {
      if (this._offPlan) this._offPlan();
      if (this._offList) this._offList();
      if (this._offErr) this._offErr();
      if (this._offSlots) this._offSlots();
      if (this._genTimeoutHandle) { clearTimeout(this._genTimeoutHandle); this._genTimeoutHandle = null; }
      if (this._pollHandle) { clearInterval(this._pollHandle); this._pollHandle = null; }
    }

    _syncPollState(checkpoints) {
      const hasInFlight = checkpoints.some(function (cp) { return (cp.state || 'pending') === 'in_progress'; });
      if (hasInFlight && !this._pollHandle) {
        this._pollHandle = setInterval(function () {
          window.uecp.call('crew_get_plan', {});
          window.uecp.call('list_crew_plans', {});
        }, 4000);
      } else if (!hasInFlight && this._pollHandle) {
        clearInterval(this._pollHandle);
        this._pollHandle = null;
      }
    }

    _switchTab(tab) {
      if (window.UECP.crewDispatchPanel) window.UECP.crewDispatchPanel.close();
      if (window.UECP.crewCheckpointDetail) window.UECP.crewCheckpointDetail.close();
      this._tab = tab;
      this.querySelectorAll('.cw-tab').forEach(function (t) { t.classList.toggle('on', t.getAttribute('data-tab') === tab); });
      this.querySelector('#cw-plans-pane').classList.toggle('hidden', tab !== 'plans');
      const rolesPane = this.querySelector('#cw-roles-pane');
      rolesPane.classList.toggle('hidden', tab !== 'roles');
      if (tab === 'roles' && !rolesPane.firstChild) {
        rolesPane.appendChild(document.createElement('uecp-screen-subagents'));
      }
    }

    _esc(s) { return esc(s); }

    _startNewCheckpoint() {
      this._editingId = '__new__';
      this._newDraft = { toolAllowlistOverride: [] };
      this._render();
      const el = this.querySelector('#cw-cp-new-desc');
      if (el) el.focus();
    }

    _genControlHtml() {
      if (this._generating) {
        return '<div class="cw-gen-status"><span class="dot"></span>Asking the Architect to draft checkpoints for this chat…</div>';
      }
      if (this._genPrompting) {
        return '<div class="cw-gen-row"><input type="text" class="cw-gen-input" id="cw-gen-input" placeholder="Describe what you want to build…"><button class="cw-add-btn pri" id="cw-gen-submit">Generate</button><button class="cw-add-btn" id="cw-gen-cancel">Cancel</button></div>';
      }
      return '';
    }

    _wireGenControl(container) {
      const self = this;
      const toggle = container.querySelector('#cw-gen-toggle');
      if (toggle) toggle.addEventListener('click', function () { self._genPrompting = true; self._render(); });

      const input = container.querySelector('#cw-gen-input');
      const submit = container.querySelector('#cw-gen-submit');
      const cancel = container.querySelector('#cw-gen-cancel');
      if (input) { input.focus(); input.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') { e.preventDefault(); self._submitGoalGen(input.value.trim()); }
        else if (e.key === 'Escape') { e.preventDefault(); self._genPrompting = false; self._render(); }
      }); }
      if (submit) submit.addEventListener('click', function () { self._submitGoalGen(input ? input.value.trim() : ''); });
      if (cancel) cancel.addEventListener('click', function () { self._genPrompting = false; self._render(); });
    }

    _submitGoalGen(goal) {
      if (!goal) return;
      window.uecp.call('send_message', {
        text: 'Draft a checkpoint plan for this goal: "' + goal + '". Break it into 3-8 checkpoints, '
          + 'each with a clear description and specific success_criteria (what the reviewer should check), '
          + 'and use depends_on where there is a natural order. Call crew_create_plan to create it — '
          + "don't dispatch or implement anything yet, just create the plan."
      });
      this._genPrompting = false;
      this._generating = true;
      this._render();
      const self = this;
      this._genTimeoutHandle = setTimeout(function () { self._generating = false; self._render(); }, 120000);
    }

    _renderPicker() {
      const box = this.querySelector('#cw-picker-list'); if (!box) return;
      const stripsBox = this.querySelector('#cw-strips');
      const self = this;
      const activeConvId = this._plan && this._plan.hasPlan ? this._plan.convId : null;

      const activeItems = [], escalatedItems = [];
      this._planList.forEach(function (p) {
        (p.activeCheckpoints || []).forEach(function (c) { activeItems.push({ convId: p.convId, goal: p.goal, desc: c.description }); });
        (p.escalatedCheckpoints || []).forEach(function (c) { escalatedItems.push({ convId: p.convId, goal: p.goal, desc: c.description }); });
      });
      let stripsHtml = '';
      if (activeItems.length) {
        stripsHtml += '<div class="cw-strip"><div class="cw-strip-hd active">Active now (' + activeItems.length + ')</div>'
          + activeItems.map(function (it, i) {
            return '<div class="cw-strip-item" data-strip="active" data-idx="' + i + '"><span class="dot"></span>' + esc(it.desc) + '</div>';
          }).join('') + '</div>';
      }
      if (escalatedItems.length) {
        stripsHtml += '<div class="cw-strip"><div class="cw-strip-hd escalated">Needs attention (' + escalatedItems.length + ')</div>'
          + escalatedItems.map(function (it, i) {
            return '<div class="cw-strip-item escalated" data-strip="escalated" data-idx="' + i + '"><span class="dot"></span>' + esc(it.desc) + '</div>';
          }).join('') + '</div>';
      }
      stripsBox.innerHTML = '<div class="cw-strips">' + stripsHtml + '</div>';
      stripsBox.querySelectorAll('.cw-strip-item').forEach(function (el) {
        el.addEventListener('click', function () {
          const list = el.getAttribute('data-strip') === 'active' ? activeItems : escalatedItems;
          const item = list[parseInt(el.getAttribute('data-idx'), 10)];
          if (item) window.uecp.call('switch_chat', { chatId: item.convId });
        });
      });

      if (!this._planList.length) {
        box.innerHTML = '<div class="cw-picker-empty">No Crew plans yet. Click + above to add the first checkpoint to this chat, or ask the Architect to build something multi-step.</div>';
        return;
      }

      box.innerHTML = this._planList.map(function (p) {
        const total = p.total || 0;
        const counts = { pending: p.pending, in_progress: p.inProgress, passed: p.passed, failed: p.failed, skipped: p.skipped };
        const isActive = p.convId === activeConvId;
        return '<div class="cw-prow' + (isActive ? ' sel' : '') + '" data-conv-id="' + esc(p.convId) + '">'
          + '<div class="pg"><span class="pgt">' + esc(p.goal || '(untitled plan)') + (p.paused ? ' <span class="pw-paused">paused</span>' : '') + '</span>'
          + (isActive ? '' : '<span class="pcopy" data-copy-conv-id="' + esc(p.convId) + '" title="Copy these checkpoints into the active chat">Copy</span>') + '</div>'
          + '<div class="pbar">' + progressBarHtml(counts, total) + '</div>'
          + '<div class="psum">' + esc(p.passed) + '/' + esc(total) + ' passed'
          + (p.failed ? ' · ' + esc(p.failed) + ' failed' : '')
          + (p.inProgress ? ' · ' + esc(p.inProgress) + ' running' : '') + '</div>'
          + '</div>';
      }).join('');

      box.querySelectorAll('.cw-prow').forEach(function (row) {
        row.addEventListener('click', function (e) {
          if (e.target.closest('.pcopy')) return;
          window.uecp.call('switch_chat', { chatId: row.getAttribute('data-conv-id') });
        });
      });
      box.querySelectorAll('.pcopy').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
          e.stopPropagation();
          const sourceConvId = btn.getAttribute('data-copy-conv-id');
          window.UECP.dialog.confirm('Copy checkpoints', 'Copy every checkpoint from this plan into the active chat as fresh (Pending) entries? Progress/history is not copied.')
            .then(function (ok) { if (ok) window.uecp.call('crew_duplicate_plan', { sourceConvId: sourceConvId }); });
        });
      });
    }

    _render() {
      const main = this.querySelector('#cw-main'); if (!main) return;
      const self = this;
      const plan = this._plan;
      const checkpoints = (plan && plan.hasPlan) ? (plan.checkpoints || []) : [];
      this._syncPollState(checkpoints);

      if ((!plan || !plan.hasPlan) && this._editingId !== '__new__') {
        main.innerHTML = (this._lastError ? '<div class="cw-err">' + esc(this._lastError) + '</div>' : '')
          + '<div class="cw-hero">'
          +   '<div class="cw-hero-logo">' + window.UECP.icon('ic-crew', 24) + '</div>'
          +   '<div class="cw-hero-title">What should the crew build?</div>'
          +   '<div class="cw-hero-sub">Break a build into checkpoints. Each one is handed to a worker, checked by a reviewer, and retried on its own if the review fails.</div>'
          +   this._genControlHtml()
          +   '<div class="cw-hero-chips">'
          +     CREW_CHIPS.map(function (c) { return '<div class="chip">' + esc(c) + '</div>'; }).join('')
          +   '</div>'
          +   '<div class="cw-actions"><button class="cw-add-btn pri" id="cw-gen-toggle">Generate from goal</button>'
          +   '<button class="cw-add-btn" id="cw-new-first">+ New Checkpoint</button></div>'
          + '</div>';
        const btn = main.querySelector('#cw-new-first');
        if (btn) btn.addEventListener('click', function () { self._startNewCheckpoint(); });
        main.querySelectorAll('.cw-hero-chips .chip').forEach(function (el, i) {
          el.addEventListener('click', function () {
            self._genPrompting = true;
            self._render();
            const inp = self.querySelector('#cw-gen-input');
            if (inp) { inp.value = CREW_CHIPS[i]; inp.focus(); }
          });
        });
        this._wireGenControl(main);
        return;
      }

      const counts = { pending: 0, in_progress: 0, passed: 0, failed: 0, skipped: 0 };
      checkpoints.forEach(function (cp) { counts[cp.state || 'pending'] = (counts[cp.state || 'pending'] || 0) + 1; });

      let html = (this._lastError ? '<div class="cw-err">' + esc(this._lastError) + '</div>' : '');
      if (plan && plan.hasPlan) {
        html += '<div class="cw-header">'
          + (this._editingGoal
            ? '<input type="text" class="cw-goal-input" id="cw-goal-input" value="' + esc(plan.goal || '') + '">'
            : '<div class="cw-goal" id="cw-goal-display" title="Click to rename">' + esc(plan.goal || '(untitled plan — click to name it)') + '</div>')
          + '<button class="cw-add-btn" id="cw-gen-toggle">Generate</button>'
          + '<button class="cw-add-btn" id="cw-new-cp">+ New Checkpoint</button>'
          + '<button class="cw-add-btn' + (plan.paused ? ' pri' : '') + '" id="cw-pause-toggle">' + (plan.paused ? 'Resume' : 'Pause') + '</button>'
          + '<button class="cw-add-btn danger" id="cw-clear-plan" title="Delete this whole plan">Delete plan</button>'
          + '</div>'
          + (plan.paused ? '<div class="cw-paused-banner">Paused — no new checkpoints will dispatch (whether from here or the Architect) until you resume. Anything already in flight keeps running.</div>' : '')
          + '<div class="cw-progress"><div class="pbar">' + progressBarHtml(counts, checkpoints.length) + '</div>'
          + '<div class="psum">' + esc(counts.passed) + '/' + esc(checkpoints.length) + ' passed'
          + (counts.failed ? ' · ' + esc(counts.failed) + ' failed' : '')
          + (counts.in_progress ? ' · ' + esc(counts.in_progress) + ' running' : '')
          + (counts.skipped ? ' · ' + esc(counts.skipped) + ' skipped' : '') + '</div></div>'
          + this._rosterHtml(plan, checkpoints)
          + this._genControlHtml();
      }

      if (this._editingId === '__new__') {
        html += this._editFormHtml(null, checkpoints);
      }

      checkpoints.forEach(function (cp) {
        if (self._editingId === cp.id) { html += self._editFormHtml(cp, checkpoints); return; }

        const state = cp.state || 'pending';
        const isEscalated = state === 'failed' && cp.attemptCount >= cp.maxAttempts;
        const attempts = cp.attemptCount > 0 ? '<span class="cw-attempts">' + esc(cp.attemptCount) + '/' + esc(cp.maxAttempts) + '</span>' : '';
        const isRetrying = state === 'pending' && cp.attemptCount > 0;
        const chipClass = isRetrying ? 'pending retrying' : state;
        const chipLabel = isRetrying ? 'Retrying' : (STATE_LABEL[state] || state);
        const unmetDeps = (cp.dependsOn || []).filter(function (depId) {
          const dep = checkpoints.find(function (c) { return c.id === depId; });
          return !dep || (dep.state !== 'passed' && dep.state !== 'skipped');
        });
        const deps = (cp.dependsOn || []).map(function (d) {
          const met = unmetDeps.indexOf(d) === -1;
          return '<span class="cw-dep-pill' + (met ? ' met' : '') + '">needs ' + esc(d) + '</span>';
        }).join('');
        const runs = (cp.linkedRuns || []).map(function (r) {
          const cls = RUN_STATUS_CLASS[r.status] || '';
          const label = (r.phase === 'reviewer' ? 'R' : 'W') + (r.attempt > 1 ? r.attempt : '');
          return '<span class="cw-run-chip ' + cls + '" title="' + esc(r.phase) + ' (' + esc(r.roleId) + ') — ' + esc(r.status) + '">' + esc(label) + '</span>';
        }).join('');
        const roles = '<span class="cw-roles">' + esc(cp.workerRoleId || 'blueprint-dev') + ' → ' + esc(cp.reviewerRoleId || 'reviewer') + '</span>';

        let escalationHtml = '';
        if (isEscalated) {
          const reasons = (cp.attemptReasons || []).map(esc).join('<br>');
          escalationHtml = '<div class="cw-escalation"><div class="cw-escalation-hd">Needs attention — ' + esc(cp.attemptCount) + '/' + esc(cp.maxAttempts) + ' attempts used</div>'
            + '<div class="cw-escalation-reason">' + (reasons || esc(cp.lastFailReason || '')) + '</div></div>';
        } else if (isRetrying) {
          const lastReason = cp.lastFailReason || (cp.attemptReasons || []).slice(-1)[0] || '';
          if (lastReason) {
            escalationHtml = '<div class="cw-escalation retry">'
              + '<div class="cw-escalation-hd retry">Last attempt failed</div>'
              + '<div class="cw-escalation-reason">' + esc(lastReason) + '</div></div>';
          }
        }

        html += '<div class="cw-cp' + (isEscalated ? ' escalated' : '') + '" data-id="' + esc(cp.id) + '">'
          + '<div class="cw-cp-head"><span class="cw-chip ' + esc(chipClass) + '">' + esc(chipLabel) + '</span>'
          + '<span class="cw-cp-desc">' + esc(cp.description) + '</span>' + attempts + '</div>'
          + '<div class="cw-meta">' + roles + deps + runs + '</div>'
          + escalationHtml
          + '<div class="cw-actions">'
          + (state === 'pending' ? '<button class="pri" data-act="dispatch" data-id="' + esc(cp.id) + '"'
              + (plan.paused ? ' disabled title="Plan is paused -- resume it first"'
                : unmetDeps.length ? ' disabled title="Blocked on: ' + esc(unmetDeps.join(', ')) + '"' : '') + '>Dispatch</button>' : '')
          + (state === 'in_progress' ? '<button data-act="cancel" data-id="' + esc(cp.id) + '">Cancel</button>' : '')
          + (state === 'failed' ? '<button data-act="retry" data-id="' + esc(cp.id) + '">Retry</button>' : '')
          + (state === 'pending' || state === 'failed' ? '<button data-act="skip" data-id="' + esc(cp.id) + '">Skip</button>' : '')
          + (state !== 'in_progress' ? '<button data-act="edit" data-id="' + esc(cp.id) + '">Edit</button>' : '')
          + (state !== 'in_progress' ? '<button class="danger" data-act="delete" data-id="' + esc(cp.id) + '">Delete</button>' : '')
          + '</div>'
          + '</div>';
      });

      if (plan && plan.hasPlan) html += this._activityHtml(checkpoints);

      main.innerHTML = html;
      this._wireHeader(main, plan);
      this._wireRoster(main, plan);
      this._wireGenControl(main);
      this._wireCheckpoints(main, checkpoints);
      this._wireEditForm(main, checkpoints);
    }

    _editFormHtml(cp, allCheckpoints) {
      const isNew = !cp;
      const idPrefix = isNew ? 'cw-cp-new' : 'cw-cp-edit-' + esc(cp.id);
      const others = allCheckpoints.filter(function (c) { return !cp || c.id !== cp.id; });
      const depsHtml = others.length
        ? others.map(function (c) {
          const checked = (!isNew && (cp.dependsOn || []).indexOf(c.id) !== -1) ? ' checked' : '';
          const label = c.description && c.description.length > 30 ? c.description.slice(0, 30) + '…' : (c.description || c.id);
          return '<label><input type="checkbox" data-dep="' + esc(c.id) + '"' + checked + '>' + esc(label) + '</label>';
        }).join('')
        : '<span style="font-size:11px;color:var(--ue-text-lo)">No other checkpoints yet.</span>';

      return '<div class="cw-cp editing" data-editing-id="' + (isNew ? '__new__' : esc(cp.id)) + '">'
        + (this._lastError && this._editingId === (isNew ? '__new__' : cp.id) ? '<div class="cw-err">' + esc(this._lastError) + '</div>' : '')
        + '<div class="cw-ef"><label>Description</label><textarea id="' + idPrefix + '-desc" rows="2" placeholder="What must the worker accomplish?">' + esc(isNew ? '' : cp.description) + '</textarea></div>'
        + '<div class="cw-ef"><label>Success criteria</label><textarea id="' + idPrefix + '-criteria" rows="2" placeholder="What the reviewer checks">' + esc(isNew ? '' : cp.successCriteria) + '</textarea></div>'
        + '<div class="cw-ef-row">'
        + '<div class="cw-ef"><label>Worker</label><select id="' + idPrefix + '-worker">' + roleOpts(isNew ? null : cp.workerRoleId, 'blueprint-dev') + '</select></div>'
        + '<div class="cw-ef"><label>Reviewer</label><select id="' + idPrefix + '-reviewer">' + roleOpts(isNew ? null : cp.reviewerRoleId, 'reviewer') + '</select></div>'
        + '</div>'
        + '<div class="cw-ef"><label>Depends on</label><div class="cw-deps-pick" id="' + idPrefix + '-deps">' + depsHtml + '</div></div>'
        + '<button type="button" class="cw-adv-toggle" id="' + idPrefix + '-adv-toggle">Restrict tools (optional)</button>'
        + '<div id="' + idPrefix + '-adv" style="display:none;margin-top:6px"></div>'
        + '<div class="cw-actions">'
        + '<button class="pri" data-editact="save" data-editing-id="' + (isNew ? '__new__' : esc(cp.id)) + '">' + (isNew ? 'Add checkpoint' : 'Save changes') + '</button>'
        + '<button data-editact="cancel">Cancel</button>'
        + '</div>'
        + '</div>';
    }

    _wireEditForm(main, checkpoints) {
      const self = this;
      const row = main.querySelector('.cw-cp.editing');
      if (!row) return;
      const editingId = row.getAttribute('data-editing-id');
      const idPrefix = editingId === '__new__' ? 'cw-cp-new' : 'cw-cp-edit-' + editingId;
      const isNew = editingId === '__new__';
      let toolAllowlistOverride = isNew
        ? (this._newDraft && this._newDraft.toolAllowlistOverride) || []
        : ((checkpoints.find(function (c) { return c.id === editingId; }) || {}).toolAllowlistOverride || []).slice();

      const advToggle = row.querySelector('#' + idPrefix + '-adv-toggle');
      const advBox = row.querySelector('#' + idPrefix + '-adv');
      advToggle.addEventListener('click', function () {
        const show = advBox.style.display === 'none';
        advBox.style.display = show ? '' : 'none';
        if (show) window.UECP.toolAllowlistEditor.mount(advBox, toolAllowlistOverride, function (sel) { toolAllowlistOverride = sel; });
      });

      row.querySelector('[data-editact="cancel"]').addEventListener('click', function () {
        self._editingId = null;
        self._render();
      });
      row.querySelector('[data-editact="save"]').addEventListener('click', function () {
        const desc = row.querySelector('#' + idPrefix + '-desc').value.trim();
        if (!desc) return;
        const payload = {
          description: desc,
          successCriteria: row.querySelector('#' + idPrefix + '-criteria').value.trim(),
          workerRoleId: row.querySelector('#' + idPrefix + '-worker').value,
          reviewerRoleId: row.querySelector('#' + idPrefix + '-reviewer').value,
          dependsOn: Array.from(row.querySelectorAll('[data-dep]:checked')).map(function (i) { return i.getAttribute('data-dep'); }),
          toolAllowlistOverride: toolAllowlistOverride
        };
        if (!isNew) payload.id = editingId;
        window.uecp.call('crew_create_plan', { checkpoints: [payload] });
        self._editingId = null;
      });
    }

    _wireHeader(main, plan) {
      const self = this;
      const newBtn = main.querySelector('#cw-new-cp');
      if (newBtn) newBtn.addEventListener('click', function () { self._startNewCheckpoint(); });

      const clearBtn = main.querySelector('#cw-clear-plan');
      if (clearBtn) clearBtn.addEventListener('click', function () {
        window.UECP.dialog.confirm('Delete plan', 'Delete every checkpoint in this plan? This cannot be undone.')
          .then(function (ok) { if (ok) window.uecp.call('crew_clear_plan', {}); });
      });

      const pauseBtn = main.querySelector('#cw-pause-toggle');
      if (pauseBtn) pauseBtn.addEventListener('click', function () {
        window.uecp.call('crew_set_plan_paused', { paused: !plan.paused });
      });

      const goalDisplay = main.querySelector('#cw-goal-display');
      if (goalDisplay) goalDisplay.addEventListener('click', function () { self._editingGoal = true; self._render(); });

      const goalInput = main.querySelector('#cw-goal-input');
      if (goalInput) {
        goalInput.focus();
        goalInput.select();
        const commit = function () {
          const val = goalInput.value.trim();
          self._editingGoal = false;
          if (val && val !== plan.goal) {
            const checkpoints = (plan.checkpoints || []).map(function (cp) {
              return {
                id: cp.id, description: cp.description, successCriteria: cp.successCriteria,
                dependsOn: cp.dependsOn, workerRoleId: cp.workerRoleId, reviewerRoleId: cp.reviewerRoleId,
                toolAllowlistOverride: cp.toolAllowlistOverride
              };
            });
            window.uecp.call('crew_create_plan', { goal: val, checkpoints: checkpoints });
          } else {
            self._render();
          }
        };
        goalInput.addEventListener('blur', commit);
        goalInput.addEventListener('keydown', function (e) {
          if (e.key === 'Enter') { e.preventDefault(); goalInput.blur(); }
          else if (e.key === 'Escape') { e.preventDefault(); self._editingGoal = false; self._render(); }
        });
      }
    }

    _wireCheckpoints(main, checkpoints) {
      const self = this;
      main.querySelectorAll('.cw-cp:not(.editing)').forEach(function (row) {
        row.addEventListener('click', function (e) {
          if (e.target.closest('button')) return;
          const cp = checkpoints.find((c) => c.id === row.getAttribute('data-id'));
          if (cp) window.UECP.crewCheckpointDetail.open(row, cp, self._openChat.bind(self));
        });
      });
      main.querySelectorAll('button[data-act]').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
          e.stopPropagation();
          const id = btn.getAttribute('data-id');
          const act = btn.getAttribute('data-act');
          const cp = checkpoints.find((c) => c.id === id);
          if (act === 'dispatch') { if (cp) window.UECP.crewDispatchPanel.open(btn, cp); return; }
          if (act === 'edit') { self._editingId = id; self._render(); return; }
          if (act === 'delete') {
            window.UECP.dialog.confirm('Delete checkpoint', 'Delete "' + ((cp && cp.description) || id) + '"? This cannot be undone.')
              .then(function (ok) { if (ok) window.uecp.call('crew_delete_checkpoint', { checkpointId: id }); });
            return;
          }
          if (act === 'cancel') window.uecp.call('crew_cancel_checkpoint_dispatch', { checkpointId: id });
          if (act === 'retry') window.uecp.call('crew_retry_checkpoint', { checkpointId: id });
          if (act === 'skip') window.uecp.call('crew_skip_checkpoint', { checkpointId: id });
        });
      });
    }

    _openChat(chatId) {
      if (!chatId) return;
      window.uecp.call('switch_chat', { chatId: chatId });
      window.UECP.router.go('architect');
      window.uecp.call('switch_view', { view: 'architect' });
      window.uecp.__emit('screen.changed', { route: 'architect', title: '' });
    }

    _modelOptions(selected) {
      const SF = window.SettingsFormat;
      return (this._slots || []).map(function (sl) {
        const name = SF && SF.slotModelName ? SF.slotModelName(sl, sl.index) : (sl.model || sl.name || ('Slot ' + (sl.index + 1)));
        return '<option data-i18n-skip value="' + esc(sl.index) + '"' + (sl.index === selected ? ' selected' : '') + '>' + esc(name) + '</option>';
      }).join('');
    }

    _fallbackSlot(agent, plan, checkpoints) {
      const def = typeof this._slotActiveIdx === 'number' ? this._slotActiveIdx : -1;
      const planner = typeof plan.plannerSlot === 'number' && plan.plannerSlot >= 0 ? plan.plannerSlot : def;
      if (agent === 'planner') return def;
      const first = checkpoints[0] || {};
      const roleId = agent === 'worker' ? (first.workerRoleId || 'blueprint-dev') : (first.reviewerRoleId || 'reviewer');
      const role = (_roles || []).find(function (r) { return r.id === roleId; });
      return role && typeof role.apiKeySlotIndex === 'number' && role.apiKeySlotIndex >= 0 ? role.apiKeySlotIndex : planner;
    }

    _rosterHtml(plan, checkpoints) {
      const live = { worker: [], reviewer: [] };
      checkpoints.forEach(function (cp) {
        if (cp.live && live[cp.live.phase]) live[cp.live.phase].push({ cp: cp, chatId: cp.live.chatId });
      });
      const self = this;
      function card(agent, roleLabel, busyLabel, idleNote, slot, runs) {
        const busy = runs.length > 0;
        const first = runs[0];
        const note = busy
          ? '<span class="cw-agent-task" data-i18n-skip>' + esc(first.cp.description) + (runs.length > 1 ? ' (+' + (runs.length - 1) + ')' : '') + '</span>'
          : '<span>' + esc(idleNote) + '</span>';
        const openId = agent === 'planner' ? plan.convId : (busy ? first.chatId : '');
        return '<div class="cw-agent' + (busy ? ' busy' : '') + '" data-agent="' + agent + '">'
          + '<div class="cw-agent-hd"><span class="cw-agent-role">' + esc(roleLabel) + '</span>'
          + '<span class="cw-agent-state">' + esc(agent === 'planner' ? 'This chat' : (busy ? busyLabel : 'Idle')) + '</span></div>'
          + '<select class="cw-agent-model" data-agent="' + agent + '">'
          + self._modelOptions(slot >= 0 ? slot : self._fallbackSlot(agent, plan, checkpoints)) + '</select>'
          + '<div class="cw-agent-note">' + note + '</div>'
          + (openId ? '<button class="cw-agent-open" data-open-chat="' + esc(openId) + '">Open chat</button>' : '')
          + '</div>';
      }
      const num = function (v) { return typeof v === 'number' ? v : -1; };
      return '<div class="cw-roster">'
        + card('planner', 'Planner', '', 'Plans the checkpoints and sends each one out.', num(plan.plannerSlot), [])
        + card('worker', 'Worker', 'Building', 'Builds each checkpoint.', num(plan.workerSlot), live.worker)
        + card('reviewer', 'Reviewer', 'Reviewing', 'Checks each result and passes or fails it.', num(plan.reviewerSlot), live.reviewer)
        + '</div>';
    }

    _wireRoster(main, plan) {
      const self = this;
      main.querySelectorAll('.cw-agent-model').forEach(function (sel) {
        sel.addEventListener('change', function () {
          const v = parseInt(sel.value, 10);
          const args = { chatId: plan.convId };
          args[sel.getAttribute('data-agent') + 'Slot'] = isNaN(v) ? -1 : v;
          window.uecp.call('crew_set_models', args);
        });
      });
      main.querySelectorAll('[data-open-chat]').forEach(function (b) {
        const id = b.getAttribute('data-open-chat');
        if (!id) return;
        b.addEventListener('click', function (ev) { if (ev && ev.stopPropagation) ev.stopPropagation(); self._openChat(id); });
      });
    }

    _activityHtml(checkpoints) {
      const rows = [];
      checkpoints.forEach(function (cp) {
        (cp.linkedRuns || []).forEach(function (r) { rows.push({ cp: cp, r: r }); });
      });
      if (!rows.length) return '';
      rows.sort(function (x, y) { return String(y.r.linkedAt || '').localeCompare(String(x.r.linkedAt || '')); });
      const html = rows.slice(0, 12).map(function (x) {
        const r = x.r;
        const reviewer = r.phase === 'reviewer';
        let what, cls = '';
        if (reviewer) {
          const m = /VERDICT:\s*(PASS|FAIL)/i.exec(r.reportSnippet || '');
          if (m && m[1].toUpperCase() === 'PASS') { what = 'Passed'; cls = ' pass'; }
          else if (m) { what = 'Failed'; cls = ' fail'; }
          else { what = 'Stopped'; cls = ' fail'; }
        } else {
          what = r.status === 'succeeded' || /sent to review/i.test(r.reportSnippet || '') ? 'Sent to review' : 'Stopped';
          if (what === 'Stopped') cls = ' fail';
        }
        const dt = r.linkedAt ? new Date(r.linkedAt) : null;
        const tm = dt && !isNaN(dt.getTime()) ? ('0' + dt.getHours()).slice(-2) + ':' + ('0' + dt.getMinutes()).slice(-2) : '';
        return '<div class="cw-act" data-open-chat="' + esc(r.chatId || '') + '">'
          + '<span class="tm">' + esc(tm) + '</span>'
          + '<span class="who">' + esc(reviewer ? 'Reviewer' : 'Worker') + '</span>'
          + '<span class="what' + cls + '">' + esc(what) + '</span>'
          + '<span class="on" data-i18n-skip>' + esc(x.cp.description) + '</span>'
          + '</div>';
      }).join('');
      return '<div class="cw-activity"><div class="cw-activity-hd">Activity</div>' + html + '</div>';
    }
  }

  if (!customElements.get('uecp-screen-crew')) {
    customElements.define('uecp-screen-crew', UecpScreenCrew);
  }
})();
