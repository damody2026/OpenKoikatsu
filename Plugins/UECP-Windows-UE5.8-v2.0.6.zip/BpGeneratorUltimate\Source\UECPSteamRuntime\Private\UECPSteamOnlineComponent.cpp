// Copyright 2026, BlueprintsLab, All rights reserved
#include "UECPSteamOnlineComponent.h"

#include "Async/UECPSteamSessionAsync.h"
#include "Library/UECPSteamSessionLibrary.h"
#include "UECPSteamRuntimeModule.h"

UUECPSteamOnlineComponent::UUECPSteamOnlineComponent()
{
	PrimaryComponentTick.bCanEverTick = false;
}

bool UUECPSteamOnlineComponent::IsInSession() const
{
	return UUECPSteamSessionLibrary::IsInSteamSession(this, NAME_None);
}

void UUECPSteamOnlineComponent::HostSession()
{
	if (bBusy)
	{
		UE_LOG(LogUECPSteam, Warning, TEXT("HostSession ignored: another session operation is in flight."));
		return;
	}
	bBusy = true;

	UUECPSteamCreateSession* Node =
		UUECPSteamCreateSession::CreateSteamSession(this, HostSettings, NAME_None);
	Node->OnSuccess.AddDynamic(this, &UUECPSteamOnlineComponent::HandleHostComplete);
	Node->OnFailure.AddDynamic(this, &UUECPSteamOnlineComponent::HandleHostComplete);
	Node->Activate();
}

void UUECPSteamOnlineComponent::HandleHostComplete(FUECPSteamError Error)
{
	bBusy = false;

	if (!Error.bSucceeded())
	{
		bIsHosting = false;
		BP_OnHostFailed(Error);
		OnHostComplete.Broadcast(Error);
		return;
	}

	bIsHosting = true;
	BP_OnHostSucceeded();
	OnHostComplete.Broadcast(Error);

	if (bAutoTravel && !HostTravelMap.IsEmpty())
	{
		UUECPSteamSessionLibrary::HostTravelToMap(this, HostTravelMap);
	}
}

void UUECPSteamOnlineComponent::FindSessions()
{
	if (bBusy)
	{
		UE_LOG(LogUECPSteam, Warning, TEXT("FindSessions ignored: another session operation is in flight."));
		return;
	}
	bBusy = true;
	LastResults.Reset();

	UUECPSteamFindSessions* Node = UUECPSteamFindSessions::FindSteamSessions(this, SearchSettings);
	Node->OnSuccess.AddDynamic(this, &UUECPSteamOnlineComponent::HandleFindComplete);
	Node->OnFailure.AddDynamic(this, &UUECPSteamOnlineComponent::HandleFindComplete);
	Node->Activate();
}

void UUECPSteamOnlineComponent::HandleFindComplete(
	const TArray<FUECPSteamSessionSearchResult>& Results, FUECPSteamError Error)
{
	bBusy = false;
	LastResults = Results;

	if (Error.bSucceeded())
	{
		BP_OnSessionsFound(LastResults);
	}
	else
	{
		BP_OnFindFailed(Error);
	}
	OnFindComplete.Broadcast(LastResults, Error);
}

void UUECPSteamOnlineComponent::JoinSessionByIndex(int32 Index)
{
	if (!LastResults.IsValidIndex(Index))
	{
		const FUECPSteamError Error(EUECPSteamResult::InvalidParameter,
			FString::Printf(TEXT("No search result at index %d (have %d). Run Find Sessions first."),
				Index, LastResults.Num()));
		BP_OnJoinFailed(Error);
		OnJoinComplete.Broadcast(Error);
		return;
	}
	JoinSession(LastResults[Index]);
}

void UUECPSteamOnlineComponent::JoinSession(const FUECPSteamSessionSearchResult& SearchResult)
{
	if (bBusy)
	{
		UE_LOG(LogUECPSteam, Warning, TEXT("JoinSession ignored: another session operation is in flight."));
		return;
	}
	bBusy = true;

	UUECPSteamJoinSession* Node =
		UUECPSteamJoinSession::JoinSteamSession(this, SearchResult, NAME_None);
	Node->OnSuccess.AddDynamic(this, &UUECPSteamOnlineComponent::HandleJoinComplete);
	Node->OnFailure.AddDynamic(this, &UUECPSteamOnlineComponent::HandleJoinComplete);
	Node->Activate();
}

void UUECPSteamOnlineComponent::HandleJoinComplete(const FString& ConnectString, FUECPSteamError Error)
{
	bBusy = false;

	if (!Error.bSucceeded())
	{
		BP_OnJoinFailed(Error);
		OnJoinComplete.Broadcast(Error);
		return;
	}

	bIsHosting = false;
	BP_OnJoinSucceeded(ConnectString);
	OnJoinComplete.Broadcast(Error);

	if (bAutoTravel)
	{
		UUECPSteamSessionLibrary::TravelToSteamSession(this, NAME_None);
	}
}

void UUECPSteamOnlineComponent::LeaveSession()
{
	if (bBusy)
	{
		UE_LOG(LogUECPSteam, Warning, TEXT("LeaveSession ignored: another session operation is in flight."));
		return;
	}
	bBusy = true;

	UUECPSteamDestroySession* Node = UUECPSteamDestroySession::DestroySteamSession(this, NAME_None);
	Node->OnSuccess.AddDynamic(this, &UUECPSteamOnlineComponent::HandleLeaveComplete);
	Node->OnFailure.AddDynamic(this, &UUECPSteamOnlineComponent::HandleLeaveComplete);
	Node->Activate();
}

void UUECPSteamOnlineComponent::HandleLeaveComplete(FUECPSteamError Error)
{
	bBusy = false;
	bIsHosting = false;

	BP_OnSessionLeft();
	OnLeaveComplete.Broadcast(Error);
}

bool UUECPSteamOnlineComponent::InviteFriend(FUECPSteamID FriendSteamId)
{
	return UUECPSteamSessionLibrary::SendSteamSessionInvite(this, FriendSteamId, NAME_None);
}
