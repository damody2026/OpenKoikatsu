(function () {
  if (!document.getElementById('uecp-topbar-css')) {
    const s = document.createElement('style'); s.id = 'uecp-topbar-css';
    s.textContent = `
uecp-topbar{height:var(--ue-topbar-h);flex-shrink:0;background:var(--ue-panel);border-bottom:1px solid var(--ue-line-soft);display:flex;align-items:center;gap:12px;padding:0 16px}
/* The title is the active chat name, which is arbitrary length — ellipsis it, or a
   long one wraps inside a 48px row and shoves the MCP status out of the bar. */
uecp-topbar .title{font-size:14.5px;font-weight:var(--ue-fw-semi);min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
uecp-topbar .spacer{flex:1}
/* The element sets display:flex, so [hidden] alone would not hide it. */
uecp-topbar[hidden]{display:none}`;
    document.head.appendChild(s);
  }
  class Topbar extends HTMLElement {
    connectedCallback() {
      this.innerHTML = '<span class="title"></span><span class="spacer"></span>';
      this._syncVisibility();
      this._u1 = window.uecp.on('status.changed', (p) => this._apply(p));
      this._u2 = window.uecp.on('screen.changed', (p) => {
        if (p && p.title != null) { this.querySelector('.title').textContent = p.title; this._syncVisibility(); }
        if (p && p.route) this._applyRoute(p.route);
      });
    }
    disconnectedCallback() { if (this._u1) this._u1(); if (this._u2) this._u2(); }

    _applyRoute(route) {
      this._route = route;
      this._syncVisibility();
    }

    _syncVisibility() {
      const el = this.querySelector('.title');
      const hasTitle = !!(el && el.textContent.trim());
      this.hidden = (this._route === 'learn') || !hasTitle;
    }
    _apply(p) {
      if (!p) return;
      if (p.title != null) {
        this.querySelector('.title').textContent = p.title;
        this._syncVisibility();
      }
    }
  }
  customElements.define('uecp-topbar', Topbar);
})();
