// Copyright 2026, BlueprintsLab, All rights reserved
#include "Library/UECPSteamInventoryLibrary.h"

#include "UECPSteamAPI.h"

namespace
{
	constexpr double InventoryTimeoutSeconds = 30.0;
}

UUECPSteamGetInventory* UUECPSteamGetInventory::GetSteamInventory(UObject* WorldContextObject)
{
	UUECPSteamGetInventory* Node = NewObject<UUECPSteamGetInventory>();
	Node->ContextObject = WorldContextObject;
	Node->RegisterWithGameInstance(WorldContextObject);
	return Node;
}

bool UUECPSteamGetInventory::Start(FUECPSteamError& OutError)
{
#if UECP_WITH_STEAM
	ISteamInventory* Inv = UECPSteam::Inventory();
	if (!Inv)
	{
		OutError = FUECPSteamError::Unavailable();
		return false;
	}

	SteamInventoryResult_t Handle = k_SteamInventoryResultInvalid;
	if (!Inv->GetAllItems(&Handle) || Handle == k_SteamInventoryResultInvalid)
	{
		OutError = FUECPSteamError(EUECPSteamResult::BackendFailure,
			TEXT("GetAllItems was rejected. Steam Inventory is usually not configured for this app."));
		return false;
	}
	ResultHandle = static_cast<int32>(Handle);

	PollStartSeconds = FPlatformTime::Seconds();
	PollHandle = FTSTicker::GetCoreTicker().AddTicker(
		FTickerDelegate::CreateUObject(this, &UUECPSteamGetInventory::PollResult), 0.1f);
	return true;
#else
	OutError = FUECPSteamError::Unavailable();
	return false;
#endif
}

bool UUECPSteamGetInventory::PollResult(float )
{
#if UECP_WITH_STEAM
	ISteamInventory* Inv = UECPSteam::Inventory();
	if (!Inv || ResultHandle < 0)
	{
		CompleteFailure(FUECPSteamError::Unavailable());
		return false;
	}

	const SteamInventoryResult_t Handle = static_cast<SteamInventoryResult_t>(ResultHandle);
	const EResult Status = Inv->GetResultStatus(Handle);

	if (Status == k_EResultPending)
	{
		if (FPlatformTime::Seconds() - PollStartSeconds > InventoryTimeoutSeconds)
		{
			CompleteFailure(FUECPSteamError(EUECPSteamResult::Timeout,
				TEXT("Steam did not return the inventory in time.")));
			return false;
		}
		return true;
	}

	if (Status != k_EResultOK)
	{
		CompleteFromResult(static_cast<int32>(Status), TEXT("Reading the Steam inventory failed"));
		return false;
	}

	uint32 Count = 0;
	if (Inv->GetResultItems(Handle, nullptr, &Count) && Count > 0)
	{
		TArray<SteamItemDetails_t> Native;
		Native.SetNumUninitialized(Count);
		if (Inv->GetResultItems(Handle, Native.GetData(), &Count))
		{
			Items.Reserve(Count);
			for (uint32 Index = 0; Index < Count; ++Index)
			{
				const SteamItemDetails_t& Detail = Native[Index];
				FUECPSteamInventoryItem Item;
				Item.ItemId       = static_cast<int64>(Detail.m_itemId);
				Item.DefinitionId = static_cast<int32>(Detail.m_iDefinition);
				Item.Quantity     = static_cast<int32>(Detail.m_unQuantity);
				Item.bTradable    = (Detail.m_unFlags & k_ESteamItemNoTrade) == 0;
				Items.Add(MoveTemp(Item));
			}
		}
	}

	CompleteSuccess();
	return false;
#else
	return false;
#endif
}

void UUECPSteamGetInventory::ReleaseResult()
{
#if UECP_WITH_STEAM
	if (ResultHandle >= 0)
	{
		if (ISteamInventory* Inv = UECPSteam::Inventory())
		{
			Inv->DestroyResult(static_cast<SteamInventoryResult_t>(ResultHandle));
		}
		ResultHandle = -1;
	}
#endif
}

void UUECPSteamGetInventory::OnCleanup()
{
	if (PollHandle.IsValid())
	{
		FTSTicker::GetCoreTicker().RemoveTicker(PollHandle);
		PollHandle.Reset();
	}
	ReleaseResult();
}

void UUECPSteamGetInventory::BroadcastResult(bool bSucceeded, const FUECPSteamError& Error)
{
	(bSucceeded ? OnSuccess : OnFailure).Broadcast(Items, Error);
}

bool UUECPSteamInventoryLibrary::LoadItemDefinitions()
{
#if UECP_WITH_STEAM
	if (ISteamInventory* Inv = UECPSteam::Inventory()) { return Inv->LoadItemDefinitions(); }
#endif
	return false;
}

TArray<int32> UUECPSteamInventoryLibrary::GetItemDefinitionIds()
{
	TArray<int32> Out;
#if UECP_WITH_STEAM
	ISteamInventory* Inv = UECPSteam::Inventory();
	if (!Inv)
	{
		return Out;
	}

	uint32 Count = 0;
	if (!Inv->GetItemDefinitionIDs(nullptr, &Count) || Count == 0)
	{
		return Out;
	}

	TArray<SteamItemDef_t> Native;
	Native.SetNumUninitialized(Count);
	if (Inv->GetItemDefinitionIDs(Native.GetData(), &Count))
	{
		Out.Reserve(Count);
		for (uint32 Index = 0; Index < Count; ++Index)
		{
			Out.Add(static_cast<int32>(Native[Index]));
		}
	}
#endif
	return Out;
}

FString UUECPSteamInventoryLibrary::GetItemDefinitionProperty(int32 DefinitionId, const FString& PropertyName)
{
#if UECP_WITH_STEAM
	ISteamInventory* Inv = UECPSteam::Inventory();
	if (!Inv)
	{
		return FString();
	}

	uint32 Size = 0;
	const auto Utf8Prop = StringCast<UTF8CHAR>(*PropertyName);
	const char* Prop = reinterpret_cast<const char*>(Utf8Prop.Get());

	if (!Inv->GetItemDefinitionProperty(static_cast<SteamItemDef_t>(DefinitionId), Prop, nullptr, &Size)
		|| Size == 0)
	{
		return FString();
	}

	TArray<char> Buffer;
	Buffer.SetNumZeroed(Size + 1);
	if (Inv->GetItemDefinitionProperty(static_cast<SteamItemDef_t>(DefinitionId), Prop, Buffer.GetData(), &Size))
	{
		return UTF8_TO_TCHAR(Buffer.GetData());
	}
#endif
	return FString();
}

bool UUECPSteamInventoryLibrary::ConsumeItem(int64 ItemId, int32 Quantity)
{
#if UECP_WITH_STEAM
	ISteamInventory* Inv = UECPSteam::Inventory();
	if (Inv && ItemId != 0 && Quantity > 0)
	{
		SteamInventoryResult_t Handle = k_SteamInventoryResultInvalid;
		const bool bOk = Inv->ConsumeItem(&Handle,
			static_cast<SteamItemInstanceID_t>(ItemId), static_cast<uint32>(Quantity));
		if (Handle != k_SteamInventoryResultInvalid)
		{
			Inv->DestroyResult(Handle);
		}
		return bOk;
	}
#endif
	return false;
}

bool UUECPSteamInventoryLibrary::TriggerItemDrop(int32 DefinitionId)
{
#if UECP_WITH_STEAM
	ISteamInventory* Inv = UECPSteam::Inventory();
	if (Inv)
	{
		SteamInventoryResult_t Handle = k_SteamInventoryResultInvalid;
		const bool bOk = Inv->TriggerItemDrop(&Handle, static_cast<SteamItemDef_t>(DefinitionId));
		if (Handle != k_SteamInventoryResultInvalid)
		{
			Inv->DestroyResult(Handle);
		}
		return bOk;
	}
#endif
	return false;
}

bool UUECPSteamInventoryLibrary::GrantPromoItems()
{
#if UECP_WITH_STEAM
	ISteamInventory* Inv = UECPSteam::Inventory();
	if (Inv)
	{
		SteamInventoryResult_t Handle = k_SteamInventoryResultInvalid;
		const bool bOk = Inv->GrantPromoItems(&Handle);
		if (Handle != k_SteamInventoryResultInvalid)
		{
			Inv->DestroyResult(Handle);
		}
		return bOk;
	}
#endif
	return false;
}
