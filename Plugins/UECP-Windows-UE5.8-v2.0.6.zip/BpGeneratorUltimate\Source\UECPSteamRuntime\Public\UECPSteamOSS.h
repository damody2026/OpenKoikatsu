// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "Interfaces/OnlineIdentityInterface.h"
#include "Interfaces/OnlineSessionInterface.h"
#include "OnlineSubsystem.h"
#include "UECPSteamTypes.h"

namespace UECPSteamOSS
{
	UECPSTEAMRUNTIME_API IOnlineSubsystem* Get(const UObject* WorldContextObject);

	UECPSTEAMRUNTIME_API IOnlineSessionPtr     Session(const UObject* WorldContextObject);
	UECPSTEAMRUNTIME_API IOnlineIdentityPtr    Identity(const UObject* WorldContextObject);
	UECPSTEAMRUNTIME_API IOnlineFriendsPtr     Friends(const UObject* WorldContextObject);
	UECPSTEAMRUNTIME_API IOnlineAchievementsPtr Achievements(const UObject* WorldContextObject);
	UECPSTEAMRUNTIME_API IOnlineLeaderboardsPtr Leaderboards(const UObject* WorldContextObject);
	UECPSTEAMRUNTIME_API IOnlineUserCloudPtr   UserCloud(const UObject* WorldContextObject);
	UECPSTEAMRUNTIME_API IOnlineSharedCloudPtr SharedCloud(const UObject* WorldContextObject);
	UECPSTEAMRUNTIME_API IOnlinePresencePtr    Presence(const UObject* WorldContextObject);
	UECPSTEAMRUNTIME_API IOnlineExternalUIPtr  ExternalUI(const UObject* WorldContextObject);
	UECPSTEAMRUNTIME_API IOnlineVoicePtr       Voice(const UObject* WorldContextObject);

	UECPSTEAMRUNTIME_API FUniqueNetIdPtr LocalUserId(const UObject* WorldContextObject, int32 LocalUserNum = 0);

	UECPSTEAMRUNTIME_API FUECPSteamError InterfaceUnavailable(const TCHAR* InterfaceName);

	UECPSTEAMRUNTIME_API FUECPSteamError NoLocalUser();

	UECPSTEAMRUNTIME_API FUECPSteamID ToSteamID(const FUniqueNetId& NetId);
	UECPSTEAMRUNTIME_API FUECPSteamID ToSteamID(const FUniqueNetIdPtr& NetId);
}
