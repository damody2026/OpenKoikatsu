// Copyright 2026, BlueprintsLab, All rights reserved
#include "UECPSteamSubsystem.h"

#include "Engine/Engine.h"
#include "Engine/GameInstance.h"
#include "UECPSteamAPI.h"
#include "UECPSteamImage.h"
#include "UECPSteamSettings.h"

#if UECP_WITH_STEAM
class FUECPSteamCallbackBridge
{
public:
	explicit FUECPSteamCallbackBridge(UUECPSteamSubsystem* InOwner)
		: Owner(InOwner)
	{
	}

private:
	TWeakObjectPtr<UUECPSteamSubsystem> Owner;

	void Forward(TFunction<void(UUECPSteamSubsystem&)> Work)
	{
		TWeakObjectPtr<UUECPSteamSubsystem> WeakOwner = Owner;
		UECPSteam::RunOnGameThread([WeakOwner, Work = MoveTemp(Work)]()
		{
			if (UUECPSteamSubsystem* Subsystem = WeakOwner.Get())
			{
				Work(*Subsystem);
			}
		});
	}

	STEAM_CALLBACK(FUECPSteamCallbackBridge, OnGameOverlayActivated, GameOverlayActivated_t);
	STEAM_CALLBACK(FUECPSteamCallbackBridge, OnSteamServersConnected, SteamServersConnected_t);
	STEAM_CALLBACK(FUECPSteamCallbackBridge, OnSteamServersDisconnected, SteamServersDisconnected_t);
	STEAM_CALLBACK(FUECPSteamCallbackBridge, OnSteamShutdown, SteamShutdown_t);
	STEAM_CALLBACK(FUECPSteamCallbackBridge, OnAvatarImageLoaded, AvatarImageLoaded_t);
	STEAM_CALLBACK(FUECPSteamCallbackBridge, OnPersonaStateChange, PersonaStateChange_t);
	STEAM_CALLBACK(FUECPSteamCallbackBridge, OnP2PSessionRequest,
		SteamNetworkingMessagesSessionRequest_t);
};

void FUECPSteamCallbackBridge::OnGameOverlayActivated(GameOverlayActivated_t* Param)
{
	const bool bActive = Param && Param->m_bActive != 0;
	Forward([bActive](UUECPSteamSubsystem& S) { S.HandleOverlayActivated(bActive); });
}

void FUECPSteamCallbackBridge::OnSteamServersConnected(SteamServersConnected_t* )
{
	Forward([](UUECPSteamSubsystem& S) { S.HandleSteamServersConnected(); });
}

void FUECPSteamCallbackBridge::OnSteamServersDisconnected(SteamServersDisconnected_t* Param)
{
	const int32 RawResult = Param ? static_cast<int32>(Param->m_eResult) : 0;
	Forward([RawResult](UUECPSteamSubsystem& S) { S.HandleSteamServersDisconnected(RawResult); });
}

void FUECPSteamCallbackBridge::OnSteamShutdown(SteamShutdown_t* )
{
	Forward([](UUECPSteamSubsystem& S) { S.HandleSteamShutdown(); });
}

void FUECPSteamCallbackBridge::OnAvatarImageLoaded(AvatarImageLoaded_t* Param)
{
	if (!Param)
	{
		return;
	}
	const int64 Raw = UECPSteam::FromSteamID(Param->m_steamID);
	Forward([Raw](UUECPSteamSubsystem& S) { S.HandleAvatarLoaded(Raw); });
}

void FUECPSteamCallbackBridge::OnPersonaStateChange(PersonaStateChange_t* Param)
{
	if (!Param)
	{
		return;
	}
	const int64 Raw = static_cast<int64>(Param->m_ulSteamID);
	Forward([Raw](UUECPSteamSubsystem& S) { S.HandlePersonaStateChanged(Raw); });
}

void FUECPSteamCallbackBridge::OnP2PSessionRequest(SteamNetworkingMessagesSessionRequest_t* Param)
{
	if (!Param)
	{
		return;
	}
	const int64 Raw = UECPSteam::FromSteamID(Param->m_identityRemote.GetSteamID());
	Forward([Raw](UUECPSteamSubsystem& S) { S.HandleP2PSessionRequest(Raw); });
}

#else

class FUECPSteamCallbackBridge
{
public:
	explicit FUECPSteamCallbackBridge(UUECPSteamSubsystem*) {}
};

#endif

UUECPSteamSubsystem::UUECPSteamSubsystem() = default;

UUECPSteamSubsystem::UUECPSteamSubsystem(FVTableHelper& Helper) : Super(Helper) {}

UUECPSteamSubsystem::~UUECPSteamSubsystem() = default;

void UUECPSteamSubsystem::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);

	const UUECPSteamSettings* Settings = UUECPSteamSettings::Get();
	if (Settings && Settings->bAutoAcquireOnGameInstanceStart)
	{
		AcquireSteam();
	}

}

void UUECPSteamSubsystem::Deinitialize()
{
	CallbackBridge.Reset();
	UECPSteam::FlushImageCache();
	UECPSteam::ReleaseClient();

	Super::Deinitialize();
}

UUECPSteamSubsystem* UUECPSteamSubsystem::Get(const UObject* WorldContextObject)
{
	if (!WorldContextObject)
	{
		return nullptr;
	}
	const UWorld* World = GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::ReturnNull);
	if (!World)
	{
		return nullptr;
	}
	UGameInstance* GameInstance = World->GetGameInstance();
	return GameInstance ? GameInstance->GetSubsystem<UUECPSteamSubsystem>() : nullptr;
}

bool UUECPSteamSubsystem::AcquireSteam()
{
	if (!UECPSteam::AcquireClient())
	{
		return false;
	}
	if (!CallbackBridge.IsValid())
	{
		CallbackBridge = MakeUnique<FUECPSteamCallbackBridge>(this);
	}
	return true;
}

bool UUECPSteamSubsystem::IsSteamAvailable() const
{
	return UECPSteam::IsClientAvailable();
}

bool UUECPSteamSubsystem::IsSteamCompiledIn() const
{
	return FUECPSteamRuntimeModule::IsCompiledWithSteam();
}

bool UUECPSteamSubsystem::IsOnlineSubsystemSteamActive() const
{
	return UECPSteam::IsOssSteamActive();
}

int32 UUECPSteamSubsystem::GetAppId() const
{
#if UECP_WITH_STEAM
	if (ISteamUtils* U = UECPSteam::Utils()) { return static_cast<int32>(U->GetAppID()); }
#endif
	return 0;
}

FUECPSteamID UUECPSteamSubsystem::GetLocalSteamID() const
{
#if UECP_WITH_STEAM
	if (ISteamUser* U = UECPSteam::User()) { return FUECPSteamID(UECPSteam::FromSteamID(U->GetSteamID())); }
#endif
	return FUECPSteamID();
}

FString UUECPSteamSubsystem::GetLocalPersonaName() const
{
#if UECP_WITH_STEAM
	if (ISteamFriends* F = UECPSteam::Friends()) { return UTF8_TO_TCHAR(F->GetPersonaName()); }
#endif
	return FString();
}

bool UUECPSteamSubsystem::IsRunningOnSteamDeck() const
{
#if UECP_WITH_STEAM
	if (ISteamUtils* U = UECPSteam::Utils()) { return U->IsSteamRunningOnSteamDeck(); }
#endif
	return false;
}

bool UUECPSteamSubsystem::IsOverlayActive() const
{
	return bOverlayActive;
}

void UUECPSteamSubsystem::HandleOverlayActivated(bool bActive)
{
	bOverlayActive = bActive;
	OnOverlayActivated.Broadcast(bActive);
}

void UUECPSteamSubsystem::HandleSteamServersConnected()
{
	UE_LOG(LogUECPSteam, Log, TEXT("Connected to the Steam backend."));
	OnSteamServersConnected.Broadcast();
}

void UUECPSteamSubsystem::HandleSteamServersDisconnected(int32 RawResult)
{
	const FUECPSteamError Error = UECPSteam::MakeError(RawResult, TEXT("Lost the connection to the Steam backend"));
	UE_LOG(LogUECPSteam, Warning, TEXT("%s"), *Error.Message);
	OnSteamServersDisconnected.Broadcast(Error);
}

void UUECPSteamSubsystem::HandleSteamShutdown()
{
	UE_LOG(LogUECPSteam, Warning, TEXT("The Steam client is shutting down; Steam features will stop responding."));
	OnSteamShutdown.Broadcast();
}

void UUECPSteamSubsystem::HandleAvatarLoaded(int64 RawSteamId)
{
	OnAvatarLoaded.Broadcast(FUECPSteamID(RawSteamId));
}

void UUECPSteamSubsystem::HandlePersonaStateChanged(int64 RawSteamId)
{
	OnPersonaStateChanged.Broadcast(FUECPSteamID(RawSteamId));
}

void UUECPSteamSubsystem::HandleP2PSessionRequest(int64 RawSteamId)
{
	OnP2PSessionRequest.Broadcast(FUECPSteamID(RawSteamId));
}

void UUECPSteamSubsystem::HandleP2PMessage(int64 RawSenderId, const TArray<uint8>& Data, int32 Channel)
{
	OnP2PMessage.Broadcast(FUECPSteamID(RawSenderId), Data, Channel);
}
