(function () {
  if (!document.getElementById('uecp-task-bar-css')) {
    const s = document.createElement('style'); s.id = 'uecp-task-bar-css';
    s.textContent = `
uecp-task-bar{display:none;flex-direction:column;border-bottom:1px solid var(--ue-line-soft);padding-bottom:8px;margin-bottom:10px}
uecp-task-bar .tb-header{display:flex;align-items:center;gap:8px;cursor:pointer;user-select:none}
uecp-task-bar .tb-title{font-family:var(--ue-font-mono);font-size:11px;font-weight:var(--ue-fw-semi);letter-spacing:.06em;color:var(--ue-text-mid);text-transform:uppercase}
uecp-task-bar .tb-badge{font-family:var(--ue-font-mono);font-size:10px;padding:1px 6px;border-radius:8px;background:var(--ue-accent);color:#fff}
uecp-task-bar .tb-spacer{flex:1}
uecp-task-bar .tb-clear{font-family:var(--ue-font-mono);font-size:10px;padding:3px 7px;border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);background:none;color:var(--ue-text-mid);cursor:pointer}
uecp-task-bar .tb-clear:hover{border-color:var(--ue-accent);color:var(--ue-accent-bright)}
uecp-task-bar .tb-chev{stroke:var(--ue-text-lo);flex-shrink:0}
uecp-task-bar.collapsed .tb-chev{transform:rotate(-90deg)}
uecp-task-bar.collapsed .tb-body{display:none}
/* Capped and scrolling: the composer never shrinks, so an uncapped list (a GDD plan
   runs to 40 tasks) pushed the text box itself off the bottom of the panel. */
uecp-task-bar .tb-body{padding-top:8px;padding-right:4px;max-height:220px;max-height:min(220px,30vh);overflow-y:auto}
uecp-task-bar .tb-row{display:flex;align-items:center;gap:8px;padding:4px 0}
uecp-task-bar .tb-dot{width:8px;height:8px;border-radius:50%;border:1.5px solid var(--ue-line);flex-shrink:0;background:none}
uecp-task-bar .tb-dot.done{background:var(--ue-accent);border-color:var(--ue-accent)}
uecp-task-bar .tb-dot.in_progress{border-color:var(--ue-warn,#e5a000)}
uecp-task-bar .tb-dot.failed{border-color:var(--ue-error,#cf6b5a)}
uecp-task-bar .tb-content{flex:1;font-size:12px;color:var(--ue-text-hi);min-width:0;white-space:pre-wrap;word-break:break-word}
uecp-task-bar .tb-content.done-text{color:var(--ue-text-lo);text-decoration:line-through}
uecp-task-bar .tb-group-header{font-family:var(--ue-font-mono);font-size:10px;font-weight:var(--ue-fw-semi);letter-spacing:.05em;color:var(--ue-text-lo);text-transform:uppercase;padding:6px 0 2px}
uecp-task-bar .tb-group-header:first-child{padding-top:0}`;
    document.head.appendChild(s);
  }

  class UecpTaskBar extends HTMLElement {
    connectedCallback() {
      this.style.display = 'none';
      this._tasks = [];
      this._build();

      const self = this;
      this._u1 = window.uecp.on('tasks.state', function (d) {
        self._tasks = (d && d.tasks) ? d.tasks : [];
        self._render();
      });
    }

    disconnectedCallback() {
      if (this._u1) { this._u1(); this._u1 = null; }
    }

    collapse() { this.classList.add('collapsed'); }
    expand()   { this.classList.remove('collapsed'); }
    toggle()   { this.classList.toggle('collapsed'); }

    _build() {
      this.innerHTML =
        '<div class="tb-header">' +
          '<svg class="tb-chev" width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>' +
          '<span class="tb-title">Tasks</span>' +
          '<span class="tb-badge">0</span>' +
          '<span class="tb-spacer"></span>' +
          '<button class="tb-clear" type="button">Clear</button>' +
        '</div>' +
        '<div class="tb-body"></div>';

      const self = this;
      this.querySelector('.tb-header').addEventListener('click', function () {
        self.toggle();
      });
      this.querySelector('.tb-clear').addEventListener('click', function (e) {
        e.stopPropagation();
        window.uecp.call('clear_tasks', {});
      });
    }

    _render() {
      const tasks = this._tasks;
      if (!tasks.length) { this.style.display = 'none'; return; }
      this.style.display = 'flex';

      const E = window.UECP.escapeHtml;
      const badge = this.querySelector('.tb-badge');
      if (badge) badge.textContent = String(tasks.length);

      const body = this.querySelector('.tb-body');
      if (!body) return;

      const order = [];
      const buckets = Object.create(null);
      tasks.forEach(function (task) {
        const group = task.group || '';
        if (!Object.prototype.hasOwnProperty.call(buckets, group)) {
          buckets[group] = [];
          order.push(group);
        }
        buckets[group].push(task);
      });
      const grouped = [];
      order.forEach(function (group) { buckets[group].forEach(function (t) { grouped.push(t); }); });

      const active = grouped.find(function (t) { return t.status === 'in_progress'; });

      let lastGroup = undefined;
      body.innerHTML = grouped.map(function (task) {
        const st = task.status || 'pending';
        const isDone = st === 'done';
        const group = task.group || '';
        let header = '';
        if (group !== lastGroup) {
          lastGroup = group;
          if (group) header = '<div class="tb-group-header">' + E(group) + '</div>';
        }
        const titleAttr = task.criteria ? (' title="' + E(task.criteria) + '"') : '';
        return header + '<div class="tb-row"' + titleAttr + (task === active ? ' data-active="1"' : '') + '>' +
          '<span class="tb-dot ' + E(st) + '"></span>' +
          '<span class="tb-content' + (isDone ? ' done-text' : '') + '">' + E(task.content || '') + '</span>' +
        '</div>';
      }).join('');

      this._followActive(body, active);
    }

    _followActive(body, active) {
      const key = active ? String(active.index) + '\u0001' + (active.content || '') : '';
      if (key === this._activeKey) return;
      this._activeKey = key;
      if (!key) return;
      const row = body.querySelector('.tb-row[data-active]');
      if (!row || body.scrollHeight <= body.clientHeight) return;
      const top = row.getBoundingClientRect().top - body.getBoundingClientRect().top + body.scrollTop;
      body.scrollTop = Math.max(0, top - body.clientHeight / 3);
    }
  }

  customElements.define('uecp-task-bar', UecpTaskBar);
})();
