(function () {
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  if (!document.getElementById('uecp-bugreport-overlay-css')) {
    var s = document.createElement('style'); s.id = 'uecp-bugreport-overlay-css';
    s.textContent = [
'uecp-bugreport-overlay{position:fixed;inset:0;z-index:1200;display:none}',
'uecp-bugreport-overlay.open{display:block}',
'uecp-bugreport-overlay .overlay{position:absolute;inset:0;display:flex;align-items:center;justify-content:center}',
'uecp-bugreport-overlay .modal{width:520px;max-height:calc(100% - 24px);display:flex;flex-direction:column;overflow:hidden}',
'uecp-bugreport-overlay .br-body{padding:16px 20px;overflow-y:auto;display:flex;flex-direction:column;gap:12px}',
'uecp-bugreport-overlay .br-label{font-size:11px;color:var(--ue-text-mid);display:block;margin-bottom:4px}',
'uecp-bugreport-overlay select,uecp-bugreport-overlay textarea{width:100%;box-sizing:border-box;background:var(--ue-bg);border:1px solid var(--ue-line);color:var(--ue-text-hi);padding:6px 8px;border-radius:var(--ue-r-sm);font-size:12.5px;font-family:inherit}',
'uecp-bugreport-overlay textarea{resize:vertical;min-height:90px}',
'uecp-bugreport-overlay .br-attach{display:flex;gap:6px;flex-wrap:wrap;align-items:center}',
'uecp-bugreport-overlay .br-tbtn{background:var(--ue-elev);border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);color:var(--ue-text-hi);padding:4px 9px;cursor:pointer;font-size:11.5px}',
'uecp-bugreport-overlay .br-tbtn:hover{background:var(--ue-line-soft)}',
'uecp-bugreport-overlay .br-images{display:flex;flex-wrap:wrap;gap:6px}',
'uecp-bugreport-overlay .br-thumb{width:48px;height:48px;object-fit:cover;border:1px solid var(--ue-line);border-radius:var(--ue-r-sm)}',
'uecp-bugreport-overlay .br-foot{padding:12px 20px;border-top:1px solid var(--ue-line-soft);display:flex;justify-content:flex-end;gap:8px}'
    ].join('\n');
    document.head.appendChild(s);
  }

  class UecpBugReportOverlay extends HTMLElement {
    connectedCallback() {
      this._build();
      var self = this;
      this._subs = [ window.uecp.on('bugreport.images', function (d) { self._onImages(d); }) ];
    }
    disconnectedCallback() { (this._subs || []).forEach(function (u) { u(); }); this._subs = []; }

    open() { this.classList.add('open'); }
    close() { this.classList.remove('open'); }
    isOpen() { return this.classList.contains('open'); }

    _build() {
      var self = this;
      this.innerHTML = '';
      this._overlayEl = document.createElement('div');
      this._overlayEl.className = 'overlay open';
      window.UECP.dom.bindBackdropClose(this._overlayEl, function () { self.close(); });
      this.appendChild(this._overlayEl);

      this._box = document.createElement('div');
      this._box.className = 'modal';
      this._box.innerHTML =
        '<div class="modal-head">' +
          '<span class="tile" style="width:26px;height:26px"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m8 2 1.88 1.88M14.12 3.88 16 2M9 7.13v-1a3.003 3.003 0 1 1 6 0v1M12 20c-3.3 0-6-2.7-6-6v-3a4 4 0 0 1 4-4h4a4 4 0 0 1 4 4v3c0 3.3-2.7 6-6 6"/></svg></span>' +
          '<div style="flex:1">' +
            '<div class="modal-title">Report a Bug</div>' +
            '<div class="modal-sub">Send a bug, feedback, or feature request</div>' +
          '</div>' +
          '<button class="icon-btn" data-act="close" title="Close" aria-label="Close"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18M6 6l12 12"/></svg></button>' +
        '</div>' +
        '<div class="br-body">' +
          '<div><label class="br-label">Issue Type</label>' +
            '<select id="br-type"><option value="bug">Bug / Crash</option><option value="feedback">General Feedback</option><option value="feature_request">Feature Request</option></select></div>' +
          '<div><label class="br-label">Attach Conversation</label>' +
            '<select id="br-conv"><option value="">None (no conversation attached)</option></select></div>' +
          '<div><label class="br-label">Description</label>' +
            '<textarea id="br-desc" placeholder="Describe what happened…"></textarea></div>' +
          '<div class="br-attach">' +
            '<button class="br-tbtn" data-act="attach">Attach image</button>' +
            '<button class="br-tbtn" data-act="paste">Paste image</button>' +
            '<button class="br-tbtn" data-act="clear" style="color:var(--ue-error,#cf6b5a)">Clear</button>' +
          '</div>' +
          '<div class="br-images" data-images></div>' +
        '</div>' +
        '<div class="br-foot">' +
          '<button class="br-tbtn" data-act="cancel">Cancel</button>' +
          '<button class="btn-accent" data-act="submit">Submit Report</button>' +
        '</div>';
      this._overlayEl.appendChild(this._box);

      var convSel = this._box.querySelector('#br-conv');
      this._uChatList = window.uecp.on('chat.list', function (list) {
        if (!convSel || !Array.isArray(list)) return;
        var keep = convSel.value;
        convSel.innerHTML = '<option value="">None (no conversation attached)</option>' +
          list.map(function (c) { return '<option value="' + esc(c.id) + '">' + esc(c.title || 'Untitled') + '</option>'; }).join('');
        convSel.value = keep;
      });

      this._box.querySelector('[data-act="close"]').addEventListener('click', function () { self.close(); });
      this._box.querySelector('[data-act="cancel"]').addEventListener('click', function () { self.close(); });
      this._box.querySelector('[data-act="attach"]').addEventListener('click', function () { window.uecp.call('attach_bug_image', {}); });
      this._box.querySelector('[data-act="paste"]').addEventListener('click', function () { window.uecp.call('paste_bug_image', {}); });
      this._box.querySelector('[data-act="clear"]').addEventListener('click', function () { window.uecp.call('clear_bug_images', {}); });
      this._box.querySelector('[data-act="submit"]').addEventListener('click', function () {
        var desc = (self._box.querySelector('#br-desc').value || '').trim();
        if (!desc) { if (window.UECP && window.UECP.toast) window.UECP.toast('Please describe the issue first.', 'error'); return; }
        window.uecp.call('submit_bug_report', {
          type: self._box.querySelector('#br-type').value,
          description: desc,
          conversation_id: self._box.querySelector('#br-conv').value
        });
        self.close();
        self._box.querySelector('#br-desc').value = '';
      });
    }

    _onImages(d) {
      var box = this._box && this._box.querySelector('[data-images]');
      if (!box) return;
      var imgs = (d && Array.isArray(d.images)) ? d.images : [];
      box.innerHTML = imgs.map(function (im) {
        var src = im && (im.dataUrl || (im.mime && im.base64 ? ('data:' + im.mime + ';base64,' + im.base64) : ''));
        return src ? '<img class="br-thumb" src="' + esc(src) + '" alt="attachment">' :
          '<span class="br-tbtn">' + esc((im && im.name) || 'image') + '</span>';
      }).join('');
    }
  }

  customElements.define('uecp-bugreport-overlay', UecpBugReportOverlay);

  window.UECP = window.UECP || {};
  window.UECP.openBugReport = function () {
    var ov = document.querySelector('uecp-bugreport-overlay');
    if (!ov) { ov = document.createElement('uecp-bugreport-overlay'); document.body.appendChild(ov); }
    ov.open();
    return ov;
  };
})();
