(function () {
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  var t = function (key, vars) {
    if (window.uecp && typeof window.uecp.t === 'function') return window.uecp.t(key, vars);
    var out = String(key);
    if (vars) Object.keys(vars).forEach(function (k) {
      out = out.replace(new RegExp('\\{' + k + '\\}', 'g'), String(vars[k]));
    });
    return out;
  };

  var ALLOWED_TAGS = [
    'b', 'strong', 'i', 'em', 'u', 'br', 'p',
    'ul', 'ol', 'li', 'code', 'pre', 'h3', 'h4', 'small', 'hr'
  ].join('|');
  var ATTR_TAIL = '(?:\\s+[a-zA-Z][\\w:-]*(?:=(?:&quot;[^&]*&quot;|&#39;[^&]*&#39;|[^\\s&>]*))?)*';
  var TAG_RE = new RegExp('&lt;(\\/?)(' + ALLOWED_TAGS + ')' + ATTR_TAIL + '\\s*\\/?&gt;', 'gi');
  var LINK_RE = /&lt;a\s+href=&quot;(https?:\/\/[^&"'\s<>]+)&quot;\s*&gt;([\s\S]*?)&lt;\/a&gt;/gi;

  var COLOURS = ['accent', 'warn', 'danger', 'muted'];
  var COLOUR_RE = new RegExp('\\{(' + COLOURS.join('|') + ')\\}([\\s\\S]*?)\\{\\/\\1\\}', 'g');

  function sanitizeHtml(raw) {
    var s = esc(raw);
    if (!s) return '';
    s = s.replace(LINK_RE, function (m, url, text) {
      return '<a data-href="' + esc(url) + '">' + text + '</a>';
    });
    s = s.replace(TAG_RE, function (m, close, tag) {
      return '<' + close + tag.toLowerCase() + '>';
    });
    return s.replace(COLOUR_RE, function (m, name, text) {
      return '<span class="c-' + name + '">' + text + '</span>';
    });
  }

  function fmtDate(iso) {
    if (!iso) return '';
    try {
      var parts = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(iso));
      var d = parts
        ? new Date(Number(parts[1]), Number(parts[2]) - 1, Number(parts[3]))
        : new Date(String(iso));
      if (isNaN(d.getTime())) return String(iso);
      var lang = (window.uecp && window.uecp.getLang && window.uecp.getLang()) || 'en';
      return d.toLocaleDateString(lang, { year: 'numeric', month: 'long', day: 'numeric' });
    } catch (e) { return String(iso); }
  }

  if (!document.getElementById('uecp-whatsnew-overlay-css')) {
    var s = document.createElement('style'); s.id = 'uecp-whatsnew-overlay-css';
    s.textContent = [
'uecp-whatsnew-overlay{position:fixed;inset:0;z-index:1200;display:none}',
'uecp-whatsnew-overlay.open{display:block}',
'uecp-whatsnew-overlay .overlay{position:absolute;inset:0;background:rgba(0,0,0,.5);display:flex;align-items:center;justify-content:center}',
'uecp-whatsnew-overlay .modal{width:620px;max-width:calc(100% - 24px);height:680px;max-height:calc(100% - 24px);display:flex;flex-direction:column;overflow:hidden;background:var(--ue-panel);border:1px solid var(--ue-line);border-radius:var(--ue-r-lg)}',
'uecp-whatsnew-overlay .wn-body{flex:1;min-height:0;overflow-y:auto;padding:0 20px}',
'uecp-whatsnew-overlay .wn-empty{padding:40px 8px;text-align:center;color:var(--ue-text-mid);font-size:12.5px}',
'uecp-whatsnew-overlay .wn-entry{padding:20px 0;border-bottom:1px solid var(--ue-line-soft)}',
'uecp-whatsnew-overlay .wn-entry:last-child{border-bottom:none}',
'uecp-whatsnew-overlay .wn-meta{display:flex;align-items:baseline;justify-content:space-between;gap:10px;font-size:11.5px;color:var(--ue-text-mid)}',
'uecp-whatsnew-overlay .wn-title{font-size:19px;font-weight:var(--ue-fw-semi);color:var(--ue-text-hi);margin:6px 0 8px}',
'uecp-whatsnew-overlay .wn-new{display:inline-block;margin-left:8px;padding:1px 6px;border-radius:999px;background:var(--ue-accent-soft);color:var(--ue-accent-bright);font-size:10px;font-weight:var(--ue-fw-semi);vertical-align:middle}',
'uecp-whatsnew-overlay .wn-text{font-size:13px;line-height:1.6;color:var(--ue-text-mid)}',
'uecp-whatsnew-overlay .wn-text p{margin:0 0 8px}',
'uecp-whatsnew-overlay .wn-text a{color:var(--ue-accent-bright);text-decoration:underline;cursor:pointer}',
'uecp-whatsnew-overlay .wn-text code{font-family:var(--ue-font-mono);background:var(--ue-elev);padding:0 4px;border-radius:3px}',
'uecp-whatsnew-overlay .wn-text .c-accent{color:var(--ue-accent-bright)}',
'uecp-whatsnew-overlay .wn-text .c-warn{color:var(--ue-warn)}',
'uecp-whatsnew-overlay .wn-text .c-danger{color:var(--ue-danger)}',
'uecp-whatsnew-overlay .wn-text .c-muted{color:var(--ue-text-lo)}',
'uecp-whatsnew-overlay .wn-media{margin:14px 0 0;border-radius:var(--ue-r-lg);overflow:hidden;background:var(--ue-bg);border:1px solid var(--ue-line)}',
'uecp-whatsnew-overlay .wn-media img,uecp-whatsnew-overlay .wn-media video{display:block;width:100%;height:auto;max-height:340px;object-fit:contain;background:var(--ue-bg)}',
'uecp-whatsnew-overlay .wn-actions{display:flex;align-items:center;gap:8px;margin-top:14px;flex-wrap:wrap}',
'uecp-whatsnew-overlay .wn-actions .spacer{flex:1}',
'uecp-whatsnew-overlay .wn-react{display:inline-flex;align-items:center;gap:6px;background:var(--ue-elev);border:1px solid var(--ue-line);border-radius:999px;padding:4px 11px;cursor:pointer;color:var(--ue-text-mid);font:inherit;font-size:12.5px}',
'uecp-whatsnew-overlay .wn-react:hover{border-color:var(--ue-accent)}',
'uecp-whatsnew-overlay .wn-react.on{background:var(--ue-accent-soft);border-color:var(--ue-accent);color:var(--ue-accent-bright)}',
'uecp-whatsnew-overlay .wn-react .wn-emoji{font-size:14px;line-height:1}',
'uecp-whatsnew-overlay .wn-react .wn-count{font-variant-numeric:tabular-nums}',
'uecp-whatsnew-overlay .wn-foot{padding:12px 20px;border-top:1px solid var(--ue-line-soft);display:flex;align-items:center;justify-content:center}',
'uecp-whatsnew-overlay .wn-foot[hidden]{display:none}'
    ].join('\n');
    document.head.appendChild(s);
  }

  class UecpWhatsNewOverlay extends HTMLElement {
    connectedCallback() {
      this._entries = [];
      this._lastSeen = '';
      this._subs = [];
      this._build();
      var self = this;
      this._subs.push(window.uecp.on('whatsnew.feed', function (d) { self._onFeed(d); }));
    }
    disconnectedCallback() {
      (this._subs || []).forEach(function (u) { u(); });
      this._subs = [];
      this._unbindKey();
    }

    open() {
      this.classList.add('open');
      this._bindKey();
      window.uecp.call('request_whatsnew', {});
      this._markSeen();
    }
    close() { this.classList.remove('open'); this._unbindKey(); }
    isOpen() { return this.classList.contains('open'); }

    _bindKey() {
      this._unbindKey();
      var self = this;
      this._keyHandler = function (e) { if (e.key === 'Escape') self.close(); };
      document.addEventListener('keydown', this._keyHandler);
    }
    _unbindKey() {
      if (this._keyHandler) { document.removeEventListener('keydown', this._keyHandler); this._keyHandler = null; }
    }

    _sanitize(raw) { return sanitizeHtml(raw); }

    _reactedKey(entryId, emoji) { return 'uecp.wn.react.' + entryId + '.' + emoji; }
    _hasReacted(entryId, emoji) {
      try { return localStorage.getItem(this._reactedKey(entryId, emoji)) === '1'; } catch (e) { return false; }
    }
    _setReacted(entryId, emoji, on) {
      try {
        if (on) localStorage.setItem(this._reactedKey(entryId, emoji), '1');
        else localStorage.removeItem(this._reactedKey(entryId, emoji));
      } catch (e) {  }
    }

    _toggleReaction(btn) {
      var entryId = btn.getAttribute('data-react');
      var emoji = btn.getAttribute('data-emoji');
      if (!entryId || !emoji) return;
      var on = !this._hasReacted(entryId, emoji);
      this._setReacted(entryId, emoji, on);

      var countEl = btn.querySelector('.wn-count');
      if (countEl) {
        var n = Number(countEl.textContent) || 0;
        n = Math.max(0, n + (on ? 1 : -1));
        countEl.textContent = n ? String(n) : '';
      }
      btn.classList.toggle('on', on);
      window.uecp.call('react_whatsnew', { entry_id: entryId, emoji: emoji, on: on });
    }

    _onFeed(d) {
      this._entries = (d && Array.isArray(d.entries)) ? d.entries : [];
      this._lastSeen = (d && typeof d.last_seen === 'string') ? d.last_seen : '';
      this._render();
      if (this.isOpen()) this._markSeen();
    }

    _markSeen() {
      var newest = this._entries.length ? this._entries[0].entry_id : '';
      if (!newest || newest === this._lastSeen) return;
      this._lastSeen = newest;
      window.uecp.call('mark_whatsnew_seen', { entry_id: newest });
      if (window.uecp && window.uecp.__emit) window.uecp.__emit('whatsnew.seen', { entry_id: newest });
    }

    _render() {
      var body = this.querySelector('.wn-body');
      if (!body) return;
      if (!this._entries.length) {
        body.innerHTML = '<div class="wn-empty">' + esc(t('Nothing new right now.')) + '</div>';
        return;
      }

      var seenAt = this._seenIndex();
      var html = '';
      for (var i = 0; i < this._entries.length; i++) {
        html += this._entryHtml(this._entries[i], i < seenAt);
      }
      body.innerHTML = html;
      body.scrollTop = 0;
      this._bindMedia(body);
    }

    _seenIndex() {
      if (!this._lastSeen) return 0;
      for (var i = 0; i < this._entries.length; i++) {
        if (this._entries[i].entry_id === this._lastSeen) return i;
      }
      return 0;
    }

    _entryHtml(e, isNew) {
      var head = '';
      if (e.version_label || e.released_at) {
        head = '<div class="wn-meta"><span>' + esc(e.version_label || '') + '</span>' +
               '<span>' + esc(fmtDate(e.released_at)) + '</span></div>';
      }

      var title = e.title
        ? '<div class="wn-title">' + esc(e.title) +
          (isNew ? '<span class="wn-new">' + esc(t('New')) + '</span>' : '') + '</div>'
        : '';

      var text = e.body_html ? '<div class="wn-text">' + sanitizeHtml(e.body_html) + '</div>' : '';

      var media = '';
      if (e.media_url && e.media_type === 'video') {
        media = '<div class="wn-media"><video controls autoplay muted loop preload="metadata" playsinline' +
          (e.media_poster_url ? ' poster="' + esc(e.media_poster_url) + '"' : '') +
          ' data-poster="' + esc(e.media_poster_url || '') + '">' +
          '<source src="' + esc(e.media_url) + '"></video></div>';
      } else if (e.media_url) {
        media = '<div class="wn-media"><img alt="" src="' + esc(e.media_url) + '"></div>';
      }

      var pills = '';
      var offered = Array.isArray(e.reactions) ? e.reactions : [];
      var counts = e.reaction_counts || {};
      for (var r = 0; r < offered.length; r++) {
        var emoji = offered[r];
        var n = Number(counts[emoji]) || 0;
        var mine = this._hasReacted(e.entry_id, emoji);
        pills += '<button class="wn-react' + (mine ? ' on' : '') + '"' +
                 ' data-react="' + esc(e.entry_id) + '" data-emoji="' + esc(emoji) + '">' +
                 '<span class="wn-emoji">' + esc(emoji) + '</span>' +
                 '<span class="wn-count">' + (n ? String(n) : '') + '</span></button>';
      }

      var buttons = '';
      var ctas = Array.isArray(e.cta_buttons) ? e.cta_buttons : [];
      for (var i = 0; i < ctas.length; i++) {
        var b = ctas[i];
        if (!b || !b.url || !/^https?:\/\//i.test(b.url)) continue;
        var cls = 'ue-btn' + (b.style === 'primary' || b.style === 'cyan' ? ' accent' : '');
        buttons += '<button class="' + cls + '" data-href="' + esc(b.url) + '">' + esc(b.label || '') + '</button>';
      }
      var actions = (pills || buttons)
        ? '<div class="wn-actions">' + pills + '<span class="spacer"></span>' + buttons + '</div>'
        : '';

      return '<div class="wn-entry">' + head + title + text + media + actions + '</div>';
    }

    _bindMedia(root) {
      var vids = root.querySelectorAll('video');
      for (var i = 0; i < vids.length; i++) {
        (function (v) {
          var fail = function () {
            if (!v.parentNode) return;
            var poster = v.getAttribute('data-poster');
            if (!poster) {
              var box = v.parentNode;
              if (box.parentNode) box.parentNode.removeChild(box);
              return;
            }
            var img = document.createElement('img');
            img.alt = '';
            img.src = poster;
            v.parentNode.replaceChild(img, v);
          };
          v.addEventListener('error', fail, true);
          var src = v.querySelector('source');
          if (src) src.addEventListener('error', fail);
        })(vids[i]);
      }
    }

    _build() {
      var self = this;
      this.innerHTML = '';
      var overlay = document.createElement('div');
      overlay.className = 'overlay';
      window.UECP.dom.bindBackdropClose(overlay, function () { self.close(); });
      this.appendChild(overlay);

      var box = document.createElement('div');
      box.className = 'modal';
      box.innerHTML =
        '<div class="modal-head">' +
          '<div style="flex:1">' +
            '<div class="modal-title">What\'s New</div>' +
            '<div class="modal-sub">Everything added since you last looked</div>' +
          '</div>' +
          '<button class="icon-btn" data-act="close" title="Close" aria-label="Close"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18M6 6l12 12"/></svg></button>' +
        '</div>' +
        '<div class="wn-body"></div>' +
        '<div class="wn-foot" hidden><button class="ue-btn" data-act="suggest"></button></div>';
      overlay.appendChild(box);

      box.querySelector('[data-act="close"]').addEventListener('click', function () { self.close(); });

      box.addEventListener('click', function (ev) {
        var react = (ev.target && ev.target.closest) ? ev.target.closest('[data-react]') : null;
        if (react) { self._toggleReaction(react); return; }
        var el = (ev.target && ev.target.closest) ? ev.target.closest('[data-href]') : null;
        if (!el) return;
        if (ev.preventDefault) ev.preventDefault();
        var url = el.getAttribute('data-href');
        if (url && window.uecp && window.uecp.call) window.uecp.call('open_external_url', { url: url });
      });

      this._syncFooter();
      this._subs.push(window.uecp.on('config.ui', function () { self._syncFooter(); }));
    }

    _syncFooter() {
      var cfg = window._uiConfig || {};
      var foot = this.querySelector('.wn-foot');
      var btn = this.querySelector('[data-act="suggest"]');
      if (!foot || !btn) return;
      var url = cfg.whatsnew_footer_url;
      if (!url || !/^https?:\/\//i.test(url)) { foot.hidden = true; return; }
      btn.textContent = cfg.whatsnew_footer_label || t('Suggest new features');
      btn.setAttribute('data-href', url);
      foot.hidden = false;
    }
  }

  customElements.define('uecp-whatsnew-overlay', UecpWhatsNewOverlay);

  window.UECP = window.UECP || {};

  window.UECP.sanitizeNoticeHtml = sanitizeHtml;

  window.UECP.openWhatsNew = function () {
    var ov = document.querySelector('uecp-whatsnew-overlay');
    if (!ov) { ov = document.createElement('uecp-whatsnew-overlay'); document.body.appendChild(ov); }
    ov.open();
    return ov;
  };
})();
