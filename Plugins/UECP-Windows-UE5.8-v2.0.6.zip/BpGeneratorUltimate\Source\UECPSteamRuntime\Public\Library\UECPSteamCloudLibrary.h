// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "UECPSteamTypes.h"
#include "UECPSteamCloudLibrary.generated.h"

USTRUCT(BlueprintType)
struct UECPSTEAMRUNTIME_API FUECPSteamCloudFile
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	FString FileName;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	int32 SizeBytes = 0;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	FDateTime Timestamp;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	bool bPersisted = false;
};

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamCloudLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Cloud")
	static bool IsCloudEnabledForApp();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Cloud")
	static bool IsCloudEnabledForAccount();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Cloud")
	static TArray<FUECPSteamCloudFile> GetCloudFiles();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Cloud")
	static bool FileExists(const FString& FileName);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Cloud")
	static bool IsFilePersisted(const FString& FileName);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Cloud")
	static int32 GetFileSize(const FString& FileName);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Cloud")
	static bool WriteStringToCloud(const FString& FileName, const FString& Contents);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Cloud")
	static FString ReadStringFromCloud(const FString& FileName);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Cloud")
	static bool WriteBytesToCloud(const FString& FileName, const TArray<uint8>& Data);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Cloud")
	static TArray<uint8> ReadBytesFromCloud(const FString& FileName);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Cloud")
	static bool DeleteCloudFile(const FString& FileName);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Cloud")
	static bool ForgetCloudFile(const FString& FileName);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Cloud")
	static bool GetCloudQuota(int64& TotalBytes, int64& AvailableBytes);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Cloud")
	static bool ShareCloudFile(const FString& FileName);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Cloud", meta = (AdvancedDisplay = "Priority"))
	static bool DownloadSharedFile(int64 UgcHandle, int32 Priority = 0);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Cloud")
	static bool ReadSharedFile(int64 UgcHandle, TArray<uint8>& OutData);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Cloud")
	static bool GetSharedFileInfo(int64 UgcHandle, FString& FileName, int32& SizeBytes,
		FUECPSteamID& Owner);
};
