(function () {
  const t = function (key, vars) {
    if (window.uecp && typeof window.uecp.t === 'function') return window.uecp.t(key, vars);
    return String(key).replace(/\{(\w+)\}/g, function (m, k) {
      return vars && (k in vars) ? String(vars[k]) : m;
    });
  };

  const esc = function (s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  };

  const STATUS_TONE = {
    modified:   'var(--ue-warn)',
    added:      'var(--ue-success)',
    deleted:    'var(--ue-danger)',
    renamed:    'var(--ue-accent-bright)',
    conflicted: 'var(--ue-danger)',
    untracked:  'var(--ue-text-lo)',
  };

  let REQ = 0;

  if (!document.getElementById('uecp-scm-css')) {
    const s = document.createElement('style');
    s.id = 'uecp-scm-css';
    s.textContent = `
uecp-screen-sourcecontrol .scm-head{display:flex;align-items:center;gap:12px}
uecp-screen-sourcecontrol .scm-provider{display:flex;align-items:center;gap:9px;min-width:0}
uecp-screen-sourcecontrol .scm-name{font-size:14.5px;font-weight:var(--ue-fw-semi);color:var(--ue-text-hi)}
uecp-screen-sourcecontrol .scm-meta{display:flex;flex-wrap:wrap;gap:6px 16px;margin-top:10px}
uecp-screen-sourcecontrol .scm-meta div{display:flex;gap:6px;font-size:12px;min-width:0}
uecp-screen-sourcecontrol .scm-meta .k{font-family:var(--ue-font-mono);font-size:10px;letter-spacing:.06em;text-transform:uppercase;color:var(--ue-text-lo);padding-top:2px}
uecp-screen-sourcecontrol .scm-meta .v{color:var(--ue-text-mid);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:280px}
/* File rows: fixed-height, monospace path, status word right-aligned so the eye
   scans one column rather than ragged text. */
uecp-screen-sourcecontrol .f-row{display:flex;align-items:center;gap:10px;padding:7px 10px;border-radius:var(--ue-r-sm);cursor:pointer;transition:background var(--ue-dur)}
uecp-screen-sourcecontrol .f-row:hover{background:var(--ue-line-soft)}
uecp-screen-sourcecontrol .f-path{flex:1;font-family:var(--ue-font-mono);font-size:11.5px;color:var(--ue-text-mid);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;direction:rtl;text-align:left}
uecp-screen-sourcecontrol .f-stat{font-family:var(--ue-font-mono);font-size:10px;letter-spacing:.05em;text-transform:uppercase;flex-shrink:0}
uecp-screen-sourcecontrol .f-clash{font-size:10.5px;color:var(--ue-warn);flex-shrink:0}
uecp-screen-sourcecontrol .cb{width:14px;height:14px;border-radius:3px;border:1.5px solid var(--ue-line);flex-shrink:0;display:flex;align-items:center;justify-content:center}
uecp-screen-sourcecontrol .cb.on{background:var(--ue-accent);border-color:var(--ue-accent)}
uecp-screen-sourcecontrol .cb.on::after{content:"";width:7px;height:4px;border-left:1.5px solid var(--ue-on-accent);border-bottom:1.5px solid var(--ue-on-accent);transform:rotate(-45deg) translate(1px,-1px)}
uecp-screen-sourcecontrol .scm-empty{padding:26px 10px;text-align:center;font-size:12.5px;color:var(--ue-text-lo)}
uecp-screen-sourcecontrol .scm-banner{display:flex;gap:10px;align-items:flex-start;background:var(--ue-warn-soft);border:1px solid var(--ue-warn);border-radius:var(--ue-r-lg);padding:12px 14px;margin-top:14px}
uecp-screen-sourcecontrol .scm-banner .bt{font-size:12.5px;font-weight:var(--ue-fw-semi);color:var(--ue-text-hi)}
uecp-screen-sourcecontrol .scm-banner .bd{font-size:11.5px;color:var(--ue-text-mid);margin-top:3px;line-height:1.5}
uecp-screen-sourcecontrol .scm-err{background:var(--ue-danger-soft);border:1px solid var(--ue-danger);border-radius:var(--ue-r);padding:10px 12px;font-size:12px;color:var(--ue-text-hi);margin-top:12px}
uecp-screen-sourcecontrol .scm-busy{opacity:.55;pointer-events:none}
uecp-screen-sourcecontrol .list-line{border-bottom:1px solid var(--ue-line-soft);padding:9px 2px;font-size:12.5px;color:var(--ue-text-mid);display:flex;gap:10px;align-items:baseline}
uecp-screen-sourcecontrol .list-line:last-child{border-bottom:none}
uecp-screen-sourcecontrol .list-line .mono{font-family:var(--ue-font-mono);font-size:11px;color:var(--ue-text-lo);flex-shrink:0}
uecp-screen-sourcecontrol .list-line .grow{flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}`;
    document.head.appendChild(s);
  }

  class UecpScreenSourceControl extends HTMLElement {
    connectedCallback() {
      this.style.cssText = 'display:flex;flex-direction:column;flex:1;min-width:0;min-height:0;background:var(--ue-bg)';

      this._pending  = {};
      this._state    = null;
      this._caps     = null;
      this._clashes  = [];
      this._tab      = 'branches';
      this._tabData  = {};
      this._selected = {};
      this._providers = [];
      this._pick     = null;
      this._error    = '';
      this._busy     = false;

      this._sub = window.uecp.on('scm.result', (p) => this._onResult(p));
      this._build();
      this.refresh();
    }

    disconnectedCallback() { if (this._sub) this._sub(); this._pending = {}; }

    _call(tool, args) {
      const id = 'scm' + (++REQ);
      const payload = Object.assign({}, args || {});

      if (this._pick && tool !== 'scm_providers' && tool !== 'scm_init') {
        payload.provider = this._pick.toLowerCase();
      }

      return new Promise((resolve) => {
        this._pending[id] = resolve;
        window.uecp.call('scm_action', { tool: tool, args: payload, request_id: id });
      });
    }

    _onResult(p) {
      if (!p || !p.request_id) return;
      const done = this._pending[p.request_id];
      if (!done) return;
      delete this._pending[p.request_id];
      done(p);
    }

    async refresh() {
      this._setBusy(true);
      this._error = '';

      const providers = await this._call('scm_providers');
      this._providers = providers.ok && providers.data ? (providers.data.providers || []) : [];

      const names = this._providers.map((p) => p.provider);
      if (this._pick && names.indexOf(this._pick) < 0) this._pick = null;

      const chosen = this._pick
        ? this._providers.filter((p) => p.provider === this._pick)[0]
        : this._providers.filter((p) => p.active)[0];
      this._caps = chosen ? chosen.capabilities : null;

      const status = await this._call('scm_status');
      if (!status.ok) {
        this._state = null;
        this._error = status.error || 'Could not read source control status.';
        this._setBusy(false);
        this._render();
        return;
      }
      this._state = status.data || {};

      this._selected = {};
      (this._state.files || []).forEach((f) => { this._selected[f.file] = true; });

      this._clashes = [];
      if (this._caps && this._caps.clash_detection) {
        const cl = await this._call('scm_clashes');
        if (cl.ok && cl.data) this._clashes = cl.data.clashes || [];
      }

      await this._loadTab(this._tab, true);
      this._setBusy(false);
      this._render();
    }

    async _loadTab(tab, quiet) {
      if (!this._caps) return;
      if (!quiet) this._setBusy(true);

      if (tab === 'branches' && this._caps.branches) {
        const r = await this._call('scm_branch', { action: 'list' });
        this._tabData.branches = r.ok && r.data ? (r.data.branches || []) : [];
      } else if (tab === 'shelves' && this._caps.shelve) {
        const r = await this._call('scm_shelve', { action: 'list' });
        this._tabData.shelves = r.ok && r.data ? (r.data.shelves || []) : [];
      } else if (tab === 'history' && this._caps.file_history) {
        const r = await this._call('scm_log', { max_count: 20 });
        this._tabData.history = r.ok && r.data ? (r.data.commits || []) : [];
      }

      if (!quiet) { this._setBusy(false); this._render(); }
    }

    _setBusy(v) {
      this._busy = v;
      const page = this.querySelector('#scm-page');
      if (page) page.classList.toggle('scm-busy', v);
    }

    async _mutate(tool, args) {
      this._setBusy(true);
      const r = await this._call(tool, args);
      if (!r.ok) {
        this._error = r.error || t('That action failed.');
        this._setBusy(false);
        this._render();
        return false;
      }
      await this.refresh();
      return true;
    }

    _build() {
      this.innerHTML =
        '<div class="content-head"><span class="crumb"><b>Source Control</b></span>'
        + '<span id="scm-crumb" class="hint" style="margin-left:8px"></span></div>'
        + '<div id="scm-page" class="page page-wide" style="flex:1;overflow-y:auto"></div>';
      this._render();
    }

    _render() {
      const page = this.querySelector('#scm-page');
      if (!page) return;

      const crumb = this.querySelector('#scm-crumb');
      if (crumb) {
        crumb.textContent = this._state && this._state.provider
          ? this._state.provider + (this._state.branch ? '  ·  ' + this._state.branch : '')
          : '';
      }

      if (!this._state) { page.innerHTML = this._renderNoProvider(); this._wire(); return; }

      page.innerHTML =
        this._renderProviderCard()
        + this._renderProviderSwitch()
        + this._renderClashBanner()
        + (this._error ? '<div class="scm-err">' + esc(this._error) + '</div>' : '')
        + this._renderChanges()
        + this._renderTabs();
      this._wire();
      page.classList.toggle('scm-busy', this._busy);
    }

    _renderNoProvider() {
      return '<div class="page-title">Source Control</div>'
        + '<div class="page-sub">Nothing is tracking this project yet.</div>'
        + (this._error ? '<div class="scm-err">' + esc(this._error) + '</div>' : '')
        + '<div class="card" style="margin-top:18px">'
        + '<div class="card-desc">UECP looks for a Diversion workspace, a Perforce client view, a git repository, '
        + 'and any provider configured in Editor Preferences. Set one up and refresh, or start one here.</div>'
        + '<div style="display:flex;gap:8px;margin-top:14px">'
        + '<button class="btn-accent" data-act="init-git">Create a git repository</button>'
        + '<button class="btn-ghost" data-act="init-dv">Create a Diversion repository</button>'
        + '<button class="btn-ghost" data-act="refresh">Refresh</button>'
        + '</div></div>';
    }

    _renderProviderCard() {
      const s = this._state;
      const rows = [
        ['Workspace', s.workspace], ['Branch', s.branch], ['Revision', s.revision],
        ['User', s.user], ['Server', s.server], ['Root', s.root],
      ].filter((r) => r[1]);

      return '<div class="scm-head" style="justify-content:space-between">'
        + '<div><div class="page-title">Source Control</div>'
        + '<div class="page-sub">Everything here runs through the same backend the assistant uses.</div></div>'
        + '<button class="btn-ghost" data-act="refresh">Refresh</button>'
        + '</div>'
        + '<div class="card" style="margin-top:18px">'
        + '<div class="scm-provider">'
        + '<span class="dot ' + (s.available ? 'dot-ok' : '') + '" style="' + (s.available ? '' : 'background:var(--ue-text-lo)') + '"></span>'
        + '<span class="scm-name">' + esc(s.provider || 'Unknown') + '</span>'
        + '</div>'
        + '<div class="scm-meta">'
        + rows.map((r) => '<div><span class="k">' + esc(r[0]) + '</span><span class="v">' + esc(r[1]) + '</span></div>').join('')
        + '</div></div>';
    }

    _renderProviderSwitch() {
      if (!this._providers || this._providers.length < 2) return '';

      const detected = (this._providers.filter((p) => p.active)[0] || {}).provider;
      const current = this._pick || detected;

      return '<div class="section-label">THIS PROJECT IS UNDER ' + this._providers.length + ' PROVIDERS</div>'
        + '<div class="seg-wide" id="scm-pick">'
        + this._providers.map((p) =>
            '<span' + (p.provider === current ? ' class="active"' : '') + ' data-pick="' + esc(p.provider) + '">'
            + esc(p.provider) + (p.provider === detected ? ' (detected)' : '') + '</span>').join('')
        + '</div>';
    }

    _renderClashBanner() {
      if (!this._clashes.length) return '';
      const names = [];
      this._clashes.forEach((c) => (c.also_edited_by || []).forEach((w) => {
        if (names.indexOf(w) < 0) names.push(w);
      }));
      const who = names.length ? names.join(', ') : t('someone else');
      const detail = t('{who} has uncommitted changes to {count} of these files. Nobody has committed yet, so this will not show as a conflict until someone does.',
        { who: who, count: this._clashes.length });

      return '<div class="scm-banner">'
        + '<span class="dot" style="background:var(--ue-warn);margin-top:5px"></span>'
        + '<div><div class="bt">Files are also being edited elsewhere</div>'
        + '<div class="bd">' + esc(detail) + '</div></div></div>';
    }

    _renderChanges() {
      const files = (this._state.files || []);
      const clashBy = {};
      this._clashes.forEach((c) => { clashBy[c.file] = (c.also_edited_by || []).join(', '); });

      const selectedCount = files.filter((f) => this._selected[f.file]).length;

      let body;
      if (!files.length) {
        body = '<div class="scm-empty">No local changes.</div>';
      } else {
        body = files.map((f) => {
          const tone = STATUS_TONE[f.status] || 'var(--ue-text-lo)';
          const on = this._selected[f.file] ? ' on' : '';
          const clash = clashBy[f.file];
          return '<div class="f-row" data-file="' + esc(f.file) + '">'
            + '<span class="cb' + on + '"></span>'
            + '<span class="f-path" title="' + esc(f.file) + '">' + esc(f.file) + '</span>'
            + (clash ? '<span class="f-clash" title="' + esc(clash) + '">also: ' + esc(clash) + '</span>' : '')
            + '<span class="f-stat" style="color:' + tone + '">' + esc(f.status) + '</span>'
            + '</div>';
        }).join('');
      }

      const c = this._caps || {};
      const actions = [];
      actions.push('<button class="btn-accent" data-act="commit"' + (selectedCount ? '' : ' disabled') + '>'
        + esc(selectedCount ? t('Commit {count} selected', { count: selectedCount }) : t('Commit'))
        + '</button>');
      if (c.push) actions.push('<button class="btn-ghost" data-act="push">Push</button>');
      actions.push('<button class="btn-ghost" data-act="sync">Sync</button>');
      if (c.shelve && files.length) actions.push('<button class="btn-ghost" data-act="shelve">Shelve</button>');
      if (files.length) actions.push('<button class="btn-danger" data-act="revert" style="margin-left:auto">Discard selected</button>');

      return '<div class="section-label">LOCAL CHANGES' + (files.length ? ' (' + files.length + ')' : '') + '</div>'
        + '<div class="card" style="padding:8px 9px">' + body + '</div>'
        + (files.length
          ? '<div style="display:flex;gap:10px;margin-top:8px">'
            + '<span class="util" data-act="all">Select all</span>'
            + '<span class="util" data-act="none">Select none</span></div>'
          : '')
        + '<div style="margin-top:14px"><div class="field-label">Commit message</div>'
        + '<textarea id="scm-msg" placeholder="What changed, and why"'
        + ' style="background:var(--ue-bg);border:1px solid var(--ue-line);border-radius:var(--ue-r);padding:9px 12px;'
        + 'font-size:13px;color:var(--ue-text-hi);width:100%;box-sizing:border-box;resize:vertical;min-height:64px;'
        + 'font-family:var(--ue-font-sans)"></textarea></div>'
        + '<div style="display:flex;gap:8px;margin-top:12px;align-items:center">' + actions.join('') + '</div>';
    }

    _renderTabs() {
      const c = this._caps || {};
      const tabs = [];
      if (c.branches) tabs.push(['branches', 'Branches']);
      if (c.shelve) tabs.push(['shelves', 'Shelves']);
      if (c.file_history) tabs.push(['history', 'History']);
      if (!tabs.length) return '';

      if (!tabs.some((t) => t[0] === this._tab)) this._tab = tabs[0][0];

      const head = '<div class="tabs" style="margin-top:22px" id="scm-tabs">'
        + tabs.map((t) => '<span' + (t[0] === this._tab ? ' class="active"' : '') + ' data-tab="' + t[0] + '">' + t[1] + '</span>').join('')
        + '</div>';

      let body = '';
      if (this._tab === 'branches') {
        const list = this._tabData.branches || [];
        body = list.length ? list.map((b) =>
          '<div class="list-line"><span class="grow" style="' + (b.current ? 'color:var(--ue-accent-bright);font-weight:600' : '') + '">'
          + esc(b.name) + (b.current ? '  (current)' : '') + '</span>'
          + (b.current ? '' : '<span class="util" data-act="switch" data-name="' + esc(b.name) + '">Switch</span>')
          + '</div>').join('') : '<div class="scm-empty">No branches.</div>';
        body += '<div style="display:flex;gap:8px;margin-top:12px">'
          + '<input id="scm-branch-name" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="new-branch-name" style="flex:1;background:var(--ue-bg);'
          + 'border:1px solid var(--ue-line);border-radius:var(--ue-r);padding:8px 12px;font-size:13px;color:var(--ue-text-hi)">'
          + '<button class="btn-ghost" data-act="branch-create">Create</button></div>';
      } else if (this._tab === 'shelves') {
        const list = this._tabData.shelves || [];
        body = list.length ? list.map((s) =>
          '<div class="list-line"><span class="grow">' + esc(s.name) + '</span>'
          + (s.created ? '<span class="mono">' + esc(s.created) + '</span>' : '')
          + '<span class="util" data-act="shelf-apply" data-name="' + esc(s.name) + '">Apply</span>'
          + '<span class="util" data-act="shelf-delete" data-name="' + esc(s.name) + '">Delete</span>'
          + '</div>').join('') : '<div class="scm-empty">No shelves.</div>';
      } else {
        const list = this._tabData.history || [];
        body = list.length ? list.map((cm) =>
          '<div class="list-line"><span class="mono">' + esc((cm.short_id || cm.id || '').slice(0, 12)) + '</span>'
          + '<span class="grow">' + esc(cm.message || '') + '</span>'
          + '<span class="mono">' + esc((cm.date || '').slice(0, 10)) + '</span></div>').join('')
          : '<div class="scm-empty">No commits.</div>';
      }

      return head + '<div class="card" style="margin-top:12px">' + body + '</div>';
    }

    _wire() {
      const self = this;

      this.querySelectorAll('#scm-pick span').forEach((n) => {
        n.addEventListener('click', async function () {
          self._pick = n.dataset.pick;
          await self.refresh();
        });
      });

      this.querySelectorAll('#scm-tabs span').forEach((n) => {
        n.addEventListener('click', async function () {
          self._tab = n.dataset.tab;
          await self._loadTab(self._tab, false);
          self._render();
        });
      });

      this.querySelectorAll('.f-row').forEach((n) => {
        n.addEventListener('click', function () {
          const f = n.dataset.file;
          self._selected[f] = !self._selected[f];
          self._render();
        });
      });

      this.querySelectorAll('[data-act]').forEach((n) => {
        n.addEventListener('click', function (e) {
          e.stopPropagation();
          self._act(n.dataset.act, n.dataset.name);
        });
      });
    }

    _selectedFiles() {
      return (this._state && this._state.files ? this._state.files : [])
        .filter((f) => this._selected[f.file]).map((f) => f.file);
    }

    async _act(act, name) {
      const msgEl = this.querySelector('#scm-msg');
      const msg = msgEl ? msgEl.value.trim() : '';
      this._error = '';

      if (act === 'refresh') return this.refresh();
      if (act === 'all')  { Object.keys(this._selected).forEach((k) => { this._selected[k] = true; }); return this._render(); }
      if (act === 'none') { Object.keys(this._selected).forEach((k) => { this._selected[k] = false; }); return this._render(); }

      if (act === 'init-git' || act === 'init-dv') {
        return this._mutate('scm_init', { provider: act === 'init-git' ? 'git' : 'diversion' });
      }

      if (act === 'commit') {
        const files = this._selectedFiles();
        if (!files.length) { this._error = 'Select at least one file to commit.'; return this._render(); }
        if (!msg) { this._error = 'A commit message is required.'; return this._render(); }
        const ok = await this._mutate('scm_commit', { description: msg, files: files });
        if (ok) { const m = this.querySelector('#scm-msg'); if (m) m.value = ''; }
        return ok;
      }

      if (act === 'push') return this._mutate('scm_push', {});
      if (act === 'sync') return this._mutate('scm_sync', {});

      if (act === 'revert') {
        const files = this._selectedFiles();
        if (!files.length) { this._error = 'Select the files to discard.'; return this._render(); }
        const go = await this._confirm(
          t('Discard the selected changes?'),
          t('{count} file(s) will be reverted. This throws the edits away and there is no undo.', { count: files.length }));
        if (!go) return false;
        return this._mutate('scm_revert', { files: files });
      }

      if (act === 'shelve') {
        const shelfName = msg || ('shelf-' + Date.now());
        return this._mutate('scm_shelve', { action: 'create', name: shelfName, description: msg });
      }
      if (act === 'shelf-apply')  return this._mutate('scm_shelve', { action: 'apply', name: name });
      if (act === 'shelf-delete') {
        const go = await this._confirm(
          t('Delete this shelf?'),
          t('Deleting "{name}" discards the changes it holds. They are the only copy.', { name: name }));
        if (!go) return false;
        return this._mutate('scm_shelve', { action: 'delete', name: name });
      }

      if (act === 'branch-create') {
        const input = this.querySelector('#scm-branch-name');
        const bn = input ? input.value.trim() : '';
        if (!bn) { this._error = 'Enter a branch name.'; return this._render(); }
        return this._mutate('scm_branch', { action: 'create', name: bn });
      }
      if (act === 'switch') {
        return this._mutate('scm_branch', { action: 'switch', name: name, local_changes: 'take' });
      }
      return false;
    }

    _confirm(title, body) {
      if (window.UECP && window.UECP.dialog && window.UECP.dialog.confirm) {
        return Promise.resolve(window.UECP.dialog.confirm(title, body));
      }
      return Promise.resolve(window.confirm(title + '\n\n' + body));
    }
  }

  customElements.define('uecp-screen-sourcecontrol', UecpScreenSourceControl);

  if (window.UECP && window.UECP.router) {
    window.UECP.router.register('sourcecontrol', 'uecp-screen-sourcecontrol');
  }
})();
