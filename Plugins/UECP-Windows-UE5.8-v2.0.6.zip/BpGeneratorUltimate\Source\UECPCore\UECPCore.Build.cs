﻿// Copyright 2026, BlueprintsLab, All rights reserved
using UnrealBuildTool;

public class UECPCore : ModuleRules
{
	public UECPCore(ReadOnlyTargetRules Target) : base(Target)
	{
		bUsePrecompiled = true;
		if (Target.Type != TargetType.Editor)
		{
			return;
		}

		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;
		bUseUnity = false;

		PublicDependencyModuleNames.AddRange(new string[]
		{
			"Core",
			"CoreUObject",
			"Engine",
			"HTTP",
			"Json",
			"JsonUtilities",
			"Slate",
			"SlateCore"
		});

		PrivateDependencyModuleNames.AddRange(new string[]
		{
			"Projects",
			"UnrealEd",
			"EditorFramework",
			"ToolMenus",
			"InputCore",
			"ApplicationCore",
			"DesktopPlatform",
			"Sockets",
			"Networking",
			"AssetRegistry",
			"AssetTools",
			"EditorScriptingUtilities",
			"ContentBrowser",
			"ContentBrowserData",
			"WebBrowser",
			"WebBrowserWidget",
			"FileUtilities",

			"BlueprintGraph", "Kismet", "GraphEditor",
			"AIModule", "AIGraph", "BehaviorTreeEditor",
			"MaterialEditor",
			"UMG", "UMGEditor",
		});

		if (Target.Platform == UnrealTargetPlatform.Win64)
		{
			PublicSystemLibraries.Add("Crypt32.lib");

			string VmpSdk = System.Environment.GetEnvironmentVariable("UECP_VMPROTECT_SDK");
			if (!string.IsNullOrEmpty(VmpSdk) && System.IO.Directory.Exists(VmpSdk))
			{
				PrivateDefinitions.Add("UECP_VMPROTECT=1");
				PrivateIncludePaths.Add(System.IO.Path.Combine(VmpSdk, "Include", "C"));
				PublicSystemLibraryPaths.Add(System.IO.Path.Combine(VmpSdk, "Lib", "Windows"));
				PublicAdditionalLibraries.Add(System.IO.Path.Combine(VmpSdk, "Lib", "Windows", "VMProtectSDK64.lib"));
			}
		}
		else if (Target.Platform == UnrealTargetPlatform.Mac)
		{
			PublicFrameworks.AddRange(new string[] { "Security", "CoreFoundation" });
		}
	}
}

