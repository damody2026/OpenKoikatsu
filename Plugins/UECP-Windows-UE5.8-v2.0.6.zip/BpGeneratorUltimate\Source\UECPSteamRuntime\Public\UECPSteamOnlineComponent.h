// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "Components/ActorComponent.h"
#include "CoreMinimal.h"
#include "UECPSteamSessionTypes.h"
#include "UECPSteamTypes.h"
#include "UECPSteamOnlineComponent.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FUECPSteamComponentResultSignature, FUECPSteamError, Error);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FUECPSteamComponentFoundSignature,
	const TArray<FUECPSteamSessionSearchResult>&, Results, FUECPSteamError, Error);

UCLASS(ClassGroup = (UECP), Blueprintable, meta = (BlueprintSpawnableComponent,
	DisplayName = "UECP Steam Online"))
class UECPSTEAMRUNTIME_API UUECPSteamOnlineComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UUECPSteamOnlineComponent();

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UECP|Steam|Host")
	FUECPSteamSessionSettings HostSettings;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UECP|Steam|Host")
	FString HostTravelMap;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UECP|Steam")
	bool bAutoTravel = true;

	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "UECP|Steam|Find")
	FUECPSteamSessionSearchSettings SearchSettings;

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam")
	void HostSession();

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam")
	void FindSessions();

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam")
	void JoinSessionByIndex(int32 Index);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam")
	void JoinSession(const FUECPSteamSessionSearchResult& SearchResult);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam")
	void LeaveSession();

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam")
	bool InviteFriend(FUECPSteamID FriendSteamId);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam")
	const TArray<FUECPSteamSessionSearchResult>& GetLastSearchResults() const { return LastResults; }

	UFUNCTION(BlueprintPure, Category = "UECP|Steam")
	bool IsInSession() const;

	UFUNCTION(BlueprintPure, Category = "UECP|Steam")
	bool IsHosting() const { return bIsHosting; }

	UFUNCTION(BlueprintPure, Category = "UECP|Steam")
	bool IsBusy() const { return bBusy; }

	UFUNCTION(BlueprintImplementableEvent, Category = "UECP|Steam", meta = (DisplayName = "On Host Succeeded"))
	void BP_OnHostSucceeded();

	UFUNCTION(BlueprintImplementableEvent, Category = "UECP|Steam", meta = (DisplayName = "On Host Failed"))
	void BP_OnHostFailed(const FUECPSteamError& Error);

	UFUNCTION(BlueprintImplementableEvent, Category = "UECP|Steam", meta = (DisplayName = "On Sessions Found"))
	void BP_OnSessionsFound(const TArray<FUECPSteamSessionSearchResult>& Results);

	UFUNCTION(BlueprintImplementableEvent, Category = "UECP|Steam", meta = (DisplayName = "On Find Failed"))
	void BP_OnFindFailed(const FUECPSteamError& Error);

	UFUNCTION(BlueprintImplementableEvent, Category = "UECP|Steam", meta = (DisplayName = "On Join Succeeded"))
	void BP_OnJoinSucceeded(const FString& ConnectString);

	UFUNCTION(BlueprintImplementableEvent, Category = "UECP|Steam", meta = (DisplayName = "On Join Failed"))
	void BP_OnJoinFailed(const FUECPSteamError& Error);

	UFUNCTION(BlueprintImplementableEvent, Category = "UECP|Steam", meta = (DisplayName = "On Session Left"))
	void BP_OnSessionLeft();

	UPROPERTY(BlueprintAssignable, Category = "UECP|Steam|Events")
	FUECPSteamComponentResultSignature OnHostComplete;

	UPROPERTY(BlueprintAssignable, Category = "UECP|Steam|Events")
	FUECPSteamComponentFoundSignature OnFindComplete;

	UPROPERTY(BlueprintAssignable, Category = "UECP|Steam|Events")
	FUECPSteamComponentResultSignature OnJoinComplete;

	UPROPERTY(BlueprintAssignable, Category = "UECP|Steam|Events")
	FUECPSteamComponentResultSignature OnLeaveComplete;

private:
	UPROPERTY()
	TArray<FUECPSteamSessionSearchResult> LastResults;

	bool bIsHosting = false;
	bool bBusy = false;

	UFUNCTION()
	void HandleHostComplete(FUECPSteamError Error);

	UFUNCTION()
	void HandleFindComplete(const TArray<FUECPSteamSessionSearchResult>& Results, FUECPSteamError Error);

	UFUNCTION()
	void HandleJoinComplete(const FString& ConnectString, FUECPSteamError Error);

	UFUNCTION()
	void HandleLeaveComplete(FUECPSteamError Error);
};
