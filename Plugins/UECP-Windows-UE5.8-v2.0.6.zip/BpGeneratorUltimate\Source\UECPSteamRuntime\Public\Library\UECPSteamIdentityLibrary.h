// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "UECPSteamTypes.h"
#include "UECPSteamIdentityLibrary.generated.h"

UENUM(BlueprintType)
enum class EUECPSteamLoginStatus : uint8
{
	NotLoggedIn     UMETA(DisplayName = "Not Logged In"),
	UsingLocalProfile UMETA(DisplayName = "Using Local Profile"),
	LoggedIn        UMETA(DisplayName = "Logged In"),
};

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamIdentityLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Identity",
		meta = (WorldContext = "WorldContextObject"))
	static EUECPSteamLoginStatus GetSteamLoginStatus(const UObject* WorldContextObject);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Identity",
		meta = (WorldContext = "WorldContextObject"))
	static FUECPSteamID GetSteamPlayerId(const UObject* WorldContextObject);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Identity",
		meta = (WorldContext = "WorldContextObject"))
	static FString GetSteamPlayerNickname(const UObject* WorldContextObject);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Identity",
		meta = (WorldContext = "WorldContextObject"))
	static FString GetSteamAuthToken(const UObject* WorldContextObject);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Identity",
		meta = (CompactNodeTitle = "->", BlueprintAutocast))
	static FString Conv_SteamIDToString(const FUECPSteamID& SteamId);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Identity")
	static FUECPSteamID MakeSteamIDFromString(const FString& SteamIdString);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Identity",
		meta = (DisplayName = "Is Valid (Steam ID)"))
	static bool IsValidSteamID(const FUECPSteamID& SteamId);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Identity",
		meta = (DisplayName = "Equal (Steam ID)", CompactNodeTitle = "==", Keywords = "== equal"))
	static bool EqualEqual_SteamID(const FUECPSteamID& A, const FUECPSteamID& B);
};
