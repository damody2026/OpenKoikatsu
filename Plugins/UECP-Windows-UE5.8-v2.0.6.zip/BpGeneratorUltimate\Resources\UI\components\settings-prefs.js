(function () {
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  const CHEV_SVG = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>';

  const LANGUAGES = [
    'English', 'Bahasa Indonesia', 'Deutsch', 'Español', 'Français', 'Italiano',
    'Nederlands', 'Polski', 'Português', 'Română', 'Tiếng Việt', 'Türkçe',
    'Русский', 'Українська', 'العربية', 'हिंदी', 'ภาษาไทย', '中文', '日本語', '한국어',
  ];

  const LANG_CODE = {
    'English': 'en', 'Bahasa Indonesia': 'id', 'Deutsch': 'de', 'Español': 'es',
    'Français': 'fr', 'Italiano': 'it', 'Nederlands': 'nl', 'Polski': 'pl',
    'Português': 'pt', 'Română': 'ro', 'Tiếng Việt': 'vi', 'Türkçe': 'tr',
    'Русский': 'ru', 'Українська': 'uk', 'العربية': 'ar', 'हिंदी': 'hi',
    'ภาษาไทย': 'th', '中文': 'zh', '日本語': 'ja', '한국어': 'ko',
  };

  const STARTUP_VIEWS = [
    { value: 'architect',     label: 'Architect' },
    { value: 'crew',          label: 'Crew' },
    { value: 'tools',         label: 'Tools' },
    { value: 'sourcecontrol', label: 'Source Control' },
    { value: 'mcp',           label: 'MCP' },
    { value: 'dashboard',     label: 'Dashboard' },
  ];
  function normStartup(v) {
    const s = String(v == null ? '' : v).toLowerCase();
    if (s === 'crew' || s === 'subagents') return 'crew';
    if (s === 'tools')     return 'tools';
    if (s === 'sourcecontrol') return 'sourcecontrol';
    if (s === 'mcp')       return 'mcp';
    if (s === 'dashboard') return 'dashboard';
    return 'architect';
  }

  class SettingsPrefs extends HTMLElement {
    connectedCallback() {
      this.style.cssText = 'display:flex;flex-direction:column;flex:1;min-height:0';
      this._prefs      = {};
      this._chatPrefs  = {};
      this._tools      = {};
      this._arrangeRebind = null;
      this._pttRebind = null;
      this._rebindTarget = null;
      this._render();
    }

    disconnectedCallback() {
      if (this._rebindTarget) {
        window.uecp.call('set_rebind_capturing', { capturing: false });
        this._rebindTarget = null;
      }
      if (this._kbHandler) {
        document.removeEventListener('keydown', this._kbHandler, true);
        this._kbHandler = null;
      }
    }

    _onSettingsInit(state) {
      if (!state) return;
      this._prefs     = (state.preferences) || {};
      this._chatPrefs = (state.chatPrefs)   || {};
      this._privacy   = (state.privacy)     || {};
      this._tools     = (state.tools)       || {};
      this._arrangeRebind = this._prefs.arrangeKeybind  || null;
      this._pttRebind     = this._prefs.voicePTTKeybind || null;
      this._render();
    }

    _render() {
      const p  = this._prefs;
      const cp = this._chatPrefs;
      const ts = this._tools || {};
      const shareUsage = (this._privacy || {}).shareUsageData !== false;
      const lang           = p.language     || 'English';
      const startupView    = normStartup(p.startupView);
      const autoCompact    = cp.autoCompact !== false;
      const compactMode    = cp.compactMode || 'discard';
      const autoCompactPct = cp.autoCompactPercent != null ? cp.autoCompactPercent : 80;
      const toastDur       = cp.toastDuration != null ? cp.toastDuration : 5;
      const sendOnEnter    = cp.sendOnEnter    !== false;
      const persistSubagentRuns = cp.persistSubagentRuns === true;
      const askAfterCrash  = cp.askAfterCrash !== false;
      const autoScroll     = cp.autoScroll     !== false;
      const showTimestamps = cp.timestamps !== false;
      const soundOnDone    = cp.soundOnCompletion === true;
      const fullWidth      = cp.fullWidthChat === true;
      const hideAnnounce   = ts.hideAnnouncements === true;
      const chatMaxWidth   = (typeof cp.chatMaxWidth === 'number' && cp.chatMaxWidth > 0) ? cp.chatMaxWidth : 760;
      const subagentTimeoutSec = (typeof cp.subagentTimeoutSeconds === 'number' && cp.subagentTimeoutSeconds > 0) ? cp.subagentTimeoutSeconds : 1800;
      window.UECP = window.UECP || {};
      window.UECP.toastDuration = (Number(toastDur) || 5) * 1000;

      const arrangeStr = this._fmtKeybind(this._arrangeRebind || p.arrangeKeybind  || { modifier: 'LeftControl', key: 'R' });
      const pttStr     = this._fmtKeybind(this._pttRebind     || p.voicePTTKeybind || { modifier: 'LeftAlt', key: 'V' });

      const langOptions = LANGUAGES.map(function (l) {
        return '<option value="' + esc(l) + '"' + (l === lang ? ' selected' : '') + '>' + esc(l) + '</option>';
      }).join('');

      const startupOptions = STARTUP_VIEWS.map(function (v) {
        return '<option value="' + esc(v.value) + '"' + (v.value === startupView ? ' selected' : '') + '>' + esc(v.label) + '</option>';
      }).join('');

      const selectStyle = 'background:transparent;border:none;width:100%;padding:9px 12px;color:var(--ue-text-hi);outline:none;appearance:none;font-size:13px;cursor:pointer';

      let html =
        '<div class="content-head"><span class="crumb"><b>Preferences</b></span></div>'
        + '<div class="page page-narrow" style="overflow-y:auto">'
        + '<div class="page-title">Preferences</div>'
        + '<div class="page-sub">General behaviour and localisation.</div>'

        + '<div class="row" style="margin-top:20px">'
        + '<div>'
        + '<div class="field-label">Language</div>'
        + '<div class="input" style="padding:0;display:flex;align-items:center">'
        + '<select id="sp-lang" style="' + selectStyle + '">' + langOptions + '</select>'
        + '<span class="chev" style="pointer-events:none;padding-right:10px">' + CHEV_SVG + '</span>'
        + '</div></div>'
        + '<div>'
        + '<div class="field-label">Startup view</div>'
        + '<div class="input" style="padding:0;display:flex;align-items:center">'
        + '<select id="sp-startup" style="' + selectStyle + '">' + startupOptions + '</select>'
        + '<span class="chev" style="pointer-events:none;padding-right:10px">' + CHEV_SVG + '</span>'
        + '</div></div>'
        + '</div>'

        + '<div class="toggle-card" style="margin-top:14px">'
        + this._tRow('sp-send-on-enter',   'Send on Enter',   'Press Enter to send (Shift+Enter for newline).', sendOnEnter)
        + this._tRow('sp-persist-subagents', 'Persist subagent runs', 'Only affects SUCCESSFUL runs: off (default) clears them automatically once delivered; on keeps them in the sidebar as inspectable history. Failed / needs-input / timed-out runs are always kept until you dismiss them, regardless of this setting.', persistSubagentRuns)
        + this._tRow('sp-auto-scroll',     'Auto-scroll',     'Scroll to the bottom when new messages arrive.', autoScroll)
        + this._tRow('sp-show-timestamps', 'Show timestamps', 'Display message timestamps in chat.',            showTimestamps)
        + this._tRow('sp-sound-done',      'Sound when finished', 'Play the editor\'s compile-finished sound when the AI completes a response. Follows Editor Preferences → Enable Editor Sounds.', soundOnDone)
        + this._tRow('sp-full-width',      'Full-width chat', 'Expand chat to the full panel width instead of a fixed column.', fullWidth)
        + this._tRow('sp-auto-compact',    'Auto-compact',    'Automatically compact when context reaches the threshold.', autoCompact)
        + this._tRow('sp-hide-announce',   'Hide announcement banner', 'Suppress the header notice strip permanently. The banner\'s own X only dismisses it until the plugin window is reopened.', hideAnnounce)
        + '</div>'

        + '<div class="toggle-card" style="margin-top:14px">'
        + this._tRow('sp-share-usage', 'Share usage data',
            'Sends which tools you run, plus scripts executed via the Python tool, to improve the plugin and to auto-complete Learn lessons. Turn it off and none of that leaves the editor. Your course progress and XP still sync, but lessons stop completing themselves and you mark them done by hand.',
            shareUsage)
        + this._tRow('sp-ask-crash', 'Ask to send a report after a crash',
            'When the editor crashed or closed unexpectedly, the next start offers to send a report. Turn it off and that prompt never appears and nothing is sent.',
            askAfterCrash)
        + '</div>'

        + '<div class="card" style="margin-top:14px">'
        + '<div class="field-label">Chat max width (px)</div>'
        + '<input class="input mono" id="sp-chat-width" type="number" min="600" max="2000" step="20" value="' + chatMaxWidth + '" style="width:100%;box-sizing:border-box">'
        + '<div style="font-size:11.5px;color:var(--ue-text-lo);margin-top:5px">Fixed column width when "Full-width chat" is off.</div>'
        + '</div>'

        + '<div class="card" style="margin-top:14px">'
        + '<div class="field-label">Subagent Timeout (s)</div>'
        + '<input class="input mono" id="sp-subagent-timeout" type="number" min="60" max="7200" step="60" value="' + subagentTimeoutSec + '" style="width:100%;box-sizing:border-box">'
        + '<div style="font-size:11.5px;color:var(--ue-text-lo);margin-top:5px">Stops a single worker/reviewer subagent run (ad-hoc delegate or Crew checkpoint) after this long with no progress — no new tool call, tool result or message. A run that keeps working is never cut off, however slow the model.</div>'
        + '</div>'

        + '<div class="section-label" style="margin-top:20px">KEYBOARD SHORTCUTS</div>'
        + '<div class="card">'
        + '<div style="margin-bottom:14px">'
        + '<div class="field-label">Arrange Keybind</div>'
        + '<div style="display:flex;align-items:center;gap:10px">'
        + '<div class="input mono" id="sp-arrange-chip" data-i18n-skip style="flex:1;font-size:12px">' + esc(arrangeStr) + '</div>'
        + '<button class="btn-ghost" id="sp-arrange-rebind">Rebind</button>'
        + '</div>'
        + '<div style="font-size:11.5px;color:var(--ue-text-lo);margin-top:5px">Shortcut to auto-arrange the Blueprint graph.</div>'
        + '</div>'
        + '<div>'
        + '<div class="field-label">Push-to-Talk</div>'
        + '<div style="display:flex;align-items:center;gap:10px">'
        + '<div class="input mono" id="sp-ptt-chip" data-i18n-skip style="flex:1;font-size:12px">' + esc(pttStr) + '</div>'
        + '<button class="btn-ghost" id="sp-ptt-rebind">Rebind</button>'
        + '</div>'
        + '<div style="font-size:11.5px;color:var(--ue-text-lo);margin-top:5px">Hold to capture voice input.</div>'
        + '</div></div>'

        + '<div class="section-label" style="margin-top:20px">COMPACTION</div>'
        + '<div class="card">'
        + '<div style="margin-bottom:14px">'
        + '<div class="field-label">Compact Mode</div>'
        + '<div class="seg-wide" id="sp-compact-mode">'
        + [['discard','Discard'],['fork','Fork'],['marker','Marker']].map(function (pair) {
            return '<div class="ue-seg' + (pair[0] === compactMode ? ' active' : '') + '" data-value="' + pair[0] + '">' + pair[1] + '</div>';
          }).join('')
        + '</div></div>'
        + '<div style="margin-bottom:14px">'
        + '<div class="field-label">Auto-compact Threshold (%)</div>'
        + '<input class="input mono" id="sp-compact-pct" type="number" min="50" max="95" value="' + autoCompactPct + '" style="width:100%;box-sizing:border-box">'
        + '</div>'
        + '<div>'
        + '<div class="field-label">Toast Duration (s)</div>'
        + '<input class="input mono" id="sp-toast-dur" type="number" min="2" max="30" step="1" value="' + toastDur + '" style="width:100%;box-sizing:border-box">'
        + '</div></div>'

        + '<div class="section-label" style="margin-top:20px">ONBOARDING</div>'
        + '<div class="card">'
        + '<div class="card-desc" style="margin-bottom:12px">Reset guided tours to replay them on the next open.</div>'
        + '<button class="btn-ghost" id="sp-reset-tours">Reset Tutorials</button>'
        + '<div class="card-desc" style="margin:16px 0 12px">Show the welcome screen again the next time the editor starts.</div>'
        + '<button class="btn-ghost" id="sp-reset-welcome">Reset Welcome Screen</button>'
        + '</div>'

        + window.UECP.saveBar.html(this, 'sp-save')
        + '</div>';

      this.innerHTML = html;

      const self = this;

      this.querySelectorAll('#sp-compact-mode .ue-seg').forEach(function (seg) {
        seg.addEventListener('click', function () {
          self.querySelectorAll('#sp-compact-mode .ue-seg').forEach(function (s) { s.classList.remove('active'); });
          seg.classList.add('active');
        });
      });

      this.querySelectorAll('.toggle').forEach(function (t) {
        t.addEventListener('click', function () {
          t.classList.toggle('on');
        });
      });

      this.querySelector('#sp-arrange-rebind').addEventListener('click', function () { self._startRebind('arrange'); });
      this.querySelector('#sp-ptt-rebind').addEventListener('click',    function () { self._startRebind('ptt'); });
      this.querySelector('#sp-save').addEventListener('click', function () { self._save(); });
      this.querySelector('#sp-reset-tours').addEventListener('click', function () {
        window.uecp.call('reset_tutorials', {});
      });

      this.querySelector('#sp-reset-welcome').addEventListener('click', function () {
        window.uecp.call('reset_welcome', {});
      });

      const autosave = function () { self._save(); };
      ['sp-send-on-enter', 'sp-persist-subagents', 'sp-auto-scroll', 'sp-show-timestamps',
       'sp-full-width', 'sp-auto-compact', 'sp-hide-announce', 'sp-share-usage', 'sp-ask-crash',
      ].forEach(function (id) {
        const el = self.querySelector('#' + id);
        if (el) el.addEventListener('click', autosave);
      });
      ['sp-lang', 'sp-startup', 'sp-chat-width', 'sp-subagent-timeout', 'sp-compact-pct',
       'sp-toast-dur',
      ].forEach(function (id) {
        const el = self.querySelector('#' + id);
        if (el) el.addEventListener('change', autosave);
      });
      this.querySelectorAll('#sp-compact-mode .ue-seg').forEach(function (seg) {
        seg.addEventListener('click', autosave);
      });
    }

    _startRebind(target) {
      const chipId = target === 'arrange' ? 'sp-arrange-chip' : 'sp-ptt-chip';
      const chip = this.querySelector('#' + chipId);
      if (!chip) return;
      chip.classList.add('capturing');
      chip.textContent = 'Press a key…';
      this._rebindTarget = target;
      window.uecp.call('set_rebind_capturing', { capturing: true });

      const self = this;
      if (this._kbHandler) document.removeEventListener('keydown', this._kbHandler, true);
      this._kbHandler = function (e) {
        e.preventDefault(); e.stopPropagation();
        const step = window.SettingsFormat.rebindCaptureStep(e);
        if (step.status === 'cancel')   { self._cancelRebind(chip); return; }
        if (step.status === 'progress') { chip.textContent = step.display; return; }
        const kb = { modifier: step.modifier, key: step.key };
        if (target === 'arrange') self._arrangeRebind = kb;
        else                      self._pttRebind     = kb;
        chip.textContent = self._fmtKeybind(kb);
        chip.classList.remove('capturing');
        window.uecp.call('set_rebind_capturing', { capturing: false });
        document.removeEventListener('keydown', self._kbHandler, true);
        self._kbHandler = null;
        self._rebindTarget = null;
      };
      document.addEventListener('keydown', this._kbHandler, true);
    }

    _cancelRebind(chip) {
      chip.classList.remove('capturing');
      const target = this._rebindTarget;
      const kb = target === 'arrange' ? this._arrangeRebind : this._pttRebind;
      chip.textContent = kb ? this._fmtKeybind(kb) : '—';
      window.uecp.call('set_rebind_capturing', { capturing: false });
      if (this._kbHandler) {
        document.removeEventListener('keydown', this._kbHandler, true);
        this._kbHandler = null;
      }
      this._rebindTarget = null;
    }

    _fmtKeybind(kb) {
      if (!kb || !kb.key) return '—';
      return (kb.modifier ? kb.modifier + ' + ' : '') + kb.key;
    }

    _tRow(id, title, desc, checked) {
      return '<div class="toggle-row">'
        + '<div class="t"><div class="t-name">' + title + '</div><div class="t-desc">' + desc + '</div></div>'
        + '<div class="toggle' + (checked ? ' on' : '') + '" id="' + id + '"><span class="knob"></span></div>'
        + '</div>';
    }

    _save() {
      const ar  = this._arrangeRebind || {};
      const ptt = this._pttRebind     || {};
      const compactMode = (this.querySelector('#sp-compact-mode .ue-seg.active') || {}).dataset.value || 'discard';
      const langName = (this.querySelector('#sp-lang') || {}).value || 'English';
      window.uecp.__emit('language.changed', { lang: LANG_CODE[langName] || 'en' });
      window.uecp.call('save_preferences', {
        language:        langName,
        startupView:     (this.querySelector('#sp-startup') || {}).value || 'architect',
        arrangeKeybind:  { modifier: ar.modifier  || '', key: ar.key   || '' },
        voicePTTKeybind: { modifier: ptt.modifier || '', key: ptt.key  || '' },
        chatPrefs: {
          sendOnEnter:        this.querySelector('#sp-send-on-enter').classList.contains('on'),
          persistSubagentRuns: this.querySelector('#sp-persist-subagents').classList.contains('on'),
          askAfterCrash:      this.querySelector('#sp-ask-crash').classList.contains('on'),
          subagentTimeoutSeconds: parseInt((this.querySelector('#sp-subagent-timeout') || {}).value || '1800', 10),
          autoScroll:         this.querySelector('#sp-auto-scroll').classList.contains('on'),
          timestamps:         this.querySelector('#sp-show-timestamps').classList.contains('on'),
          soundOnCompletion:  this.querySelector('#sp-sound-done').classList.contains('on'),
          fullWidthChat:      this.querySelector('#sp-full-width').classList.contains('on'),
          chatMaxWidth:       parseInt((this.querySelector('#sp-chat-width') || {}).value || '760', 10),
          autoCompact:        this.querySelector('#sp-auto-compact').classList.contains('on'),
          compactMode:        compactMode,
          autoCompactPercent: parseInt((this.querySelector('#sp-compact-pct') || {}).value || '80', 10),
          toastDuration:      parseInt((this.querySelector('#sp-toast-dur')   || {}).value || '5', 10),
        },
        privacy: {
          shareUsageData: this.querySelector('#sp-share-usage').classList.contains('on'),
        },
      });
      this._saveHideAnnouncements(this.querySelector('#sp-hide-announce').classList.contains('on'));
      window.UECP.saveBar.flash(this);
    }

    _saveHideAnnouncements(hide) {
      window.uecp.call('save_tool_settings', { hideAnnouncements: hide });
      this._tools = this._tools || {};
      this._tools.hideAnnouncements = hide;
      try {
        if (hide) localStorage.setItem('hide_announcements', '1');
        else      localStorage.removeItem('hide_announcements');
      } catch (e) {}
      window._uiConfig = window._uiConfig || {};
      window._uiConfig.hide_announcements = hide;
      if (window.uecp.__emit) window.uecp.__emit('config.ui', window._uiConfig);
    }
  }
  customElements.define('settings-prefs', SettingsPrefs);
})();
