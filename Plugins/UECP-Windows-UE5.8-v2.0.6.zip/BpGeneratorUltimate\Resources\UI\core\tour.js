(function () {
  'use strict';

  function resolveStep(steps, idx, dir, isVisible) {
    var d = (dir < 0) ? -1 : 1;
    while (idx >= 0 && idx < steps.length) {
      var s = steps[idx];
      if (!s.sel || isVisible(s)) return idx;
      idx += d;
    }
    if (idx < 0) return 0;
    return steps.length;
  }

  function seenKey(view) { return 'ubg.tour.' + view; }
  function isSeen(view, store) {
    try { return (store || _store()).getItem(seenKey(view)) === '1'; } catch (e) { return false; }
  }
  function markSeen(view, store) {
    try { (store || _store()).setItem(seenKey(view), '1'); } catch (e) {}
  }
  function clearSeen(views, store) {
    var st = store || _store();
    try { (views || []).forEach(function (v) { st.removeItem(seenKey(v)); }); } catch (e) {}
  }

  function computeCard(rect, card, vw, vh, gap, pad) {
    if (!rect) return { centered: true };
    var g = (typeof gap === 'number') ? gap : 14;
    var p = (typeof pad === 'number') ? pad : 6;
    var cw = card.width || 312, ch = card.height || 150;
    var top, left;
    if ((vh - rect.bottom) >= ch + g + 8)      { top = rect.bottom + g;     left = rect.left; }
    else if (rect.top >= ch + g + 8)           { top = rect.top - g - ch;   left = rect.left; }
    else if ((vw - rect.right) >= cw + g + 8)  { left = rect.right + g;     top = rect.top; }
    else if (rect.left >= cw + g + 8)          { left = rect.left - g - cw; top = rect.top; }
    else                                       { top = rect.top + g;        left = rect.left; }
    if (top + ch > vh - 8) top = vh - ch - 8;
    if (top < 8) top = 8;
    if (left + cw > vw - 8) left = vw - cw - 8;
    if (left < 8) left = 8;
    return {
      centered: false, top: top, left: left,
      spot: { top: rect.top - p, left: rect.left - p, width: rect.width + p * 2, height: rect.height + p * 2 }
    };
  }

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { resolveStep: resolveStep, computeCard: computeCard, seenKey: seenKey, isSeen: isSeen, markSeen: markSeen, clearSeen: clearSeen };
  }

  if (typeof document === 'undefined') return;

  function _store() { return window.localStorage; }

  var TOURS = {
    architect: [
      { tf: 'Welcome to Architect', bf: 'Architect is your AI build partner - describe what you want and it edits your project directly. Here is a quick tour.' },
      { sel: 'uecp-chat-list', tf: 'Your conversations', bf: 'Every chat is saved here, per project. Switch between them anytime; right-click one to rename, export, or delete it.' },
      { sel: 'uecp-chat-list .btn-new', tf: 'Start fresh', bf: 'Start a new conversation with a clean context.' },
      { sel: 'uecp-composer .composer-input', tf: 'Talk to the AI', bf: 'Describe what to build here. Type @ to mention an asset for context, / for slash commands, or drag files and paste images straight in.' },
      { sel: 'uecp-composer .cbtn-attach', tf: 'Attach context', bf: 'Attach images, files or reference a plugin directory. You can also paste images directly into chat.' },
      { sel: 'uecp-composer .cbtn-mode', tf: 'Response mode', bf: 'Choose how the AI acts - Just Chat (no edits), Ask Before Edit, Auto Edit, or Plan. It is set per chat.' },
      { sel: 'uecp-composer .cbtn-model', tf: 'AI model', bf: 'The model this chat uses. Switch providers/models here - each chat can run a different one. Assign a keybind to any slot in Settings to switch to it on the fly.' },
      { sel: 'uecp-composer .ctx-ring-wrap', tf: 'Context meter', bf: 'Shows how full this conversation is. Click it to compact the chat when it starts to fill up.' },
      { sel: 'uecp-rail .item[data-route="crew"]', tf: 'Want to delegate?', bf: 'The Crew tab lets you hand focused tasks to specialized agent roles, and build multi-step checkpoint plans that dispatch and review the work for you.' }
    ],
    crew: [
      { tf: 'Crew', bf: 'Build a checkpoint plan for this chat: describe the work as checkpoints, dispatch each to a worker + reviewer subagent pair, and watch them get done. Roles and plans live together here.' },
      { sel: 'uecp-screen-crew .cw-picker-new', tf: 'Add a checkpoint', bf: 'Start a plan by adding a checkpoint - what needs doing and how a reviewer checks it. Edit any checkpoint in place, right in the list.' },
      { sel: 'uecp-screen-crew .cw-tab[data-tab="roles"]', tf: 'Roles', bf: 'Switch here to manage the subagent roles that do the work - the built-in Blueprint Dev, Reviewer, and Tester, plus any you create.' }
    ],
    settings: [
      { tf: 'Settings', bf: 'This is where you configure the plugin. We will go down the nav rail top to bottom so you know what each section is for.' },
      { sel: 'uecp-settings-nav .nav-item[data-sub="ai"]', section: 'ai', tf: 'AI Models', bf: 'Pick what powers the AI here - a Free backend, a CLI coding agent, or your own API key / local model. Each chat remembers the slot it used; assign a keybind to any slot to switch to it on the fly.' },
      { sel: 'uecp-settings-nav .nav-item[data-sub="img"]', section: 'img', tf: 'Image & 3D', bf: 'Keys and options for image and 3D generation - Meshy for meshes, plus the image providers the texture and material tools use.' },
      { sel: 'uecp-settings-nav .nav-item[data-sub="audio"]', section: 'audio', tf: 'Audio', bf: 'Audio options - voice input (push-to-talk) and the sound-generation provider.' },
      { sel: 'uecp-settings-nav .nav-item[data-sub="appear"]', section: 'appear', tf: 'Appearance', bf: 'Theme and accent colour - tune the plugin look to match your editor.' },
      { sel: 'uecp-settings-nav .nav-item[data-sub="a11y"]', section: 'a11y', tf: 'Accessibility', bf: 'Readability options - text size and higher-contrast modes.' },
      { sel: 'uecp-settings-nav .nav-item[data-sub="prefs"]', section: 'prefs', tf: 'Preferences', bf: 'General preferences - language (which drives the localized labels), keyboard shortcuts, chat options, and Reset Tutorials to replay these guided tours.' },
      { sel: 'uecp-settings-nav .nav-item[data-sub="sc"]', section: 'sc', tf: 'Source Control', bf: 'Connect Git or Perforce so the AI can work alongside your versioned project - commit, branch, and check status from here.' },
      { sel: 'uecp-settings-nav .nav-item[data-sub="behav"]', section: 'behav', tf: 'AI Behaviour', bf: 'How the AI works - auto-edit, confirmation prompts, default asset save paths, and other tool defaults.' },
      { sel: 'uecp-settings-nav .nav-item[data-sub="ext"]', section: 'ext', tf: 'Extensions', bf: 'Toggle optional tool packs on or off - Niagara, Control Rig, Mass Entity and more - so the AI only loads what you use.' },
      { sel: 'uecp-settings-nav .nav-item[data-sub="mcp"]', section: 'mcp', tf: 'MCP Server', bf: 'Expose these tools to external AI clients like Claude Desktop or Cursor over the built-in MCP server.' },
      { sel: 'uecp-settings-nav .nav-item[data-sub="info"]', section: 'info', tf: 'Info', bf: 'Plugin version, links to docs and Discord, and your license details.' }
    ]
  };

  function ensureCss() {
    if (document.getElementById('uecp-tour-css')) return;
    var st = document.createElement('style'); st.id = 'uecp-tour-css';
    st.textContent =
      '#uecp-tour-overlay{position:fixed;inset:0;z-index:100050;pointer-events:auto;display:none}' +
      '#uecp-tour-overlay.show{display:block}' +
      '#uecp-tour-spot{position:fixed;border-radius:7px;box-shadow:0 0 0 9999px rgba(0,0,0,.62),0 0 0 2px var(--ue-accent);pointer-events:none}' +
      '#uecp-tour-spot.no-target{top:50%;left:50%;width:0;height:0;box-shadow:0 0 0 9999px rgba(0,0,0,.62)}' +
      '#uecp-tour-card{position:fixed;width:312px;max-width:calc(100vw - 24px);background:var(--ue-panel);' +
        'border:1px solid var(--ue-line);border-radius:var(--ue-r-lg,10px);padding:14px 16px 12px;' +
        'box-shadow:var(--ue-shadow-pop,0 12px 40px rgba(0,0,0,.5));pointer-events:auto;font-family:var(--ue-font-sans)}' +
      '#uecp-tour-card.centered{top:50%!important;left:50%!important;transform:translate(-50%,-50%)}' +
      '#uecp-tour-card-step{font-size:10.5px;letter-spacing:.5px;text-transform:uppercase;color:var(--ue-text-lo);margin-bottom:6px}' +
      '#uecp-tour-card-title{font-size:14.5px;font-weight:600;color:var(--ue-text-hi);margin-bottom:7px}' +
      '#uecp-tour-card-body{font-size:12.5px;color:var(--ue-text-mid);line-height:1.55;margin-bottom:14px}' +
      '#uecp-tour-card-btns{display:flex;align-items:center;gap:8px}' +
      '.uecp-tour-btn{padding:6px 14px;border-radius:7px;border:1px solid var(--ue-line);background:transparent;' +
        'color:var(--ue-text-mid);font:inherit;font-size:12px;cursor:pointer}' +
      '.uecp-tour-btn:hover{border-color:var(--ue-accent);color:var(--ue-accent-bright)}' +
      '.uecp-tour-btn.primary{background:var(--ue-accent);border-color:var(--ue-accent);color:var(--ue-on-accent,#fff)}' +
      '.uecp-tour-btn.primary:hover{filter:brightness(1.08);color:var(--ue-on-accent,#fff)}' +
      '.uecp-tour-btn.skip{margin-right:auto;border-color:transparent;color:var(--ue-text-lo);padding-left:0}' +
      '.uecp-tour-btn.skip:hover{color:var(--ue-text-hi);border-color:transparent}';
    document.head.appendChild(st);
  }

  function ensureOverlay() {
    var ov = document.getElementById('uecp-tour-overlay');
    if (ov) return ov;
    ensureCss();
    ov = document.createElement('div');
    ov.id = 'uecp-tour-overlay';
    ov.innerHTML =
      '<div id="uecp-tour-spot"></div>' +
      '<div id="uecp-tour-card">' +
        '<div id="uecp-tour-card-step"></div>' +
        '<div id="uecp-tour-card-title"></div>' +
        '<div id="uecp-tour-card-body"></div>' +
        '<div id="uecp-tour-card-btns">' +
          '<button class="uecp-tour-btn skip" id="uecp-tour-skip">Skip</button>' +
          '<button class="uecp-tour-btn" id="uecp-tour-back">Back</button>' +
          '<button class="uecp-tour-btn primary" id="uecp-tour-next">Next</button>' +
        '</div>' +
      '</div>';
    document.body.appendChild(ov);
    ov.querySelector('#uecp-tour-skip').addEventListener('click', function () { end(true); });
    ov.querySelector('#uecp-tour-back').addEventListener('click', function () { prev(); });
    ov.querySelector('#uecp-tour-next').addEventListener('click', function () { next(); });
    return ov;
  }

  function visible(step) {
    if (!step || !step.sel) return true;
    var el = document.querySelector(step.sel);
    if (!el) return false;
    var r = el.getBoundingClientRect();
    if (r.width < 1 || r.height < 1) return false;
    if (r.bottom <= 0 || r.right <= 0 || r.top >= window.innerHeight || r.left >= window.innerWidth) return false;
    return true;
  }

  function applySection(step) {
    if (!step || !step.section) return;
    var nav = document.querySelector('uecp-settings-nav');
    if (!nav) return;
    var item = nav.querySelector('.nav-item[data-sub="' + step.section + '"]');
    if (item && !item.classList.contains('active')) { try { item.click(); } catch (e) {} }
  }

  var _tour = null;

  function start(view) {
    var steps = TOURS[view];
    if (!steps || !steps.length) return false;
    _tour = { view: view, steps: steps, i: 0 };
    ensureOverlay().classList.add('show');
    goto(0, 1);
    return true;
  }

  function maybeStart(view) {
    if (_tour || !TOURS[view] || isSeen(view)) return;
    setTimeout(function () {
      if (!_tour && !isSeen(view) && window.UECP.router && window.UECP.router.active() === view) start(view);
    }, 350);
  }

  function goto(idx, dir) {
    if (!_tour) return;
    var steps = _tour.steps;
    var probe = idx;
    var d = (dir < 0) ? -1 : 1;
    while (probe >= 0 && probe < steps.length) {
      applySection(steps[probe]);
      if (!steps[probe].sel || visible(steps[probe])) break;
      probe += d;
    }
    idx = resolveStep(steps, idx, dir, visible);
    if (idx >= steps.length) { end(true); return; }
    if (idx < 0) idx = 0;
    _tour.i = idx;
    applySection(steps[idx]);
    if (steps[idx].section) setTimeout(render, 60); else render();
  }

  function next() { if (_tour) goto(_tour.i + 1, 1); }
  function prev() { if (_tour) goto(_tour.i - 1, -1); }

  function end(markIt) {
    var ov = document.getElementById('uecp-tour-overlay');
    if (ov) ov.classList.remove('show');
    if (_tour && markIt) markSeen(_tour.view);
    _tour = null;
  }

  function render() {
    if (!_tour) return;
    var step = _tour.steps[_tour.i];
    var ov = ensureOverlay();
    var card = ov.querySelector('#uecp-tour-card');
    var spot = ov.querySelector('#uecp-tour-spot');
    ov.querySelector('#uecp-tour-card-step').textContent = (_tour.i + 1) + ' / ' + _tour.steps.length;
    ov.querySelector('#uecp-tour-card-title').textContent = tourText(step);
    ov.querySelector('#uecp-tour-card-body').textContent = bodyText(step);
    ov.querySelector('#uecp-tour-back').style.visibility = (_tour.i === 0) ? 'hidden' : 'visible';
    ov.querySelector('#uecp-tour-next').textContent = (_tour.i === _tour.steps.length - 1) ? 'Done' : 'Next';

    var el = step.sel ? document.querySelector(step.sel) : null;
    if (el) { try { el.scrollIntoView({ block: 'center', inline: 'nearest' }); } catch (e) {} }
    var rect = null;
    if (el) {
      var r = el.getBoundingClientRect();
      if (r.width >= 1 && r.height >= 1) rect = { top: r.top, left: r.left, right: r.right, bottom: r.bottom, width: r.width, height: r.height };
    }
    var pos = computeCard(rect, { width: card.offsetWidth || 312, height: card.offsetHeight || 150 },
      window.innerWidth, window.innerHeight, 14, 6);
    if (pos.centered) {
      spot.classList.add('no-target');
      spot.style.top = spot.style.left = spot.style.width = spot.style.height = '';
      card.classList.add('centered');
      card.style.top = ''; card.style.left = '';
      return;
    }
    spot.classList.remove('no-target');
    card.classList.remove('centered');
    spot.style.top = pos.spot.top + 'px'; spot.style.left = pos.spot.left + 'px';
    spot.style.width = pos.spot.width + 'px'; spot.style.height = pos.spot.height + 'px';
    card.style.top = pos.top + 'px'; card.style.left = pos.left + 'px';
  }

  function tourText(step) {
    if (step.t && window.uecp && window.uecp.t) { var v = window.uecp.t(step.t); if (v && v !== step.t) return v; }
    return step.tf || '';
  }
  function bodyText(step) {
    if (step.b && window.uecp && window.uecp.t) { var v = window.uecp.t(step.b); if (v && v !== step.b) return v; }
    return step.bf || '';
  }

  window.addEventListener('resize', function () { if (_tour) render(); });
  document.addEventListener('keydown', function (e) {
    if (!_tour) return;
    if (e.key === 'Escape') { e.preventDefault(); end(true); return; }
    var tag = e.target && e.target.tagName;
    if (tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT') return;
    if (e.key === 'ArrowRight') { e.preventDefault(); next(); }
    else if (e.key === 'ArrowLeft') { e.preventDefault(); prev(); }
  });

  if (window.uecp && window.uecp.on) {
    window.uecp.on('screen.changed', function (p) { if (p && p.route) maybeStart(p.route); });
  }
  window.addEventListener('load', function () {
    setTimeout(function () {
      var v = (window.UECP.router && window.UECP.router.active()) || 'architect';
      maybeStart(v);
    }, 800);
  });

  window.tourResetAll = function () {
    clearSeen(Object.keys(TOURS));
    if (typeof window.UECP.tooltip !== 'undefined') {  }
    var v = (window.UECP.router && window.UECP.router.active()) || 'architect';
    maybeStart(v);
  };

  window.UECP = window.UECP || {};
  window.UECP.tour = {
    start: start, maybeStart: maybeStart, next: next, prev: prev, end: end,
    resetAll: window.tourResetAll, isSeen: isSeen, markSeen: markSeen,
    resolveStep: resolveStep, computeCard: computeCard, seenKey: seenKey,
    tours: TOURS
  };
})();
