(function () {
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  const ACCENT_PRESETS = [
    { base: '#e0a458', deep: '#bd7f38', bright: '#f0bd7a' },
    { base: '#4f8ff7', deep: '#3470d8', bright: '#7fb0fc' },
    { base: '#2bbf96', deep: '#1f9470', bright: '#56d4ae' },
    { base: '#a472e0', deep: '#7e52b6', bright: '#c598f5' },
    { base: '#e0686a', deep: '#b84d50', bright: '#f2888a' },
  ];

  const COLOR_FIELDS = [
    { key: 'bg',       label: 'Background',              cssVar: '--ue-bg' },
    { key: 'surface',  label: 'Surface (Cards / Panels)', cssVar: '--ue-panel' },
    { key: 'text',     label: 'Text',                     cssVar: '--ue-text-hi' },
    { key: 'codeBg',   label: 'Code Background',          cssVar: '--ue-code-bg' },
    { key: 'codeLine', label: 'Code Border',              cssVar: '--ue-code-line' },
    { key: 'codeText', label: 'Code Text',                cssVar: '--ue-code-text' },
  ];
  const HEX_RE = /^#[0-9a-fA-F]{6}$/;

  const CHEV_SVG = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>';

  class SettingsAppearance extends HTMLElement {
    connectedCallback() {
      this.style.cssText = 'display:flex;flex-direction:column;flex:1;min-height:0';
      this._theme = 'dark';
      this._accentColor = ACCENT_PRESETS[0].base;
      this._accent = ACCENT_PRESETS[0];
      this._density = 'normal';
      this._bgColor = '';
      this._surfaceColor = '';
      this._textColor = '';
      this._autoContrast = true;
      this._codeBgColor = '';
      this._codeLineColor = '';
      this._codeTextColor = '';
      this._render();
    }

    _onSettingsInit(state) {
      if (!state) return;
      const ap = (state.appearance) || {};
      this._theme       = ap.colorTheme || 'dark';
      this._accentColor = ap.accentColor || ACCENT_PRESETS[0].base;
      this._accent = ACCENT_PRESETS.find(function (p) { return p.base === ap.accentColor; }) || { base: this._accentColor, deep: this._accentColor, bright: this._accentColor };
      this._density = ap.chatDensity || 'normal';
      this._bgColor        = ap.bgColor || '';
      this._surfaceColor   = ap.surfaceColor || '';
      this._textColor      = ap.textColor || '';
      this._autoContrast   = ap.autoContrast !== false;
      this._codeBgColor    = ap.codeBgColor || '';
      this._codeLineColor  = ap.codeLineColor || '';
      this._codeTextColor  = ap.codeTextColor || '';
      this._applyColorOverrides();
      this._render();
    }

    _onAppearance(data) {
      if (!data) return;
      this._theme       = data.colorTheme || this._theme;
      if (data.accentColor) {
        this._accentColor = data.accentColor;
        this._accent = ACCENT_PRESETS.find(function (p) { return p.base === data.accentColor; }) || { base: data.accentColor, deep: data.accentColor, bright: data.accentColor };
      }
      if (data.chatDensity) this._density = data.chatDensity;
      if (data.bgColor !== undefined)        this._bgColor = data.bgColor || '';
      if (data.surfaceColor !== undefined)   this._surfaceColor = data.surfaceColor || '';
      if (data.textColor !== undefined)      this._textColor = data.textColor || '';
      if (data.autoContrast !== undefined)   this._autoContrast = data.autoContrast !== false;
      if (data.codeBgColor !== undefined)    this._codeBgColor = data.codeBgColor || '';
      if (data.codeLineColor !== undefined)  this._codeLineColor = data.codeLineColor || '';
      if (data.codeTextColor !== undefined)  this._codeTextColor = data.codeTextColor || '';
      this._applyColorOverrides();
      this._render();
    }

    _render() {
      const theme      = this._theme;
      const accent     = this._accent || ACCENT_PRESETS[0];
      const accentBase = this._accentColor || accent.base || '#e0a458';

      const swatchesHtml = ACCENT_PRESETS.map(function (p, i) {
        const isSel = (p.base === accentBase);
        return '<span class="swatch' + (isSel ? ' sel' : '') + '" data-preset="' + i + '" style="background:' + esc(p.base) + '" title="' + esc(p.base) + '"></span>';
      }).join('');

      this.innerHTML =
        '<div class="content-head"><span class="crumb"><b>Appearance</b></span></div>'
        + '<div class="page page-narrow" style="overflow-y:auto">'
        + '<div class="page-title">Appearance</div>'
        + '<div class="page-sub">Tune the plugin\'s look to match your editor.</div>'

        + '<div class="section-label">COLOR THEME</div>'
        + '<div class="grid-3">'
        + this._themeCard('dark',    'Dark',    theme)
        + this._themeCard('light',   'Light',   theme)
        + this._themeCard('classic', 'Classic', theme)
        + '</div>'

        + '<div class="section-label">ACCENT COLOUR</div>'
        + '<div class="card" style="display:flex;align-items:center;gap:11px;padding:14px 16px">'
        + swatchesHtml
        + '<div style="width:1px;height:24px;background:var(--ue-line);margin:0 4px"></div>'
        + '<div style="display:flex;align-items:center;gap:8px;flex:1">'
        + '<span id="sap-color-preview" style="width:26px;height:26px;border-radius:6px;background:' + esc(accentBase) + ';border:1px solid var(--ue-line);flex-shrink:0"></span>'
        + '<input id="sap-hex" type="text" value="' + esc(accentBase) + '" maxlength="7" spellcheck="false" class="mono" style="font-size:12.5px;color:var(--ue-text-mid);background:transparent;border:none;outline:none;flex:1;min-width:0">'
        + '</div></div>'

        + '<div class="section-label">MESSAGE DENSITY</div>'
        + '<div class="card" style="padding:14px 16px">'
        + '<div class="seg-wide" id="sap-density">'
        + [{ value: 'compact', label: 'Compact' }, { value: 'normal', label: 'Normal' }, { value: 'comfortable', label: 'Comfortable' }].map(function (o) {
            return '<span' + (o.value === this._density ? ' class="active"' : '') + ' data-value="' + esc(o.value) + '">' + esc(o.label) + '</span>';
          }, this).join('')
        + '</div>'
        + '<div style="font-size:11.5px;color:var(--ue-text-lo);margin-top:8px">Controls vertical spacing between chat messages.</div>'
        + '</div>'

        + '<div class="section-label">COLORS</div>'
        + '<div class="card">'
        + this._colorFieldHtml(COLOR_FIELDS[0])
        + this._colorFieldHtml(COLOR_FIELDS[1])
        + this._colorFieldHtml(COLOR_FIELDS[2])
        + '<div class="toggle-row" style="padding:12px 0 4px">'
        + '<div class="t"><div class="t-name">Auto-adjust Text Color</div>'
        + '<div class="t-desc">Automatically pick a readable text color from background brightness when Text is left blank (overridden by a manual Text color above).</div></div>'
        + '<div class="toggle' + (this._autoContrast ? ' on' : '') + '" id="sap-auto-contrast"><span class="knob"></span></div>'
        + '</div>'
        + '<div class="section-label" style="margin:14px 0 8px;font-size:9px">CODE BLOCK</div>'
        + this._colorFieldHtml(COLOR_FIELDS[3])
        + this._colorFieldHtml(COLOR_FIELDS[4])
        + this._colorFieldHtml(COLOR_FIELDS[5])
        + '<div class="hint" style="margin-top:10px">Leave a field blank to use the current theme\'s default; overrides apply on top of the selected theme and follow it if you switch themes while a field is blank.</div>'
        + '</div>'

        + window.UECP.saveBar.html(this, 'sap-save')
        + '</div>';

      const self = this;

      this.querySelectorAll('.grid-3 .card[data-theme]').forEach(function (card) {
        card.addEventListener('click', function () {
          self._theme = card.dataset.theme;
          self.querySelectorAll('.grid-3 .card[data-theme]').forEach(function (c) { c.classList.remove('active'); });
          card.classList.add('active');
          self._previewTheme();
          self._applyColorOverrides();
          self._refreshDefaultPreviews();
        });
      });

      this.querySelectorAll('.swatch[data-preset]').forEach(function (sw) {
        sw.addEventListener('click', function () {
          const preset = ACCENT_PRESETS[parseInt(sw.dataset.preset, 10)];
          if (!preset) return;
          self._accent = preset;
          self._accentColor = preset.base;
          self.querySelectorAll('.swatch').forEach(function (s) { s.classList.remove('sel'); });
          sw.classList.add('sel');
          const hex  = self.querySelector('#sap-hex');
          const prev = self.querySelector('#sap-color-preview');
          if (hex)  hex.value = preset.base;
          if (prev) prev.style.background = preset.base;
          self._previewAccent(preset);
        });
      });

      const hexInput  = this.querySelector('#sap-hex');
      const colorPrev = this.querySelector('#sap-color-preview');
      if (hexInput) {
        hexInput.addEventListener('input', function () {
          const val = hexInput.value.trim();
          if (/^#[0-9a-fA-F]{6}$/.test(val)) {
            if (colorPrev) colorPrev.style.background = val;
            self._accentColor = val;
            self._accent = ACCENT_PRESETS.find(function (p) { return p.base === val; }) || { base: val, deep: val, bright: val };
            self.querySelectorAll('.swatch').forEach(function (s) { s.classList.remove('sel'); });
            self._previewAccent(self._accent);
          }
        });
      }

      const densitySeg = this.querySelector('#sap-density');
      if (densitySeg) {
        densitySeg.addEventListener('click', function (e) {
          const item = e.target.closest('span[data-value]');
          if (!item) return;
          self._density = item.dataset.value;
          densitySeg.querySelectorAll('span').forEach(function (s) { s.classList.remove('active'); });
          item.classList.add('active');
          self._previewDensity(self._density);
        });
      }

      COLOR_FIELDS.forEach(function (def) { self._wireColorField(def); });

      const autoToggle = this.querySelector('#sap-auto-contrast');
      if (autoToggle) {
        autoToggle.addEventListener('click', function () {
          self._autoContrast = !self._autoContrast;
          autoToggle.classList.toggle('on', self._autoContrast);
          self._applyColorOverrides();
          self._refreshFieldPreview('text');
        });
      }

      this.querySelector('#sap-save').addEventListener('click', function () { self._save(); });
      window.UECP.saveBar.autosave(this, function () { self._save(); });
    }

    _colorFieldHtml(def) {
      const stored  = this['_' + def.key + 'Color'] || '';
      const preview = this._effectivePreview(def.key, def.cssVar);
      return '<label class="field-label" style="margin-top:12px">' + esc(def.label) + '</label>'
        + '<div class="color-row" style="display:flex;align-items:center;gap:8px;margin-bottom:2px">'
        + '<span id="sap-' + def.key + '-swatch" title="Click to pick a color" style="cursor:pointer;width:24px;height:24px;border-radius:6px;border:1px solid var(--ue-line);flex-shrink:0;background:' + esc(preview) + '"></span>'
        + '<input id="sap-' + def.key + '-hex" type="text" value="' + esc(stored) + '" maxlength="7" spellcheck="false" class="input mono" style="flex:1;padding:7px 10px" placeholder="' + esc(preview) + ' (default)">'
        + '<button class="btn-ghost" type="button" id="sap-' + def.key + '-reset">Reset</button>'
        + '</div>';
    }

    _setColorFieldValue(def, hexInput, v) {
      this['_' + def.key + 'Color'] = v;
      if (hexInput) hexInput.value = v;
      this._applyColorOverrides();
      this._refreshFieldPreview(def.key);
      if (def.key === 'bg') this._refreshFieldPreview('text');
    }

    _wireColorField(def) {
      const self      = this;
      const hexInput  = this.querySelector('#sap-' + def.key + '-hex');
      const resetBtn  = this.querySelector('#sap-' + def.key + '-reset');
      const swatch    = this.querySelector('#sap-' + def.key + '-swatch');
      if (hexInput) {
        hexInput.addEventListener('input', function () {
          const v = hexInput.value.trim();
          if (v !== '' && !HEX_RE.test(v)) return;
          self._setColorFieldValue(def, null, v);
        });
      }
      if (resetBtn) {
        resetBtn.addEventListener('click', function () {
          if (window.UECP && window.UECP.closeColorPicker) window.UECP.closeColorPicker();
          self._setColorFieldValue(def, hexInput, '');
        });
      }
      if (swatch && window.UECP && window.UECP.openColorPicker) {
        swatch.addEventListener('click', function () {
          const seed = self._effectivePreview(def.key, def.cssVar);
          window.UECP.openColorPicker(swatch, seed, function onChange(hex) {
            self._setColorFieldValue(def, hexInput, hex);
          }, function onClose() {  });
        });
      }
    }

    _refreshFieldPreview(key) {
      const def = COLOR_FIELDS.find(function (f) { return f.key === key; });
      if (!def) return;
      const swatch   = this.querySelector('#sap-' + key + '-swatch');
      const hexInput = this.querySelector('#sap-' + key + '-hex');
      const preview  = this._effectivePreview(key, def.cssVar);
      if (swatch) swatch.style.background = preview;
      if (hexInput && !hexInput.value) hexInput.placeholder = preview + ' (default)';
    }

    _refreshDefaultPreviews() {
      const self = this;
      COLOR_FIELDS.forEach(function (def) { self._refreshFieldPreview(def.key); });
    }

    _effectivePreview(key, cssVar) {
      const stored = this['_' + key + 'Color'];
      if (HEX_RE.test(stored)) return stored;
      if (key === 'text' && this._autoContrast) {
        const bg = HEX_RE.test(this._bgColor) ? this._bgColor : this._themeDefault('--ue-bg');
        return this._contrastTextFor(bg);
      }
      return this._themeDefault(cssVar);
    }

    _themeDefault(cssVar) {
      const root = document.documentElement;
      const had = root.style.getPropertyValue(cssVar);
      if (had) root.style.removeProperty(cssVar);
      const val = getComputedStyle(root).getPropertyValue(cssVar).trim();
      if (had) root.style.setProperty(cssVar, had);
      return val || '';
    }

    _contrastTextFor(hex) {
      const m = /^#?([0-9a-fA-F]{6})$/.exec(String(hex || ''));
      if (!m) return '#ece6dc';
      const n = parseInt(m[1], 16);
      const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
      const lin = function (c) { const v = c / 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
      const L = 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b);
      return L > 0.5 ? '#1a1a1a' : '#f0ede8';
    }

    _shiftHex(hex, d) {
      const m = /^#?([0-9a-fA-F]{6})$/.exec(String(hex || ''));
      if (!m) return hex;
      const n = parseInt(m[1], 16);
      const c = [(n >> 16) & 255, (n >> 8) & 255, n & 255].map(function (v) { return Math.max(0, Math.min(255, v + d)); });
      return '#' + c.map(function (v) { return ('0' + v.toString(16)).slice(-2); }).join('');
    }

    _applyColorOverrides() {
      const root = document.documentElement;
      if (HEX_RE.test(this._bgColor)) root.style.setProperty('--ue-bg', this._bgColor);
      else root.style.removeProperty('--ue-bg');

      if (HEX_RE.test(this._surfaceColor)) {
        root.style.setProperty('--ue-panel', this._surfaceColor);
        root.style.setProperty('--ue-elev', this._shiftHex(this._surfaceColor, 18));
      } else {
        root.style.removeProperty('--ue-panel');
        root.style.removeProperty('--ue-elev');
      }

      if (HEX_RE.test(this._textColor)) {
        root.style.setProperty('--ue-text-hi', this._textColor);
      } else if (this._autoContrast) {
        const bg = HEX_RE.test(this._bgColor) ? this._bgColor : this._themeDefault('--ue-bg');
        root.style.setProperty('--ue-text-hi', this._contrastTextFor(bg));
      } else {
        root.style.removeProperty('--ue-text-hi');
      }

      if (HEX_RE.test(this._codeBgColor))   root.style.setProperty('--ue-code-bg', this._codeBgColor);     else root.style.removeProperty('--ue-code-bg');
      if (HEX_RE.test(this._codeLineColor)) root.style.setProperty('--ue-code-line', this._codeLineColor); else root.style.removeProperty('--ue-code-line');
      if (HEX_RE.test(this._codeTextColor)) root.style.setProperty('--ue-code-text', this._codeTextColor); else root.style.removeProperty('--ue-code-text');
    }

    _themeCard(id, label, current) {
      const active = id === current ? ' active' : '';
      const previews = {
        dark:    '<div style="width:34%;background:#191714;border-right:1px solid #2a2620"></div><div style="flex:1;padding:8px"><div style="width:60%;height:7px;border-radius:3px;background:#2a2620;margin-bottom:5px"></div><div style="width:80%;height:7px;border-radius:3px;background:#e0a458"></div></div>',
        light:   '<div style="width:34%;background:#f4f0e8;border-right:1px solid #e4ded2"></div><div style="flex:1;padding:8px"><div style="width:60%;height:7px;border-radius:3px;background:#e4ded2;margin-bottom:5px"></div><div style="width:80%;height:7px;border-radius:3px;background:#c17d35"></div></div>',
        classic: '<div style="width:34%;background:#1f1f1f;border-right:1px solid #0d0d0d"></div><div style="flex:1;padding:8px"><div style="width:60%;height:7px;border-radius:3px;background:#333;margin-bottom:5px"></div><div style="width:80%;height:7px;border-radius:3px;background:#cf7c45"></div></div>',
      };
      const bgMap = { dark: '#121110', light: '#fdfbf7', classic: '#1a1a1a' };
      return '<div class="card' + active + '" data-theme="' + id + '" style="cursor:pointer;padding:3px">'
        + '<div style="border-radius:8px;overflow:hidden;height:64px;display:flex;background:' + (bgMap[id] || '#121110') + '">' + (previews[id] || '') + '</div>'
        + '<div style="text-align:center;font-size:12px;font-weight:500;color:var(--ue-text-mid);padding:7px 0 4px">' + esc(label) + '</div>'
        + '</div>';
    }

    _previewTheme() {
      document.documentElement.dataset.theme = this._theme;
    }

    _previewAccent(accent) {
      const root = document.documentElement;
      root.style.setProperty('--ue-accent',        accent.base   || '');
      root.style.setProperty('--ue-accent-deep',   accent.deep   || '');
      root.style.setProperty('--ue-accent-bright', accent.bright || '');
    }

    _previewDensity(density) {
      const root = document.documentElement;
      if (!density || density === 'normal') root.removeAttribute('data-density');
      else root.setAttribute('data-density', density);
    }

    _save() {
      window.uecp.call('save_preferences', {
        appearance: {
          colorTheme:   this._theme,
          accentColor:  this._accentColor,
          chatDensity:  this._density,
          bgColor:       this._bgColor,
          surfaceColor:  this._surfaceColor,
          textColor:     this._textColor,
          autoContrast:  this._autoContrast,
          codeBgColor:   this._codeBgColor,
          codeLineColor: this._codeLineColor,
          codeTextColor: this._codeTextColor,
        },
      });
      window.UECP.saveBar.flash(this);
    }
  }
  customElements.define('settings-appearance', SettingsAppearance);
})();
