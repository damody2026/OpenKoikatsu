// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"

namespace UECPSteamP2P
{
	void OpenChannel(int32 Channel);
	void CloseChannel(int32 Channel);
	TArray<int32> GetOpenChannels();

	bool HasOpenChannels();

	void PumpMessages();

	void Reset();
}
