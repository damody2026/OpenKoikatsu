// Copyright 2026, BlueprintsLab, All rights reserved
#include "Library/UECPSteamVoiceLibrary.h"

#include "UECPSteamAPI.h"

namespace
{
	constexpr int32 CompressedVoiceBufferBytes = 8 * 1024;

	constexpr int32 DecompressedVoiceBufferBytes = 64 * 1024;
}

bool UUECPSteamVoiceLibrary::StartVoiceRecording()
{
#if UECP_WITH_STEAM
	if (ISteamUser* U = UECPSteam::User()) { U->StartVoiceRecording(); return true; }
#endif
	return false;
}

bool UUECPSteamVoiceLibrary::StopVoiceRecording()
{
#if UECP_WITH_STEAM
	if (ISteamUser* U = UECPSteam::User()) { U->StopVoiceRecording(); return true; }
#endif
	return false;
}

bool UUECPSteamVoiceLibrary::GetCompressedVoice(TArray<uint8>& OutCompressedData)
{
	OutCompressedData.Reset();

#if UECP_WITH_STEAM
	ISteamUser* U = UECPSteam::User();
	if (!U)
	{
		return false;
	}

	TArray<uint8> Buffer;
	Buffer.SetNumUninitialized(CompressedVoiceBufferBytes);
	uint32 Written = 0;

	const EVoiceResult Result = U->GetVoice(true, Buffer.GetData(), Buffer.Num(), &Written);

	if (Result != k_EVoiceResultOK || Written == 0)
	{
		return false;
	}

	Buffer.SetNum(Written, EAllowShrinking::No);
	OutCompressedData = MoveTemp(Buffer);
	return true;
#else
	return false;
#endif
}

bool UUECPSteamVoiceLibrary::DecompressVoice(const TArray<uint8>& CompressedData,
	TArray<uint8>& OutPcmData, int32 SampleRate)
{
	OutPcmData.Reset();

#if UECP_WITH_STEAM
	ISteamUser* U = UECPSteam::User();
	if (!U || CompressedData.Num() == 0)
	{
		return false;
	}

	const uint32 Rate = (SampleRate > 0)
		? static_cast<uint32>(SampleRate)
		: U->GetVoiceOptimalSampleRate();

	TArray<uint8> Buffer;
	Buffer.SetNumUninitialized(DecompressedVoiceBufferBytes);
	uint32 Written = 0;

	EVoiceResult Result = U->DecompressVoice(
		CompressedData.GetData(), CompressedData.Num(),
		Buffer.GetData(), Buffer.Num(), &Written, Rate);

	if (Result == k_EVoiceResultBufferTooSmall && Written > 0)
	{
		Buffer.SetNumUninitialized(Written);
		Result = U->DecompressVoice(
			CompressedData.GetData(), CompressedData.Num(),
			Buffer.GetData(), Buffer.Num(), &Written, Rate);
	}

	if (Result != k_EVoiceResultOK || Written == 0)
	{
		return false;
	}

	Buffer.SetNum(Written, EAllowShrinking::No);
	OutPcmData = MoveTemp(Buffer);
	return true;
#else
	(void)SampleRate;
	return false;
#endif
}

int32 UUECPSteamVoiceLibrary::GetVoiceOptimalSampleRate()
{
#if UECP_WITH_STEAM
	if (ISteamUser* U = UECPSteam::User()) { return static_cast<int32>(U->GetVoiceOptimalSampleRate()); }
#endif
	return 0;
}

bool UUECPSteamVoiceLibrary::IsVoiceRecordingAvailable()
{
#if UECP_WITH_STEAM
	ISteamUser* U = UECPSteam::User();
	if (!U)
	{
		return false;
	}
	uint32 Available = 0;
	return U->GetAvailableVoice(&Available) != k_EVoiceResultNotInitialized;
#else
	return false;
#endif
}
