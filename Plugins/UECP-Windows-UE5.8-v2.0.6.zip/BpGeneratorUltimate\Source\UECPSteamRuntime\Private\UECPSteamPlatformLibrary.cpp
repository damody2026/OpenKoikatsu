// Copyright 2026, BlueprintsLab, All rights reserved
#include "Library/UECPSteamPlatformLibrary.h"

#include "UECPSteamAPI.h"

bool UUECPSteamPlatformLibrary::TriggerScreenshot()
{
#if UECP_WITH_STEAM
	if (ISteamScreenshots* S = UECPSteam::Screenshots()) { S->TriggerScreenshot(); return true; }
#endif
	return false;
}

bool UUECPSteamPlatformLibrary::SetScreenshotHookEnabled(bool bHooked)
{
#if UECP_WITH_STEAM
	if (ISteamScreenshots* S = UECPSteam::Screenshots()) { S->HookScreenshots(bHooked); return true; }
#endif
	return false;
}

int32 UUECPSteamPlatformLibrary::AddScreenshotToLibrary(
	const FString& ImageFilePath, int32 Width, int32 Height)
{
#if UECP_WITH_STEAM
	if (ISteamScreenshots* S = UECPSteam::Screenshots())
	{
		if (!ImageFilePath.IsEmpty() && Width > 0 && Height > 0)
		{
			return static_cast<int32>(S->AddScreenshotToLibrary(
				TCHAR_TO_UTF8(*ImageFilePath), nullptr, Width, Height));
		}
	}
#endif
	return -1;
}

bool UUECPSteamPlatformLibrary::TagUserInScreenshot(int32 ScreenshotId, FUECPSteamID SteamId)
{
#if UECP_WITH_STEAM
	if (ISteamScreenshots* S = UECPSteam::Screenshots())
	{
		if (ScreenshotId >= 0 && SteamId.IsValid())
		{
			return S->TagUser(static_cast<ScreenshotHandle>(ScreenshotId),
				UECPSteam::ToSteamID(SteamId.Value));
		}
	}
#endif
	return false;
}

bool UUECPSteamPlatformLibrary::TagLocationInScreenshot(
	int32 ScreenshotId, const FString& LocationName)
{
#if UECP_WITH_STEAM
	if (ISteamScreenshots* S = UECPSteam::Screenshots())
	{
		if (ScreenshotId >= 0 && !LocationName.IsEmpty())
		{
			return S->SetLocation(static_cast<ScreenshotHandle>(ScreenshotId),
				TCHAR_TO_UTF8(*LocationName));
		}
	}
#endif
	return false;
}

bool UUECPSteamPlatformLibrary::IsMusicEnabled()
{
#if UECP_WITH_STEAM
	if (ISteamMusic* M = UECPSteam::Music()) { return M->BIsEnabled(); }
#endif
	return false;
}

bool UUECPSteamPlatformLibrary::IsMusicPlaying()
{
#if UECP_WITH_STEAM
	if (ISteamMusic* M = UECPSteam::Music()) { return M->BIsPlaying(); }
#endif
	return false;
}

void UUECPSteamPlatformLibrary::PauseMusic()
{
#if UECP_WITH_STEAM
	if (ISteamMusic* M = UECPSteam::Music()) { M->Pause(); }
#endif
}

void UUECPSteamPlatformLibrary::PlayMusic()
{
#if UECP_WITH_STEAM
	if (ISteamMusic* M = UECPSteam::Music()) { M->Play(); }
#endif
}

float UUECPSteamPlatformLibrary::GetMusicVolume()
{
#if UECP_WITH_STEAM
	if (ISteamMusic* M = UECPSteam::Music()) { return M->GetVolume(); }
#endif
	return 0.f;
}

bool UUECPSteamPlatformLibrary::IsParentalLockEnabled()
{
#if UECP_WITH_STEAM
	if (ISteamParentalSettings* P = UECPSteam::ParentalSettings())
	{
		return P->BIsParentalLockEnabled() && !P->BIsParentalLockLocked();
	}
#endif
	return false;
}

bool UUECPSteamPlatformLibrary::IsParentalChatBlocked()
{
#if UECP_WITH_STEAM
	if (ISteamParentalSettings* P = UECPSteam::ParentalSettings())
	{
		return P->BIsFeatureBlocked(k_EFeatureFriends);
	}
#endif
	return false;
}

bool UUECPSteamPlatformLibrary::IsParentalStoreBlocked()
{
#if UECP_WITH_STEAM
	if (ISteamParentalSettings* P = UECPSteam::ParentalSettings())
	{
		return P->BIsFeatureBlocked(k_EFeatureStore);
	}
#endif
	return false;
}

int32 UUECPSteamPlatformLibrary::GetRemotePlaySessionCount()
{
#if UECP_WITH_STEAM
	if (ISteamRemotePlay* R = UECPSteam::RemotePlay()) { return static_cast<int32>(R->GetSessionCount()); }
#endif
	return 0;
}

bool UUECPSteamPlatformLibrary::IsPlayingOnRemoteDevice()
{
#if UECP_WITH_STEAM
	if (ISteamRemotePlay* R = UECPSteam::RemotePlay()) { return R->GetSessionCount() > 0; }
#endif
	return false;
}

bool UUECPSteamPlatformLibrary::ShowRemotePlayTogetherInvite(FUECPSteamID FriendId)
{
#if UECP_WITH_STEAM
	if (ISteamRemotePlay* R = UECPSteam::RemotePlay())
	{
		if (FriendId.IsValid())
		{
			return R->BSendRemotePlayTogetherInvite(UECPSteam::ToSteamID(FriendId.Value));
		}
	}
#endif
	return false;
}

int32 UUECPSteamPlatformLibrary::GetPingToDataCenter(const FString& DataCenterCode)
{
#if UECP_WITH_STEAM
	ISteamNetworkingUtils* N = UECPSteam::NetworkingUtils();
	if (!N || DataCenterCode.IsEmpty())
	{
		return -1;
	}

	const auto Utf8 = StringCast<UTF8CHAR>(*DataCenterCode);
	const SteamNetworkingPOPID PopId =
		CalculateSteamNetworkingPOPIDFromString(reinterpret_cast<const char*>(Utf8.Get()));

	SteamNetworkingPOPID ViaRelay = 0;
	const int32 Ping = N->GetPingToDataCenter(PopId, &ViaRelay);
	return Ping > 0 ? Ping : -1;
#else
	return -1;
#endif
}

bool UUECPSteamPlatformLibrary::IsPingDataReady()
{
#if UECP_WITH_STEAM
	if (ISteamNetworkingUtils* N = UECPSteam::NetworkingUtils())
	{
		return N->GetRelayNetworkStatus(nullptr) == k_ESteamNetworkingAvailability_Current;
	}
#endif
	return false;
}

void UUECPSteamPlatformLibrary::RefreshPingData()
{
#if UECP_WITH_STEAM
	if (ISteamNetworkingUtils* N = UECPSteam::NetworkingUtils())
	{
		N->InitRelayNetworkAccess();
	}
#endif
}
