// Copyright 2026, BlueprintsLab, All rights reserved
#include "Async/UECPSteamStatsAsync.h"

#include "UECPSteamAPI.h"
#include "UECPSteamCallResult.h"

UUECPSteamGetPlayerCount* UUECPSteamGetPlayerCount::GetSteamPlayerCount(UObject* WorldContextObject)
{
	UUECPSteamGetPlayerCount* Node = NewObject<UUECPSteamGetPlayerCount>();
	Node->ContextObject = WorldContextObject;
	Node->RegisterWithGameInstance(WorldContextObject);
	return Node;
}

bool UUECPSteamGetPlayerCount::Start(FUECPSteamError& OutError)
{
#if UECP_WITH_STEAM
	ISteamUserStats* Stats = UECPSteam::UserStats();
	if (!Stats)
	{
		OutError = FUECPSteamError::Unavailable();
		return false;
	}

	const SteamAPICall_t Call = Stats->GetNumberOfCurrentPlayers();
	if (Call == k_uAPICallInvalid)
	{
		OutError = FUECPSteamError(EUECPSteamResult::BackendFailure,
			TEXT("GetNumberOfCurrentPlayers was rejected."));
		return false;
	}

	TWeakObjectPtr<UUECPSteamGetPlayerCount> WeakThis(this);
	UECPSteamSetCallResult<NumberOfCurrentPlayers_t>(CallResultHolder, Call,
		[WeakThis](NumberOfCurrentPlayers_t* Result, bool bIOFailure)
		{
			const bool bOk   = Result && !bIOFailure && Result->m_bSuccess;
			const int32 Count = Result ? Result->m_cPlayers : 0;

			UECPSteam::RunOnGameThread([WeakThis, bOk, Count]()
			{
				UUECPSteamGetPlayerCount* Node = WeakThis.Get();
				if (!Node)
				{
					return;
				}
				Node->PlayerCount = Count;
				bOk ? Node->CompleteSuccess()
				    : Node->CompleteFailure(FUECPSteamError(EUECPSteamResult::BackendFailure,
				        TEXT("Steam could not report the current player count.")));
			});
		});

	return true;
#else
	OutError = FUECPSteamError::Unavailable();
	return false;
#endif
}

void UUECPSteamGetPlayerCount::BroadcastResult(bool bSucceeded, const FUECPSteamError& Error)
{
	(bSucceeded ? OnSuccess : OnFailure).Broadcast(PlayerCount, Error);
}
