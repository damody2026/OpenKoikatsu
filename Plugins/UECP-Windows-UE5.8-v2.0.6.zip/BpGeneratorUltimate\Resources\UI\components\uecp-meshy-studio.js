(function () {
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function svgIcon(n, sz) {
    return (window.UECP && window.UECP.icon) ? window.UECP.icon(n, sz) : '';
  }
  function toast(msg, kind) {
    if (window.UECP && window.UECP.toast) window.UECP.toast(msg, kind || 'info');
  }

  if (!document.getElementById('uecp-meshy-studio-css')) {
    const st = document.createElement('style');
    st.id = 'uecp-meshy-studio-css';
    st.textContent = `
uecp-meshy-studio .st-wrap{flex:1;min-height:0;overflow-y:auto}
uecp-meshy-studio .st-sub{display:none;flex:1;min-height:0;overflow-y:auto;padding:20px;flex-direction:column}
uecp-meshy-studio .st-sub.active{display:flex}
uecp-meshy-studio .st-back{background:none;border:none;cursor:pointer;color:var(--ue-text-mid);font-size:12.5px;display:inline-flex;align-items:center;gap:6px;padding:0 0 12px;text-decoration:none}
uecp-meshy-studio .st-back:hover{color:var(--ue-text-hi)}
uecp-meshy-studio .st-sub-title{font-size:15px;font-weight:700;color:var(--ue-text-hi);display:flex;align-items:center;gap:8px;margin-bottom:4px}
uecp-meshy-studio .st-sub-desc{font-size:12.5px;color:var(--ue-text-mid);margin-bottom:14px}
uecp-meshy-studio .st-field{margin-bottom:12px}
uecp-meshy-studio .st-label{font-size:11.5px;color:var(--ue-text-mid);margin-bottom:4px;font-weight:var(--ue-fw-semi)}
uecp-meshy-studio .st-input{width:100%;background:var(--ue-bg);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm);color:var(--ue-text-hi);padding:6px 10px;font-size:12.5px;box-sizing:border-box}
uecp-meshy-studio .st-input:focus{outline:none;border-color:var(--ue-accent)}
uecp-meshy-studio .st-row{display:flex;gap:8px;margin-bottom:12px;flex-wrap:wrap}
uecp-meshy-studio .st-btn{background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm);color:var(--ue-text-hi);padding:6px 14px;cursor:pointer;font-size:12.5px}
uecp-meshy-studio .st-btn:hover{background:var(--ue-elev)}
uecp-meshy-studio .st-btn-primary{background:var(--ue-accent);border-color:var(--ue-accent);color:var(--ue-on-accent)}
uecp-meshy-studio .st-btn-primary:hover{opacity:.88}
uecp-meshy-studio .st-result{background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm);padding:12px;font-size:12px;color:var(--ue-text-mid);min-height:60px;white-space:pre-wrap;margin-top:8px}
uecp-meshy-studio .st-bone-list{max-height:220px;overflow-y:auto;background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm);margin-top:4px}
uecp-meshy-studio .st-bone-row{display:flex;align-items:center;gap:8px;padding:5px 10px;font-size:12px;color:var(--ue-text-hi);cursor:pointer}
uecp-meshy-studio .st-bone-row:hover{background:var(--ue-elev)}
uecp-meshy-studio .st-bone-row label{cursor:pointer}
uecp-meshy-studio .st-picker{display:flex;gap:12px;align-items:flex-start}
uecp-meshy-studio .st-picker .st-bone-list{flex:1;margin-top:0}
uecp-meshy-studio .st-body{width:170px;flex:0 0 170px;background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm);padding:8px}
uecp-meshy-studio .st-body svg{display:block;width:100%;height:auto}
uecp-meshy-studio .st-zone{fill:var(--ue-elev);stroke:var(--ue-line-soft);stroke-width:2;cursor:pointer}
uecp-meshy-studio .st-zone:hover{fill:var(--ue-accent-soft);stroke:var(--ue-accent)}
uecp-meshy-studio .st-zone.on{fill:var(--ue-accent);stroke:var(--ue-accent-bright)}
uecp-meshy-studio .st-zone.off{fill:none;stroke:var(--ue-line-soft);stroke-dasharray:4 4;cursor:not-allowed;opacity:.5}
uecp-meshy-studio .st-zone-label{fill:var(--ue-text-mid);font-size:15px;text-anchor:middle;pointer-events:none;user-select:none}
uecp-meshy-studio .st-zone-label.on{fill:var(--ue-on-accent)}
uecp-meshy-studio .st-body-hint{font-size:11px;color:var(--ue-text-lo);text-align:center;margin-top:6px;min-height:14px}
uecp-meshy-studio .meshy-tabs{display:flex;gap:4px;flex-wrap:wrap;margin-bottom:14px;border-bottom:1px solid var(--ue-line-soft);padding-bottom:8px}
uecp-meshy-studio .meshy-tab{background:none;border:none;color:var(--ue-text-mid);padding:5px 12px;font-size:12.5px;cursor:pointer;border-radius:var(--ue-r-sm)}
uecp-meshy-studio .meshy-tab.active{background:var(--ue-accent-soft);color:var(--ue-accent-bright)}
uecp-meshy-studio .meshy-form{display:none;flex-direction:column}
uecp-meshy-studio .meshy-form.active{display:flex}
uecp-meshy-studio .meshy-jobs{background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm);padding:10px;margin-top:14px;font-size:12px;color:var(--ue-text-mid)}
uecp-meshy-studio .meshy-job-row{padding:6px 0;border-bottom:1px solid var(--ue-line-soft);display:flex;align-items:center;gap:8px}
uecp-meshy-studio .meshy-job-row:last-child{border-bottom:none}
uecp-meshy-studio .meshy-credits{font-size:12px;color:var(--ue-text-mid);margin-bottom:8px}
uecp-meshy-studio .meshy-anim-dropdown{display:none;position:absolute;left:0;right:0;top:100%;z-index:20;max-height:240px;overflow-y:auto;background:var(--ue-panel);border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);box-shadow:0 6px 18px rgba(0,0,0,.35)}
uecp-meshy-studio .meshy-anim-dropdown.open{display:block}
uecp-meshy-studio .meshy-anim-cat{padding:4px 10px;font-size:10px;letter-spacing:.06em;text-transform:uppercase;color:var(--ue-text-lo);background:var(--ue-bg);position:sticky;top:0}
uecp-meshy-studio .meshy-anim-item{padding:6px 10px;font-size:12.5px;color:var(--ue-text-hi);cursor:pointer;display:flex;justify-content:space-between;gap:8px}
uecp-meshy-studio .meshy-anim-item:hover{background:var(--ue-accent-soft)}
uecp-meshy-studio .meshy-anim-item .aid{color:var(--ue-text-lo);font-family:var(--ue-font-mono);font-size:11px}
uecp-meshy-studio .meshy-anim-dropdown-empty{padding:10px;font-size:12px;color:var(--ue-text-lo)}
uecp-meshy-studio .st-2col{display:grid;grid-template-columns:1fr 1fr;gap:12px}
uecp-meshy-studio .st-history-table{width:100%;border-collapse:collapse;font-size:12px}
uecp-meshy-studio .st-history-table th{text-align:left;color:var(--ue-text-mid);font-weight:var(--ue-fw-semi);padding:5px 8px;border-bottom:1px solid var(--ue-line-soft)}
uecp-meshy-studio .st-history-table td{padding:5px 8px;color:var(--ue-text-hi);vertical-align:top}

/* ---- v2 polish -------------------------------------------------------------
   Appended after the inherited rules so it overrides them, and scoped to this
   element so nothing else on the Tools screen shifts. */
/* Visibility is the HOST's call, signalled the same way in both places: it
   toggles '.active' on this element. The Tools screen hides subpages behind a
   landing grid, so an element that is always visible renders inline underneath
   it -- which is exactly what happened when only the inner content was made
   visible. Cloud Studio marks it active on mount, because a tab IS the page. */
uecp-meshy-studio{display:none}
uecp-meshy-studio.active{display:flex;flex-direction:column;flex:1;min-height:0}
uecp-meshy-studio .st-sub-title{font-size:17px;letter-spacing:.2px;margin-bottom:2px}
uecp-meshy-studio .st-sub-desc{margin-bottom:16px}

/* Tabs read as a segmented control rather than plain words. */
uecp-meshy-studio .meshy-tabs{gap:2px;border-bottom:1px solid var(--ue-line-soft);padding-bottom:0;margin-bottom:16px}
uecp-meshy-studio .meshy-tab{padding:8px 14px;font-size:12.5px;font-weight:var(--ue-fw-semi);
  color:var(--ue-text-mid);border-radius:var(--ue-r-sm) var(--ue-r-sm) 0 0;
  border-bottom:2px solid transparent;transition:color .12s,border-color .12s}
uecp-meshy-studio .meshy-tab:hover{color:var(--ue-text-hi);background:var(--ue-elev)}
uecp-meshy-studio .meshy-tab.active{background:transparent;color:var(--ue-accent-bright);
  border-bottom-color:var(--ue-accent)}

/* Each pane becomes a card, which is what the newer screens do and what makes a
   form look deliberate instead of dumped on the page. */
uecp-meshy-studio .meshy-form.active{display:flex;border:1px solid var(--ue-line-soft);
  border-radius:var(--ue-r-md);background:var(--ue-bg-raise);padding:16px;gap:0}

uecp-meshy-studio .st-field{margin-bottom:14px}
uecp-meshy-studio .st-label{font-size:11px;text-transform:uppercase;letter-spacing:.6px;
  color:var(--ue-text-mid);margin-bottom:6px;font-weight:var(--ue-fw-semi)}
uecp-meshy-studio .st-input{background:var(--ue-bg-sink);padding:8px 10px;font-size:13px;
  border-radius:var(--ue-r-sm);transition:border-color .12s}
uecp-meshy-studio .st-input:focus{outline:none;border-color:var(--ue-accent)}
uecp-meshy-studio textarea.st-input{min-height:64px;resize:vertical;font-family:inherit}

uecp-meshy-studio .st-btn{padding:8px 16px;font-weight:var(--ue-fw-semi);border-radius:var(--ue-r-sm);
  transition:background .12s,border-color .12s}
uecp-meshy-studio .st-btn-primary{background:var(--ue-accent);border-color:var(--ue-accent);
  color:#1a1206}
uecp-meshy-studio .st-btn-primary:hover{filter:brightness(1.08)}

/* Cost and credit lines are money, so they read as a warning rather than as
   another grey paragraph. */
uecp-meshy-studio .tripo-note,
uecp-meshy-studio .meshy-credits{font-size:12px;color:var(--ue-warn,#e0a54a);
  background:var(--ue-elev);border-radius:var(--ue-r-sm);padding:8px 10px;margin:4px 0 12px}

uecp-meshy-studio .meshy-jobs,uecp-meshy-studio .tripo-jobs{margin-top:14px;border-top:1px solid var(--ue-line-soft);
  padding-top:12px}
uecp-meshy-studio .meshy-job-row,uecp-meshy-studio .tripo-job-row{padding:8px 0}
uecp-meshy-studio .st-history-table th{font-size:11px;text-transform:uppercase;letter-spacing:.5px}

/* While a job runs the form folds away, leaving the job list at the top of the
   panel. Without this the user has pressed Generate, sees the same form, and
   presses it again -- and each press is a paid call. */
uecp-meshy-studio.busy .meshy-form.active{display:none}
uecp-meshy-studio .studio-busy{display:none}
uecp-meshy-studio.busy .studio-busy{display:flex;align-items:center;gap:10px;
  border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-md);
  background:var(--ue-bg-raise);padding:12px 14px;margin-bottom:12px}
uecp-meshy-studio .studio-busy-text{flex:1;font-size:12.5px;color:var(--ue-text-hi)}
`;
    document.head.appendChild(st);
  }

  const MESHYJOBS = [];
  const MESHYHISTORY = [];

  class UecpMeshyStudio extends HTMLElement {
    connectedCallback() {
      if (!this._initialised) {
        this._initialised = true;
      this._meshyTab = 'text';
      }
      if (!this.firstChild) this._render();
      this._subscribe();
      if (this._renderMeshyJobs) this._renderMeshyJobs();
    }

    disconnectedCallback() {
      (this._subs || []).forEach(function (u) { try { u(); } catch (e) {} });
      this._subs = [];
    }

    _subscribe() {
      if (!window.uecp || !window.uecp.on) return;
      const self = this;
      this._subs = [
        window.uecp.on('tools.meshy_job_added', function (data) {
          self._onMeshyJobAdded(data);
        }),
        window.uecp.on('tools.meshy_job_progress', function (data) {
          self._onMeshyJobProgress(data.taskId, data.progress, data.status);
        }),
        window.uecp.on('tools.meshy_job_finished', function (data) {
          self._onMeshyJobFinished(data.taskId, data.status, data.body || data);
        }),
        window.uecp.on('tools.meshy_balance', function (data) {
          self._onMeshyBalance(typeof data === 'number' ? data : (data && data.credits) || 0);
        }),
        window.uecp.on('tools.meshy_anim_catalog', function (data) {
          self._onMeshyAnimCatalog(data);
        }),
        window.uecp.on('tools.meshy_asset_picked', function (data) {
          self._onMeshyAssetPicked(data.fieldId, data.assetPath);
        }),
        window.uecp.on('tools.model_source_image', function (data) {
          self._onModelSourceImage(data);
        }),
        window.uecp.on('tools.meshy_history', function (data) {
          self._onMeshyHistoryLoaded(data);
        }),
      ];
    }

    _normPath(p) {
      if (!p) return '';
      const dot = p.indexOf('.');
      return dot === -1 ? p : p.substring(0, dot);
    }

    _toast(msg, sev) {
      if (window.UECP && window.UECP.toast) window.UECP.toast(msg, sev || 'info');
    }

    _backBtn(label) {
      if (typeof this.backButtonFactory === 'function') return this.backButtonFactory(label);
      const span = document.createElement('span');
      span.style.display = 'none';
      return span;
    }

    _maybeAutoChainAnimate(body, status) {
      if (!body || status !== 'done') return;
      if (!this._autoChains) return;
      if (!body.skeleton_path || !body.skeletal_mesh_path) return;
      const keys = Object.keys(this._autoChains);
      let hit = null;
      for (let i = 0; i < keys.length; i++) {
        if (body.skeletal_mesh_path.indexOf(keys[i]) !== -1 || body.skeleton_path.indexOf(keys[i]) !== -1) { hit = keys[i]; break; }
      }
      if (!hit) return;
      const chain = this._autoChains[hit];
      delete this._autoChains[hit];
      window.uecp.call('meshy_animate', Object.assign({
        rig_task_id:         body.task_id,
        skeleton_asset_path: body.skeleton_path,
        change_fps:          chain.fps,
        asset_name:          chain.animAssetName,
        save_path:           chain.savePath
      }, chain.motion || { action_id: chain.actionId }));
      this._toast('Rig complete — animating...', 'info');
    }
    _animateInspectSource() {
      const el = this; if (!el) return;
      const raw = el.querySelector('#st-m-anim-mesh').value.trim();
      const info = el.querySelector('#st-m-anim-meshinfo');
      if (!info) return;
      if (!raw) { info.textContent = ''; return; }
      const path = this._normPath(raw);
      const self = this;
      const rig = (MESHYHISTORY || []).find(function (h) {
        if (h.tool !== 'rigging') return false;
        return self._normPath(h.skeletal_mesh_path) === path
            || self._normPath(h.skeleton_path) === path
            || self._normPath(h.asset_path) === path;
      });
      if (rig) info.innerHTML = '<span style="color:var(--ue-ok,#4fb87a)">✓</span> Already rigged via Meshy — animation only (~3 credits)';
      else     info.innerHTML = '<span style="color:var(--ue-accent-bright)">↻</span> Will auto-rig before animating (~5+3 credits)';
    }
    _submitAnimate() {
      const el = this; if (!el) return;
      const self = this;
      const meshPath  = el.querySelector('#st-m-anim-mesh').value.trim();
      const manualRig = el.querySelector('#st-m-anim-rigid').value.trim();
      const manualSkel= el.querySelector('#st-m-anim-skel').value.trim();

      const manualStr = el.querySelector('#st-m-anim-action-manual').value.trim();
      const fromSelStr = el.querySelector('#st-m-anim-action').value;
      const manual = manualStr ? parseInt(manualStr, 10) : NaN;
      const fromSel = fromSelStr !== '' ? parseInt(fromSelStr, 10) : NaN;
      const actionId = !isNaN(manual) ? manual : fromSel;
      const prompt   = ((el.querySelector('#st-m-anim-prompt')   || {}).value || '').trim();
      const duration = parseFloat((el.querySelector('#st-m-anim-duration') || {}).value) || 4;
      const mode     = (el.querySelector('#st-m-anim-mode')     || {}).value || 'prime';
      if (!prompt && (isNaN(actionId) || actionId < 0)) {
        this._toast('Describe the motion, or pick an animation from the catalog.', 'error'); return;
      }
      const motion = prompt
        ? { prompt: prompt, duration: duration, mode: mode }
        : { action_id: actionId };

      const outName  = el.querySelector('#st-m-anim-asset').value.trim() ||
        (prompt ? '' : ('MeshyAnim_' + actionId));
      const savePath = el.querySelector('#st-m-anim-savepath').value.trim();
      const fps      = parseInt(el.querySelector('#st-m-anim-fps').value, 10) || 0;

      if (manualRig && manualSkel) {
        window.uecp.call('meshy_animate', Object.assign({
          rig_task_id: manualRig, skeleton_asset_path: manualSkel,
          change_fps: fps, asset_name: outName, save_path: savePath
        }, motion));
        return;
      }

      if (!meshPath) { this._toast('Pick a mesh to animate (or fill the Advanced override fields).', 'error'); return; }
      const meshKey = this._normPath(meshPath);

      const rigEntry = (MESHYHISTORY || []).find(function (h) {
        if (h.tool !== 'rigging') return false;
        return self._normPath(h.skeletal_mesh_path) === meshKey
            || self._normPath(h.skeleton_path) === meshKey
            || self._normPath(h.asset_path) === meshKey;
      });
      if (rigEntry && (rigEntry.task_id || rigEntry.taskId) && rigEntry.skeleton_path) {
        window.uecp.call('meshy_animate', Object.assign({
          rig_task_id: rigEntry.task_id || rigEntry.taskId,
          skeleton_asset_path: rigEntry.skeleton_path, change_fps: fps,
          asset_name: outName, save_path: savePath
        }, motion));
        return;
      }

      const meshName = meshPath.split('/').pop().split('.').pop() || 'AutoRig';
      const rigChainKey = meshName + '_Rig_' + Math.floor(Date.now() / 1000).toString(36);
      this._autoChains = this._autoChains || {};
      this._autoChains[rigChainKey] = { motion: motion, animAssetName: outName, savePath: savePath, fps: fps };

      const srcEntry = (MESHYHISTORY || []).find(function (h) {
        return (h.tool === 'text_to_3d' || h.tool === 'text_to_3d_refine' || h.tool === 'image_to_3d')
            && self._normPath(h.asset_path) === meshKey;
      });
      const rigBody = { asset_name: rigChainKey, save_path: savePath, height_meters: 1.7, import_basic_animations: false };
      if (srcEntry && (srcEntry.task_id || srcEntry.taskId)) rigBody.input_task_id = srcEntry.task_id || srcEntry.taskId;
      else rigBody.mesh_asset_path = meshPath;
      window.uecp.call('meshy_rig', rigBody);
      this._toast('Auto-rig started — animation will follow.', 'info');
    }
    _openAnimList() {
      const dd = this.querySelector('#st-m-anim-dropdown');
      if (dd) dd.classList.add('open');
      this._filterAnims();
    }
    _filterAnims() {
      const el = this; if (!el) return;
      const dd = el.querySelector('#st-m-anim-dropdown');
      const search = el.querySelector('#st-m-anim-search');
      if (!dd || !search) return;
      const cat = this._animCatalog;
      if (!cat || !cat.length) { dd.innerHTML = '<div class="meshy-anim-dropdown-empty">Load the catalog first.</div>'; return; }
      const q = search.value.trim().toLowerCase();
      let matches = cat;
      if (q) {
        matches = cat.filter(function (a) {
          return String(a.name || '').toLowerCase().indexOf(q) !== -1
              || String(a.category || '').toLowerCase().indexOf(q) !== -1
              || String(a.action_id) === q;
        });
      }
      if (!matches.length) { dd.innerHTML = '<div class="meshy-anim-dropdown-empty">No matches.</div>'; return; }
      const self = this;
      dd.innerHTML = matches.slice(0, 200).map(function (a) {
        return '<div class="meshy-anim-item" data-aid="' + esc(String(a.action_id)) + '" data-name="' + esc(String(a.name || '')) + '">' +
          '<span>' + esc(String(a.name || a.action_id)) + '</span>' +
          '<span class="aid">#' + esc(String(a.action_id)) + '</span></div>';
      }).join('');
      dd.querySelectorAll('.meshy-anim-item').forEach(function (item) {
        item.addEventListener('click', function () {
          el.querySelector('#st-m-anim-action').value = item.dataset.aid;
          search.value = item.dataset.name || ('action_id ' + item.dataset.aid);
          dd.classList.remove('open');
        });
      });
    }

    _onModelSourceImage(data) {
      const el = this; if (!el) return;
      const label = el.querySelector('#st-m-img-name');
      const name = data && data.name;
      if (label && name) label.textContent = name;
    }

    _syncBusy() {
      const running = MESHYJOBS.some(function (j) { return j && !j.finished; });
      if (running) this.classList.add('busy');
      else this.classList.remove('busy');

      let banner = this.querySelector('.studio-busy');
      if (!banner) {
        const host = this.querySelector('.meshy-tabs');
        if (!host || !host.parentNode) return;
        banner = document.createElement('div');
        banner.className = 'studio-busy';
        banner.innerHTML = '<span class="studio-busy-text">Working&hellip; the form is hidden '
          + 'so you can watch progress below.</span>'
          + '<button class="st-btn" data-show-form="1">Show the form</button>';
        host.parentNode.insertBefore(banner, host.nextSibling);
        const self = this;
        banner.querySelector('[data-show-form]').addEventListener('click', function () {
          self.classList.remove('busy');
        });
      }
    }

    onOpened() {
      window.uecp.call('meshy_get_balance', {});
      window.uecp.call('meshy_load_history', {});
    }

    _render() {
      const built = this._buildMeshy();
      while (this.firstChild) this.removeChild(this.firstChild);

      built.classList.add('active');
      this.appendChild(built);
    }

    _buildMeshy() {
      const el = document.createElement('div');
      el.className = 'st-sub';
      el.id = 'st-sub-meshy';

      el.innerHTML =
        '<div class="st-row" style="justify-content:space-between;align-items:center;margin-bottom:4px">' +
          '<div class="st-sub-title" style="margin-bottom:0">' + svgIcon('ic-box', 14) + ' Meshy Studio</div>' +
          '<span class="meshy-credits" id="st-meshy-credits">- credits</span>' +
        '</div>' +
        '<div class="st-sub-desc">Generate, rig, animate, and re-texture 3D assets with Meshy AI.</div>' +
        '<div class="meshy-tabs" id="st-meshy-tabs">' +
          '<button class="meshy-tab active" data-tab="text">Text→3D</button>' +
          '<button class="meshy-tab" data-tab="image">Image→3D</button>' +
          '<button class="meshy-tab" data-tab="rig">Animate</button>' +
          '<button class="meshy-tab" data-tab="rigonly">Rig</button>' +
          '<button class="meshy-tab" data-tab="retex">Retexture</button>' +
          '<button class="meshy-tab" data-tab="remesh">Remesh</button>' +
          '<button class="meshy-tab" data-tab="txt2img">Text→Image</button>' +
          '<button class="meshy-tab" data-tab="history">History</button>' +
        '</div>' +
        '<div class="meshy-form active" data-meshy-form="text">' +
          '<div class="st-field"><div class="st-label">Prompt</div><textarea class="st-input" id="st-m-text-prompt" rows="3" placeholder="A stylized medieval sword..." style="resize:vertical"></textarea></div>' +
          '<div class="st-field"><div class="st-label">Negative Prompt (optional)</div><input class="st-input" id="st-m-text-neg" placeholder="low-poly, blurry"></div>' +
          '<div class="st-2col">' +
            '<div class="st-field"><div class="st-label">Pose</div><select class="st-input" id="st-m-text-pose"><option value="">Default</option><option value="a-pose">A-Pose</option><option value="t-pose">T-Pose</option></select></div>' +
            '<div class="st-field"><div class="st-label">Asset Name</div><input class="st-input" id="st-m-text-asset" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="GeneratedMesh"></div>' +
          '</div>' +
          '<div class="st-field"><div class="st-label">Save Path</div><input class="st-input" id="st-m-text-savepath" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="/Game/MeshyGen/"></div>' +
          '<label style="display:flex;align-items:center;gap:7px;font-size:12.5px;cursor:pointer;margin-bottom:10px"><input type="checkbox" id="st-m-text-autorefine"> Auto-refine (+10 credits, can cause seams)</label>' +
          '<div class="st-row"><button class="st-btn st-btn-primary" id="st-m-text-go">Generate Model</button></div>' +
        '</div>' +
        '<div class="meshy-form" data-meshy-form="image">' +
          '<div class="st-field"><div class="st-label">Source Image</div><div class="st-row"><button class="st-btn" id="st-m-img-browse">Browse Image</button><span id="st-m-img-name" style="font-size:12px;color:var(--ue-text-mid)">No image selected</span></div></div>' +
          '<div class="st-field"><div class="st-label">Optional Prompt</div><input class="st-input" id="st-m-img-prompt" placeholder="A wooden chest, weathered planks"></div>' +
          '<div class="st-2col">' +
            '<div class="st-field"><div class="st-label">Pose</div><select class="st-input" id="st-m-img-pose"><option value="">Default</option><option value="a-pose">A-Pose</option><option value="t-pose">T-Pose</option></select></div>' +
            '<div class="st-field"><div class="st-label">Asset Name</div><input class="st-input" id="st-m-img-asset" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="MeshyModelFromImage"></div>' +
          '</div>' +
          '<div class="st-field"><div class="st-label">Save Path</div><input class="st-input" id="st-m-img-savepath" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="/Game/MeshyGen/"></div>' +
          '<label style="display:flex;align-items:center;gap:7px;font-size:12.5px;cursor:pointer;margin-bottom:10px"><input type="checkbox" id="st-m-img-autorefine"> Auto-refine (can cause seams)</label>' +
          '<div class="st-row"><button class="st-btn st-btn-primary" id="st-m-img-go">Generate Model</button></div>' +
        '</div>' +
        '<div class="meshy-form" data-meshy-form="rig">' +
          '<div class="st-sub-desc" style="margin-top:0">Animate a humanoid mesh with a motion from Meshy\'s catalog, or describe the motion and Meshy generates it. Unrigged meshes are auto-rigged first, then animated.</div>' +
          '<div class="st-field"><div class="st-label">Mesh to animate</div><div class="st-row"><input class="st-input" id="st-m-anim-mesh" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="/Game/MeshyGen/Wizard" style="flex:1"><button class="st-btn" id="st-m-anim-usesel">Use Selected</button></div>' +
            '<div id="st-m-anim-meshinfo" style="font-size:11.5px;margin-top:4px;color:var(--ue-text-mid)"></div></div>' +
          '<div class="st-field"><div class="st-label">Describe the motion</div>' +
            '<textarea class="st-input" id="st-m-anim-prompt" rows="2" placeholder="a character waves hello with the right hand"></textarea>' +
            '<div style="font-size:11.5px;margin-top:4px;color:var(--ue-text-lo)">Leave empty to use a catalog animation instead.</div></div>' +
          '<div class="st-2col">' +
            '<div class="st-field"><div class="st-label">Seconds (2-10)</div><input class="st-input" type="number" id="st-m-anim-duration" min="2" max="10" step="0.5" value="4"></div>' +
            '<div class="st-field"><div class="st-label">Quality</div><select class="st-input" id="st-m-anim-mode">' +
              '<option value="prime">Prime - best quality (10 credits)</option>' +
              '<option value="swift">Swift - faster and cheaper (3 credits)</option>' +
            '</select></div>' +
          '</div>' +
          '<div class="st-field" style="position:relative"><div class="st-label">Or pick a catalog animation</div><div class="st-row"><input class="st-input" id="st-m-anim-search" placeholder="Load catalog →" style="flex:1" autocomplete="off"><button class="st-btn" id="st-m-anim-catalog">Load catalog</button></div>' +
            '<span id="st-m-anim-catalog-status" style="font-size:11px;color:var(--ue-text-lo)"></span>' +
            '<input type="hidden" id="st-m-anim-action">' +
            '<div class="meshy-anim-dropdown" id="st-m-anim-dropdown"></div></div>' +
          '<div class="st-2col">' +
            '<div class="st-field"><div class="st-label">Animation Name</div><input class="st-input" id="st-m-anim-asset" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="MeshyAnim"></div>' +
            '<div class="st-field"><div class="st-label">Save Path</div><input class="st-input" id="st-m-anim-savepath" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="/Game/MeshyGen/"></div>' +
          '</div>' +
          '<div class="st-2col">' +
            '<div class="st-field"><div class="st-label">FPS (0 = keep)</div><input class="st-input" type="number" id="st-m-anim-fps" min="0" max="120" value="0"></div>' +
            '<div class="st-field"><div class="st-label">Manual action_id (optional)</div><input class="st-input" id="st-m-anim-action-manual" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="overrides catalog pick"></div>' +
          '</div>' +
          '<details style="margin-bottom:10px"><summary style="cursor:pointer;font-size:12px;color:var(--ue-text-mid)">Advanced: animate an already-rigged source</summary>' +
            '<div class="st-2col" style="margin-top:8px">' +
              '<div class="st-field"><div class="st-label">Rig Task ID</div><input class="st-input" id="st-m-anim-rigid" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="prior rig task_id"></div>' +
              '<div class="st-field"><div class="st-label">Skeleton Asset Path</div><input class="st-input" id="st-m-anim-skel" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="/Game/.../SK_...Skeleton"></div>' +
            '</div>' +
          '</details>' +
          '<div class="st-row"><button class="st-btn st-btn-primary" id="st-m-anim-go">Generate Animation</button></div>' +
        '</div>' +
        '<div class="meshy-form" data-meshy-form="rigonly">' +
          '<div class="st-sub-desc" style="margin-top:0">Rig a humanoid mesh (≤300k polys, +Z forward). Produces a skeletal mesh + skeleton, no animation.</div>' +
          '<div class="st-field"><div class="st-label">Mesh Asset Path</div><div class="st-row"><input class="st-input" id="st-m-rig-mesh" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="/Game/MeshyGen/Wizard" style="flex:1"><button class="st-btn" id="st-m-rig-usesel">Use Selected</button></div></div>' +
          '<div class="st-2col">' +
            '<div class="st-field"><div class="st-label">Input Task ID (optional)</div><input class="st-input" id="st-m-rig-taskid" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="prior Meshy job"></div>' +
            '<div class="st-field"><div class="st-label">Model URL (optional)</div><input class="st-input" id="st-m-rig-url" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="https://..."></div>' +
          '</div>' +
          '<div class="st-2col">' +
            '<div class="st-field"><div class="st-label">Height (m)</div><input class="st-input" type="number" id="st-m-rig-height" step="0.1" value="1.7"></div>' +
            '<div class="st-field"><div class="st-label">Asset Name</div><input class="st-input" id="st-m-rig-asset" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="RiggedMesh"></div>' +
          '</div>' +
          '<div class="st-field"><div class="st-label">Save Path</div><input class="st-input" id="st-m-rig-savepath" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="/Game/MeshyGen/"></div>' +
          '<label style="display:flex;align-items:center;gap:7px;font-size:12.5px;cursor:pointer;margin-bottom:10px"><input type="checkbox" id="st-m-rig-anims"> Import basic Walk + Run anims</label>' +
          '<div class="st-row"><button class="st-btn st-btn-primary" id="st-m-rig-go">Rig Model (no animation)</button></div>' +
        '</div>' +
        '<div class="meshy-form" data-meshy-form="retex">' +
          '<div class="st-sub-desc" style="margin-top:0">Re-textures an existing UE StaticMesh asset using a Meshy style prompt.</div>' +
          '<div class="st-field"><div class="st-label">Source Mesh</div><div class="st-row"><input class="st-input" id="st-m-retex-mesh" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="/Game/Meshes/SM_Sword" style="flex:1"><button class="st-btn" id="st-m-retex-usesel">Use Selected</button></div></div>' +
          '<div class="st-field"><div class="st-label">Style Prompt</div><input class="st-input" id="st-m-retex-prompt" placeholder="rusted iron, weathered, dark patina"></div>' +
          '<div class="st-2col"><div class="st-field"><div class="st-label">Material Name</div><input class="st-input" id="st-m-retex-matname" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="M_Sword_Rusted"></div><div class="st-field"><div class="st-label">Save Path</div><input class="st-input" id="st-m-retex-savepath" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="/Game/GeneratedTextures/"></div></div>' +
          '<label style="display:flex;align-items:center;gap:7px;font-size:12.5px;cursor:pointer;margin-bottom:10px"><input type="checkbox" id="st-m-retex-pbr" checked> Enable PBR</label>' +
          '<div class="st-row"><button class="st-btn st-btn-primary" id="st-m-retex-go">Retexture</button></div>' +
        '</div>' +
        '<div class="meshy-form" data-meshy-form="remesh">' +
          '<div class="st-sub-desc" style="margin-top:0">Reshape a mesh to a different topology / polycount.</div>' +
          '<div class="st-field"><div class="st-label">Mesh to remesh</div><div class="st-row"><input class="st-input" id="st-m-remesh-mesh" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="/Game/MeshyGen/SomeMesh" style="flex:1"><button class="st-btn" id="st-m-remesh-usesel">Use Selected</button></div></div>' +
          '<div class="st-2col">' +
            '<div class="st-field"><div class="st-label">Topology</div><select class="st-input" id="st-m-remesh-topology"><option value="quad" selected>Quad</option><option value="triangle">Triangle</option></select></div>' +
            '<div class="st-field"><div class="st-label">Target Polycount</div><input class="st-input" type="number" id="st-m-remesh-poly" min="100" max="300000" value="30000"></div>' +
          '</div>' +
          '<div class="st-2col"><div class="st-field"><div class="st-label">Asset Name</div><input class="st-input" id="st-m-remesh-asset" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="RemeshedModel"></div><div class="st-field"><div class="st-label">Save Path</div><input class="st-input" id="st-m-remesh-savepath" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="/Game/MeshyGen/"></div></div>' +
          '<div class="st-row"><button class="st-btn st-btn-primary" id="st-m-remesh-go">Remesh</button></div>' +
        '</div>' +
        '<div class="meshy-form" data-meshy-form="txt2img">' +
          '<div class="st-sub-desc" style="margin-top:0">Generates a Texture2D from text. Useful as a feeder for Image→3D.</div>' +
          '<div class="st-field"><div class="st-label">Prompt</div><textarea class="st-input" id="st-m-t2i-prompt" rows="3" placeholder="A weathered wooden chest, transparent background" style="resize:vertical"></textarea></div>' +
          '<div class="st-2col">' +
            '<div class="st-field"><div class="st-label">AI Model</div><select class="st-input" id="st-m-t2i-model"><option value="nano-banana-2" selected>nano-banana-2 (default)</option><option value="nano-banana">nano-banana</option><option value="nano-banana-pro">nano-banana-pro</option></select></div>' +
            '<div class="st-field"><div class="st-label">Aspect Ratio</div><select class="st-input" id="st-m-t2i-aspect"><option value="" selected>Default</option><option value="1:1">1:1</option><option value="16:9">16:9</option><option value="9:16">9:16</option></select></div>' +
          '</div>' +
          '<div class="st-field"><div class="st-label">Negative Prompt</div><input class="st-input" id="st-m-t2i-neg" placeholder="blurry, low quality"></div>' +
          '<div class="st-2col"><div class="st-field"><div class="st-label">Asset Name</div><input class="st-input" id="st-m-t2i-asset" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="GeneratedImage"></div><div class="st-field"><div class="st-label">Save Path</div><input class="st-input" id="st-m-t2i-savepath" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="/Game/MeshyGen/"></div></div>' +
          '<div class="st-row"><button class="st-btn st-btn-primary" id="st-m-t2i-go">Generate Image</button></div>' +
        '</div>' +
        '<div class="meshy-form" data-meshy-form="history">' +
          '<table class="st-history-table"><thead><tr><th>Tool</th><th>Status</th><th>Asset</th></tr></thead><tbody id="st-m-hist-body"><tr><td colspan="3" style="padding:14px;text-align:center;color:var(--ue-text-lo)">No jobs run this session yet.</td></tr></tbody></table>' +
        '</div>' +
        '<div class="meshy-jobs" id="st-meshy-jobs"><div style="font-size:11px;font-weight:var(--ue-fw-semi);color:var(--ue-text-mid);margin-bottom:6px">Active Jobs</div><div id="st-meshy-jobs-list" style="color:var(--ue-text-lo);font-size:12px">No active jobs.</div></div>';

      el.prepend(this._backBtn('Back to Tools'));

      const self = this;

      el.querySelector('#st-meshy-tabs').addEventListener('click', function (e) {
        const btn = e.target.closest('.meshy-tab');
        if (!btn) return;
        const tab = btn.dataset.tab;
        el.querySelectorAll('.meshy-tab').forEach(function (t) { t.classList.remove('active'); });
        btn.classList.add('active');
        el.querySelectorAll('.meshy-form').forEach(function (f) { f.classList.remove('active'); });
        const form = el.querySelector('[data-meshy-form="' + tab + '"]');
        if (form) form.classList.add('active');
        self._meshyTab = tab;
        if (tab === 'history') window.uecp.call('meshy_load_history', {});
      });

      el.querySelector('#st-m-text-go').addEventListener('click', function () {
        window.uecp.call('meshy_create_text', {
          prompt:          el.querySelector('#st-m-text-prompt').value.trim(),
          negative_prompt: el.querySelector('#st-m-text-neg').value.trim(),
          pose_mode:       el.querySelector('#st-m-text-pose').value,
          asset_name:      el.querySelector('#st-m-text-asset').value.trim(),
          save_path:       el.querySelector('#st-m-text-savepath').value.trim(),
          auto_refine:     el.querySelector('#st-m-text-autorefine').checked
        });
      });
      el.querySelector('#st-m-img-browse').addEventListener('click', function () {
        window.uecp.call('browse_model_source_image', {});
      });
      el.querySelector('#st-m-img-go').addEventListener('click', function () {
        window.uecp.call('meshy_create_image', {
          prompt:      el.querySelector('#st-m-img-prompt').value.trim(),
          pose_mode:   el.querySelector('#st-m-img-pose').value,
          asset_name:  el.querySelector('#st-m-img-asset').value.trim(),
          save_path:   el.querySelector('#st-m-img-savepath').value.trim(),
          auto_refine: el.querySelector('#st-m-img-autorefine').checked
        });
      });
      el.querySelector('#st-m-anim-usesel').addEventListener('click', function () {
        window.uecp.call('meshy_use_selected_asset', { fieldId: 'st-m-anim-mesh', classFilter: 'Mesh' });
        setTimeout(function () { self._animateInspectSource(); }, 60);
      });
      el.querySelector('#st-m-anim-mesh').addEventListener('input', function () { self._animateInspectSource(); });
      el.querySelector('#st-m-anim-catalog').addEventListener('click', function () {
        window.uecp.call('meshy_list_animations', {});
      });
      const animSearch = el.querySelector('#st-m-anim-search');
      animSearch.addEventListener('focus', function () { self._openAnimList(); });
      animSearch.addEventListener('input', function () { self._filterAnims(); });
      document.addEventListener('click', function (e) {
        const dd = self && self.querySelector('#st-m-anim-dropdown');
        if (dd && !dd.contains(e.target) && e.target !== animSearch) dd.classList.remove('open');
      });
      el.querySelector('#st-m-anim-go').addEventListener('click', function () { self._submitAnimate(); });
      el.querySelector('#st-m-rig-usesel').addEventListener('click', function () {
        window.uecp.call('meshy_use_selected_asset', { fieldId: 'st-m-rig-mesh', classFilter: 'StaticMesh' });
      });
      el.querySelector('#st-m-rig-go').addEventListener('click', function () {
        const meshPath = el.querySelector('#st-m-rig-mesh').value.trim();
        const taskId   = el.querySelector('#st-m-rig-taskid').value.trim();
        const url      = el.querySelector('#st-m-rig-url').value.trim();
        if (!meshPath && !taskId && !url) {
          self._toast('Provide a mesh path, input task ID, or model URL.', 'error');
          return;
        }
        window.uecp.call('meshy_rig', {
          mesh_asset_path:         meshPath,
          input_task_id:           taskId,
          model_url:               url,
          height_meters:           parseFloat(el.querySelector('#st-m-rig-height').value) || 1.7,
          import_basic_animations: el.querySelector('#st-m-rig-anims').checked,
          asset_name:              el.querySelector('#st-m-rig-asset').value.trim(),
          save_path:               el.querySelector('#st-m-rig-savepath').value.trim()
        });
      });
      el.querySelector('#st-m-retex-usesel').addEventListener('click', function () {
        window.uecp.call('meshy_use_selected_asset', { fieldId: 'st-m-retex-mesh', classFilter: 'StaticMesh' });
      });
      el.querySelector('#st-m-retex-go').addEventListener('click', function () {
        window.uecp.call('meshy_retexture', {
          mesh_asset_path: el.querySelector('#st-m-retex-mesh').value.trim(),
          style_prompt:    el.querySelector('#st-m-retex-prompt').value.trim(),
          material_name:   el.querySelector('#st-m-retex-matname').value.trim(),
          save_path:       el.querySelector('#st-m-retex-savepath').value.trim(),
          enable_pbr:      el.querySelector('#st-m-retex-pbr').checked
        });
      });
      el.querySelector('#st-m-remesh-usesel').addEventListener('click', function () {
        window.uecp.call('meshy_use_selected_asset', { fieldId: 'st-m-remesh-mesh', classFilter: 'StaticMesh' });
      });
      el.querySelector('#st-m-remesh-go').addEventListener('click', function () {
        window.uecp.call('meshy_remesh', {
          mesh_asset_path: el.querySelector('#st-m-remesh-mesh').value.trim(),
          topology:        el.querySelector('#st-m-remesh-topology').value,
          poly_count:      parseInt(el.querySelector('#st-m-remesh-poly').value, 10) || 30000,
          asset_name:      el.querySelector('#st-m-remesh-asset').value.trim(),
          save_path:       el.querySelector('#st-m-remesh-savepath').value.trim()
        });
      });
      el.querySelector('#st-m-t2i-go').addEventListener('click', function () {
        window.uecp.call('meshy_text_to_image', {
          prompt:          el.querySelector('#st-m-t2i-prompt').value.trim(),
          ai_model:        el.querySelector('#st-m-t2i-model').value,
          aspect_ratio:    el.querySelector('#st-m-t2i-aspect').value,
          negative_prompt: el.querySelector('#st-m-t2i-neg').value.trim(),
          asset_name:      el.querySelector('#st-m-t2i-asset').value.trim(),
          save_path:       el.querySelector('#st-m-t2i-savepath').value.trim()
        });
      });

      return el;
    }
    _onMeshyJobAdded(info) {
      info = info || {};
      const job = {
        taskId: info.taskId || info.id || '',
        tool:   info.tool || '',
        name:   info.label || info.tool || info.id || '',
        progress: 0, status: 'queued', finished: false
      };
      MESHYJOBS.push(job);
      this._renderMeshyJobs();
      this._syncBusy();
    }
    _onMeshyJobProgress(taskId, progress, status) {
      const job = MESHYJOBS.find(function (j) { return j && j.taskId === taskId; });
      if (job) { job.progress = progress; job.status = status; }
      this._renderMeshyJobs();
      this._syncBusy();
    }
    _onMeshyJobFinished(taskId, status, body) {
      const job = MESHYJOBS.find(function (j) { return j && j.taskId === taskId; });
      const tool = job ? job.tool : '';
      if (job) { job.status = status; job.finished = true; }
      body = body || {};
      MESHYHISTORY.unshift({
        taskId: taskId, status: status, body: body, tool: tool,
        task_id: body.task_id || taskId,
        asset_path: body.asset_path || '',
        skeleton_path: body.skeleton_path || '',
        skeletal_mesh_path: body.skeletal_mesh_path || '',
        time: new Date().toLocaleTimeString()
      });
      this._renderMeshyJobs();
      this._syncBusy();
      this._renderMeshyHistory();
      this._maybeAutoChainAnimate(body, status);
    }
    _renderMeshyJobs() {
      const list = this && this.querySelector('#st-meshy-jobs-list');
      if (!list) return;
      const active = MESHYJOBS.filter(function (j) { return j && !j.finished; });
      if (!active.length) { list.innerHTML = '<span style="color:var(--ue-text-lo)">No active jobs.</span>'; return; }
      list.innerHTML = active.map(function (j) {
        return '<div class="meshy-job-row"><span style="flex:1;color:var(--ue-text-hi)">' + esc(j.name || j.taskId || '') + '</span>' +
          '<span style="color:var(--ue-text-mid)">' + esc(String(j.progress || 0)) + '% ' + esc(j.status || '') + '</span>' +
          '<button class="btn-ghost st-meshy-cancel" data-job-id="' + esc(j.taskId || '') + '" style="font-size:11px;padding:3px 9px;color:var(--ue-danger);border-color:rgba(207,107,90,.3)">Cancel</button></div>';
      }).join('');
      list.querySelectorAll('.st-meshy-cancel').forEach(function (btn) {
        btn.addEventListener('click', function () {
          var jid = btn.dataset.jobId;
          if (jid) window.uecp.call('meshy_cancel_job', { jobId: jid });
        });
      });
    }
    _renderMeshyHistory() {
      const tbody = this && this.querySelector('#st-m-hist-body');
      if (!tbody) return;
      if (!MESHYHISTORY.length) {
        tbody.innerHTML = '<tr><td colspan="3" style="padding:14px;text-align:center;color:var(--ue-text-lo)">No jobs run this session yet.</td></tr>';
        return;
      }
      tbody.innerHTML = MESHYHISTORY.slice(0, 50).map(function (h) {
        var asset = (h.body && (h.body.asset_path || h.body.assetPath)) || h.asset_path || h.taskId || '';
        var view = /^\/Game\//.test(asset)
          ? ' <button class="st-btn" data-view="' + esc(asset) + '" style="padding:2px 8px;font-size:11px">View</button>'
          : '';
        return '<tr><td>' + esc(h.time || '') + '</td><td>' + esc(h.status || '') + '</td><td>'
          + esc(asset) + view + '</td></tr>';
      }).join('');

      const self = this;
      tbody.querySelectorAll('[data-view]').forEach(function (b) {
        b.addEventListener('click', function () {
          window.uecp.call('reveal_asset', { asset_path: b.getAttribute('data-view') });
        });
      });
    }
    _onMeshyBalance(credits) {
      const el = this && this.querySelector('#st-meshy-credits');
      if (el) el.textContent = credits + ' credits';
    }
    _onMeshyAnimCatalog(catalog) {
      const el = this; if (!el) return;
      let arr = catalog;
      if (typeof arr === 'string') { try { arr = JSON.parse(arr); } catch (e) { arr = null; } }
      if (arr && !Array.isArray(arr) && Array.isArray(arr.animations)) arr = arr.animations;
      this._animCatalog = Array.isArray(arr) ? arr : [];
      const status = el.querySelector('#st-m-anim-catalog-status');
      const search = el.querySelector('#st-m-anim-search');
      if (status) status.textContent = this._animCatalog.length ? ('(' + this._animCatalog.length + ' loaded — click to pick)') : '(catalog empty)';
      if (search && this._animCatalog.length) search.placeholder = 'Type to filter ' + this._animCatalog.length + ' animations…';
      this._filterAnims();
    }
    _onMeshyAssetPicked(fieldId, assetPath) {
      const el = this;
      if (!el) return;
      const input = el.querySelector('#' + fieldId);
      if (input) input.value = assetPath;
    }
    _onMeshyHistoryLoaded(jsonArray) {
      try {
        const arr = typeof jsonArray === 'string' ? JSON.parse(jsonArray) : jsonArray;
        if (!Array.isArray(arr)) return;

        const seen = {};
        arr.forEach(function (h) { if (h && h.taskId) seen[h.taskId] = true; });
        const keep = MESHYHISTORY.filter(function (h) { return h && h.taskId && !seen[h.taskId]; });
        MESHYHISTORY.length = 0;
        Array.prototype.push.apply(MESHYHISTORY, keep.concat(arr));
        this._renderMeshyHistory();
      } catch (e) {  }
    }
  }

  UecpMeshyStudio.JOBS = MESHYJOBS;
  UecpMeshyStudio.HISTORY = MESHYHISTORY;

  customElements.define('uecp-meshy-studio', UecpMeshyStudio);
})();
