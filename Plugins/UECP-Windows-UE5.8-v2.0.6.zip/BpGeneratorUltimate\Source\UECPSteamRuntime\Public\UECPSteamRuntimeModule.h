// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "Containers/Ticker.h"
#include "Modules/ModuleManager.h"

DECLARE_LOG_CATEGORY_EXTERN(LogUECPSteam, Log, All);

class UECPSTEAMRUNTIME_API FUECPSteamRuntimeModule : public IModuleInterface
{
public:
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

	static FUECPSteamRuntimeModule& Get()
	{
		return FModuleManager::LoadModuleChecked<FUECPSteamRuntimeModule>(TEXT("UECPSteamRuntime"));
	}

	static bool IsAvailable()
	{
		return FModuleManager::Get().IsModuleLoaded(TEXT("UECPSteamRuntime"));
	}

	static bool IsCompiledWithSteam();

private:
	FTSTicker::FDelegateHandle PumpHandle;

	bool Tick(float DeltaTime);
};
