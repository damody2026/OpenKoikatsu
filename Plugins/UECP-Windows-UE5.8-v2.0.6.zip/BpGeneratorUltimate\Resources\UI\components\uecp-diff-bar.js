(function () {
  if (!document.getElementById('uecp-diff-bar-css')) {
    const s = document.createElement('style'); s.id = 'uecp-diff-bar-css';
    s.textContent = `
uecp-diff-bar{display:block;margin:8px 0}
uecp-diff-bar .diff-card{background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r)}
uecp-diff-bar .diff-head{display:flex;align-items:center;gap:10px;padding:9px 13px;cursor:pointer}
uecp-diff-bar .diff-head-icon{flex-shrink:0;color:var(--ue-text-lo)}
uecp-diff-bar .diff-label{font-size:12px;color:var(--ue-text-mid);white-space:nowrap}
uecp-diff-bar .diff-chips{display:flex;flex-wrap:wrap;align-items:center;gap:2px 10px;flex:1;min-width:0}
uecp-diff-bar .diff-chip{font-size:12px;color:var(--ue-text-mid);white-space:nowrap}
uecp-diff-bar .diff-chip b{font-weight:var(--ue-fw-semi)}
uecp-diff-bar .diff-added b{color:var(--ue-success)}
uecp-diff-bar .diff-removed b{color:var(--ue-danger,#cf6b5a)}
uecp-diff-bar .diff-changed b{color:var(--ue-accent-bright)}
uecp-diff-bar .btn-review-toggle{margin-left:auto;display:inline-flex;align-items:center;gap:4px;padding:5px 8px 5px 12px;background:linear-gradient(150deg,var(--ue-accent),var(--ue-accent-deep));color:var(--ue-on-accent);border:none;border-radius:var(--ue-r-sm);font-size:11.5px;font-weight:var(--ue-fw-semi);cursor:pointer;flex-shrink:0}
uecp-diff-bar .diff-chevron{flex-shrink:0;transition:transform .18s}
uecp-diff-bar.open .diff-chevron{transform:rotate(90deg)}
uecp-diff-bar .diff-detail{display:none;border-top:1px solid var(--ue-line-soft);padding:2px 13px}
uecp-diff-bar.open .diff-detail{display:block}
uecp-diff-bar .diff-row{display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--ue-line-soft)}
uecp-diff-bar .diff-row:last-child{border-bottom:none}
uecp-diff-bar .diff-row-name{flex:0 1 auto;max-width:40%;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12px;font-weight:var(--ue-fw-medium);color:var(--ue-text-hi)}
uecp-diff-bar .btn-review{padding:3px 10px;background:transparent;border:1px solid var(--ue-accent);color:var(--ue-accent-bright);border-radius:var(--ue-r-sm);font-size:11px;font-weight:var(--ue-fw-semi);cursor:pointer;flex-shrink:0}
uecp-diff-bar .diff-expired{font-size:11px;color:var(--ue-text-lo);flex-shrink:0;cursor:default}`;
    document.head.appendChild(s);
  }

  function decodeDiffAttr(raw) {
    if (!raw) return null;
    try { return JSON.parse(decodeURIComponent(raw)); }
    catch (e) { return null; }
  }

  const liveSnaps = new Set();
  function isLive(item) { return !!(item && item.snap) && liveSnaps.has(String(item.snap)); }

  if (window.uecp && typeof window.uecp.on === 'function') {
    window.uecp.on('diff.live', function (data) {
      liveSnaps.clear();
      const ids = (data && data.snaps) || [];
      for (let i = 0; i < ids.length; i++) liveSnaps.add(String(ids[i]));
      if (typeof document.querySelectorAll !== 'function') return;
      const bars = document.querySelectorAll('uecp-diff-bar');
      for (let i = 0; i < bars.length; i++) { if (bars[i]._data) bars[i]._build(); }
    });
  }

  function t(key) {
    return (window.uecp && typeof window.uecp.t === 'function') ? window.uecp.t(key) : key;
  }

  function escText(s) {
    return String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  }

  const KINDS = [
    { key: 'added',       total: 'totalAdded',       cls: 'diff-added',   words: function (n) { return n === 1 ? t('{n} node added') : t('{n} nodes added'); } },
    { key: 'removed',     total: 'totalRemoved',     cls: 'diff-removed', words: function (n) { return n === 1 ? t('{n} node removed') : t('{n} nodes removed'); } },
    { key: 'compAdded',   total: 'totalCompAdded',   cls: 'diff-added',   words: function (n) { return n === 1 ? t('{n} component added') : t('{n} components added'); } },
    { key: 'compRemoved', total: 'totalCompRemoved', cls: 'diff-removed', words: function (n) { return n === 1 ? t('{n} component removed') : t('{n} components removed'); } },
    { key: 'compChanged', total: 'totalCompChanged', cls: 'diff-changed', words: function (n) { return n === 1 ? t('{n} component changed') : t('{n} components changed'); } },
    { key: 'values',      total: 'totalValues',      cls: 'diff-changed', words: function (n) { return n === 1 ? t('{n} value changed') : t('{n} values changed'); } },
    { key: 'links',       total: 'totalLinks',       cls: 'diff-changed', words: function (n) { return n === 1 ? t('{n} connection changed') : t('{n} connections changed'); } },
  ];

  function wordsHtml(part) {
    const m = /^(\s*)([\s\S]*?)(\s*)$/.exec(part);
    return m[1] + (m[2] ? '<span>' + escText(m[2]) + '</span>' : '') + m[3];
  }

  function numberedHtml(n, phrase) {
    const at = phrase.indexOf('{n}');
    if (at < 0) return '<b>' + n + '</b> ' + wordsHtml(phrase);
    return wordsHtml(phrase.slice(0, at)) + '<b>' + n + '</b>' + wordsHtml(phrase.slice(at + 3));
  }

  function chipsHtml(counts, field) {
    let html = '';
    for (let i = 0; i < KINDS.length; i++) {
      const kind = KINDS[i];
      const n = Number(counts[kind[field]] || 0);
      if (!(n > 0)) continue;
      html += '<span class="diff-chip ' + kind.cls + '">' + numberedHtml(n, kind.words(n)) + '</span>';
    }
    return '<span class="diff-chips">' + html + '</span>';
  }

  class UecpDiffBar extends HTMLElement {
    connectedCallback() {
      if (!this.innerHTML) this._build();
    }

    setDiff(data) {
      this._data = data || null;
      this._build();
    }

    _build() {
      const data = this._data || decodeDiffAttr(this.getAttribute('data-diff'));
      if (!data || !data.items || !data.items.length) { this.innerHTML = ''; return; }
      this._data = data;

      const label = data.bpsChanged > 1
        ? '<b>' + Number(data.bpsChanged) + '</b> <span>Blueprints modified:</span>'
        : '<span>Blueprint modified:</span>';
      const icon = (window.UECP && window.UECP.icon) ? window.UECP.icon('ic-bar-chart', 13) : '';
      const esc = (window.UECP && window.UECP.escapeHtml) ? window.UECP.escapeHtml : function (t) { return String(t == null ? '' : t); };
      const anyLive = data.items.some(isLive);
      const open = !!(this.classList && this.classList.contains && this.classList.contains('open'));

      this.innerHTML =
        '<div class="diff-card">' +
          '<div class="diff-head">' +
            '<span class="diff-head-icon">' + icon + '</span>' +
            '<span class="diff-label">' + label + '</span>' +
            chipsHtml(data, 'total') +
            '<button class="btn-review-toggle" aria-expanded="' + (open ? 'true' : 'false') + '">' +
              (anyLive ? '<span>Review</span>' : '<span>Details</span>') +
              '<svg class="diff-chevron" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>' +
            '</button>' +
          '</div>' +
          '<div class="diff-detail">' +
            data.items.map(function (it) {
              const action = isLive(it)
                ? '<button class="btn-review" data-path="' + esc(it.path) + '" data-snap="' + esc(it.snap) + '">Review</button>'
                : '<span class="diff-expired" data-tip="The copy of this Blueprint from before the change is kept only for recent changes in this editor session.">Review expired</span>';
              return '<div class="diff-row">' +
                '<span class="diff-row-name" data-i18n-skip title="' + esc(it.path) + '">' + esc(it.name) + '</span>' +
                chipsHtml(it, 'key') +
                action +
              '</div>';
            }).join('') +
          '</div>' +
        '</div>';

      const self = this;
      const toggle = this.querySelector('.btn-review-toggle');
      this.querySelector('.diff-head').addEventListener('click', function () {
        self.classList.toggle('open');
        if (toggle) toggle.setAttribute('aria-expanded', self.classList.contains('open') ? 'true' : 'false');
      });
      Array.prototype.slice.call(this.querySelectorAll('.btn-review')).forEach(function (btn) {
        btn.addEventListener('click', function (e) {
          e.stopPropagation();
          window.uecp.call('review_changes_bp', {
            path: btn.getAttribute('data-path') || '',
            snap: btn.getAttribute('data-snap') || '',
          });
        });
      });
    }
  }
  customElements.define('uecp-diff-bar', UecpDiffBar);
})();
