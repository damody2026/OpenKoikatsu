// Copyright 2026, BlueprintsLab, All rights reserved
#include "Library/UECPSteamFriendsLibrary.h"

#include "Engine/Texture2D.h"
#include "UECPSteamAPI.h"
#include "UECPSteamImage.h"

#if UECP_WITH_STEAM
namespace
{
	EUECPSteamPersonaState ConvertPersonaState(EPersonaState In)
	{
		switch (In)
		{
		case k_EPersonaStateOnline:         return EUECPSteamPersonaState::Online;
		case k_EPersonaStateBusy:           return EUECPSteamPersonaState::Busy;
		case k_EPersonaStateAway:           return EUECPSteamPersonaState::Away;
		case k_EPersonaStateSnooze:         return EUECPSteamPersonaState::Snooze;
		case k_EPersonaStateLookingToTrade: return EUECPSteamPersonaState::LookingToTrade;
		case k_EPersonaStateLookingToPlay:  return EUECPSteamPersonaState::LookingToPlay;
		case k_EPersonaStateInvisible:      return EUECPSteamPersonaState::Invisible;
		case k_EPersonaStateOffline:
		default:                            return EUECPSteamPersonaState::Offline;
		}
	}

	FUECPSteamFriendInfo BuildFriendInfo(ISteamFriends& F, const CSteamID& Id)
	{
		FUECPSteamFriendInfo Info;
		Info.SteamId      = FUECPSteamID(UECPSteam::FromSteamID(Id));
		Info.PersonaName  = UTF8_TO_TCHAR(F.GetFriendPersonaName(Id));
		Info.PersonaState = ConvertPersonaState(F.GetFriendPersonaState(Id));

		if (const char* Nick = F.GetPlayerNickname(Id))
		{
			Info.Nickname = UTF8_TO_TCHAR(Nick);
		}

		FriendGameInfo_t GameInfo;
		if (F.GetFriendGamePlayed(Id, &GameInfo))
		{
			Info.PlayingAppId = static_cast<int32>(GameInfo.m_gameID.AppID());
			Info.LobbyId      = FUECPSteamID(UECPSteam::FromSteamID(GameInfo.m_steamIDLobby));

			if (ISteamUtils* U = UECPSteam::Utils())
			{
				Info.bIsPlayingThisGame = (GameInfo.m_gameID.AppID() == U->GetAppID());
			}
		}

		return Info;
	}

	int32 AvatarHandle(ISteamFriends& F, const CSteamID& Id, EUECPSteamAvatarSize Size)
	{
		switch (Size)
		{
		case EUECPSteamAvatarSize::Small:  return F.GetSmallFriendAvatar(Id);
		case EUECPSteamAvatarSize::Large:  return F.GetLargeFriendAvatar(Id);
		case EUECPSteamAvatarSize::Medium:
		default:                           return F.GetMediumFriendAvatar(Id);
		}
	}
}
#endif

TArray<FUECPSteamFriendInfo> UUECPSteamFriendsLibrary::GetFriends()
{
	TArray<FUECPSteamFriendInfo> Out;
#if UECP_WITH_STEAM
	ISteamFriends* F = UECPSteam::Friends();
	if (!F)
	{
		return Out;
	}

	const int32 Count = F->GetFriendCount(k_EFriendFlagImmediate);
	Out.Reserve(FMath::Max(0, Count));

	for (int32 Index = 0; Index < Count; ++Index)
	{
		const CSteamID Id = F->GetFriendByIndex(Index, k_EFriendFlagImmediate);
		if (Id.IsValid())
		{
			Out.Add(BuildFriendInfo(*F, Id));
		}
	}
#endif
	return Out;
}

TArray<FUECPSteamFriendInfo> UUECPSteamFriendsLibrary::GetFriendsInGame()
{
	TArray<FUECPSteamFriendInfo> Out;
	for (FUECPSteamFriendInfo& Info : GetFriends())
	{
		if (Info.bIsPlayingThisGame)
		{
			Out.Add(MoveTemp(Info));
		}
	}
	return Out;
}

FUECPSteamFriendInfo UUECPSteamFriendsLibrary::GetFriendInfo(FUECPSteamID SteamId)
{
#if UECP_WITH_STEAM
	ISteamFriends* F = UECPSteam::Friends();
	if (F && SteamId.IsValid())
	{
		return BuildFriendInfo(*F, UECPSteam::ToSteamID(SteamId.Value));
	}
#endif
	return FUECPSteamFriendInfo();
}

FString UUECPSteamFriendsLibrary::GetPersonaName(FUECPSteamID SteamId)
{
#if UECP_WITH_STEAM
	if (ISteamFriends* F = UECPSteam::Friends())
	{
		if (SteamId.IsValid())
		{
			return UTF8_TO_TCHAR(F->GetFriendPersonaName(UECPSteam::ToSteamID(SteamId.Value)));
		}
	}
#endif
	return FString();
}

UTexture2D* UUECPSteamFriendsLibrary::GetAvatar(FUECPSteamID SteamId, EUECPSteamAvatarSize Size)
{
#if UECP_WITH_STEAM
	ISteamFriends* F = UECPSteam::Friends();
	if (!F || !SteamId.IsValid())
	{
		return nullptr;
	}

	const CSteamID Id = UECPSteam::ToSteamID(SteamId.Value);

	F->RequestUserInformation(Id, false);

	return UECPSteam::CreateTextureFromImageHandle(AvatarHandle(*F, Id, Size));
#else
	(void)SteamId; (void)Size;
	return nullptr;
#endif
}

bool UUECPSteamFriendsLibrary::IsFriend(FUECPSteamID SteamId)
{
#if UECP_WITH_STEAM
	if (ISteamFriends* F = UECPSteam::Friends())
	{
		if (SteamId.IsValid())
		{
			return F->HasFriend(UECPSteam::ToSteamID(SteamId.Value), k_EFriendFlagImmediate);
		}
	}
#endif
	return false;
}

bool UUECPSteamFriendsLibrary::SetRichPresence(const FString& Key, const FString& Value)
{
#if UECP_WITH_STEAM
	if (ISteamFriends* F = UECPSteam::Friends())
	{
		return F->SetRichPresence(TCHAR_TO_UTF8(*Key), Value.IsEmpty() ? nullptr : TCHAR_TO_UTF8(*Value));
	}
#endif
	return false;
}

void UUECPSteamFriendsLibrary::ClearRichPresence()
{
#if UECP_WITH_STEAM
	if (ISteamFriends* F = UECPSteam::Friends()) { F->ClearRichPresence(); }
#endif
}

FString UUECPSteamFriendsLibrary::GetFriendRichPresence(FUECPSteamID SteamId, const FString& Key)
{
#if UECP_WITH_STEAM
	if (ISteamFriends* F = UECPSteam::Friends())
	{
		if (SteamId.IsValid())
		{
			return UTF8_TO_TCHAR(F->GetFriendRichPresence(
				UECPSteam::ToSteamID(SteamId.Value), TCHAR_TO_UTF8(*Key)));
		}
	}
#endif
	return FString();
}

void UUECPSteamFriendsLibrary::SetPlayedWith(FUECPSteamID SteamId)
{
#if UECP_WITH_STEAM
	if (ISteamFriends* F = UECPSteam::Friends())
	{
		if (SteamId.IsValid())
		{
			F->SetPlayedWith(UECPSteam::ToSteamID(SteamId.Value));
		}
	}
#endif
}

TMap<FUECPSteamID, FString> UUECPSteamFriendsLibrary::GetClans()
{
	TMap<FUECPSteamID, FString> Out;
#if UECP_WITH_STEAM
	ISteamFriends* F = UECPSteam::Friends();
	if (!F)
	{
		return Out;
	}

	const int32 Count = F->GetClanCount();
	for (int32 Index = 0; Index < Count; ++Index)
	{
		const CSteamID Clan = F->GetClanByIndex(Index);
		if (Clan.IsValid())
		{
			Out.Add(FUECPSteamID(UECPSteam::FromSteamID(Clan)), UTF8_TO_TCHAR(F->GetClanName(Clan)));
		}
	}
#endif
	return Out;
}

FString UUECPSteamFriendsLibrary::GetClanTag(FUECPSteamID ClanId)
{
#if UECP_WITH_STEAM
	if (ISteamFriends* F = UECPSteam::Friends())
	{
		if (ClanId.IsValid()) { return UTF8_TO_TCHAR(F->GetClanTag(UECPSteam::ToSteamID(ClanId.Value))); }
	}
#endif
	return FString();
}

bool UUECPSteamFriendsLibrary::GetClanActivityCounts(
	FUECPSteamID ClanId, int32& Online, int32& InGame, int32& Chatting)
{
	Online = 0; InGame = 0; Chatting = 0;
#if UECP_WITH_STEAM
	ISteamFriends* F = UECPSteam::Friends();
	if (F && ClanId.IsValid())
	{
		const CSteamID Clan = UECPSteam::ToSteamID(ClanId.Value);
		if (F->GetClanActivityCounts(Clan, &Online, &InGame, &Chatting))
		{
			return true;
		}
		CSteamID Pending[1] = { Clan };
		F->DownloadClanActivityCounts(Pending, 1);
	}
#endif
	return false;
}

int32 UUECPSteamFriendsLibrary::GetFollowerCount()
{
#if UECP_WITH_STEAM
	ISteamFriends* F = UECPSteam::Friends();
	ISteamUser* U = UECPSteam::User();
	if (F && U)
	{
		F->GetFollowerCount(U->GetSteamID());
	}
#endif
	return 0;
}

TArray<FUECPSteamID> UUECPSteamFriendsLibrary::GetRecentPlayers()
{
	TArray<FUECPSteamID> Out;
#if UECP_WITH_STEAM
	ISteamFriends* F = UECPSteam::Friends();
	if (!F)
	{
		return Out;
	}

	const int32 Count = F->GetCoplayFriendCount();
	Out.Reserve(FMath::Max(0, Count));
	for (int32 Index = 0; Index < Count; ++Index)
	{
		const CSteamID Id = F->GetCoplayFriend(Index);
		if (Id.IsValid())
		{
			Out.Add(FUECPSteamID(UECPSteam::FromSteamID(Id)));
		}
	}
#endif
	return Out;
}

int64 UUECPSteamFriendsLibrary::GetCoplayTime(FUECPSteamID SteamId)
{
#if UECP_WITH_STEAM
	if (ISteamFriends* F = UECPSteam::Friends())
	{
		if (SteamId.IsValid())
		{
			return static_cast<int64>(F->GetFriendCoplayTime(UECPSteam::ToSteamID(SteamId.Value)));
		}
	}
#endif
	return 0;
}

bool UUECPSteamFriendsLibrary::ShowInviteDialogWithConnectString(const FString& ConnectString)
{
#if UECP_WITH_STEAM
	if (ISteamFriends* F = UECPSteam::Friends())
	{
		if (!ConnectString.IsEmpty())
		{
			F->ActivateGameOverlayInviteDialogConnectString(TCHAR_TO_UTF8(*ConnectString));
			return true;
		}
	}
#endif
	return false;
}
