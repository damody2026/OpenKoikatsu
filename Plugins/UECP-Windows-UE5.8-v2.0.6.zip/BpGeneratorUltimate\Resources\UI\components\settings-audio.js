(function () {
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  const TTS_VOICES = ['alloy','echo','fable','onyx','nova','shimmer'];
  const STT_LANGS = [
    { c: '',   n: 'Auto-detect' }, { c: 'en', n: 'English' }, { c: 'es', n: 'Español' },
    { c: 'fr', n: 'Français' }, { c: 'de', n: 'Deutsch' }, { c: 'it', n: 'Italiano' },
    { c: 'pt', n: 'Português' }, { c: 'nl', n: 'Nederlands' }, { c: 'pl', n: 'Polski' },
    { c: 'ru', n: 'Русский' }, { c: 'uk', n: 'Українська' }, { c: 'ja', n: '日本語' },
    { c: 'ko', n: '한국어' }, { c: 'zh', n: '中文' }, { c: 'ar', n: 'العربية' },
    { c: 'hi', n: 'हिन्दी' }, { c: 'id', n: 'Bahasa Indonesia' }, { c: 'th', n: 'ไทย' },
    { c: 'tr', n: 'Türkçe' }, { c: 'vi', n: 'Tiếng Việt' }, { c: 'ro', n: 'Română' },
  ];

  const WHISPER_MODELS = [
    { id: 'tiny',  name: 'Tiny',  size: '75 MB',  mb: 75,  desc: 'Fastest, lowest accuracy. Good for quick tests or low-end machines.' },
    { id: 'base',  name: 'Base',  size: '142 MB', mb: 142, desc: 'Balanced — good accuracy, fast on CPU. The default.' },
    { id: 'small', name: 'Medium', size: '466 MB', mb: 466, desc: 'More accurate than Base, moderate download. Still fine on CPU.' },
    { id: 'large', name: 'Large', size: '1.6 GB', mb: 1620, rec: 'Best accuracy', desc: 'Most accurate, fully multilingual. Big download; best on a decent machine or GPU.' },
  ];
  const WHISPER_BUILDS = [
    { id: 'cpu',  name: 'CPU',                 size: '8 MB',   mb: 8,   desc: 'Runs on any machine, no GPU needed.' },
    { id: 'blas', name: 'CPU + OpenBLAS',      size: '20 MB',  mb: 20,  desc: 'Faster on CPU.' },
    { id: 'cuda', name: 'NVIDIA GPU (CUDA 12)', size: '640 MB', mb: 640, desc: 'Much faster. Needs an NVIDIA GPU + recent driver.' },
  ];

  const SG_PROVIDERS_FALLBACK = ['OpenAI','ElevenLabs','PlayHT','Custom'];

  const CHEV_SVG = '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>';

  class SettingsAudio extends HTMLElement {
    connectedCallback() {
      this.style.cssText = 'display:flex;flex-direction:column;flex:1;min-height:0;overflow-y:auto';
      this._v = {};
      this._installing = false;
      const self = this;
      window.onWhisperInstallProgress = function (stage, frac, done, ok, msg) {
        self._onWhisperProgress(stage, frac, done, ok, msg);
      };
      this._render();
    }
    disconnectedCallback() {
      if (window.onWhisperInstallProgress) window.onWhisperInstallProgress = null;
    }
    _onSettingsInit(state) {
      this._v = (state && state.voice) || {};
      this._ptt = (state && state.preferences && state.preferences.voicePTTKeybind) || null;
      this._sgKeyCache = this._parseKeyCache(this._v.soundGenKeyCache);
      this._render();
    }

    _parseKeyCache(raw) {
      if (!raw) return {};
      if (typeof raw === 'object') return raw;
      try { return JSON.parse(raw) || {}; } catch (e) { return {}; }
    }

    _fmtPtt() {
      const kb = this._ptt;
      if (kb && kb.key) return (kb.modifier ? kb.modifier + ' + ' : '') + kb.key;
      return this._v.pttKeybind || 'LeftAlt + V';
    }

    _whisper() { return (this._v && this._v.whisper) || {}; }
    _installedModels() { return this._whisper().installedModels || []; }
    _installedBuilds() { return this._whisper().installedVariants || []; }
    _isModelInstalled(id) { return this._installedModels().indexOf(id) !== -1; }
    _isBuildInstalled(id) { return this._installedBuilds().indexOf(id) !== -1; }

    _render() {
      const v = this._v;
      const apiKey    = v.apiKey     || '';
      const enabled   = v.enabled   !== false;
      const autoPlay  = v.autoPlay  ? true : false;
      const autoSend  = v.autoSend  ? true : false;
      const ttsVoice  = v.ttsVoice  || 'alloy';
      const sttLang   = v.sttLanguage || '';
      const provider  = (v.sttProvider === 'local') ? 'local' : 'openai';
      const wModel    = v.whisperModel   || 'base';
      const wBuild    = v.whisperVariant || 'cpu';
      const sgProv    = v.soundGenProvider || 'OpenAI';
      const sgKey     = v.soundGenApiKey   || '';
      const pttStr    = this._fmtPtt();
      const sgProviders = (Array.isArray(v.soundGenProviders) && v.soundGenProviders.length)
        ? v.soundGenProviders
        : SG_PROVIDERS_FALLBACK.map(function (name) { return { provider_id: name, display_name: name }; });

      const isLocal   = provider === 'local';
      const keyHint   = isLocal
        ? 'Optional — only needed for Text-to-Speech playback. Local speech-to-text needs no key.'
        : 'Used for Whisper speech-to-text and TTS playback.';

      this.innerHTML =
        '<div class="content-head"><span class="crumb"><b>Audio</b></span></div>'
        + '<div class="page page-narrow">'
        + '<div class="page-title">Audio</div>'
        + '<div class="page-sub">Speech-to-text for dictating prompts and text-to-speech for reading replies aloud.</div>'

        + '<div class="card" style="margin-top:20px">'
        + '<div class="section-label" style="margin:0 0 13px">SPEECH PROVIDER</div>'
        + '<div style="display:flex;flex-direction:column;gap:13px">'

        + '<div class="seg" style="display:flex;gap:8px">'
        + this._segBtn('sau-prov-openai', 'Cloud (OpenAI)', !isLocal)
        + this._segBtn('sau-prov-local',  'Local — offline', isLocal)
        + '</div>'

        + '<div><div class="field-label">API Key</div>'
        + '<div class="input mono"><input id="sau-api-key" type="password" style="background:transparent;border:none;flex:1;color:inherit;outline:none;font-family:inherit;font-size:inherit" value="' + esc(apiKey) + '" placeholder="sk-…" autocomplete="new-password"><span class="link-hover" style="color:var(--ue-text-mid);font-family:var(--ue-font-sans);font-size:11px;cursor:pointer;margin-left:8px;flex-shrink:0" id="sau-show">Show</span></div>'
        + '<div style="font-size:11.5px;color:var(--ue-text-lo);margin-top:7px;line-height:1.5">' + esc(keyHint) + '</div>'
        + '</div>'

        + (isLocal ? this._renderLocal(wBuild, wModel) : '')

        + '<div><div class="field-label">Speech Language</div>'
        + '<div class="input"><select id="sau-stt-lang" style="background:transparent;border:none;flex:1;color:var(--ue-text-hi);outline:none;font-size:13px;appearance:none">'
        + STT_LANGS.map(function (l) { return '<option value="' + esc(l.c) + '"' + (l.c === sttLang ? ' selected' : '') + '>' + esc(l.n) + '</option>'; }).join('')
        + '</select><span class="chev">' + CHEV_SVG + '</span></div>'
        + '<div style="font-size:11.5px;color:var(--ue-text-lo);margin-top:7px;line-height:1.5">The language you dictate in. Auto-detect works for most; pick one if it mishears you.</div>'
        + '</div>'

        + '<div><div class="field-label">TTS Voice</div>'
        + '<div class="input"><select id="sau-tts-voice" style="background:transparent;border:none;flex:1;color:var(--ue-text-hi);outline:none;font-size:13px;appearance:none">'
        + TTS_VOICES.map(function (vn) { return '<option value="' + esc(vn) + '"' + (vn === ttsVoice ? ' selected' : '') + '>' + esc(vn) + '</option>'; }).join('')
        + '</select><span class="chev">' + CHEV_SVG + '</span></div></div>'

        + '</div></div>'

        + '<div class="toggle-card" style="margin-top:14px">'
        + '<div class="section-label" style="margin:13px 0 4px">VOICE OPTIONS</div>'
        + this._tRow('sau-enabled',   'Voice Enabled',           'Master toggle for all voice functionality.',        enabled)
        + this._tRow('sau-autoplay',  'Auto-Play Responses',     'Automatically read AI replies aloud.',              autoPlay)
        + this._tRow('sau-autosend',  'Auto-Send Transcription', 'Send transcribed text without confirming.',         autoSend)
        + '</div>'

        + '<div class="card" style="margin-top:14px;display:flex;align-items:center;gap:12px;padding:13px 16px">'
        + '<span style="font-size:13px;font-weight:500;flex:1">Push-to-talk shortcut</span>'
        + '<span class="ue-code" id="sau-ptt-chip" style="font-size:12px;padding:5px 11px">' + esc(pttStr) + '</span>'
        + '<button class="btn-ghost" id="sau-ptt-rebind" style="padding:5px 11px;font-size:11.5px">Rebind</button>'
        + '</div>'

        + '<div class="card" style="margin-top:14px">'
        + '<div class="section-label" style="margin:0 0 13px">SOUND GENERATION</div>'
        + '<div style="display:flex;flex-direction:column;gap:13px">'

        + '<div><div class="field-label">Provider</div>'
        + '<div class="input"><select id="sau-sg-provider" style="background:transparent;border:none;flex:1;color:var(--ue-text-hi);outline:none;font-size:13px;appearance:none">'
        + sgProviders.map(function (prov) {
            const id   = typeof prov === 'string' ? prov : (prov.provider_id || prov.display_name || '');
            const name = typeof prov === 'string' ? prov : (prov.display_name || prov.provider_id || '');
            return '<option value="' + esc(id) + '"' + (id === sgProv ? ' selected' : '') + '>' + esc(name) + '</option>';
          }).join('')
        + '</select><span class="chev">' + CHEV_SVG + '</span></div></div>'

        + '<div><div class="field-label">API Key</div>'
        + '<div class="input mono"><input id="sau-sg-key" type="password" style="background:transparent;border:none;flex:1;color:inherit;outline:none;font-family:inherit;font-size:inherit" value="' + esc(sgKey) + '" placeholder="…" autocomplete="new-password"><span class="link-hover" style="color:var(--ue-text-mid);font-family:var(--ue-font-sans);font-size:11px;cursor:pointer;margin-left:8px;flex-shrink:0" id="sau-show-sg">Show</span></div></div>'

        + '</div></div>'

        + window.UECP.saveBar.html(this, 'sau-save')
        + '</div>';

      this._wire();
    }

    _renderLocal(wBuild, wModel) {
      const self = this;
      const buildInstalled = this._isBuildInstalled(wBuild);
      const modelInstalled = this._isModelInstalled(wModel);
      const ready = buildInstalled && modelInstalled;

      const bInfo = WHISPER_BUILDS.find(function (b) { return b.id === wBuild; }) || WHISPER_BUILDS[0];
      const mInfo = WHISPER_MODELS.find(function (m) { return m.id === wModel; }) || WHISPER_MODELS[1];
      const dlMB  = (buildInstalled ? 0 : bInfo.mb) + (modelInstalled ? 0 : mInfo.mb);

      let statusHtml;
      if (ready) {
        statusHtml = '<span style="color:var(--ue-good,#4caf50);font-weight:600">● Ready</span> — ' + esc(mInfo.name) + ' model, ' + esc(bInfo.name) + ' build';
      } else if (!buildInstalled && !modelInstalled) {
        statusHtml = 'Not installed yet. Download a build + model to dictate fully offline.';
      } else if (!modelInstalled) {
        statusHtml = 'Build ready. The <b>' + esc(mInfo.name) + '</b> model still needs downloading.';
      } else {
        statusHtml = 'Model ready. The <b>' + esc(bInfo.name) + '</b> build still needs downloading.';
      }

      const btnLabel = ready
        ? 'Installed'
        : ('Download &amp; Install' + (dlMB > 0 ? ' (' + (dlMB >= 1024 ? (dlMB / 1024).toFixed(1) + ' GB' : dlMB + ' MB') + ')' : ''));

      return ''
        + '<div id="sau-local" style="border:1px solid var(--ue-border,#333);border-radius:8px;padding:14px;display:flex;flex-direction:column;gap:14px;background:var(--ue-bg-2,rgba(255,255,255,0.02))">'
        + '<div class="section-label" style="margin:0">LOCAL ENGINE — whisper.cpp</div>'
        + '<div style="font-size:11.5px;color:var(--ue-text-lo);margin-top:-6px;line-height:1.5">Runs OpenAI\'s Whisper on your machine. No API key, no network — everything stays local. Downloaded once and shared across projects.</div>'

        + '<div><div class="field-label">Build</div>'
        + '<div class="input"><select id="sau-w-build" style="background:transparent;border:none;flex:1;color:var(--ue-text-hi);outline:none;font-size:13px;appearance:none">'
        + WHISPER_BUILDS.map(function (b) {
            const tick = self._isBuildInstalled(b.id) ? ' ✓' : '';
            return '<option value="' + esc(b.id) + '"' + (b.id === wBuild ? ' selected' : '') + '>' + esc(b.name) + ' · ' + esc(b.size) + tick + '</option>';
          }).join('')
        + '</select><span class="chev">' + CHEV_SVG + '</span></div>'
        + '<div style="font-size:11.5px;color:var(--ue-text-lo);margin-top:7px;line-height:1.5">' + esc(bInfo.desc) + '</div>'
        + '</div>'

        + '<div><div class="field-label">Model</div>'
        + '<div style="display:flex;flex-direction:column;gap:8px">'
        + WHISPER_MODELS.map(function (m) {
            const sel = (m.id === wModel);
            const inst = self._isModelInstalled(m.id);
            return '<div class="w-model-row" data-id="' + esc(m.id) + '" style="display:flex;align-items:flex-start;gap:11px;padding:10px 12px;border:1px solid ' + (sel ? 'var(--ue-accent)' : 'var(--ue-border,#333)') + ';border-radius:7px;cursor:pointer;background:' + (sel ? 'var(--ue-accent-dim,rgba(120,150,255,0.08))' : 'transparent') + '">'
              + '<div style="width:15px;height:15px;border-radius:50%;border:2px solid ' + (sel ? 'var(--ue-accent)' : 'var(--ue-text-lo)') + ';margin-top:2px;flex-shrink:0;display:flex;align-items:center;justify-content:center">' + (sel ? '<div style="width:7px;height:7px;border-radius:50%;background:var(--ue-accent)"></div>' : '') + '</div>'
              + '<div style="flex:1;min-width:0">'
              + '<div style="font-size:13px;font-weight:600;display:flex;align-items:center;gap:8px">' + esc(m.name) + ' <span style="font-weight:400;color:var(--ue-text-lo);font-size:11.5px">' + esc(m.size) + '</span>'
              + (m.rec ? '<span style="font-size:10.5px;font-weight:600;color:var(--ue-accent);border:1px solid var(--ue-accent);border-radius:4px;padding:1px 6px">' + esc(m.rec) + '</span>' : '')
              + (inst ? '<span style="font-size:10.5px;font-weight:600;color:var(--ue-good,#4caf50);border:1px solid var(--ue-good,#4caf50);border-radius:4px;padding:1px 6px">Installed</span>' : '')
              + '</div>'
              + '<div style="font-size:11.5px;color:var(--ue-text-lo);margin-top:3px;line-height:1.45">' + esc(m.desc) + '</div>'
              + '</div>'
              + (inst ? '<span class="w-remove link-hover" data-id="' + esc(m.id) + '" style="color:var(--ue-text-mid);font-size:11px;cursor:pointer;flex-shrink:0;margin-top:2px">Remove</span>' : '')
              + '</div>';
          }).join('')
        + '</div></div>'

        + '<div id="sau-w-status" style="font-size:12px;color:var(--ue-text-mid);line-height:1.5">' + statusHtml + '</div>'
        + '<div id="sau-w-progwrap" style="display:none;flex-direction:column;gap:5px">'
        + '<div style="height:6px;border-radius:4px;background:var(--ue-border,#333);overflow:hidden"><div id="sau-w-bar" style="height:100%;width:0%;background:var(--ue-accent);transition:width .2s"></div></div>'
        + '<div id="sau-w-progtext" style="font-size:11px;color:var(--ue-text-lo)"></div>'
        + '</div>'
        + '<button class="btn-primary" id="sau-w-install" style="align-self:flex-start;padding:7px 16px;font-size:12.5px"' + (ready ? ' disabled' : '') + '>' + btnLabel + '</button>'
        + '</div>';
    }

    _segBtn(id, label, on) {
      return '<div id="' + id + '" class="seg-btn' + (on ? ' on' : '') + '" role="button" tabindex="0" style="flex:1;text-align:center;padding:9px 12px;border:1px solid ' + (on ? 'var(--ue-accent)' : 'var(--ue-border,#333)') + ';border-radius:7px;cursor:pointer;font-size:12.5px;font-weight:600;color:' + (on ? 'var(--ue-text-hi)' : 'var(--ue-text-mid)') + ';background:' + (on ? 'var(--ue-accent-dim,rgba(120,150,255,0.08))' : 'transparent') + '">' + esc(label) + '</div>';
    }

    _wire() {
      const self = this;

      function mkShow(btnId, inputId) {
        const b = self.querySelector('#' + btnId);
        if (!b) return;
        b.addEventListener('click', function () {
          const inp = self.querySelector('#' + inputId);
          inp.type = inp.type === 'password' ? 'text' : 'password';
          this.textContent = inp.type === 'password' ? 'Show' : 'Hide';
        });
      }
      mkShow('sau-show',    'sau-api-key');
      mkShow('sau-show-sg', 'sau-sg-key');

      const provOpenai = this.querySelector('#sau-prov-openai');
      const provLocal  = this.querySelector('#sau-prov-local');
      if (provOpenai) provOpenai.addEventListener('click', function () { self._setProvider('openai'); });
      if (provLocal)  provLocal.addEventListener('click',  function () { self._setProvider('local'); });

      const buildSel = this.querySelector('#sau-w-build');
      if (buildSel) buildSel.addEventListener('change', function () {
        self._v.whisperVariant = this.value;
        self._save();
        self._render();
      });
      this.querySelectorAll('.w-model-row').forEach(function (row) {
        row.addEventListener('click', function (e) {
          if (e.target && e.target.classList && e.target.classList.contains('w-remove')) return;
          self._v.whisperModel = row.getAttribute('data-id');
          self._save();
          self._render();
        });
      });
      this.querySelectorAll('.w-remove').forEach(function (rm) {
        rm.addEventListener('click', function (e) {
          e.stopPropagation();
          const id = rm.getAttribute('data-id');
          window.uecp.call('whisper_delete_model', { model: id });
        });
      });
      const installBtn = this.querySelector('#sau-w-install');
      if (installBtn) installBtn.addEventListener('click', function () { self._install(); });

      const provSel = this.querySelector('#sau-sg-provider');
      if (provSel) provSel.addEventListener('change', function () {
        const keyInput = self.querySelector('#sau-sg-key');
        if (keyInput) keyInput.value = (self._sgKeyCache && self._sgKeyCache[this.value]) || '';
      });

      const autosave = function () { self._save(); };
      ['sau-enabled', 'sau-autoplay', 'sau-autosend'].forEach(function (id) {
        const el = self.querySelector('#' + id);
        if (el) el.addEventListener('click', autosave);
      });
      ['sau-tts-voice', 'sau-stt-lang', 'sau-sg-provider'].forEach(function (id) {
        const el = self.querySelector('#' + id);
        if (el) el.addEventListener('change', autosave);
      });
      ['sau-api-key', 'sau-sg-key'].forEach(function (id) {
        const el = self.querySelector('#' + id);
        if (el) el.addEventListener('change', autosave);
      });

      const saveBtn = this.querySelector('#sau-save');
      if (saveBtn) saveBtn.addEventListener('click', function () { self._save(); });

      const pttRebindBtn = this.querySelector('#sau-ptt-rebind');
      if (pttRebindBtn) pttRebindBtn.addEventListener('click', function () { self._startPttRebind(); });

      if (this._installing) this._showProgress(this._lastFrac || 0, this._lastProgText || 'Installing…');
    }

    _setProvider(p) {
      this._v.sttProvider = p;
      this._save();
      this._render();
    }

    _install() {
      const build = this._v.whisperVariant || 'cpu';
      const model = this._v.whisperModel   || 'base';
      this._installing = true;
      this._showProgress(0, 'Starting…');
      const btn = this.querySelector('#sau-w-install');
      if (btn) { btn.disabled = true; btn.textContent = 'Installing…'; }
      window.uecp.call('whisper_install', { variant: build, model: model });
    }

    _showProgress(frac, text) {
      const wrap = this.querySelector('#sau-w-progwrap');
      const bar  = this.querySelector('#sau-w-bar');
      const txt  = this.querySelector('#sau-w-progtext');
      if (wrap) wrap.style.display = 'flex';
      if (bar)  bar.style.width = Math.round((frac || 0) * 100) + '%';
      if (txt)  txt.textContent = text || '';
    }

    _onWhisperProgress(stage, frac, done, ok, msg) {
      this._lastFrac = frac;
      const label = (stage || '') + (msg ? ' · ' + msg : '');
      this._lastProgText = label;
      const btn = this.querySelector('#sau-w-install');

      if (!done) {
        this._showProgress(frac, label);
        if (btn) { btn.disabled = true; btn.textContent = 'Installing… ' + Math.round((frac || 0) * 100) + '%'; }
        return;
      }

      this._installing = false;
      if (ok) {
        this._showProgress(1, 'Done');
        window.uecp.call('whisper_status', {});
      } else {
        this._showProgress(frac || 0, 'Failed' + (msg ? ': ' + msg : ''));
        if (btn) { btn.disabled = false; btn.textContent = 'Retry download'; }
      }
    }

    _startPttRebind() {
      const chip = this.querySelector('#sau-ptt-chip');
      const btn  = this.querySelector('#sau-ptt-rebind');
      if (!chip) return;
      const self = this;
      const prevText = chip.textContent;
      chip.style.borderColor = 'var(--ue-accent)';
      chip.style.color = 'var(--ue-text-lo)';
      chip.textContent = 'Press a key…';
      if (btn) btn.disabled = true;
      window.uecp.call('set_rebind_capturing', { capturing: true });

      if (this._kbHandler) document.removeEventListener('keydown', this._kbHandler, true);
      this._kbHandler = function (e) {
        e.preventDefault(); e.stopPropagation();
        const step = window.SettingsFormat.rebindCaptureStep(e);
        if (step.status === 'cancel') {
          chip.style.borderColor = '';
          chip.style.color = '';
          chip.textContent = prevText;
          if (btn) btn.disabled = false;
          window.uecp.call('set_rebind_capturing', { capturing: false });
          document.removeEventListener('keydown', self._kbHandler, true);
          self._kbHandler = null;
          return;
        }
        if (step.status === 'progress') { chip.textContent = step.display; return; }
        chip.style.borderColor = '';
        chip.style.color = '';
        chip.textContent = (step.modifier ? step.modifier + ' + ' : '') + step.key;
        if (btn) btn.disabled = false;
        self._ptt = { modifier: step.modifier || '', key: step.key };
        window.uecp.call('set_rebind_capturing', { capturing: false });
        window.uecp.call('save_preferences', {
          voicePTTKeybind: { modifier: step.modifier || 'None', key: step.key },
        });
        document.removeEventListener('keydown', self._kbHandler, true);
        self._kbHandler = null;
      };
      document.addEventListener('keydown', this._kbHandler, true);
    }

    _tRow(id, title, desc, checked) {
      return '<div class="toggle-row"><div class="t"><div class="t-name">' + title + '</div><div class="t-desc">' + desc + '</div></div>'
        + '<div class="toggle' + (checked ? ' on' : '') + '" id="' + id + '" onclick="this.classList.toggle(\'on\')" role="switch" aria-checked="' + (checked ? 'true' : 'false') + '" tabindex="0"><span class="knob"></span></div></div>';
    }

    _save() {
      const sgProvider = (this.querySelector('#sau-sg-provider') || {}).value || 'OpenAI';
      const sgKey      = (this.querySelector('#sau-sg-key')      || {}).value || '';
      this._sgKeyCache = this._sgKeyCache || {};
      if (sgKey) this._sgKeyCache[sgProvider] = sgKey;
      const q = function (id, dflt) { const el = this.querySelector('#' + id); return el ? el.value : dflt; }.bind(this);
      const t = function (id) { const el = this.querySelector('#' + id); return el ? el.classList.contains('on') : false; }.bind(this);
      window.uecp.call('save_voice', {
        apiKey:           q('sau-api-key', '') || '',
        enabled:          this.querySelector('#sau-enabled') ? t('sau-enabled') : (this._v.enabled !== false),
        autoPlay:         this.querySelector('#sau-autoplay') ? t('sau-autoplay') : !!this._v.autoPlay,
        autoSend:         this.querySelector('#sau-autosend') ? t('sau-autosend') : !!this._v.autoSend,
        ttsVoice:         q('sau-tts-voice', 'alloy') || 'alloy',
        sttLanguage:      q('sau-stt-lang', '') || '',
        sttProvider:      (this._v.sttProvider === 'local') ? 'local' : 'openai',
        whisperModel:     this._v.whisperModel   || 'base',
        whisperVariant:   this._v.whisperVariant || 'cpu',
        soundGenProvider: sgProvider,
        soundGenApiKey:   sgKey,
        soundGenKeyCache: JSON.stringify(this._sgKeyCache),
      });
      window.UECP.saveBar.flash(this);
    }
  }
  customElements.define('settings-audio', SettingsAudio);
})();
