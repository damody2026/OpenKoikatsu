(function () {
  function el(tag, attrs, children) {
    const n = document.createElement(tag);
    if (attrs) for (const k in attrs) {
      if (k === 'class') n.className = attrs[k];
      else if (k === 'text') n.textContent = attrs[k];
      else if (k.slice(0, 2) === 'on' && typeof attrs[k] === 'function') n.addEventListener(k.slice(2), attrs[k]);
      else if (attrs[k] != null) n.setAttribute(k, attrs[k]);
    }
    if (children) for (const c of [].concat(children)) if (c != null) n.appendChild(typeof c === 'string' ? document.createTextNode(c) : c);
    return n;
  }
  function clear(node) { while (node.firstChild) node.removeChild(node.firstChild); }

  function shouldCloseOnBackdrop(downTarget, upTarget, backdrop) {
    return downTarget === backdrop && upTarget === backdrop;
  }

  function bindBackdropClose(backdrop, closeFn) {
    if (!backdrop) return function () {};
    var downTarget = null;
    function onDown(e) { downTarget = e.target; }
    function onClick(e) {
      if (shouldCloseOnBackdrop(downTarget, e.target, backdrop)) closeFn(e);
      downTarget = null;
    }
    backdrop.addEventListener('mousedown', onDown);
    backdrop.addEventListener('click', onClick);
    return function () {
      backdrop.removeEventListener('mousedown', onDown);
      backdrop.removeEventListener('click', onClick);
    };
  }

  var _collapsed = false;
  var _STORE_KEY = 'uecp.sidebarCollapsed';
  try {
    if (typeof localStorage !== 'undefined' && localStorage.getItem(_STORE_KEY) === '1') _collapsed = true;
  } catch (e) {  }

  function sidebarCollapsed() { return _collapsed; }
  function setSidebarCollapsed(on) {
    _collapsed = !!on;
    try {
      if (typeof localStorage !== 'undefined') localStorage.setItem(_STORE_KEY, _collapsed ? '1' : '0');
    } catch (e) {  }
    return _collapsed;
  }
  function toggleSidebarCollapsed() { return setSidebarCollapsed(!_collapsed); }

  if (typeof document !== 'undefined' && document.addEventListener) {
    ['compositionstart', 'compositionend', 'focusout'].forEach(function (type) {
      document.addEventListener(type, function (e) {
        const t = e.target;
        if (t && t.classList && (t.tagName === 'TEXTAREA' || t.tagName === 'INPUT')) {
          t.classList.toggle('ime-composing', type === 'compositionstart');
        }
      }, true);
    });
  }

  window.UECP = window.UECP || {};
  window.UECP.dom = { el, clear, shouldCloseOnBackdrop, bindBackdropClose };
  window.UECP.sidebar = {
    isCollapsed: sidebarCollapsed,
    setCollapsed: setSidebarCollapsed,
    toggle: toggleSidebarCollapsed,
  };
})();
