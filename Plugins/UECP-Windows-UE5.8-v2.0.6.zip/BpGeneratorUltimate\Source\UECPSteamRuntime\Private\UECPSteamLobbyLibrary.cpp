// Copyright 2026, BlueprintsLab, All rights reserved
#include "Library/UECPSteamLobbyLibrary.h"

#include "UECPSteamAPI.h"

TArray<FUECPSteamID> UUECPSteamLobbyLibrary::GetLobbyMembers(FUECPSteamID LobbyId)
{
	TArray<FUECPSteamID> Out;
#if UECP_WITH_STEAM
	ISteamMatchmaking* MM = UECPSteam::Matchmaking();
	if (!MM || !LobbyId.IsValid())
	{
		return Out;
	}

	const CSteamID Lobby = UECPSteam::ToSteamID(LobbyId.Value);
	const int32 Count = MM->GetNumLobbyMembers(Lobby);
	Out.Reserve(Count);
	for (int32 Index = 0; Index < Count; ++Index)
	{
		Out.Add(FUECPSteamID(UECPSteam::FromSteamID(MM->GetLobbyMemberByIndex(Lobby, Index))));
	}
#endif
	return Out;
}

int32 UUECPSteamLobbyLibrary::GetLobbyMemberLimit(FUECPSteamID LobbyId)
{
#if UECP_WITH_STEAM
	if (ISteamMatchmaking* MM = UECPSteam::Matchmaking())
	{
		if (LobbyId.IsValid()) { return MM->GetLobbyMemberLimit(UECPSteam::ToSteamID(LobbyId.Value)); }
	}
#endif
	return 0;
}

FUECPSteamID UUECPSteamLobbyLibrary::GetLobbyOwner(FUECPSteamID LobbyId)
{
#if UECP_WITH_STEAM
	if (ISteamMatchmaking* MM = UECPSteam::Matchmaking())
	{
		if (LobbyId.IsValid())
		{
			return FUECPSteamID(UECPSteam::FromSteamID(MM->GetLobbyOwner(UECPSteam::ToSteamID(LobbyId.Value))));
		}
	}
#endif
	return FUECPSteamID();
}

FString UUECPSteamLobbyLibrary::GetLobbyData(FUECPSteamID LobbyId, const FString& Key)
{
#if UECP_WITH_STEAM
	if (ISteamMatchmaking* MM = UECPSteam::Matchmaking())
	{
		if (LobbyId.IsValid())
		{
			return UTF8_TO_TCHAR(MM->GetLobbyData(UECPSteam::ToSteamID(LobbyId.Value), TCHAR_TO_UTF8(*Key)));
		}
	}
#endif
	return FString();
}

TMap<FString, FString> UUECPSteamLobbyLibrary::GetAllLobbyData(FUECPSteamID LobbyId)
{
	TMap<FString, FString> Out;
#if UECP_WITH_STEAM
	ISteamMatchmaking* MM = UECPSteam::Matchmaking();
	if (!MM || !LobbyId.IsValid())
	{
		return Out;
	}

	const CSteamID Lobby = UECPSteam::ToSteamID(LobbyId.Value);
	const int32 Count = MM->GetLobbyDataCount(Lobby);
	for (int32 Index = 0; Index < Count; ++Index)
	{
		char Key[k_nMaxLobbyKeyLength] = {};
		char Value[k_cubChatMetadataMax] = {};
		if (MM->GetLobbyDataByIndex(Lobby, Index, Key, UE_ARRAY_COUNT(Key), Value, UE_ARRAY_COUNT(Value)))
		{
			Out.Add(UTF8_TO_TCHAR(Key), UTF8_TO_TCHAR(Value));
		}
	}
#endif
	return Out;
}

bool UUECPSteamLobbyLibrary::SetLobbyData(FUECPSteamID LobbyId, const FString& Key, const FString& Value)
{
#if UECP_WITH_STEAM
	if (ISteamMatchmaking* MM = UECPSteam::Matchmaking())
	{
		if (LobbyId.IsValid())
		{
			return MM->SetLobbyData(UECPSteam::ToSteamID(LobbyId.Value),
				TCHAR_TO_UTF8(*Key), TCHAR_TO_UTF8(*Value));
		}
	}
#endif
	return false;
}

FString UUECPSteamLobbyLibrary::GetLobbyMemberData(
	FUECPSteamID LobbyId, FUECPSteamID MemberId, const FString& Key)
{
#if UECP_WITH_STEAM
	if (ISteamMatchmaking* MM = UECPSteam::Matchmaking())
	{
		if (LobbyId.IsValid() && MemberId.IsValid())
		{
			return UTF8_TO_TCHAR(MM->GetLobbyMemberData(
				UECPSteam::ToSteamID(LobbyId.Value),
				UECPSteam::ToSteamID(MemberId.Value),
				TCHAR_TO_UTF8(*Key)));
		}
	}
#endif
	return FString();
}

bool UUECPSteamLobbyLibrary::SetLobbyMemberData(FUECPSteamID LobbyId, const FString& Key, const FString& Value)
{
#if UECP_WITH_STEAM
	if (ISteamMatchmaking* MM = UECPSteam::Matchmaking())
	{
		if (LobbyId.IsValid())
		{
			MM->SetLobbyMemberData(UECPSteam::ToSteamID(LobbyId.Value),
				TCHAR_TO_UTF8(*Key), TCHAR_TO_UTF8(*Value));
			return true;
		}
	}
#endif
	return false;
}

bool UUECPSteamLobbyLibrary::SendLobbyChatMessage(FUECPSteamID LobbyId, const FString& Message)
{
#if UECP_WITH_STEAM
	ISteamMatchmaking* MM = UECPSteam::Matchmaking();
	if (!MM || !LobbyId.IsValid() || Message.IsEmpty())
	{
		return false;
	}

	const FTCHARToUTF8 Utf8(*Message);
	return MM->SendLobbyChatMsg(UECPSteam::ToSteamID(LobbyId.Value), Utf8.Get(), Utf8.Length() + 1);
#else
	return false;
#endif
}

bool UUECPSteamLobbyLibrary::SetLobbyOwner(FUECPSteamID LobbyId, FUECPSteamID NewOwnerId)
{
#if UECP_WITH_STEAM
	if (ISteamMatchmaking* MM = UECPSteam::Matchmaking())
	{
		if (LobbyId.IsValid() && NewOwnerId.IsValid())
		{
			return MM->SetLobbyOwner(UECPSteam::ToSteamID(LobbyId.Value),
				UECPSteam::ToSteamID(NewOwnerId.Value));
		}
	}
#endif
	return false;
}

bool UUECPSteamLobbyLibrary::SetLobbyJoinable(FUECPSteamID LobbyId, bool bJoinable)
{
#if UECP_WITH_STEAM
	if (ISteamMatchmaking* MM = UECPSteam::Matchmaking())
	{
		if (LobbyId.IsValid())
		{
			return MM->SetLobbyJoinable(UECPSteam::ToSteamID(LobbyId.Value), bJoinable);
		}
	}
#endif
	return false;
}

bool UUECPSteamLobbyLibrary::InviteUserToLobby(FUECPSteamID LobbyId, FUECPSteamID FriendId)
{
#if UECP_WITH_STEAM
	if (ISteamMatchmaking* MM = UECPSteam::Matchmaking())
	{
		if (LobbyId.IsValid() && FriendId.IsValid())
		{
			return MM->InviteUserToLobby(UECPSteam::ToSteamID(LobbyId.Value),
				UECPSteam::ToSteamID(FriendId.Value));
		}
	}
#endif
	return false;
}

void UUECPSteamLobbyLibrary::LeaveLobby(FUECPSteamID LobbyId)
{
#if UECP_WITH_STEAM
	if (ISteamMatchmaking* MM = UECPSteam::Matchmaking())
	{
		if (LobbyId.IsValid()) { MM->LeaveLobby(UECPSteam::ToSteamID(LobbyId.Value)); }
	}
#endif
}
