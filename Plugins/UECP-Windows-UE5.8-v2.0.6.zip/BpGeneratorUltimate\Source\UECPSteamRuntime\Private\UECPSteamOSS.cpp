// Copyright 2026, BlueprintsLab, All rights reserved
#include "UECPSteamOSS.h"

#include "Engine/Engine.h"
#include "Engine/World.h"
#include "Interfaces/OnlineAchievementsInterface.h"
#include "Interfaces/OnlineExternalUIInterface.h"
#include "Interfaces/OnlineFriendsInterface.h"
#include "Interfaces/OnlineLeaderboardInterface.h"
#include "Interfaces/OnlinePresenceInterface.h"
#include "Interfaces/OnlineSharedCloudInterface.h"
#include "Interfaces/OnlineUserCloudInterface.h"
#include "Interfaces/VoiceInterface.h"
#include "OnlineSubsystemNames.h"
#include "OnlineSubsystemUtils.h"
#include "UECPSteamRuntimeModule.h"

IOnlineSubsystem* UECPSteamOSS::Get(const UObject* WorldContextObject)
{
	const UWorld* World = WorldContextObject
		? GEngine->GetWorldFromContextObject(WorldContextObject, EGetWorldErrorMode::ReturnNull)
		: nullptr;

	return World ? Online::GetSubsystem(World, STEAM_SUBSYSTEM)
	             : IOnlineSubsystem::Get(STEAM_SUBSYSTEM);
}

#define UECP_OSS_INTERFACE(PtrType, FuncName, Getter)                       \
	PtrType UECPSteamOSS::FuncName(const UObject* WorldContextObject)       \
	{                                                                       \
		IOnlineSubsystem* OSS = Get(WorldContextObject);                    \
		return OSS ? OSS->Getter() : PtrType();                             \
	}

UECP_OSS_INTERFACE(IOnlineSessionPtr,      Session,      GetSessionInterface)
UECP_OSS_INTERFACE(IOnlineIdentityPtr,     Identity,     GetIdentityInterface)
UECP_OSS_INTERFACE(IOnlineFriendsPtr,      Friends,      GetFriendsInterface)
UECP_OSS_INTERFACE(IOnlineAchievementsPtr, Achievements, GetAchievementsInterface)
UECP_OSS_INTERFACE(IOnlineLeaderboardsPtr, Leaderboards, GetLeaderboardsInterface)
UECP_OSS_INTERFACE(IOnlineUserCloudPtr,    UserCloud,    GetUserCloudInterface)
UECP_OSS_INTERFACE(IOnlineSharedCloudPtr,  SharedCloud,  GetSharedCloudInterface)
UECP_OSS_INTERFACE(IOnlinePresencePtr,     Presence,     GetPresenceInterface)
UECP_OSS_INTERFACE(IOnlineExternalUIPtr,   ExternalUI,   GetExternalUIInterface)
UECP_OSS_INTERFACE(IOnlineVoicePtr,        Voice,        GetVoiceInterface)

#undef UECP_OSS_INTERFACE

FUniqueNetIdPtr UECPSteamOSS::LocalUserId(const UObject* WorldContextObject, int32 LocalUserNum)
{
	const IOnlineIdentityPtr IdentityPtr = Identity(WorldContextObject);
	return IdentityPtr.IsValid() ? IdentityPtr->GetUniquePlayerId(LocalUserNum) : nullptr;
}

FUECPSteamError UECPSteamOSS::InterfaceUnavailable(const TCHAR* InterfaceName)
{
	return FUECPSteamError(EUECPSteamResult::SteamUnavailable,
		FString::Printf(
			TEXT("The Steam %s interface is not available. Check that the OnlineSubsystemSteam plugin is enabled and that DefaultEngine.ini sets [OnlineSubsystem] DefaultPlatformService=Steam."),
			InterfaceName));
}

FUECPSteamError UECPSteamOSS::NoLocalUser()
{
	return FUECPSteamError(EUECPSteamResult::NotLoggedIn,
		TEXT("No local user is signed in to Steam."));
}

FUECPSteamID UECPSteamOSS::ToSteamID(const FUniqueNetId& NetId)
{
	if (NetId.GetSize() == sizeof(uint64))
	{
		uint64 Raw = 0;
		FMemory::Memcpy(&Raw, NetId.GetBytes(), sizeof(uint64));
		return FUECPSteamID(static_cast<int64>(Raw));
	}

	uint64 Parsed = 0;
	LexFromString(Parsed, *NetId.ToString());
	return FUECPSteamID(static_cast<int64>(Parsed));
}

FUECPSteamID UECPSteamOSS::ToSteamID(const FUniqueNetIdPtr& NetId)
{
	return NetId.IsValid() ? ToSteamID(*NetId) : FUECPSteamID();
}
