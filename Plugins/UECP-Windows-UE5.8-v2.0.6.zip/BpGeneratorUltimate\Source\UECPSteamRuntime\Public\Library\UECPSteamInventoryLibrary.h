// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "Async/UECPSteamAsyncAction.h"
#include "CoreMinimal.h"
#include "Containers/Ticker.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "UECPSteamTypes.h"
#include "UECPSteamInventoryLibrary.generated.h"

USTRUCT(BlueprintType)
struct UECPSTEAMRUNTIME_API FUECPSteamInventoryItem
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	int64 ItemId = 0;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	int32 DefinitionId = 0;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	int32 Quantity = 0;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	bool bTradable = false;
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FUECPSteamInventorySignature,
	const TArray<FUECPSteamInventoryItem>&, Items, FUECPSteamError, Error);

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamGetInventory : public UUECPSteamAsyncAction
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Inventory",
		meta = (BlueprintInternalUseOnly = "true", WorldContext = "WorldContextObject",
		        DisplayName = "Get Steam Inventory"))
	static UUECPSteamGetInventory* GetSteamInventory(UObject* WorldContextObject);

	UPROPERTY(BlueprintAssignable)
	FUECPSteamInventorySignature OnSuccess;

	UPROPERTY(BlueprintAssignable)
	FUECPSteamInventorySignature OnFailure;

protected:
	virtual bool Start(FUECPSteamError& OutError) override;
	virtual void BroadcastResult(bool bSucceeded, const FUECPSteamError& Error) override;
	virtual void OnCleanup() override;

private:
	TArray<FUECPSteamInventoryItem> Items;

	int32 ResultHandle = -1;

	FTSTicker::FDelegateHandle PollHandle;
	double PollStartSeconds = 0.0;

	bool PollResult(float DeltaTime);
	void ReleaseResult();
};

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamInventoryLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Inventory")
	static bool LoadItemDefinitions();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Inventory")
	static TArray<int32> GetItemDefinitionIds();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Inventory")
	static FString GetItemDefinitionProperty(int32 DefinitionId, const FString& PropertyName);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Inventory")
	static bool ConsumeItem(int64 ItemId, int32 Quantity = 1);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Inventory")
	static bool TriggerItemDrop(int32 DefinitionId);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Inventory")
	static bool GrantPromoItems();
};
