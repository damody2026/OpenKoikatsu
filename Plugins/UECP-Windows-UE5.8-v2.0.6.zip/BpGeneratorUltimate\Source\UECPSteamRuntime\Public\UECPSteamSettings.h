// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "Engine/DeveloperSettings.h"
#include "UECPSteamSettings.generated.h"

UCLASS(config = Engine, defaultconfig, meta = (DisplayName = "UECP Steam"))
class UECPSTEAMRUNTIME_API UUECPSteamSettings : public UDeveloperSettings
{
	GENERATED_BODY()

public:
	UUECPSteamSettings();

	UPROPERTY(config, EditAnywhere, Category = "Lifecycle")
	bool bAutoAcquireOnGameInstanceStart = true;

	UPROPERTY(config, EditAnywhere, Category = "Diagnostics")
	bool bVerboseCallbackLogging = false;

	virtual FName GetCategoryName() const override;

	static const UUECPSteamSettings* Get();
};
