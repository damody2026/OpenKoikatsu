// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "UECPSteamTypes.h"
#include "UECPSteamUtilsLibrary.generated.h"

UENUM(BlueprintType)
enum class EUECPSteamNotificationPosition : uint8
{
	TopLeft     UMETA(DisplayName = "Top Left"),
	TopRight    UMETA(DisplayName = "Top Right"),
	BottomLeft  UMETA(DisplayName = "Bottom Left"),
	BottomRight UMETA(DisplayName = "Bottom Right"),
};

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamUtilsLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Utils")
	static int32 GetSteamAppId();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Utils")
	static bool IsRunningOnSteamDeck();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Utils")
	static bool IsSteamInBigPictureMode();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Utils")
	static bool IsSteamRunningInVR();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Utils")
	static bool IsOverlayEnabled();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Utils")
	static FString GetIPCountry();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Utils")
	static FString GetSteamUILanguage();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Utils")
	static int32 GetCurrentBatteryPower();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Utils")
	static int32 GetSecondsSinceAppActive();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Utils")
	static int64 GetServerRealTime();

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Utils")
	static void SetOverlayNotificationPosition(EUECPSteamNotificationPosition Position);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Utils")
	static void SetOverlayNotificationInset(int32 HorizontalInset, int32 VerticalInset);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Utils")
	static FString FilterText(const FString& Text, FUECPSteamID SpeakerSteamId);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Utils",
		meta = (AdvancedDisplay = "bMultiline,MaxLength"))
	static bool ShowGamepadTextInput(const FString& Description, const FString& ExistingText,
		bool bPassword = false, bool bMultiline = false, int32 MaxLength = 256);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Utils")
	static FString GetEnteredGamepadTextInput();
};
