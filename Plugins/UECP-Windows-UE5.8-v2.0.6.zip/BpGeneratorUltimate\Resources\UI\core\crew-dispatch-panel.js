(function () {
  if (typeof document === 'undefined') return;

  function esc(s) { return window.UECP.escapeHtml(s == null ? '' : String(s)); }

  if (!document.getElementById('uecp-crew-dispatch-css')) {
    var st = document.createElement('style'); st.id = 'uecp-crew-dispatch-css';
    st.textContent =
      '#uecp-crew-dispatch{position:fixed;z-index:9500;display:none;width:380px;' +
      'background:var(--ue-panel);color:var(--ue-text-hi);border:1px solid var(--ue-line);border-radius:var(--ue-r);' +
      'padding:14px 16px;font-family:var(--ue-font-sans);font-size:12.5px;box-shadow:var(--ue-shadow-pop,0 8px 24px rgba(0,0,0,.35))}' +
      '#uecp-crew-dispatch.open{display:block}' +
      '#uecp-crew-dispatch h4{margin:0 0 10px;font-size:13px}' +
      '#uecp-crew-dispatch label{display:block;font-size:10.5px;text-transform:uppercase;letter-spacing:.4px;color:var(--ue-text-lo);margin-bottom:3px}' +
      '#uecp-crew-dispatch textarea{width:100%;box-sizing:border-box;background:var(--ue-elev);border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);color:var(--ue-text-hi);padding:7px 9px;font-family:inherit;font-size:12.5px;resize:vertical;min-height:70px;margin-bottom:10px}' +
      '#uecp-crew-dispatch .cdp-row{display:flex;gap:8px;margin-bottom:10px}' +
      '#uecp-crew-dispatch .cdp-row > div{flex:1}' +
      '#uecp-crew-dispatch select{width:100%;box-sizing:border-box;background:var(--ue-elev);border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);color:var(--ue-text-hi);padding:6px 8px;font-family:inherit;font-size:12px}' +
      '#uecp-crew-dispatch .cdp-btns{display:flex;justify-content:flex-end;gap:8px}' +
      '#uecp-crew-dispatch .cdp-cancel{font-size:12px;color:var(--ue-text-mid);background:var(--ue-elev);border:1px solid var(--ue-line);padding:6px 12px;border-radius:var(--ue-r-sm);cursor:pointer}' +
      '#uecp-crew-dispatch .cdp-go{font-size:12px;font-weight:var(--ue-fw-semi,600);color:var(--ue-on-accent);background:var(--ue-accent);border:none;padding:6px 12px;border-radius:var(--ue-r-sm);cursor:pointer}';
    document.head.appendChild(st);
  }

  var _el = null;
  var _roles = null;
  var _anchorEl = null;

  function ensureEl() {
    if (_el) return _el;
    _el = document.createElement('div');
    _el.id = 'uecp-crew-dispatch';
    document.body.appendChild(_el);
    return _el;
  }

  function fetchRoles(cb) {
    if (_roles) { cb(_roles); return; }
    window.uecp.on('subagent.roles', function (d) { _roles = (d && d.roles) || []; cb(_roles); });
    window.uecp.call('list_subagent_roles', {});
  }

  function roleOpts(selected) {
    return (_roles || []).map(function (r) {
      return '<option value="' + esc(r.id) + '"' + (r.id === selected ? ' selected' : '') + '>' + esc(r.name || r.id) + '</option>';
    }).join('');
  }

  function render(checkpoint) {
    var cp = checkpoint || {};
    var brief = cp.description || '';
    var MACHINE_REASON = /^(Interrupted by editor restart|worker did not complete|reviewer did not complete|cancelled by user|reviewer's reply never included a VERDICT)/;
    var reason = cp.attemptCount > 0 ? (cp.lastFailReason || '') : '';
    if (reason && !MACHINE_REASON.test(reason)) {
      brief += '\n\nAddress this feedback from the last attempt: ' + reason;
    }
    var el = ensureEl();
    el.innerHTML =
      '<h4>Dispatch “' + esc((cp.description || '').slice(0, 40)) + (cp.description && cp.description.length > 40 ? '…' : '') + '”</h4>'
      + '<label>Task brief</label><textarea id="cdp-brief">' + esc(brief) + '</textarea>'
      + '<div class="cdp-row">'
      + '<div><label>Worker</label><select id="cdp-worker">' + roleOpts(cp.workerRoleId || 'blueprint-dev') + '</select></div>'
      + '<div><label>Reviewer</label><select id="cdp-reviewer">' + roleOpts(cp.reviewerRoleId || 'reviewer') + '</select></div>'
      + '</div>'
      + '<div class="cdp-btns"><button class="cdp-cancel" id="cdp-cancel">Cancel</button><button class="cdp-go" id="cdp-go">Dispatch</button></div>';

    el.querySelector('#cdp-cancel').addEventListener('click', close);
    el.querySelector('#cdp-go').addEventListener('click', function () {
      var taskBrief = el.querySelector('#cdp-brief').value.trim();
      if (!taskBrief) return;
      window.uecp.call('crew_dispatch_checkpoint', {
        checkpointId: cp.id,
        taskBrief: taskBrief,
        workerRole: el.querySelector('#cdp-worker').value,
        reviewerRole: el.querySelector('#cdp-reviewer').value
      });
      close();
    });
  }

  function open(anchorEl, checkpoint) {
    if (!anchorEl) return;
    _anchorEl = anchorEl;
    fetchRoles(function () {
      render(checkpoint);
      var el = ensureEl();
      el.classList.add('open');

      var a = anchorEl.getBoundingClientRect();
      var rect = el.getBoundingClientRect();
      var vw = window.innerWidth, vh = window.innerHeight, margin = 8;

      var left = a.right + margin;
      if (left + rect.width + margin > vw) left = a.left - rect.width - margin;
      if (left < margin) left = margin;

      var top = a.top;
      if (top + rect.height + margin > vh) top = Math.max(margin, vh - rect.height - margin);

      el.style.left = left + 'px';
      el.style.top = top + 'px';
    });
  }

  function close() {
    if (_el) _el.classList.remove('open');
  }

  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
  document.addEventListener('click', function (e) {
    if (!_el || !_el.classList.contains('open')) return;
    if (_el.contains(e.target)) return;
    if (e.target === _anchorEl || (_anchorEl && _anchorEl.contains && _anchorEl.contains(e.target))) return;
    close();
  });
  window.addEventListener('scroll', close, true);
  window.addEventListener('resize', close);

  window.UECP = window.UECP || {};
  window.UECP.crewDispatchPanel = { open: open, close: close };
})();
