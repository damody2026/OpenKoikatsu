(function () {
  'use strict';

  function computePos(anchor, tip, vw, vh, margin) {
    var m = (typeof margin === 'number') ? margin : 8;
    var w = tip.width, h = tip.height;

    var centre = anchor.left + (anchor.width / 2);
    var left = Math.round(centre - (w / 2));
    var maxLeft = vw - w - m;
    if (maxLeft < m) maxLeft = m;
    if (left < m) left = m;
    if (left > maxLeft) left = maxLeft;

    var placement = 'above';
    var top = anchor.top - h - m;
    if (top < m) {
      placement = 'below';
      top = anchor.bottom + m;
      if (top + h > vh - m) top = Math.max(m, vh - h - m);
    }
    return { left: left, top: top, placement: placement };
  }

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { computePos: computePos };
  }

  if (typeof document === 'undefined') return;

  if (!document.getElementById('uecp-tooltip-css')) {
    var st = document.createElement('style'); st.id = 'uecp-tooltip-css';
    st.textContent =
      '#uecp-tooltip{position:fixed;z-index:10000;pointer-events:none;display:none;' +
      'max-width:320px;width:max-content;background:var(--ue-panel);color:var(--ue-text-hi);' +
      'border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);padding:7px 11px;' +
      'font-family:var(--ue-font-sans);font-size:12px;font-weight:400;line-height:1.4;' +
      'white-space:pre-line;box-shadow:var(--ue-shadow-pop,0 4px 12px rgba(0,0,0,.3))}' +
      '#uecp-tooltip.open{display:block}';
    document.head.appendChild(st);
  }

  var _tip = null;
  var _target = null;

  function ensureEl() {
    if (_tip) return _tip;
    _tip = document.createElement('div');
    _tip.id = 'uecp-tooltip';
    _tip.setAttribute('role', 'tooltip');
    document.body.appendChild(_tip);
    return _tip;
  }

  function isSelfRendered(eln) {
    return !!(eln && eln.classList && eln.classList.contains('has-tip'));
  }

  function tipHost(start) {
    var n = start;
    while (n && n.nodeType === 1) {
      if (n.getAttribute) {
        var t = n.getAttribute('data-tip');
        if (t != null && t !== '' && !isSelfRendered(n)) return n;
      }
      n = n.parentNode;
    }
    return null;
  }

  function keepName(el, title) {
    if (!title || el.hasAttribute('aria-label') || el.hasAttribute('aria-labelledby')) return;
    var own = el.innerText != null ? el.innerText : el.textContent;
    if ((own || '').trim()) return;
    el.setAttribute('aria-label', title);
    var src = el.__i18nAttrSrc;
    if (src && src.title !== undefined) src['aria-label'] = src.title;
  }

  function show(target) {
    if (!target || !target.getAttribute) return;
    var text = target.getAttribute('data-tip');
    if (text == null || text === '') return;
    if (target.hasAttribute('title')) {
      var was = target.getAttribute('title') || '';
      target.setAttribute('data-title-was', was);
      target.removeAttribute('title');
      keepName(target, was);
    }
    _target = target;
    var el = ensureEl();
    el.textContent = text;
    el.style.left = '-9999px';
    el.style.top = '0px';
    el.classList.add('open');
    var a = target.getBoundingClientRect();
    var anchor = { left: a.left, top: a.top, right: a.right, bottom: a.bottom, width: a.width, height: a.height };
    var rect = el.getBoundingClientRect();
    var pos = computePos(anchor, { width: rect.width, height: rect.height },
      window.innerWidth, window.innerHeight, 8);
    el.style.left = pos.left + 'px';
    el.style.top = pos.top + 'px';
  }

  function hide() {
    _target = null;
    if (_tip) { _tip.classList.remove('open'); }
  }

  document.addEventListener('mouseover', function (e) {
    var host = tipHost(e.target);
    if (host) { if (host !== _target) show(host); }
    else if (_target) hide();
  });
  document.addEventListener('mouseout', function (e) {
    if (!_target) return;
    var to = e.relatedTarget;
    if (to && _target.contains && _target.contains(to)) return;
    hide();
  });
  window.addEventListener('scroll', hide, true);
  window.addEventListener('resize', hide);

  window.UECP = window.UECP || {};
  window.UECP.tooltip = { show: show, hide: hide, computePos: computePos };
})();
