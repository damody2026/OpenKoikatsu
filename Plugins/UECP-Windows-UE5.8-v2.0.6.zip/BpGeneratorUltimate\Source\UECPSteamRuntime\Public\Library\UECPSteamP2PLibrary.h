// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "UECPSteamTypes.h"
#include "UECPSteamP2PLibrary.generated.h"

UENUM(BlueprintType)
enum class EUECPSteamP2PSend : uint8
{
	Reliable   UMETA(DisplayName = "Reliable (ordered, guaranteed)"),

	Unreliable UMETA(DisplayName = "Unreliable (fast, may drop)"),
};

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamP2PLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|P2P")
	static bool OpenP2PChannel(int32 Channel = 0);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|P2P")
	static bool CloseP2PChannel(int32 Channel = 0);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|P2P")
	static TArray<int32> GetOpenP2PChannels();

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|P2P")
	static bool AcceptP2PSession(FUECPSteamID PeerSteamId);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|P2P")
	static bool CloseP2PSession(FUECPSteamID PeerSteamId);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|P2P",
		meta = (AdvancedDisplay = "Channel,SendType"))
	static bool SendP2PData(FUECPSteamID PeerSteamId, const TArray<uint8>& Data,
		int32 Channel = 0, EUECPSteamP2PSend SendType = EUECPSteamP2PSend::Reliable);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|P2P",
		meta = (AdvancedDisplay = "Channel,SendType"))
	static bool SendP2PString(FUECPSteamID PeerSteamId, const FString& Message,
		int32 Channel = 0, EUECPSteamP2PSend SendType = EUECPSteamP2PSend::Reliable);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|P2P")
	static bool GetP2PSessionInfo(FUECPSteamID PeerSteamId, int32& PingMs,
		float& ConnectionQuality, bool& bRelayed);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|P2P")
	static FString Conv_P2PDataToString(const TArray<uint8>& Data);
};
