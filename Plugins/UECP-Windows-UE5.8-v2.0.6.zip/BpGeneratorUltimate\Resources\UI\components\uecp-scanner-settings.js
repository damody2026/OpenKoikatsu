(function () {
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  if (!document.getElementById('uecp-scanset-css')) {
    const s = document.createElement('style'); s.id = 'uecp-scanset-css';
    s.textContent = `
/* Height clamped against the (inset:0) overlay; the matching width clamp is the shared
   .modal rule in forge.css, so a 760px box still fits a narrow docked tab. */
#uecp-scanset-ov .modal{width:760px;height:600px;max-height:calc(100% - 24px);display:flex;flex-direction:column}
/* Two-pane body: category nav (left) + active section (right) — replaces the single
   long scroll that dumped every group on one page. */
#uecp-scanset-ov .ss-split{flex:1;min-height:0;display:flex}
#uecp-scanset-ov .ss-nav{width:178px;flex-shrink:0;border-right:1px solid var(--ue-line-soft);padding:10px 8px;display:flex;flex-direction:column;gap:2px;overflow-y:auto}
#uecp-scanset-ov .ss-nav-item{display:flex;align-items:center;gap:9px;padding:8px 10px;border-radius:var(--ue-r);font-size:12.5px;color:var(--ue-text-mid);cursor:pointer}
#uecp-scanset-ov .ss-nav-item:hover{background:var(--ue-line-soft)}
#uecp-scanset-ov .ss-nav-item.sel{background:var(--ue-accent-soft);color:var(--ue-accent-bright);font-weight:var(--ue-fw-medium)}
#uecp-scanset-ov .ss-nav-item .ss-count{margin-left:auto;font-family:var(--ue-font-mono);font-size:10px;color:var(--ue-text-lo)}
#uecp-scanset-ov .ss-nav-item.sel .ss-count{color:var(--ue-accent-bright)}
#uecp-scanset-ov .ss-body{flex:1;min-width:0;min-height:0;overflow-y:auto;padding:16px 22px 22px}
#uecp-scanset-ov .ss-pane-title{font-size:13.5px;font-weight:var(--ue-fw-semi);color:var(--ue-text-hi);margin-bottom:3px}
#uecp-scanset-ov .ss-pane-sub{font-size:11.5px;color:var(--ue-text-lo);margin-bottom:14px}
#uecp-scanset-ov .ss-row{display:flex;align-items:center;gap:10px;padding:7px 2px;border-bottom:1px solid var(--ue-line-soft)}
#uecp-scanset-ov .ss-row .lbl{flex:1;min-width:0;font-size:12.5px;color:var(--ue-text-hi)}
#uecp-scanset-ov .ss-row .meta{font-size:10.5px;color:var(--ue-text-lo);font-family:var(--ue-font-mono)}
#uecp-scanset-ov .ss-row .desc{font-size:11px;color:var(--ue-text-lo);margin-top:2px}
#uecp-scanset-ov .ss-empty{font-size:12px;color:var(--ue-text-lo);padding:8px 0}
#uecp-scanset-ov .ss-x{margin-left:auto;background:none;border:none;color:var(--ue-text-lo);font-size:20px;line-height:1;cursor:pointer}
#uecp-scanset-ov .ss-x:hover{color:var(--ue-text-hi)}
`;
    document.head.appendChild(s);
  }

  class ScannerSettings extends HTMLElement {
    connectedCallback() {
      this._data = { types: [], dirs: [], plugins: [], sources: [], options: [] };
      this._tab = 'general';
      this._build();
      this._subscribe();
    }
    disconnectedCallback() {
      (this._subs || []).forEach(function (u) { try { u(); } catch (e) {} });
      this._subs = [];
    }

    _subscribe() {
      const self = this;
      const refresh = function () { self._renderNav(); self._renderBody(); };
      this._subs = [
        window.uecp.on('scan.typefilters',  function (d) { self._data.types   = Array.isArray(d) ? d : []; refresh(); }),
        window.uecp.on('scan.directories',   function (d) { self._data.dirs    = Array.isArray(d) ? d : []; refresh(); }),
        window.uecp.on('scan.plugins',       function (d) { self._data.plugins = Array.isArray(d) ? d : []; refresh(); }),
        window.uecp.on('scan.pluginsources', function (d) { self._data.sources = Array.isArray(d) ? d : []; refresh(); }),
        window.uecp.on('scan.options',       function (d) { self._data.options = Array.isArray(d) ? d : []; refresh(); }),
      ];
    }

    open() {
      this._ov.classList.add('open');
      window.uecp.call('request_scanner_type_filters', {});
      window.uecp.call('request_scanner_directories', {});
      window.uecp.call('request_scanner_plugins', {});
      window.uecp.call('request_scanner_plugin_sources', {});
      window.uecp.call('request_scanner_options', {});
    }
    close() { this._ov.classList.remove('open'); }

    _build() {
      this._ov = document.createElement('div');
      this._ov.className = 'overlay'; this._ov.id = 'uecp-scanset-ov';
      this._ov.innerHTML =
        '<div class="modal">'
        + '<div class="modal-head">'
        + '<div><div class="modal-title">Scanner Settings</div>'
        + '<div class="modal-sub">Choose what the project index covers.</div></div>'
        + '<button class="ss-x" id="ss-close">&times;</button>'
        + '</div>'
        + '<div class="ss-split">'
        + '<div class="ss-nav" id="ss-nav"></div>'
        + '<div class="ss-body" id="ss-body"></div>'
        + '</div>'
        + '</div>';
      this.appendChild(this._ov);
      const self = this;
      this._ov.querySelector('#ss-close').addEventListener('click', function () { self.close(); });
      window.UECP.dom.bindBackdropClose(this._ov, function () { self.close(); });
      this._renderNav();
      this._renderBody();
    }

    _tabs() {
      const d = this._data;
      return [
        { id: 'general', label: 'General' },
        { id: 'types',   label: 'Asset Types', count: d.types.length },
        { id: 'dirs',    label: 'Directories', count: d.dirs.length },
        { id: 'plugins', label: 'Plugins',     count: d.plugins.length + d.sources.length },
        { id: 'maint',   label: 'Maintenance' },
      ];
    }

    _renderNav() {
      const nav = this._ov && this._ov.querySelector('#ss-nav');
      if (!nav) return;
      const self = this;
      nav.innerHTML = '';
      this._tabs().forEach(function (t) {
        const item = document.createElement('div');
        item.className = 'ss-nav-item' + (self._tab === t.id ? ' sel' : '');
        item.dataset.tab = t.id;
        item.innerHTML = esc(t.label)
          + (t.count != null ? '<span class="ss-count">' + t.count + '</span>' : '');
        item.addEventListener('click', function () {
          if (self._tab === t.id) return;
          self._tab = t.id;
          self._renderNav();
          self._renderBody();
        });
        nav.appendChild(item);
      });
    }

    _renderBody() {
      const body = this._ov && this._ov.querySelector('#ss-body');
      if (!body) return;
      const d = this._data;
      const self = this;

      const HEADERS = {
        general: ['General', 'How the scanner responds and what it includes.'],
        types:   ['Asset Types', 'Which asset classes the index covers.'],
        dirs:    ['Directories', 'Which content directories are scanned.'],
        plugins: ['Plugins', 'Plugin content mounts and C++ source the index covers.'],
        maint:   ['Maintenance', 'Reset settings or clear the crash-skip list.'],
      };
      const hdr = HEADERS[this._tab] || ['', ''];
      let html = '<div class="ss-pane-title">' + esc(hdr[0]) + '</div>'
        + '<div class="ss-pane-sub">' + esc(hdr[1]) + '</div>';

      if (this._tab === 'general') {
        html += this._toggleGroup('OPTIONS', d.options, 'option', 'key', 'label', true);
      } else if (this._tab === 'types') {
        html += this._toggleGroup('ASSET TYPES', d.types, 'type', 'key', 'label');
      } else if (this._tab === 'dirs') {
        html += this._toggleGroup('DIRECTORIES', d.dirs, 'dir', 'path', 'label');
      } else if (this._tab === 'plugins') {
        html += this._toggleGroup('PLUGINS (content)', d.plugins, 'plugin', 'name', 'name', false, 'mount_path');
        html += this._toggleGroup('PLUGIN SOURCE (C++)', d.sources, 'source', 'name', 'name', false, 'header_count', ' headers');
      } else if (this._tab === 'maint') {
        html += '<div style="display:flex;gap:8px;flex-wrap:wrap">'
          + '<button class="btn-ghost" id="ss-reset">Reset to defaults</button>'
          + '<button class="btn-ghost" id="ss-clear-crash">Clear crash-skip list</button>'
          + '</div>';
      }

      body.innerHTML = html;
      body.scrollTop = 0;

      body.querySelectorAll('.ss-row .toggle').forEach(function (tg) {
        tg.addEventListener('click', function () {
          const on = !tg.classList.contains('on');
          tg.classList.toggle('on', on);
          const kind = tg.dataset.kind;
          const idv  = tg.dataset.id;
          if (kind === 'type')   window.uecp.call('set_scanner_type_filter',   { key: idv, enabled: on });
          if (kind === 'option') window.uecp.call('set_scanner_option',        { key: idv, enabled: on });
          if (kind === 'dir')    window.uecp.call('set_scanner_directory',     { path: idv, enabled: on });
          if (kind === 'plugin') window.uecp.call('set_scanner_plugin',        { name: idv, enabled: on });
          if (kind === 'source') window.uecp.call('set_scanner_plugin_source', { name: idv, enabled: on });
        });
      });

      const reset = body.querySelector('#ss-reset');
      if (reset) reset.addEventListener('click', function () {
        window.uecp.call('reset_scanner_settings', {});
        setTimeout(function () { self.open(); }, 60);
      });
      const clr = body.querySelector('#ss-clear-crash');
      if (clr) clr.addEventListener('click', function () { window.uecp.call('clear_scanner_crash_skip_list', {}); });
    }

    _section(label, inner) {
      return '<div class="section-label">' + esc(label) + '</div>' + inner;
    }

    _toggleGroup(label, arr, kind, idKey, labelKey, showDesc, metaKey, metaSuffix) {
      let h = '<div class="section-label">' + esc(label) + '</div>';
      if (!arr || !arr.length) { return h + '<div class="ss-empty">None.</div>'; }
      arr.forEach(function (it) {
        const idv = it[idKey] || '';
        const lbl = it[labelKey] || idv;
        const on  = it.enabled === true;
        const meta = metaKey != null && it[metaKey] != null ? String(it[metaKey]) + (metaSuffix || '') : '';
        h += '<div class="ss-row">'
          + '<div class="lbl">' + esc(lbl)
          + (showDesc && it.description ? '<div class="desc">' + esc(it.description) + '</div>' : '')
          + '</div>'
          + (meta ? '<span class="meta">' + esc(meta) + '</span>' : '')
          + '<div class="toggle sm' + (on ? ' on' : '') + '" data-kind="' + esc(kind) + '" data-id="' + esc(idv) + '"><span class="knob"></span></div>'
          + '</div>';
      });
      return h;
    }
  }

  customElements.define('uecp-scanner-settings', ScannerSettings);

  let _el = null;
  window.UECP = window.UECP || {};
  window.UECP.openScannerSettings = function () {
    if (!_el) { _el = document.createElement('uecp-scanner-settings'); document.body.appendChild(_el); }
    _el.open();
  };
})();
