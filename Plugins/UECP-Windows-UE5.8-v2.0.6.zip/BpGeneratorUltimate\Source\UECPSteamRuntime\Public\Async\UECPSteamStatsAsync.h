// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "Async/UECPSteamAsyncAction.h"
#include "UECPSteamTypes.h"
#include "UECPSteamStatsAsync.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FUECPSteamPlayerCountSignature,
	int32, PlayerCount, FUECPSteamError, Error);

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamGetPlayerCount : public UUECPSteamAsyncAction
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Stats",
		meta = (BlueprintInternalUseOnly = "true", WorldContext = "WorldContextObject",
		        DisplayName = "Get Steam Player Count"))
	static UUECPSteamGetPlayerCount* GetSteamPlayerCount(UObject* WorldContextObject);

	UPROPERTY(BlueprintAssignable)
	FUECPSteamPlayerCountSignature OnSuccess;

	UPROPERTY(BlueprintAssignable)
	FUECPSteamPlayerCountSignature OnFailure;

protected:
	virtual bool Start(FUECPSteamError& OutError) override;
	virtual void BroadcastResult(bool bSucceeded, const FUECPSteamError& Error) override;

private:
	int32 PlayerCount = 0;
};
