(function () {
  function slugify(s) {
    if (typeof s !== 'string') return '';
    return s.toLowerCase().trim()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '');
  }

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { slugify: slugify };
  }
  if (typeof document === 'undefined') return;

  if (!document.getElementById('uecp-screen-subagents-css')) {
    const s = document.createElement('style'); s.id = 'uecp-screen-subagents-css';
    s.textContent = `
uecp-screen-subagents{display:flex;flex:1;min-width:0;min-height:0}
uecp-screen-subagents .rh-split{flex:1;display:flex;min-height:0}
uecp-screen-subagents .rh-list{width:240px;flex-shrink:0;border-right:1px solid var(--ue-line-soft);display:flex;flex-direction:column;min-height:0}
uecp-screen-subagents .rh-bar{display:flex;gap:6px;padding:8px 10px;border-bottom:1px solid var(--ue-line-soft)}
uecp-screen-subagents .rh-bar button{font-size:11px;border:1px solid var(--ue-line);background:var(--ue-elev);color:var(--ue-text-mid);border-radius:var(--ue-r);padding:4px 9px;cursor:pointer}
uecp-screen-subagents .rh-bar .pri{background:var(--ue-accent-soft);border-color:var(--ue-accent);color:var(--ue-accent-bright)}
uecp-screen-subagents .rh-bar .sp{margin-left:auto}
uecp-screen-subagents .rh-roles{flex:1;overflow-y:auto;padding:6px}
uecp-screen-subagents .rh-role{padding:7px 9px;border-radius:var(--ue-r);cursor:pointer;border:1px solid transparent;margin-bottom:3px}
uecp-screen-subagents .rh-role:hover{background:var(--ue-line-soft)}
uecp-screen-subagents .rh-role.sel{background:var(--ue-accent-soft);border-color:var(--ue-accent)}
uecp-screen-subagents .rh-role .nm{font-size:12.5px;color:var(--ue-text-hi);display:flex;align-items:center;gap:6px}
uecp-screen-subagents .rh-role .bi{font-size:8.5px;color:var(--ue-text-lo);border:1px solid var(--ue-line);border-radius:7px;padding:0 5px}
uecp-screen-subagents .rh-role .ds{font-size:10.5px;color:var(--ue-text-lo);margin-top:2px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
uecp-screen-subagents .rh-ed{flex:1;min-width:0;min-height:0;overflow-y:auto;padding:18px 22px}
uecp-screen-subagents .rh-empty{color:var(--ue-text-lo);font-size:12.5px;padding:24px}
uecp-screen-subagents .rh-f{display:flex;flex-direction:column;gap:4px;font-size:11px;color:var(--ue-text-lo);margin-bottom:12px;text-transform:uppercase;letter-spacing:.4px}
uecp-screen-subagents .rh-f input,uecp-screen-subagents .rh-f textarea,uecp-screen-subagents .rh-f select{font-size:13px;color:var(--ue-text-hi);background:var(--ue-elev);border:1px solid var(--ue-line);border-radius:var(--ue-r);padding:6px 8px;text-transform:none;letter-spacing:0;font-family:inherit}
uecp-screen-subagents .rh-f textarea{resize:vertical;min-height:120px}
uecp-screen-subagents .rh-frow{display:flex;gap:18px;align-items:flex-start}
uecp-screen-subagents .rh-seg{display:flex;gap:4px}
uecp-screen-subagents .rh-seg span{font-size:11px;padding:5px 11px;border-radius:14px;background:var(--ue-elev);color:var(--ue-text-mid);cursor:pointer}
uecp-screen-subagents .rh-seg span.on{background:var(--ue-accent-soft);color:var(--ue-accent-bright)}
uecp-screen-subagents .rh-seg span.dis{opacity:.45;cursor:not-allowed}
uecp-screen-subagents .rh-actions{display:flex;gap:8px;align-items:center;margin-top:6px}
uecp-screen-subagents .rh-actions button{font-size:12px;border:1px solid var(--ue-line);background:var(--ue-elev);color:var(--ue-text-mid);border-radius:var(--ue-r);padding:6px 14px;cursor:pointer}
uecp-screen-subagents .rh-actions .pri{background:var(--ue-accent-soft);border-color:var(--ue-accent);color:var(--ue-accent-bright)}`;
    document.head.appendChild(s);
  }

  class UecpScreenSubagents extends HTMLElement {
    connectedCallback() {
      this._roles = [];
      this._slots = [];
      this._sel = null;
      this._draft = null;
      this.innerHTML =
        '<div class="rh-split">'
        + '<div class="rh-list">'
        +   '<div class="rh-bar"><button class="pri" id="rh-new">+ New role</button>'
        +     '<span class="sp"></span><button id="rh-reset">Reset defaults</button></div>'
        +   '<div class="rh-roles" id="rh-roles"></div>'
        + '</div>'
        + '<div class="rh-ed" id="rh-ed"><div class="rh-empty">Select a role, or create a new one.</div></div>'
        + '</div>';

      const self = this;
      this._offRoles = window.uecp.on('subagent.roles', function (d) {
        self._roles = (d && d.roles) || [];
        if (!self._saveErr) { self._draft = null; }
        self._renderList(); self._renderEditor();
        if (self._saveErr) {
          const el = self.querySelector('#rh-err');
          if (el) { el.textContent = self._saveErr; el.style.display = 'block'; }
          self._saveErr = '';
        }
      });
      this._offSlots = window.uecp.on('slots.list', function (d) {
        self._slots = (d && d.slots) || []; self._renderEditor();
      });
      this._offErr = window.uecp.on('subagent.roleError', function (d) {
        self._saveErr = (d && d.error) || 'Could not save this role.';
        const el = self.querySelector('#rh-err');
        if (el) { el.textContent = self._saveErr; el.style.display = 'block'; }
      });
      this.querySelector('#rh-new').addEventListener('click', function () { self._newRole(); });
      this.querySelector('#rh-reset').addEventListener('click', function () {
        window.UECP.dialog.confirm('Reset roles',
          'Restore the built-in roles to their defaults? Your custom roles are kept.')
          .then(function (ok) { if (ok) window.uecp.call('reset_subagent_roles', {}); });
      });
      window.uecp.call('list_subagent_roles', {});
    }
    disconnectedCallback() { if (this._offRoles) this._offRoles(); if (this._offSlots) this._offSlots(); if (this._offErr) this._offErr(); }

    _renderList() {
      const box = this.querySelector('#rh-roles'); if (!box) return;
      const self = this;
      box.innerHTML = '';
      this._roles.forEach(function (r) {
        const row = document.createElement('div');
        row.className = 'rh-role' + (r.id === self._sel ? ' sel' : '');
        const bi = r.builtIn ? '<span class="bi">built-in</span>' : '';
        row.innerHTML = '<div class="nm">' + window.UECP.escapeHtml(r.name || r.id) + bi + '</div>'
          + '<div class="ds">' + window.UECP.escapeHtml(r.description || '') + '</div>';
        row.addEventListener('click', function () {
          self._sel = r.id; self._draft = null; self._renderList(); self._renderEditor();
        });
        box.appendChild(row);
      });
    }

    _newRole() {
      this._sel = null;
      this._draft = { id: '', name: '', description: '', systemPrompt: '',
        apiKeySlotIndex: -1, toolAccess: 'write', builtIn: false, isNew: true };
      this._renderList(); this._renderEditor();
    }

    _currentRole() {
      if (this._draft) return this._draft;
      const sel = this._sel;
      return this._roles.find(function (r) { return r.id === sel; }) || null;
    }

    _renderEditor() {
      const ed = this.querySelector('#rh-ed'); if (!ed) return;
      const r = this._currentRole();
      if (!r) { ed.innerHTML = '<div class="rh-empty">Select a role, or create a new one.</div>'; return; }
      const self = this;
      const esc = window.UECP.escapeHtml;
      const isNew = !!r.isNew;
      const ta = (r.toolAccess || 'write');
      const slotOpts = ['<option value="-1"' + (r.apiKeySlotIndex === -1 ? ' selected' : '') + '>Inherit parent chat\'s slot</option>']
        .concat(this._slots.map(function (s) {
          const SF = window.SettingsFormat;
          const model = SF && SF.slotModelName ? SF.slotModelName(s, s.index) : (s.model || s.name || ('Slot ' + (s.index + 1)));
          const where = s.index >= 1000 ? '' : ' · ' + (s.name || ('Slot ' + (s.index + 1)));
          return '<option value="' + s.index + '"' + (s.index === r.apiKeySlotIndex ? ' selected' : '') + '>'
            + esc(model + where) + '</option>';
        })).join('');
      ed.innerHTML =
        '<div id="rh-err" style="display:none;color:var(--ue-danger,#e0625e);font-size:12px;margin-bottom:10px"></div>'
        + '<label class="rh-f">Name<input id="rf-name" type="text" value="' + esc(r.name || '') + '"></label>'
        + '<label class="rh-f">Description (when to delegate)<input id="rf-desc" type="text" value="' + esc(r.description || '') + '"></label>'
        + '<label class="rh-f">System prompt<textarea id="rf-prompt" rows="8">' + esc(r.systemPrompt || '') + '</textarea></label>'
        + '<div class="rh-frow">'
        +   '<label class="rh-f" style="flex:0 0 220px">Slot<select id="rf-slot">' + slotOpts + '</select></label>'
        +   '<div class="rh-f">Tool access<div class="rh-seg" id="rf-ta">'
        +     '<span data-v="read-only" class="' + (ta === 'read-only' ? 'on' : '') + '">Read</span>'
        +     '<span data-v="write" class="' + (ta === 'write' ? 'on' : '') + '">Write</span>'
        +     '<span data-v="custom" class="' + (ta === 'custom' ? 'on' : '') + '">Custom</span>'
        +   '</div></div>'
        + '</div>'
        + '<div class="rh-f" id="rf-allowlist-wrap" style="' + (ta === 'custom' ? '' : 'display:none') + '">Allowed tools</div>'
        + '<div id="rf-allowlist" style="margin-bottom:12px;' + (ta === 'custom' ? '' : 'display:none') + '"></div>'
        + '<div class="rh-actions">'
        +   '<button class="pri" id="rf-save">Save</button>'
        +   '<button id="rf-cancel">Cancel</button>'
        +   (isNew ? '' : '<span style="margin-left:auto"></span><button id="rf-del">Delete</button>')
        + '</div>';

      let taVal = ta;
      let customAllowlist = (r.toolAllowlist || []).slice();
      const allowlistWrap = ed.querySelector('#rf-allowlist-wrap');
      const allowlistBox = ed.querySelector('#rf-allowlist');
      function syncAllowlistVisibility() {
        const show = taVal === 'custom';
        allowlistWrap.style.display = show ? '' : 'none';
        allowlistBox.style.display = show ? '' : 'none';
        if (show) window.UECP.toolAllowlistEditor.mount(allowlistBox, customAllowlist, function (sel) { customAllowlist = sel; });
      }
      syncAllowlistVisibility();
      ed.querySelectorAll('#rf-ta span[data-v]').forEach(function (sp) {
        sp.addEventListener('click', function () {
          taVal = sp.getAttribute('data-v');
          ed.querySelectorAll('#rf-ta span').forEach(function (x) { x.classList.toggle('on', x === sp); });
          syncAllowlistVisibility();
        });
      });

      ed.querySelector('#rf-save').addEventListener('click', function () {
        const errEl = ed.querySelector('#rh-err');
        if (errEl) { errEl.style.display = 'none'; errEl.textContent = ''; }
        const name = ed.querySelector('#rf-name').value;
        const payload = {
          id: isNew ? slugify(name) : r.id,
          name: name,
          description: ed.querySelector('#rf-desc').value,
          systemPrompt: ed.querySelector('#rf-prompt').value,
          apiKeySlotIndex: parseInt(ed.querySelector('#rf-slot').value, 10),
          toolAccess: taVal,
          toolAllowlist: taVal === 'custom' ? customAllowlist : [],
          isNew: isNew
        };
        if (isNew) self._sel = payload.id;
        self._draft = Object.assign({ builtIn: isNew ? false : !!r.builtIn }, payload);
        window.uecp.call('save_subagent_role', payload);
      });
      ed.querySelector('#rf-cancel').addEventListener('click', function () {
        self._draft = null; self._renderList(); self._renderEditor();
      });
      const del = ed.querySelector('#rf-del');
      if (del) del.addEventListener('click', function () {
        window.UECP.dialog.confirm('Delete role', 'Delete "' + (r.name || r.id) + '"? This cannot be undone.')
          .then(function (ok) { if (ok) { self._sel = null; window.uecp.call('delete_subagent_role', { id: r.id }); } });
      });
    }
  }

  if (!customElements.get('uecp-screen-subagents')) {
    customElements.define('uecp-screen-subagents', UecpScreenSubagents);
  }
})();
