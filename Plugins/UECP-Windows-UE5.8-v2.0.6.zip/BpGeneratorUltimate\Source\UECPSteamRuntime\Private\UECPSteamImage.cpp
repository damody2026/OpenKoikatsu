// Copyright 2026, BlueprintsLab, All rights reserved
#include "UECPSteamImage.h"

#include "Engine/Texture2D.h"
#include "UECPSteamAPI.h"

namespace
{
	TMap<int32, TWeakObjectPtr<UTexture2D>> GImageCache;
}

UTexture2D* UECPSteam::CreateTextureFromImageHandle(int32 ImageHandle)
{
#if UECP_WITH_STEAM
	if (ImageHandle <= 0)
	{
		return nullptr;
	}

	if (const TWeakObjectPtr<UTexture2D>* Cached = GImageCache.Find(ImageHandle))
	{
		if (UTexture2D* Existing = Cached->Get())
		{
			return Existing;
		}
		GImageCache.Remove(ImageHandle);
	}

	ISteamUtils* Utils = UECPSteam::Utils();
	if (!Utils)
	{
		return nullptr;
	}

	uint32 Width = 0;
	uint32 Height = 0;
	if (!Utils->GetImageSize(ImageHandle, &Width, &Height) || Width == 0 || Height == 0)
	{
		return nullptr;
	}

	const int32 BytesPerPixel = 4;
	const uint32 BufferSize = Width * Height * BytesPerPixel;

	TArray<uint8> Rgba;
	Rgba.SetNumUninitialized(BufferSize);
	if (!Utils->GetImageRGBA(ImageHandle, Rgba.GetData(), static_cast<int>(BufferSize)))
	{
		return nullptr;
	}

	UTexture2D* Texture = UTexture2D::CreateTransient(Width, Height, PF_B8G8R8A8);
	if (!Texture)
	{
		return nullptr;
	}

	Texture->SRGB = true;
	Texture->CompressionSettings = TextureCompressionSettings::TC_EditorIcon;
	Texture->Filter = TextureFilter::TF_Bilinear;

	FTexture2DMipMap& Mip = Texture->GetPlatformData()->Mips[0];
	uint8* Dest = static_cast<uint8*>(Mip.BulkData.Lock(LOCK_READ_WRITE));

	for (uint32 Pixel = 0; Pixel < Width * Height; ++Pixel)
	{
		const uint32 Offset = Pixel * BytesPerPixel;
		Dest[Offset + 0] = Rgba[Offset + 2];
		Dest[Offset + 1] = Rgba[Offset + 1];
		Dest[Offset + 2] = Rgba[Offset + 0];
		Dest[Offset + 3] = Rgba[Offset + 3];
	}

	Mip.BulkData.Unlock();
	Texture->UpdateResource();

	GImageCache.Add(ImageHandle, Texture);
	return Texture;
#else
	(void)ImageHandle;
	return nullptr;
#endif
}

void UECPSteam::FlushImageCache()
{
	GImageCache.Empty();
}
