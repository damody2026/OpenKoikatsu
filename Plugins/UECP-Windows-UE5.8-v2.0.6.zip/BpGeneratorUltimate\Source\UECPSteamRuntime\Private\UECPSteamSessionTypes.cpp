// Copyright 2026, BlueprintsLab, All rights reserved
#include "UECPSteamSessionTypes.h"

#include "Online/OnlineSessionNames.h"
#include "OnlineSessionSettings.h"
#include "UECPSteamOSS.h"

FOnlineSessionSettings FUECPSteamSessionSettings::ToOnlineSessionSettings() const
{
	FOnlineSessionSettings Out;

	Out.NumPublicConnections  = FMath::Max(0, MaxPlayers - PrivateSlots);
	Out.NumPrivateConnections = FMath::Clamp(PrivateSlots, 0, MaxPlayers);
	Out.bAllowJoinInProgress  = bAllowJoinInProgress;
	Out.bAllowInvites         = bAllowInvites;
	Out.bShouldAdvertise      = bShouldAdvertise;
	Out.bUsesStats            = bUsesStats;
	Out.bAntiCheatProtected   = bAntiCheatProtected;

	switch (SessionType)
	{
	case EUECPSteamSessionType::Lobby:
		Out.bIsLANMatch                        = false;
		Out.bIsDedicated                       = false;
		Out.bUsesPresence                      = true;
		Out.bUseLobbiesIfAvailable             = true;
		Out.bAllowJoinViaPresence              = true;
		Out.bAllowJoinViaPresenceFriendsOnly   = bFriendsOnly;
		Out.bUseLobbiesVoiceChatIfAvailable    = bUseLobbyVoiceChat;
		break;

	case EUECPSteamSessionType::ServerBrowser:
		Out.bIsLANMatch                        = false;
		Out.bIsDedicated                       = true;
		Out.bUsesPresence                      = false;
		Out.bUseLobbiesIfAvailable             = false;
		Out.bAllowJoinViaPresence              = false;
		Out.bAllowJoinViaPresenceFriendsOnly   = false;
		Out.bUseLobbiesVoiceChatIfAvailable    = false;
		break;

	case EUECPSteamSessionType::LAN:
		Out.bIsLANMatch                        = true;
		Out.bIsDedicated                       = false;
		Out.bUsesPresence                      = false;
		Out.bUseLobbiesIfAvailable             = false;
		Out.bAllowJoinViaPresence              = false;
		Out.bAllowJoinViaPresenceFriendsOnly   = false;
		Out.bUseLobbiesVoiceChatIfAvailable    = false;
		break;
	}

	if (!MapName.IsEmpty())
	{
		Out.Set(SETTING_MAPNAME, MapName, EOnlineDataAdvertisementType::ViaOnlineServiceAndPing);
	}
	if (!GameMode.IsEmpty())
	{
		Out.Set(SETTING_GAMEMODE, GameMode, EOnlineDataAdvertisementType::ViaOnlineServiceAndPing);
	}

	for (const TPair<FString, FString>& Pair : ExtraSettings)
	{
		Out.Set(FName(*Pair.Key), Pair.Value, EOnlineDataAdvertisementType::ViaOnlineServiceAndPing);
	}

	return Out;
}

FUECPSteamSessionSearchResult FUECPSteamSessionSearchResult::FromOnlineResult(
	const FOnlineSessionSearchResult& InResult)
{
	FUECPSteamSessionSearchResult Out;
	Out.OnlineResult = InResult;

	const FOnlineSessionSettings& Settings = InResult.Session.SessionSettings;

	Out.HostName             = InResult.Session.OwningUserName;

	Out.PingMs               = (InResult.PingInMs >= 9999) ? -1 : InResult.PingInMs;
	Out.MaxPlayers           = Settings.NumPublicConnections + Settings.NumPrivateConnections;
	Out.OpenSlots            = InResult.Session.NumOpenPublicConnections;
	Out.CurrentPlayers       = FMath::Max(0, Out.MaxPlayers - (InResult.Session.NumOpenPublicConnections
	                                                         + InResult.Session.NumOpenPrivateConnections));
	Out.bAllowJoinInProgress = Settings.bAllowJoinInProgress;

	if (InResult.Session.OwningUserId.IsValid())
	{
		Out.HostSteamId = UECPSteamOSS::ToSteamID(*InResult.Session.OwningUserId);
	}

	for (const TPair<FName, FOnlineSessionSetting>& Pair : Settings.Settings)
	{
		FString Value;
		Pair.Value.Data.GetValue(Value);
		Out.ExtraSettings.Add(Pair.Key.ToString(), Value);
	}

	Settings.Get(SETTING_MAPNAME, Out.MapName);
	Settings.Get(SETTING_GAMEMODE, Out.GameMode);

	return Out;
}
