// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "Containers/Ticker.h"
#include "Subsystems/GameInstanceSubsystem.h"
#include "UECPSteamTypes.h"
#include "UECPSteamSubsystem.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FUECPSteamOverlayActivatedSignature, bool, bIsActive);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FUECPSteamServersConnectedSignature);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FUECPSteamServersDisconnectedSignature, FUECPSteamError, Error);
DECLARE_DYNAMIC_MULTICAST_DELEGATE(FUECPSteamShutdownSignature);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FUECPSteamAvatarLoadedSignature, FUECPSteamID, SteamId);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FUECPSteamPersonaChangedSignature, FUECPSteamID, SteamId);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FUECPSteamP2PSessionRequestSignature, FUECPSteamID, PeerSteamId);
DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FUECPSteamP2PMessageSignature,
	FUECPSteamID, SenderSteamId, const TArray<uint8>&, Data, int32, Channel);

UCLASS(DisplayName = "UECP Steam Subsystem")
class UECPSTEAMRUNTIME_API UUECPSteamSubsystem : public UGameInstanceSubsystem
{
	GENERATED_BODY()

public:
	UUECPSteamSubsystem();
	virtual ~UUECPSteamSubsystem() override;

	UUECPSteamSubsystem(FVTableHelper& Helper);

	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

	UFUNCTION(BlueprintPure, Category = "UECP|Steam",
		meta = (WorldContext = "WorldContextObject", DisplayName = "Get Steam Subsystem"))
	static UUECPSteamSubsystem* Get(const UObject* WorldContextObject);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam")
	bool IsSteamAvailable() const;

	UFUNCTION(BlueprintPure, Category = "UECP|Steam")
	bool IsSteamCompiledIn() const;

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam")
	bool AcquireSteam();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam")
	int32 GetAppId() const;

	UFUNCTION(BlueprintPure, Category = "UECP|Steam")
	FUECPSteamID GetLocalSteamID() const;

	UFUNCTION(BlueprintPure, Category = "UECP|Steam")
	FString GetLocalPersonaName() const;

	UFUNCTION(BlueprintPure, Category = "UECP|Steam")
	bool IsRunningOnSteamDeck() const;

	UFUNCTION(BlueprintPure, Category = "UECP|Steam")
	bool IsOverlayActive() const;

	UFUNCTION(BlueprintPure, Category = "UECP|Steam")
	bool IsOnlineSubsystemSteamActive() const;

	UPROPERTY(BlueprintAssignable, Category = "UECP|Steam|Events")
	FUECPSteamOverlayActivatedSignature OnOverlayActivated;

	UPROPERTY(BlueprintAssignable, Category = "UECP|Steam|Events")
	FUECPSteamServersConnectedSignature OnSteamServersConnected;

	UPROPERTY(BlueprintAssignable, Category = "UECP|Steam|Events")
	FUECPSteamServersDisconnectedSignature OnSteamServersDisconnected;

	UPROPERTY(BlueprintAssignable, Category = "UECP|Steam|Events")
	FUECPSteamShutdownSignature OnSteamShutdown;

	UPROPERTY(BlueprintAssignable, Category = "UECP|Steam|Events")
	FUECPSteamAvatarLoadedSignature OnAvatarLoaded;

	UPROPERTY(BlueprintAssignable, Category = "UECP|Steam|Events")
	FUECPSteamPersonaChangedSignature OnPersonaStateChanged;

	UPROPERTY(BlueprintAssignable, Category = "UECP|Steam|Events")
	FUECPSteamP2PSessionRequestSignature OnP2PSessionRequest;

	UPROPERTY(BlueprintAssignable, Category = "UECP|Steam|Events")
	FUECPSteamP2PMessageSignature OnP2PMessage;

	void HandleP2PMessage(int64 RawSenderId, const TArray<uint8>& Data, int32 Channel);

private:
	friend class FUECPSteamCallbackBridge;

	TUniquePtr<class FUECPSteamCallbackBridge> CallbackBridge;

	void HandleOverlayActivated(bool bActive);
	void HandleSteamServersConnected();
	void HandleSteamServersDisconnected(int32 RawResult);
	void HandleSteamShutdown();
	void HandleAvatarLoaded(int64 RawSteamId);
	void HandlePersonaStateChanged(int64 RawSteamId);
	void HandleP2PSessionRequest(int64 RawSteamId);

	bool bOverlayActive = false;
};
