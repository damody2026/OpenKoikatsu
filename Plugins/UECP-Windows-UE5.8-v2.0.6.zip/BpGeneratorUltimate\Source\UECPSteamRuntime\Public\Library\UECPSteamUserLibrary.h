// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "UECPSteamTypes.h"
#include "UECPSteamUserLibrary.generated.h"

UENUM(BlueprintType)
enum class EUECPSteamBeginAuthResult : uint8
{
	OK               UMETA(DisplayName = "OK"),
	InvalidTicket    UMETA(DisplayName = "Invalid Ticket"),
	DuplicateRequest UMETA(DisplayName = "Duplicate Request"),
	InvalidVersion   UMETA(DisplayName = "Invalid Version"),
	GameMismatch     UMETA(DisplayName = "Game Mismatch"),
	ExpiredTicket    UMETA(DisplayName = "Expired Ticket"),
	Unavailable      UMETA(DisplayName = "Unavailable"),
};

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamUserLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintPure, Category = "UECP|Steam|User")
	static bool IsLoggedOn();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|User")
	static FUECPSteamID GetLocalSteamID();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|User")
	static int32 GetPlayerSteamLevel();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|User", meta = (AdvancedDisplay = "bFoil"))
	static int32 GetGameBadgeLevel(int32 BadgeSeries = 1, bool bFoil = false);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|User")
	static bool IsBehindNAT();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|User")
	static bool IsPhoneVerified();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|User")
	static bool IsTwoFactorEnabled();

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|User")
	static FString GetAuthTicket();

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|User")
	static EUECPSteamBeginAuthResult BeginAuthSession(const FString& Ticket, FUECPSteamID PeerSteamId);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|User")
	static void EndAuthSession(FUECPSteamID PeerSteamId);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|User")
	static void CancelAuthTicket();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|User", meta = (AdvancedDisplay = "AppId"))
	static bool UserHasLicenseForApp(FUECPSteamID PeerSteamId, int32 AppId = 0);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|User")
	static bool GetDurationControl(int32& SecondsThisSession, bool& bBlocked);
};
