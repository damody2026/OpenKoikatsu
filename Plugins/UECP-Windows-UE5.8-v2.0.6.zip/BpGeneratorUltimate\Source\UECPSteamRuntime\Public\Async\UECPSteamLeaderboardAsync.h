// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "Async/UECPSteamAsyncAction.h"
#include "UECPSteamTypes.h"
#include "UECPSteamLeaderboardAsync.generated.h"

UENUM(BlueprintType)
enum class EUECPSteamLeaderboardRequest : uint8
{
	Global          UMETA(DisplayName = "Global"),
	GlobalAroundUser UMETA(DisplayName = "Global Around User"),
	Friends         UMETA(DisplayName = "Friends"),
};

UENUM(BlueprintType)
enum class EUECPSteamLeaderboardUpload : uint8
{
	KeepBest    UMETA(DisplayName = "Keep Best"),
	ForceUpdate UMETA(DisplayName = "Force Update"),
};

UENUM(BlueprintType)
enum class EUECPSteamLeaderboardSort : uint8
{
	Ascending  UMETA(DisplayName = "Ascending (lower is better)"),
	Descending UMETA(DisplayName = "Descending (higher is better)"),
};

UENUM(BlueprintType)
enum class EUECPSteamLeaderboardDisplay : uint8
{
	Numeric          UMETA(DisplayName = "Numeric"),
	TimeSeconds      UMETA(DisplayName = "Time (seconds)"),
	TimeMilliseconds UMETA(DisplayName = "Time (milliseconds)"),
};

USTRUCT(BlueprintType)
struct UECPSTEAMRUNTIME_API FUECPSteamLeaderboardEntry
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	FUECPSteamID SteamId;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	FString PlayerName;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	int32 GlobalRank = 0;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	int32 Score = 0;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	TArray<int32> Details;
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FUECPSteamLeaderboardEntriesSignature,
	const TArray<FUECPSteamLeaderboardEntry>&, Entries, FUECPSteamError, Error);

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamDownloadLeaderboard : public UUECPSteamAsyncAction
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Leaderboard",
		meta = (BlueprintInternalUseOnly = "true", WorldContext = "WorldContextObject",
		        DisplayName = "Download Steam Leaderboard", AdvancedDisplay = "RangeStart,RangeEnd"))
	static UUECPSteamDownloadLeaderboard* DownloadSteamLeaderboard(
		UObject* WorldContextObject,
		const FString& LeaderboardName,
		EUECPSteamLeaderboardRequest RequestType = EUECPSteamLeaderboardRequest::Global,
		int32 RangeStart = 1,
		int32 RangeEnd = 10);

	UPROPERTY(BlueprintAssignable)
	FUECPSteamLeaderboardEntriesSignature OnSuccess;

	UPROPERTY(BlueprintAssignable)
	FUECPSteamLeaderboardEntriesSignature OnFailure;

protected:
	virtual bool Start(FUECPSteamError& OutError) override;
	virtual void BroadcastResult(bool bSucceeded, const FUECPSteamError& Error) override;

private:
	FString LeaderboardName;
	EUECPSteamLeaderboardRequest RequestType = EUECPSteamLeaderboardRequest::Global;
	int32 RangeStart = 1;
	int32 RangeEnd = 10;

	TArray<FUECPSteamLeaderboardEntry> Entries;

	TUniquePtr<FUECPSteamCallResultHolder> DownloadHolder;

	void OnLeaderboardFound(uint64 LeaderboardHandle);
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_FourParams(FUECPSteamLeaderboardUploadSignature,
	bool, bScoreChanged, int32, NewGlobalRank, int32, PreviousGlobalRank, FUECPSteamError, Error);

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamUploadLeaderboardScore : public UUECPSteamAsyncAction
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Leaderboard",
		meta = (BlueprintInternalUseOnly = "true", WorldContext = "WorldContextObject",
		        DisplayName = "Upload Steam Leaderboard Score",
		        AdvancedDisplay = "Details,bCreateIfMissing,SortMethod,DisplayType"))
	static UUECPSteamUploadLeaderboardScore* UploadSteamLeaderboardScore(
		UObject* WorldContextObject,
		const FString& LeaderboardName,
		int32 Score,
		TArray<int32> Details,
		EUECPSteamLeaderboardUpload Method = EUECPSteamLeaderboardUpload::KeepBest,
		bool bCreateIfMissing = false,
		EUECPSteamLeaderboardSort SortMethod = EUECPSteamLeaderboardSort::Descending,
		EUECPSteamLeaderboardDisplay DisplayType = EUECPSteamLeaderboardDisplay::Numeric);

	UPROPERTY(BlueprintAssignable)
	FUECPSteamLeaderboardUploadSignature OnSuccess;

	UPROPERTY(BlueprintAssignable)
	FUECPSteamLeaderboardUploadSignature OnFailure;

protected:
	virtual bool Start(FUECPSteamError& OutError) override;
	virtual void BroadcastResult(bool bSucceeded, const FUECPSteamError& Error) override;

private:
	FString LeaderboardName;
	int32 Score = 0;
	EUECPSteamLeaderboardUpload Method = EUECPSteamLeaderboardUpload::KeepBest;
	TArray<int32> Details;
	bool bCreateIfMissing = false;
	EUECPSteamLeaderboardSort SortMethod = EUECPSteamLeaderboardSort::Descending;
	EUECPSteamLeaderboardDisplay DisplayType = EUECPSteamLeaderboardDisplay::Numeric;

	bool bScoreChanged = false;
	int32 NewGlobalRank = 0;
	int32 PreviousGlobalRank = 0;

	TUniquePtr<FUECPSteamCallResultHolder> UploadHolder;

	void OnLeaderboardFound(uint64 LeaderboardHandle);
};
