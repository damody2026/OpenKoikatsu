(function (root, factory) {
  const api = factory(root);
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) { root.UECP = root.UECP || {}; Object.assign(root.UECP, api); }
}(typeof self !== 'undefined' ? self : null, function (root) {

  function escapeHtml(s) {
    const t = (s == null) ? '' : String(s);
    return t
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#39;');
  }

  function linkifyAssets(html) {
    return (html || '').replace(
      /<a\b[^>]*>.*?<\/a>|(\/Game\/[\w/._-]+)/g,
      function (m, g) {
        return g ? '<a href="ue://asset?name=' + g + '" class="asset-link">' + g + '</a>' : m;
      }
    );
  }

  function hlJson(s) {
    return s.replace(
      /(\"(?:\\[\s\S]|[^\\"])*\"(?=\s*:))|(\"(?:\\[\s\S]|[^\\"])*\")|(-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?\b)|(\btrue\b|\bfalse\b)|(\bnull\b)/g,
      function (m, k, v, n, b, nl) {
        if (k)  return '<span class="jk">' + k  + '</span>';
        if (v)  return '<span class="jv">' + v  + '</span>';
        if (n)  return '<span class="jn">' + n  + '</span>';
        if (b)  return '<span class="jb">' + b  + '</span>';
        if (nl) return '<span class="jnl">' + nl + '</span>';
        return m;
      }
    );
  }

  function prettyJson(s) {
    if (typeof s !== 'string' || !s) return s;
    try {
      return JSON.stringify(JSON.parse(s), null, 2);
    } catch (e) {
      return s;
    }
  }

  function expandLabel() {
    const s = (root && root.uecp && root.uecp.T)
      ? root.uecp.T('Click to expand')
      : 'Click to expand';
    return escapeHtml(s);
  }

  let renderMarkdown;

  if (root && typeof root.marked !== 'undefined') {
    renderMarkdown = function renderMarkdown(s) {
      let h = root.marked.parse(s);

      h = h.replace(/<pre[^>]*>\s*<code[^>]*>\s*<\/code>\s*<\/pre>/g, '');

      h = h.replace(/(<p[^>]*>)([\s\S]*?)(<\/p>)/g, function (m, o, c, cl) {
        return (c.indexOf('"tool_type"') !== -1 && c.indexOf('"arguments"') !== -1) ? '' : m;
      });

      if (root.createPieChart) {
        h = h.replace(/<pre><code class="language-chart">([\s\S]*?)<\/code><\/pre>/g, function (m, c) {
          return root.createPieChart(c.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&'));
        });
      }

      if (typeof root.nomnoml !== 'undefined') {
        h = h.replace(/<pre><code class="language-flow">([\s\S]*?)<\/code><\/pre>/g, function (m, c) {
          var d = c.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&').trim()
            .replace(/\]\s+([^\->\[\s][^>\[]*?)\s+(-+>)/g, '] -$1- $2')
            .replace(/\(([^)]*)\)/g, '-$1-')
            .replace(/\["([^"]*?)"\]/g, '$1')
            .replace(/\[(\d+(?:\.\d+)?%?)\]/g, '$1')
            .replace(/(\[(?:[^\[\]]|\[[^\[\]]*\])*\])\s*\+\s*(?=\[)/g, '$1, ');
          try {
            var svg = root.nomnoml.renderSvg('#stroke:#b0b0b0\n#lineWidth:2\n#fill:#272523\n#fontSize:14\n' + d);
            return '<div class="diagram-box" data-expand-label="' + expandLabel() + '" onclick="window.UECP.openLightbox({kind:\'svg\',html:this.querySelector(\'svg\').outerHTML})">' + svg + '</div>';
          } catch (e) {
            return '<pre style="color:#e06060;font-size:11px">Flow diagram error: ' + e.message + '</pre>';
          }
        });
      }

      h = (function (h) {
        var flowRx  = /\[[^\]]+\]\s*(?:--[^>]*)?-+>\s*\[[^\]]+\]/;
        var arrowRx = /\[[^\]]+\]\s*(?:--[^>]*-+>|->)/;
        function unhtml(s) {
          return s.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&')
            .replace(/<br\s*\/?>/g, '\n').replace(/<[^>]+>/g, '');
        }
        function isNodeLine(ln) {
          return ln.length > 0 && ln.length < 60 && !/[|{}=<>]/.test(ln) &&
            !/^\s*[-*]\s/.test(ln) && !/:\s/.test(ln) && !/^\d+\.\s/.test(ln);
        }
        function autoFlowBlock(raw) {
          var lines = raw.split('\n'), allFlow = [], inFlow = false, bHasExplicit = false;
          for (var i = 0; i < lines.length; i++) {
            var orig = lines[i];
            var ln = orig.replace(/^\s*flow\s*/, '').trim();
            if (/^\s*flow\s*$/.test(orig) || (/^\s*flow\s/.test(orig) && flowRx.test(ln))) bHasExplicit = true;
            if (!ln) { if (inFlow) inFlow = false; continue; }
            if (flowRx.test(ln))           { allFlow.push(ln); inFlow = true; }
            else if (arrowRx.test(ln))     { allFlow.push(ln); inFlow = true; }
            else if (ln.toLowerCase() === 'flow') { inFlow = true; }
            else if (inFlow && isNodeLine(ln)) { allFlow.push('[' + ln + ']'); }
            else { inFlow = false; }
          }
          if (allFlow.length < (bHasExplicit ? 1 : 3)) return null;
          var chains = [], cur = [];
          for (var j = 0; j < allFlow.length; j++) {
            var fl = allFlow[j];
            if (flowRx.test(fl) || arrowRx.test(fl)) {
              if (cur.length > 0) { chains.push(cur.join(' -> ')); cur = []; }
              chains.push(fl);
            } else { cur.push(fl); }
          }
          if (cur.length > 0) chains.push(cur.join(' -> '));
          return chains.join('\n');
        }
        var body = unhtml(h);
        var d = autoFlowBlock(body);
        if (d && d.split('\n').length >= 1 && typeof root.nomnoml !== 'undefined') {
          d = d.replace(/\]\s+([^\->\[\s][^>\[]*?)\s+(-+>)/g, '] -$1- $2')
               .replace(/\(([^)]*)\)/g, '-$1-')
               .replace(/\["([^"]*?)"\]/g, '$1');
          try {
            var svg = root.nomnoml.renderSvg('#stroke:#b0b0b0\n#lineWidth:2\n#fill:#272523\n#fontSize:14\n' + d);
            var diaHtml = '<div class="diagram-box" data-expand-label="' + expandLabel() + '" onclick="window.UECP.openLightbox({kind:\'svg\',html:this.querySelector(\'svg\').outerHTML})">' + svg + '</div>';
            h = h.replace(/<p>[^<]*(?:\[[^\]]+\]\s*(?:--[^>]*)?-+&gt;\s*\[[^\]]*\]|flow\s)[^<]*<\/p>/gi, '');
            h = h.replace(/<p>\s*flow\s*<\/p>/gi, '');
            h = h.replace(/(?:^|(?<=<\/[^>]+>))\s*(?:flow\s+)?\[[^\]]+\]\s*(?:--[^>]*)?-+(?:&gt;|>)\s*\[[^\]]+\].*?(?=<[a-zA-Z/]|$)/g, '');
            h += diaHtml;
          } catch (e) {  }
        }
        return h;
      })(h);

      if (root.createDepGraph) {
        h = h.replace(/<pre><code class="language-depgraph">([\s\S]*?)<\/code><\/pre>/g, function (m, c) {
          return root.createDepGraph(c.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&').replace(/&quot;/g, '"'));
        });
      }

      if (root.createHeatmap) {
        h = h.replace(/<pre><code class="language-heatmap">([\s\S]*?)<\/code><\/pre>/g, function (m, c) {
          return root.createHeatmap(c.replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&amp;/g, '&'));
        });
      }

      h = h.replace(/<pre><code class="language-json">([\s\S]*?)<\/code><\/pre>/g, function (m, c) {
        return '<pre class="json-block"><code>' + hlJson(c) + '</code></pre>';
      });

      h = h.replace(/\[([^\]]+)\]\(ue:\/\/asset\?name=([^)]+)\)/g, '<a href="ue://asset?name=$2" class="asset-link">$1</a>');

      h = h.replace(/<code>(\/Game\/[^<\s]+)<\/code>/g, '<a href="ue://asset?name=$1" class="asset-link"><code>$1</code></a>');

      h = h.replace(/@([\w.\-]+)\s*\((\/Game\/[^)\s]+)\)/g, '<a href="ue://asset?name=$2" class="asset-chip" title="$2">@$1</a>');

      h = linkifyAssets(h);

      h = h.replace(/<img /g, '<img class="chat-img" onclick="window.UECP.openLightbox({kind:\'image\',src:this.src})" ');

      return h;
    };
  }

  return { escapeHtml, linkifyAssets, hlJson, prettyJson, renderMarkdown };
}));
