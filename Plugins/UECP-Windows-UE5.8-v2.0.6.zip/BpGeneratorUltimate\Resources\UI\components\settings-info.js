(function () {
  const EULA_CITE = 'Fab EULA — §e (Plugins, Code):';
  const EULA_QUOTE = '“Code plugins that are being offered on the Epic Marketplace, including Unreal Engine Plugins and Unity Plugins (“Plugins”), are offered to you on a per-seat basis and may only be used by the number of users that you have purchased licenses for.”';

  const t = function (key, vars) {
    if (window.uecp && typeof window.uecp.t === 'function') return window.uecp.t(key, vars);
    let out = String(key);
    if (vars) Object.keys(vars).forEach(function (k) {
      out = out.replace(new RegExp('\{' + k + '\}', 'g'), String(vars[k]));
    });
    return out;
  };

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  class SettingsInfo extends HTMLElement {
    connectedCallback() {
      this.style.cssText = 'display:flex;flex-direction:column;flex:1;min-height:0';
      this._render(null);
      window.uecp.call('request_plugin_info', {});
      window.uecp.call('request_update_status', {});
    }

    _onUpdateStatus(st) {
      this._upd = st || null;
      this._render(this._info);
    }

    _onSettingsInit( ) {
    }

    _onInfo(info) {
      this._info = info;
      this._render(info);
    }

    _updatesCard() {
      const u = this._upd || {};
      const state = u.state || 'idle';
      const info  = u.update || {};
      const busy  = state === 'checking' || u.checking === true;
      const pct   = Math.round((u.progress || 0) * 100);

      let line = t('Updates are delivered from the website.');
      let action = '';

      let report = '';
      if (u.apply_report) {
        report = '<div style="margin-bottom:10px;padding:8px 11px;border-radius:6px;'
               + 'background:var(--ue-elev);font-size:12.5px">' + esc(u.apply_report) + '</div>';
      }

      if (busy) {
        line = t('Checking…');
      } else if (state === 'available') {
        line = info.size_bytes
          ? esc(t('Version {version} is available ({size} MB).', {
              version: info.version || '?',
              size: (info.size_bytes / 1048576).toFixed(1),
            }))
          : esc(t('Version {version} is available.', { version: info.version || '?' }));
        action = '<button id="si-upd-get" class="btn btn-primary" style="font-size:12.5px">'
               + esc(t('Get update')) + '</button>';
      } else if (state === 'downloading') {
        line = esc(t('Downloading {version}… {percent}%', {
          version: info.version || '?', percent: pct,
        }));
        action = '<button id="si-upd-cancel" class="btn" style="font-size:12.5px">'
               + esc(t('Cancel')) + '</button>';
      } else if (state === 'verifying') {
        line = t('Verifying download…');
      } else if (state === 'staged') {
        line = u.revert_pending
          ? esc(t('Going back to {version}. Restart the editor to apply it.', {
              version: info.version || '?',
            }))
          : esc(t('Version {version} is ready. Restart the editor to apply it.', {
              version: info.version || '?',
            }));
        action = '<button id="si-upd-restart" class="btn btn-primary" style="font-size:12.5px">'
               + esc(t('Restart now')) + '</button>';
      } else if (state === 'manual_only') {
        line = esc(info.message || t('An update is available from the website.'));
        action = '<button id="si-upd-get" class="btn" style="font-size:12.5px">'
               + esc(t('Open download page')) + '</button>';
      } else if (state === 'up_to_date') {
        line = t('You are on the latest version.');
      } else if (state === 'failed') {
        line = esc(u.error || t('Could not check for updates.'));
      }

      const checked = !u.last_checked
        ? esc(t('Never checked'))
        : esc(t('Last checked {when} UTC', {
            when: String(u.last_checked).replace('T', ' ').replace(/\..*$/, ''),
          }));

      const channel = u.channel === 'beta' ? 'beta' : 'stable';

      let bar = '';
      if (state === 'downloading') {
        bar = '<div style="margin-top:10px;height:4px;border-radius:2px;background:var(--ue-elev);overflow:hidden">'
            + '<div style="height:100%;width:' + pct + '%;background:var(--ue-accent);transition:width .2s"></div>'
            + '</div>';
      }

      let revert = '';
      if (u.revert_version && !u.revert_pending
          && state !== 'downloading' && state !== 'verifying' && state !== 'staged') {
        revert = '<div style="display:flex;align-items:center;gap:9px;margin-top:12px;'
               + 'padding-top:11px;border-top:1px solid var(--ue-border)">'
               + '<span style="font-size:12.5px;color:var(--ue-text-mid);flex:1">'
               + esc(t('Version {version} is kept on this machine.', { version: u.revert_version }))
               + '</span>'
               + '<button id="si-upd-revert" class="btn" style="font-size:12.5px">'
               + esc(t('Go back')) + '</button>'
               + '</div>';
      }

      let notes = '';
      if (state === 'available' && info.notes_md) {
        notes = '<div style="margin-top:11px;padding-top:11px;border-top:1px solid var(--ue-border);'
              + 'font-size:12.5px;color:var(--ue-text-mid);white-space:pre-wrap;max-height:120px;overflow-y:auto">'
              + esc(info.notes_md) + '</div>';
      }

      return '<div class="card" style="margin-top:14px">'
        + '<div class="section-label" style="margin:0 0 11px">' + esc(t('UPDATES')) + '</div>'
        + report
        + '<div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">'
        +   '<div style="flex:1;min-width:200px">'
        +     '<div style="font-size:13px">' + line + '</div>'
        +     '<div class="chat-item-meta" style="margin-top:3px">' + checked + '</div>'
        +   '</div>'
        +   action
        +   ((state === 'downloading' || state === 'verifying')
        ?     ''
        :     '<button id="si-upd-check" class="btn" style="font-size:12.5px"' + (busy ? ' disabled' : '') + '>'
            + esc(busy ? t('Checking…') : t('Check now')) + '</button>')
        + '</div>'
        + bar
        + notes
        + revert
        + '<div style="display:flex;align-items:center;gap:9px;margin-top:12px;padding-top:11px;border-top:1px solid var(--ue-border)">'
        +   '<span style="font-size:12.5px;color:var(--ue-text-mid);flex:1">' + esc(t('Update channel')) + '</span>'
        +   '<select id="si-upd-channel" data-no-autosave style="font-size:12.5px">'
        +     '<option value="stable"' + (channel === 'stable' ? ' selected' : '') + '>' + esc(t('Stable')) + '</option>'
        +     '<option value="beta"' + (channel === 'beta' ? ' selected' : '') + '>' + esc(t('Beta')) + '</option>'
        +   '</select>'
        + '</div>'
        + '</div>';
    }

    _render(info) {
      let body = '';

      if (!info) {
        body = '<div style="color:var(--ue-text-lo);font-size:13px;padding:20px 0">Loading plugin info…</div>';
      } else {
        const pluginName   = info.name         || 'Ultimate Engine CoPilot';
        const version      = info.version      || '—';
        const ueVersion    = info.ue_version   || '—';
        const buildConfig  = info.build_config || '—';
        const platform     = info.platform     || '—';

        const links = [
          {
            label: 'Documentation',
            icon: '<path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/>',
            url: info.docs_url || 'https://www.gamedevcore.com/docs/bpgenerator-ultimate',
          },
          {
            label: 'Discord community',
            icon: '<path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028 14.09 14.09 0 0 0 1.226-1.994.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03z"/>',
            url: info.discord_url || 'https://discord.gg/w65xMuxEhb',
          },
          {
            label: 'Website',
            icon: '<circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>',
            url: info.website_url || 'https://www.gamedevcore.com',
          },
        ];

        body += '<div class="card" style="display:flex;align-items:center;gap:15px;background:linear-gradient(110deg,var(--ue-elev),var(--ue-panel));padding:20px 22px">'
          + '<span style="width:54px;height:54px;border-radius:13px;background:linear-gradient(150deg,var(--ue-accent),var(--ue-accent-deep));display:flex;align-items:center;justify-content:center;flex-shrink:0">'
          + '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">'
          + '<path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3Z"/>'
          + '</svg>'
          + '</span>'
          + '<div style="flex:1;min-width:0">'
          + '<div style="display:flex;align-items:center;gap:10px;flex-wrap:wrap">'
          + '<span style="font-size:17px;font-weight:600;letter-spacing:-.01em">' + esc(pluginName) + '</span>'
          + '<span style="display:inline-flex;align-items:center;padding:5px 15px;border-radius:999px;'
          +   'border:1.5px solid var(--ue-accent);background:var(--ue-accent-soft);'
          +   'box-shadow:0 0 0 4px var(--ue-accent-soft);color:var(--ue-accent-bright);'
          +   'font-size:15px;font-weight:700;letter-spacing:.02em;line-height:1.45;'
          +   'font-variant-numeric:tabular-nums;white-space:nowrap">'
          + esc(version === '—' ? version : 'v' + version)
          + '</span>'
          + '</div>'
          + '</div>'
          + '</div>';

        body += '<div style="display:grid;grid-template-columns:1fr 1fr;gap:14px;margin-top:14px">';

        body += '<div class="card">'
          + '<div class="section-label" style="margin:0 0 11px">ENVIRONMENT</div>'
          + '<div style="display:flex;flex-direction:column;gap:8px">'
          + '<div style="display:flex;justify-content:space-between"><span style="font-size:12.5px;color:var(--ue-text-mid)">Unreal Engine</span><span class="mono" style="font-size:12px">' + esc(ueVersion) + '</span></div>'
          + '<div style="display:flex;justify-content:space-between"><span style="font-size:12.5px;color:var(--ue-text-mid)">Build config</span><span class="mono" style="font-size:12px">' + esc(buildConfig) + '</span></div>'
          + '<div style="display:flex;justify-content:space-between"><span style="font-size:12.5px;color:var(--ue-text-mid)">Platform</span><span class="mono" style="font-size:12px">' + esc(platform) + '</span></div>'
          + '</div>'
          + '</div>';

        body += '<div class="card">'
          + '<div class="section-label" style="margin:0 0 11px">LINKS</div>'
          + '<div style="display:flex;flex-direction:column;gap:11px">';
        links.forEach(function (lk) {
          body += '<span class="si-link" data-url="' + esc(lk.url) + '" style="display:flex;align-items:center;gap:9px;font-size:13px;color:var(--ue-accent-bright);cursor:pointer">'
            + '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">' + lk.icon + '</svg>'
            + esc(lk.label)
            + '</span>';
        });
        body += '<span class="si-replay" style="display:flex;align-items:center;gap:9px;font-size:13px;color:var(--ue-accent-bright);cursor:pointer">'
          + '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">'
          + '<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/></svg>'
          + esc(t('Replay the welcome screen'))
          + '</span>';
        body += '</div></div>';
        body += '</div>';

        body += '<div class="card" style="margin-top:14px">'
          + '<div class="section-label" style="margin:0 0 11px">LICENSE</div>'
          + '<div style="font-size:12.5px;color:var(--ue-text-mid);line-height:1.6;margin-bottom:12px">'
          +   esc(t('Per-seat license — up to 2 devices for one user. Sharing your order is automatically detected and may revoke the license.'))
          + '</div>'
          + '<div style="font-size:11.5px;color:var(--ue-text-mid);opacity:.85;line-height:1.6;margin-bottom:13px;'
          +   'padding:9px 11px;border-left:2px solid var(--ue-accent);background:var(--ue-accent-soft);border-radius:4px">'
          +   '<strong>' + EULA_CITE + '</strong> ' + EULA_QUOTE
          + '</div>'
          + '<div style="display:flex;align-items:center;gap:8px;font-size:12.5px;margin-bottom:14px">'
          +   '<span style="color:var(--ue-text-mid)">' + esc(t('This device:')) + '</span>'
          +   '<span style="color:var(--ue-accent-bright);font-family:var(--ue-font-mono);font-weight:600;'
          +     'letter-spacing:.6px;background:var(--ue-accent-soft);padding:3px 9px;border-radius:6px">'
          +     esc(info.device_id || '—') + '</span>'
          + '</div>'
          + '<div style="display:flex;flex-direction:column;gap:9px">'
          +   '<span class="si-link" data-url="https://www.gamedevcore.com/manage-devices" '
          +     'style="font-size:13px;color:var(--ue-accent-bright);cursor:pointer">'
          +     esc(t('Manage activated devices')) + '</span>'
          +   '<span class="si-link" data-url="https://www.fab.com/eula" '
          +     'style="font-size:13px;color:var(--ue-accent-bright);cursor:pointer">'
          +     esc(t('Fab license terms (per-seat)')) + '</span>'
          + '</div>'
          + '</div>';

        {
          var origin = info.auth_origin || '';
          var cred = info.auth_credential || '';
          var acctUrl = info.account_url || 'https://www.gamedevcore.com/account';
          var originLabel = origin === 'fab' ? t('FAB order') : origin === 'website' ? t('Website key') : t('Not signed in');
          body += '<div class="card" style="margin-top:14px">'
            + '<div class="section-label" style="margin:0 0 11px">' + 'ACCOUNT' + '</div>'
            + '<div style="display:flex;justify-content:space-between;align-items:center;gap:10px;flex-wrap:wrap">'
            +   '<div style="min-width:180px">'
            +     '<div style="font-size:12.5px;color:var(--ue-text-mid)">' + esc(t('Signed in with')) + '</div>'
            +     '<div style="margin-top:3px"><span style="font-size:13px">' + esc(originLabel) + '</span>'
            +       (cred ? ' <span class="mono" style="font-size:12px;color:var(--ue-text-lo)">' + esc(cred) + '</span>' : '')
            +     '</div>'
            +   '</div>'
            +   '<div style="display:flex;gap:8px;flex-wrap:wrap">'
            +     '<button class="si-account-manage" data-url="' + esc(acctUrl) + '" style="background:transparent;color:var(--ue-text-hi);border:1px solid var(--ue-line-soft);border-radius:6px;padding:7px 11px;font:inherit;font-size:12px;cursor:pointer">' + esc(t('Manage account')) + '</button>'
            +   '</div>'
            + '</div>'
            + '<div class="chat-item-meta" style="margin-top:9px">' + esc(t('Signing out and switching to a different credential lives in the Account screen.')) + '</div>'
            + '</div>';
        }

        body += this._updatesCard();
      }

      this.innerHTML =
        '<div class="content-head"><span class="crumb"><b>Info</b></span></div>'
        + '<div class="page page-narrow" style="overflow-y:auto;flex:1">'
        + body
        + '</div>';

      const chk = this.querySelector('#si-upd-check');
      if (chk) chk.addEventListener('click', function () { window.uecp.call('check_for_updates', {}); });
      const dl = this.querySelector('#si-upd-get');
      if (dl) dl.addEventListener('click', function () { window.uecp.call('open_update_download', {}); });
      const rs = this.querySelector('#si-upd-restart');
      if (rs) rs.addEventListener('click', function () { window.uecp.call('restart_editor', {}); });
      const cx = this.querySelector('#si-upd-cancel');
      if (cx) cx.addEventListener('click', function () { window.uecp.call('cancel_update_download', {}); });
      const rv = this.querySelector('#si-upd-revert');
      if (rv) rv.addEventListener('click', function () { window.uecp.call('revert_update', {}); });
      const ch = this.querySelector('#si-upd-channel');
      if (ch) ch.addEventListener('change', function () {
        window.uecp.call('set_update_channel', { channel: ch.value });
      });

      const acctMng = this.querySelector('.si-account-manage');
      if (acctMng) acctMng.addEventListener('click', function () {
        window.uecp.call('open_external_url', { url: acctMng.dataset.url || 'https://www.gamedevcore.com/account' });
      });

      const self = this;
      this.querySelectorAll('.si-link[data-url]').forEach(function (el) {
        el.addEventListener('click', function () {
          const url = el.dataset.url;
          if (url) window.uecp.call('open_external_url', { url: url });
        });
      });

      this.querySelectorAll('.si-replay').forEach(function (el) {
        el.addEventListener('click', function () { window.uecp.call('show_welcome', {}); });
      });

    }
  }
  customElements.define('settings-info', SettingsInfo);
})();
