// Copyright 2026, BlueprintsLab, All rights reserved
#include "UECPSteamDiagnostics.h"

#include "Async/UECPSteamSessionAsync.h"
#include "Containers/Ticker.h"
#include "Engine/Engine.h"
#include "Engine/World.h"
#include "Library/UECPSteamIdentityLibrary.h"
#include "Library/UECPSteamSessionLibrary.h"
#include "Library/UECPSteamP2PLibrary.h"
#include "Library/UECPSteamVoiceLibrary.h"
#include "UECPSteamAPI.h"
#include "UECPSteamOSS.h"
#include "UECPSteamRuntimeModule.h"
#include "UECPSteamSubsystem.h"
#include "UObject/UObjectGlobals.h"

namespace
{
	TArray<TStrongObjectPtr<UUECPSteamDiagnosticListener>> GHeldListeners;

	TArray<FUECPSteamSessionSearchResult> GLastFindResults;

	TArray<TStrongObjectPtr<UObject>> GHeldNodes;

	UWorld* DiagnosticWorld()
	{
		if (!GEngine)
		{
			return nullptr;
		}
		UWorld* Fallback = nullptr;
		for (const FWorldContext& Context : GEngine->GetWorldContexts())
		{
			if (!Context.World())
			{
				continue;
			}
			if (Context.WorldType == EWorldType::Game || Context.WorldType == EWorldType::PIE)
			{
				return Context.World();
			}
			if (!Fallback && Context.WorldType == EWorldType::Editor)
			{
				Fallback = Context.World();
			}
		}
		return Fallback;
	}

	UUECPSteamDiagnosticListener* MakeListener(const FString& Label)
	{
		UUECPSteamDiagnosticListener* Listener = NewObject<UUECPSteamDiagnosticListener>();
		Listener->Label = Label;
		Listener->Hold();
		return Listener;
	}

	void LogOutcome(const FString& Label, const TCHAR* Outcome, const FUECPSteamError& Error)
	{
		if (Error.bSucceeded())
		{
			UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] %s: %s"), *Label, Outcome);
		}
		else
		{
			UE_LOG(LogUECPSteam, Warning, TEXT("[DIAG] %s: FAILED (%d) %s"),
				*Label, static_cast<int32>(Error.Result), *Error.Message);
		}
	}
}

void UUECPSteamDiagnosticListener::Hold()
{
	GHeldListeners.Add(TStrongObjectPtr<UUECPSteamDiagnosticListener>(this));
}

void UUECPSteamDiagnosticListener::OnSessionResult(FUECPSteamError Error)
{
	LogOutcome(Label, TEXT("OK"), Error);
}

void UUECPSteamDiagnosticListener::OnFindResult(
	const TArray<FUECPSteamSessionSearchResult>& Results, FUECPSteamError Error)
{
	LogOutcome(Label, *FString::Printf(TEXT("OK, %d result(s)"), Results.Num()), Error);

	GLastFindResults = Results;

	for (int32 Index = 0; Index < Results.Num(); ++Index)
	{
		const FUECPSteamSessionSearchResult& Result = Results[Index];
		UE_LOG(LogUECPSteam, Display,
			TEXT("[DIAG]   [%d] host='%s' steamid=%s ping=%dms slots=%d/%d map='%s' mode='%s' joinable=%s"),
			Index, *Result.HostName, *Result.HostSteamId.ToString(), Result.PingMs,
			Result.OpenSlots, Result.MaxPlayers, *Result.MapName, *Result.GameMode,
			Result.bAllowJoinInProgress ? TEXT("yes") : TEXT("no"));
	}
}

void UUECPSteamDiagnosticListener::OnJoinResult(const FString& ConnectString, FUECPSteamError Error)
{
	LogOutcome(Label, *FString::Printf(TEXT("OK, connect='%s'"), *ConnectString), Error);
}

void UUECPSteamDiagnosticListener::OnLeaderboardEntries(
	const TArray<FUECPSteamLeaderboardEntry>& Entries, FUECPSteamError Error)
{
	LogOutcome(Label, *FString::Printf(TEXT("OK, %d entr(y/ies)"), Entries.Num()), Error);
	for (const FUECPSteamLeaderboardEntry& Entry : Entries)
	{
		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG]   #%d score=%d '%s' (%s) details=%d"),
			Entry.GlobalRank, Entry.Score, *Entry.PlayerName,
			*Entry.SteamId.ToString(), Entry.Details.Num());
	}
}

void UUECPSteamDiagnosticListener::OnWorkshopQuery(
	const TArray<FUECPSteamWorkshopItem>& Items, int32 TotalMatching, FUECPSteamError Error)
{
	LogOutcome(Label, *FString::Printf(TEXT("OK, %d item(s) of %d matching"),
		Items.Num(), TotalMatching), Error);
	for (const FUECPSteamWorkshopItem& Item : Items)
	{
		UE_LOG(LogUECPSteam, Display,
			TEXT("[DIAG]   %s '%s' by %s | +%d/-%d score=%.2f size=%lld tags=[%s]"),
			*Item.ItemId.ToString(), *Item.Title, *Item.Owner.ToString(),
			Item.UpVotes, Item.DownVotes, Item.Score, Item.FileSizeBytes,
			*FString::Join(Item.Tags, TEXT(", ")));
	}
}

void UUECPSteamDiagnosticListener::OnP2PSessionRequest(FUECPSteamID PeerSteamId)
{
	const bool bAccepted = UUECPSteamP2PLibrary::AcceptP2PSession(PeerSteamId);
	UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] P2P: session request from %s -> %s"),
		*PeerSteamId.ToString(), bAccepted ? TEXT("ACCEPTED") : TEXT("accept FAILED"));
}

void UUECPSteamDiagnosticListener::OnP2PMessage(
	FUECPSteamID SenderSteamId, const TArray<uint8>& Data, int32 Channel)
{
	UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] P2P: RECEIVED %d byte(s) on channel %d from %s: '%s'"),
		Data.Num(), Channel, *SenderSteamId.ToString(),
		*UUECPSteamP2PLibrary::Conv_P2PDataToString(Data));
}

void UUECPSteamDiagnosticListener::OnLeaderboardUpload(
	bool bScoreChanged, int32 NewGlobalRank, int32 PreviousGlobalRank, FUECPSteamError Error)
{
	LogOutcome(Label, *FString::Printf(TEXT("OK, changed=%s rank %d -> %d"),
		bScoreChanged ? TEXT("yes") : TEXT("no (kept best)"), PreviousGlobalRank, NewGlobalRank), Error);
}

#if !UE_BUILD_SHIPPING

namespace
{
	void After(float Delay, TFunction<void()> Work)
	{
		FTSTicker::GetCoreTicker().AddTicker(FTickerDelegate::CreateLambda(
			[Work = MoveTemp(Work)](float) { Work(); return false; }), Delay);
	}

	void PrintStatus(const TCHAR* Stage)
	{
		UWorld* World = DiagnosticWorld();

		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] === status (%s) ==="), Stage);
		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] compiled with Steam : %s"),
			FUECPSteamRuntimeModule::IsCompiledWithSteam() ? TEXT("yes") : TEXT("no"));
		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] SDK client live     : %s"),
			UECPSteam::IsClientAvailable() ? TEXT("yes") : TEXT("no"));
		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] OSS Steam active    : %s"),
			UECPSteam::IsOssSteamActive() ? TEXT("yes") : TEXT("no"));
		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] world              : %s"),
			World ? *World->GetName() : TEXT("<none>"));

		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] build unique id    : %d   <-- MUST MATCH on both machines"),
			GetBuildUniqueId());

		if (!World)
		{
			UE_LOG(LogUECPSteam, Warning, TEXT("[DIAG] no game world; session state unavailable"));
			return;
		}

		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] OSS subsystem       : %s"),
			UECPSteamOSS::Get(World) ? TEXT("valid") : TEXT("NULL"));
		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] session interface   : %s"),
			UECPSteamOSS::Session(World).IsValid() ? TEXT("valid") : TEXT("NULL"));
		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] local steam id      : %s"),
			*UUECPSteamIdentityLibrary::GetSteamPlayerId(World).ToString());
		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] nickname            : '%s'"),
			*UUECPSteamIdentityLibrary::GetSteamPlayerNickname(World));
		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] login status        : %d"),
			static_cast<int32>(UUECPSteamIdentityLibrary::GetSteamLoginStatus(World)));
		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] session state       : %d"),
			static_cast<int32>(UUECPSteamSessionLibrary::GetSteamSessionState(World, NAME_None)));
		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] in session          : %s"),
			UUECPSteamSessionLibrary::IsInSteamSession(World, NAME_None) ? TEXT("yes") : TEXT("no"));
		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] open slots          : %d"),
			UUECPSteamSessionLibrary::GetSteamSessionOpenSlots(World, NAME_None));
		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] connect string      : '%s'"),
			*UUECPSteamSessionLibrary::GetSteamResolvedConnectString(World, NAME_None));
	}

	void RunHost(int32 MaxPlayers)
	{
		UWorld* World = DiagnosticWorld();
		if (!World)
		{
			UE_LOG(LogUECPSteam, Warning, TEXT("[DIAG] Host: no game world."));
			return;
		}

		FUECPSteamSessionSettings Settings;
		Settings.SessionType = EUECPSteamSessionType::Lobby;
		Settings.MaxPlayers  = MaxPlayers;
		Settings.MapName     = TEXT("DiagnosticMap");
		Settings.GameMode    = TEXT("DiagnosticMode");
		Settings.ExtraSettings.Add(TEXT("UECPDIAG"), TEXT("1"));

		UUECPSteamDiagnosticListener* Listener = MakeListener(TEXT("Host"));
		UUECPSteamCreateSession* Node =
			UUECPSteamCreateSession::CreateSteamSession(World, Settings, NAME_None);
		Node->OnSuccess.AddDynamic(Listener, &UUECPSteamDiagnosticListener::OnSessionResult);
		Node->OnFailure.AddDynamic(Listener, &UUECPSteamDiagnosticListener::OnSessionResult);
		Node->Activate();

		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] Host: create requested (%d players)."), MaxPlayers);
	}

	void RunFind()
	{
		UWorld* World = DiagnosticWorld();
		if (!World)
		{
			UE_LOG(LogUECPSteam, Warning, TEXT("[DIAG] Find: no game world."));
			return;
		}

		FUECPSteamSessionSearchSettings Search;
		Search.SessionType   = EUECPSteamSessionType::Lobby;
		Search.MaxResults    = 20;
		Search.bOnlyJoinable = false;

		UUECPSteamDiagnosticListener* Listener = MakeListener(TEXT("Find"));
		UUECPSteamFindSessions* Node = UUECPSteamFindSessions::FindSteamSessions(World, Search);
		Node->OnSuccess.AddDynamic(Listener, &UUECPSteamDiagnosticListener::OnFindResult);
		Node->OnFailure.AddDynamic(Listener, &UUECPSteamDiagnosticListener::OnFindResult);
		Node->Activate();

		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] Find: search requested."));
	}

	void RunJoin(int32 Index)
	{
		UWorld* World = DiagnosticWorld();
		if (!World)
		{
			UE_LOG(LogUECPSteam, Warning, TEXT("[DIAG] Join: no game world."));
			return;
		}
		if (!GLastFindResults.IsValidIndex(Index))
		{
			UE_LOG(LogUECPSteam, Warning,
				TEXT("[DIAG] Join: no result at index %d (have %d). Run UECP.Steam.Find first."),
				Index, GLastFindResults.Num());
			return;
		}

		UUECPSteamDiagnosticListener* Listener = MakeListener(FString::Printf(TEXT("Join[%d]"), Index));
		UUECPSteamJoinSession* Node = UUECPSteamJoinSession::JoinSteamSession(
			World, GLastFindResults[Index], NAME_None);
		Node->OnSuccess.AddDynamic(Listener, &UUECPSteamDiagnosticListener::OnJoinResult);
		Node->OnFailure.AddDynamic(Listener, &UUECPSteamDiagnosticListener::OnJoinResult);
		Node->Activate();

		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] Join: requested index %d (host '%s')."),
			Index, *GLastFindResults[Index].HostName);
	}

	void RunDestroy()
	{
		UWorld* World = DiagnosticWorld();
		if (!World)
		{
			UE_LOG(LogUECPSteam, Warning, TEXT("[DIAG] Destroy: no game world."));
			return;
		}

		UUECPSteamDiagnosticListener* Listener = MakeListener(TEXT("Destroy"));
		UUECPSteamDestroySession* Node = UUECPSteamDestroySession::DestroySteamSession(World, NAME_None);
		Node->OnSuccess.AddDynamic(Listener, &UUECPSteamDiagnosticListener::OnSessionResult);
		Node->OnFailure.AddDynamic(Listener, &UUECPSteamDiagnosticListener::OnSessionResult);
		Node->Activate();

		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] Destroy: requested."));
	}
}

static FAutoConsoleCommand GSteamP2PListenCmd(
	TEXT("UECP.Steam.P2PListen"),
	TEXT("Open a P2P channel and log everything that arrives. Args: [channel]."),
	FConsoleCommandWithArgsDelegate::CreateStatic([](const TArray<FString>& Args)
	{
		const int32 Channel = Args.Num() > 0 ? FCString::Atoi(*Args[0]) : 0;

		UUECPSteamSubsystem* Subsystem = UUECPSteamSubsystem::Get(DiagnosticWorld());
		if (!Subsystem)
		{
			UE_LOG(LogUECPSteam, Warning,
				TEXT("[DIAG] P2P: no Steam subsystem -- P2P events live on the game instance, so this needs a running game."));
			return;
		}

		UUECPSteamDiagnosticListener* Listener = MakeListener(TEXT("P2P"));
		Subsystem->OnP2PSessionRequest.AddDynamic(Listener, &UUECPSteamDiagnosticListener::OnP2PSessionRequest);
		Subsystem->OnP2PMessage.AddDynamic(Listener, &UUECPSteamDiagnosticListener::OnP2PMessage);

		const bool bOpen = UUECPSteamP2PLibrary::OpenP2PChannel(Channel);
		UE_LOG(LogUECPSteam, Display,
			TEXT("[DIAG] P2P: listening on channel %d (%s). Local Steam ID is %s -- the sender needs it."),
			Channel, bOpen ? TEXT("open") : TEXT("OPEN FAILED"),
			*Subsystem->GetLocalSteamID().ToString());
	}));

static FAutoConsoleCommand GSteamP2PSendCmd(
	TEXT("UECP.Steam.P2PSend"),
	TEXT("Send a P2P message. Args: <peerSteamId> <word> [channel]."),
	FConsoleCommandWithArgsDelegate::CreateStatic([](const TArray<FString>& Args)
	{
		if (Args.Num() < 2)
		{
			UE_LOG(LogUECPSteam, Warning, TEXT("[DIAG] usage: UECP.Steam.P2PSend <peerSteamId> <word> [channel]"));
			return;
		}
		const FUECPSteamID Peer = UUECPSteamIdentityLibrary::MakeSteamIDFromString(Args[0]);
		const int32 Channel = Args.Num() > 2 ? FCString::Atoi(*Args[2]) : 0;

		UUECPSteamP2PLibrary::OpenP2PChannel(Channel);

		const bool bSent = UUECPSteamP2PLibrary::SendP2PString(Peer, Args[1], Channel);
		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] P2P: send '%s' to %s on channel %d -> %s"),
			*Args[1], *Peer.ToString(), Channel, bSent ? TEXT("accepted") : TEXT("REJECTED"));

		int32 Ping = 0; float Quality = 0.f; bool bRelayed = false;
		if (UUECPSteamP2PLibrary::GetP2PSessionInfo(Peer, Ping, Quality, bRelayed))
		{
			UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] P2P: link ping=%dms quality=%.2f relayed=%s"),
				Ping, Quality, bRelayed ? TEXT("yes") : TEXT("no"));
		}
	}));

static FAutoConsoleCommand GSteamVoiceTestCmd(
	TEXT("UECP.Steam.VoiceTest"),
	TEXT("Exercise the voice API without needing audible input."),
	FConsoleCommandDelegate::CreateStatic([]()
	{
		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] === voice ==="));
		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] capture device available : %s"),
			UUECPSteamVoiceLibrary::IsVoiceRecordingAvailable() ? TEXT("yes") : TEXT("no (expected with no mic)"));
		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] optimal sample rate      : %d Hz"),
			UUECPSteamVoiceLibrary::GetVoiceOptimalSampleRate());

		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] start recording         : %s"),
			UUECPSteamVoiceLibrary::StartVoiceRecording() ? TEXT("ok") : TEXT("failed"));

		TArray<uint8> Captured;
		const bool bGot = UUECPSteamVoiceLibrary::GetCompressedVoice(Captured);
		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] captured                : %s (%d bytes)"),
			bGot ? TEXT("data") : TEXT("none -- normal without a mic"), Captured.Num());

		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] stop recording          : %s"),
			UUECPSteamVoiceLibrary::StopVoiceRecording() ? TEXT("ok") : TEXT("failed"));

		TArray<uint8> Garbage;
		Garbage.SetNumZeroed(64);
		TArray<uint8> Pcm;
		const bool bDecoded = UUECPSteamVoiceLibrary::DecompressVoice(Garbage, Pcm);
		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] decompress(garbage)     : %s (%d bytes) -- rejecting is correct"),
			bDecoded ? TEXT("accepted?!") : TEXT("rejected cleanly"), Pcm.Num());

		if (bGot)
		{
			TArray<uint8> RoundTrip;
			const bool bOk = UUECPSteamVoiceLibrary::DecompressVoice(Captured, RoundTrip);
			UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] decompress(captured)    : %s (%d bytes PCM)"),
				bOk ? TEXT("ok") : TEXT("FAILED"), RoundTrip.Num());
		}
		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] === voice end ==="));
	}));

static FAutoConsoleCommand GSteamWorkshopCmd(
	TEXT("UECP.Steam.Workshop"),
	TEXT("Query the Workshop. Args: [page] [searchText]."),
	FConsoleCommandWithArgsDelegate::CreateStatic([](const TArray<FString>& Args)
	{
		const int32 QueryPage = Args.Num() > 0 ? FCString::Atoi(*Args[0]) : 1;
		const FString Search  = Args.Num() > 1 ? Args[1] : FString();

		UUECPSteamDiagnosticListener* Listener = MakeListener(TEXT("Workshop"));
		UUECPSteamWorkshopQuery* Node = UUECPSteamWorkshopQuery::QuerySteamWorkshop(
			DiagnosticWorld(), EUECPSteamWorkshopListType::All,
			EUECPSteamWorkshopSort::TotalSubscriptions, QueryPage, Search, TArray<FString>());
		Node->OnSuccess.AddDynamic(Listener, &UUECPSteamDiagnosticListener::OnWorkshopQuery);
		Node->OnFailure.AddDynamic(Listener, &UUECPSteamDiagnosticListener::OnWorkshopQuery);
		GHeldNodes.Add(TStrongObjectPtr<UObject>(Node));
		Node->Activate();

		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] Workshop: query requested (page %d, search '%s')."),
			QueryPage, *Search);
	}));

static FAutoConsoleCommand GSteamLeaderboardCmd(
	TEXT("UECP.Steam.Leaderboard"),
	TEXT("Download the top entries of a leaderboard. Args: <name> [count]."),
	FConsoleCommandWithArgsDelegate::CreateStatic([](const TArray<FString>& Args)
	{
		if (Args.Num() == 0)
		{
			UE_LOG(LogUECPSteam, Warning, TEXT("[DIAG] usage: UECP.Steam.Leaderboard <name> [count]"));
			return;
		}
		const int32 Count = Args.Num() > 1 ? FCString::Atoi(*Args[1]) : 5;

		UUECPSteamDiagnosticListener* Listener = MakeListener(FString::Printf(TEXT("Leaderboard '%s'"), *Args[0]));
		UUECPSteamDownloadLeaderboard* Node = UUECPSteamDownloadLeaderboard::DownloadSteamLeaderboard(
			DiagnosticWorld(), Args[0], EUECPSteamLeaderboardRequest::Global, 1, Count);
		Node->OnSuccess.AddDynamic(Listener, &UUECPSteamDiagnosticListener::OnLeaderboardEntries);
		Node->OnFailure.AddDynamic(Listener, &UUECPSteamDiagnosticListener::OnLeaderboardEntries);
		GHeldNodes.Add(TStrongObjectPtr<UObject>(Node));
		Node->Activate();

		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] Leaderboard '%s': download requested (top %d)."), *Args[0], Count);
	}));

static FAutoConsoleCommand GSteamLeaderboardUploadCmd(
	TEXT("UECP.Steam.LeaderboardUpload"),
	TEXT("Upload a score. Args: <name> <score> [create]."),
	FConsoleCommandWithArgsDelegate::CreateStatic([](const TArray<FString>& Args)
	{
		if (Args.Num() < 2)
		{
			UE_LOG(LogUECPSteam, Warning, TEXT("[DIAG] usage: UECP.Steam.LeaderboardUpload <name> <score> [create]"));
			return;
		}
		const int32 Score = FCString::Atoi(*Args[1]);
		const bool bCreate = Args.Num() > 2 && Args[2].ToBool();

		UUECPSteamDiagnosticListener* Listener = MakeListener(FString::Printf(TEXT("Upload '%s'"), *Args[0]));
		UUECPSteamUploadLeaderboardScore* Node = UUECPSteamUploadLeaderboardScore::UploadSteamLeaderboardScore(
			DiagnosticWorld(), Args[0], Score, TArray<int32>(),
			EUECPSteamLeaderboardUpload::KeepBest, bCreate);
		Node->OnSuccess.AddDynamic(Listener, &UUECPSteamDiagnosticListener::OnLeaderboardUpload);
		Node->OnFailure.AddDynamic(Listener, &UUECPSteamDiagnosticListener::OnLeaderboardUpload);
		GHeldNodes.Add(TStrongObjectPtr<UObject>(Node));
		Node->Activate();

		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] Upload '%s': score %d requested (create=%s)."),
			*Args[0], Score, bCreate ? TEXT("yes") : TEXT("no"));
	}));

static FAutoConsoleCommand GSteamStatusCmd(
	TEXT("UECP.Steam.Status"),
	TEXT("Print UECP Steam availability, identity, and current session state."),
	FConsoleCommandDelegate::CreateStatic([]() { PrintStatus(TEXT("on demand")); }));

static FAutoConsoleCommand GSteamHostCmd(
	TEXT("UECP.Steam.Host"),
	TEXT("Create a Steam lobby via the real Create Steam Session node. Optional arg: max players."),
	FConsoleCommandWithArgsDelegate::CreateStatic([](const TArray<FString>& Args)
	{
		RunHost(Args.Num() > 0 ? FCString::Atoi(*Args[0]) : 4);
	}));

static FAutoConsoleCommand GSteamFindCmd(
	TEXT("UECP.Steam.Find"),
	TEXT("Search for Steam lobbies via the real Find Steam Sessions node."),
	FConsoleCommandDelegate::CreateStatic([]() { RunFind(); }));

static FAutoConsoleCommand GSteamJoinCmd(
	TEXT("UECP.Steam.Join"),
	TEXT("Join a session from the last UECP.Steam.Find. Args: <index> (default 0)."),
	FConsoleCommandWithArgsDelegate::CreateStatic([](const TArray<FString>& Args)
	{
		RunJoin(Args.Num() > 0 ? FCString::Atoi(*Args[0]) : 0);
	}));

static FAutoConsoleCommand GSteamTravelCmd(
	TEXT("UECP.Steam.Travel"),
	TEXT("Client-travel into the joined session, using its resolved connect string."),
	FConsoleCommandDelegate::CreateStatic([]()
	{
		UWorld* World = DiagnosticWorld();
		const bool bOk = World && UUECPSteamSessionLibrary::TravelToSteamSession(World, NAME_None);
		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] Travel: %s"), bOk ? TEXT("started") : TEXT("FAILED"));
	}));

static FAutoConsoleCommand GSteamDestroyCmd(
	TEXT("UECP.Steam.Destroy"),
	TEXT("Destroy the current Steam session via the real Destroy Steam Session node."),
	FConsoleCommandDelegate::CreateStatic([]() { RunDestroy(); }));

static FAutoConsoleCommand GSteamSelfTestCmd(
	TEXT("UECP.Steam.SelfTest"),
	TEXT("Run the full Steam session round trip and log every step."),
	FConsoleCommandDelegate::CreateStatic([]()
	{
		UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] ################ SELF TEST START ################"));
		PrintStatus(TEXT("before host"));
		RunHost(4);
		After(4.0f,  []() { PrintStatus(TEXT("after host")); });
		After(6.0f,  []() { RunFind(); });
		After(14.0f, []() { RunDestroy(); });
		After(18.0f, []()
		{
			PrintStatus(TEXT("after destroy"));
			UE_LOG(LogUECPSteam, Display, TEXT("[DIAG] ################ SELF TEST END ################"));
		});
	}));

#endif
