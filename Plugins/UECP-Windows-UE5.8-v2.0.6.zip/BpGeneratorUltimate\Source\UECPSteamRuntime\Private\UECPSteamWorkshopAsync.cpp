// Copyright 2026, BlueprintsLab, All rights reserved
#include "Async/UECPSteamWorkshopAsync.h"

#include "Library/UECPSteamWorkshopLibrary.h"
#include "UECPSteamAPI.h"
#include "UECPSteamCallResult.h"

#if UECP_WITH_STEAM
namespace
{
	PublishedFileId_t ToNativeId(const FUECPSteamWorkshopItemId& In)
	{
		return static_cast<PublishedFileId_t>(static_cast<uint64>(In.Value));
	}

	ERemoteStoragePublishedFileVisibility ToNative(EUECPSteamWorkshopVisibility In)
	{
		switch (In)
		{
		case EUECPSteamWorkshopVisibility::FriendsOnly: return k_ERemoteStoragePublishedFileVisibilityFriendsOnly;
		case EUECPSteamWorkshopVisibility::Private:     return k_ERemoteStoragePublishedFileVisibilityPrivate;
		case EUECPSteamWorkshopVisibility::Unlisted:    return k_ERemoteStoragePublishedFileVisibilityUnlisted;
		case EUECPSteamWorkshopVisibility::Public:
		default:                                        return k_ERemoteStoragePublishedFileVisibilityPublic;
		}
	}

	EUECPSteamWorkshopVisibility FromNative(ERemoteStoragePublishedFileVisibility In)
	{
		switch (In)
		{
		case k_ERemoteStoragePublishedFileVisibilityFriendsOnly: return EUECPSteamWorkshopVisibility::FriendsOnly;
		case k_ERemoteStoragePublishedFileVisibilityPrivate:     return EUECPSteamWorkshopVisibility::Private;
		case k_ERemoteStoragePublishedFileVisibilityUnlisted:    return EUECPSteamWorkshopVisibility::Unlisted;
		case k_ERemoteStoragePublishedFileVisibilityPublic:
		default:                                                 return EUECPSteamWorkshopVisibility::Public;
		}
	}

	EUGCQuery ToNativeQuery(EUECPSteamWorkshopSort In)
	{
		switch (In)
		{
		case EUECPSteamWorkshopSort::PublicationDate:    return k_EUGCQuery_RankedByPublicationDate;
		case EUECPSteamWorkshopSort::Trend:              return k_EUGCQuery_RankedByTrend;
		case EUECPSteamWorkshopSort::TotalSubscriptions: return k_EUGCQuery_RankedByTotalUniqueSubscriptions;
		case EUECPSteamWorkshopSort::TextSearch:         return k_EUGCQuery_RankedByTextSearch;
		case EUECPSteamWorkshopSort::Vote:
		default:                                         return k_EUGCQuery_RankedByVote;
		}
	}

	EUserUGCList ToNativeUserList(EUECPSteamWorkshopListType In)
	{
		switch (In)
		{
		case EUECPSteamWorkshopListType::Published: return k_EUserUGCList_Published;
		case EUECPSteamWorkshopListType::Favorited: return k_EUserUGCList_Favorited;
		case EUECPSteamWorkshopListType::Subscribed:
		default:                                    return k_EUserUGCList_Subscribed;
		}
	}

	FUECPSteamWorkshopItem ReadQueryResult(ISteamUGC& UGC, UGCQueryHandle_t Handle, uint32 Index)
	{
		FUECPSteamWorkshopItem Item;

		SteamUGCDetails_t Details;
		if (!UGC.GetQueryUGCResult(Handle, Index, &Details))
		{
			return Item;
		}

		Item.ItemId        = FUECPSteamWorkshopItemId(static_cast<int64>(Details.m_nPublishedFileId));
		Item.Title         = UTF8_TO_TCHAR(Details.m_rgchTitle);
		Item.Description   = UTF8_TO_TCHAR(Details.m_rgchDescription);
		Item.Owner         = FUECPSteamID(static_cast<int64>(Details.m_ulSteamIDOwner));
		Item.Visibility    = FromNative(Details.m_eVisibility);
		Item.UpVotes       = static_cast<int32>(Details.m_unVotesUp);
		Item.DownVotes     = static_cast<int32>(Details.m_unVotesDown);
		Item.Score         = Details.m_flScore;
		Item.FileSizeBytes = static_cast<int64>(Details.m_nFileSize);
		Item.TimeCreated   = FDateTime::FromUnixTimestamp(static_cast<int64>(Details.m_rtimeCreated));
		Item.TimeUpdated   = FDateTime::FromUnixTimestamp(static_cast<int64>(Details.m_rtimeUpdated));
		Item.bBanned       = Details.m_bBanned;

		const FString TagBlob = UTF8_TO_TCHAR(Details.m_rgchTags);
		TagBlob.ParseIntoArray(Item.Tags, TEXT(","), true);
		for (FString& Tag : Item.Tags)
		{
			Tag.TrimStartAndEndInline();
		}

		char PreviewUrl[1024] = {};
		if (UGC.GetQueryUGCPreviewURL(Handle, Index, PreviewUrl, UE_ARRAY_COUNT(PreviewUrl)))
		{
			Item.PreviewUrl = UTF8_TO_TCHAR(PreviewUrl);
		}

		return Item;
	}
}
#endif

UUECPSteamWorkshopQuery* UUECPSteamWorkshopQuery::QuerySteamWorkshop(
	UObject* WorldContextObject, EUECPSteamWorkshopListType ListType, EUECPSteamWorkshopSort SortBy,
	int32 Page, const FString& SearchText, const TArray<FString>& RequiredTags)
{
	UUECPSteamWorkshopQuery* Node = NewObject<UUECPSteamWorkshopQuery>();
	Node->ContextObject = WorldContextObject;
	Node->ListType      = ListType;
	Node->SortBy        = SortBy;
	Node->Page          = FMath::Max(1, Page);
	Node->SearchText    = SearchText;
	Node->RequiredTags  = RequiredTags;
	Node->RegisterWithGameInstance(WorldContextObject);
	return Node;
}

bool UUECPSteamWorkshopQuery::Start(FUECPSteamError& OutError)
{
#if UECP_WITH_STEAM
	ISteamUGC* UGC = UECPSteam::UGC();
	ISteamUtils* Utils = UECPSteam::Utils();
	ISteamUser* User = UECPSteam::User();
	if (!UGC || !Utils || !User)
	{
		OutError = FUECPSteamError::Unavailable();
		return false;
	}

	const AppId_t AppId = Utils->GetAppID();

	const UGCQueryHandle_t Handle = (ListType == EUECPSteamWorkshopListType::All)
		? UGC->CreateQueryAllUGCRequest(ToNativeQuery(SortBy), k_EUGCMatchingUGCType_Items,
			AppId, AppId, static_cast<uint32>(Page))
		: UGC->CreateQueryUserUGCRequest(User->GetSteamID().GetAccountID(), ToNativeUserList(ListType),
			k_EUGCMatchingUGCType_Items, k_EUserUGCListSortOrder_CreationOrderDesc,
			AppId, AppId, static_cast<uint32>(Page));

	if (Handle == k_UGCQueryHandleInvalid)
	{
		OutError = FUECPSteamError(EUECPSteamResult::BackendFailure, TEXT("Creating the Workshop query failed."));
		return false;
	}

	UGC->SetReturnLongDescription(Handle, true);
	UGC->SetReturnMetadata(Handle, true);

	if (!SearchText.IsEmpty())
	{
		UGC->SetSearchText(Handle, TCHAR_TO_UTF8(*SearchText));
	}
	for (const FString& Tag : RequiredTags)
	{
		UGC->AddRequiredTag(Handle, TCHAR_TO_UTF8(*Tag));
	}

	const SteamAPICall_t Call = UGC->SendQueryUGCRequest(Handle);
	if (Call == k_uAPICallInvalid)
	{
		UGC->ReleaseQueryUGCRequest(Handle);
		OutError = FUECPSteamError(EUECPSteamResult::BackendFailure, TEXT("Sending the Workshop query failed."));
		return false;
	}

	TWeakObjectPtr<UUECPSteamWorkshopQuery> WeakThis(this);
	UECPSteamSetCallResult<SteamUGCQueryCompleted_t>(CallResultHolder, Call,
		[WeakThis, Handle](SteamUGCQueryCompleted_t* Result, bool bIOFailure)
		{
			ISteamUGC* LocalUGC = UECPSteam::UGC();
			const bool bOk = LocalUGC && Result && !bIOFailure && Result->m_eResult == k_EResultOK;

			TArray<FUECPSteamWorkshopItem> Rows;
			int32 Total = 0;
			int32 RawResult = Result ? static_cast<int32>(Result->m_eResult) : 0;

			if (bOk)
			{
				Total = static_cast<int32>(Result->m_unTotalMatchingResults);
				Rows.Reserve(Result->m_unNumResultsReturned);
				for (uint32 Index = 0; Index < Result->m_unNumResultsReturned; ++Index)
				{
					Rows.Add(ReadQueryResult(*LocalUGC, Handle, Index));
				}
			}

			if (LocalUGC)
			{
				LocalUGC->ReleaseQueryUGCRequest(Handle);
			}

			UECPSteam::RunOnGameThread([WeakThis, bOk, RawResult, Total, Rows = MoveTemp(Rows)]() mutable
			{
				UUECPSteamWorkshopQuery* Node = WeakThis.Get();
				if (!Node)
				{
					return;
				}
				if (bOk)
				{
					Node->Items         = MoveTemp(Rows);
					Node->TotalMatching = Total;
					Node->CompleteSuccess();
				}
				else
				{
					Node->CompleteFromResult(RawResult, TEXT("The Workshop query failed"));
				}
			});
		});

	return true;
#else
	OutError = FUECPSteamError::Unavailable();
	return false;
#endif
}

void UUECPSteamWorkshopQuery::BroadcastResult(bool bSucceeded, const FUECPSteamError& Error)
{
	(bSucceeded ? OnSuccess : OnFailure).Broadcast(Items, TotalMatching, Error);
}

UUECPSteamWorkshopCreateItem* UUECPSteamWorkshopCreateItem::CreateSteamWorkshopItem(UObject* WorldContextObject)
{
	UUECPSteamWorkshopCreateItem* Node = NewObject<UUECPSteamWorkshopCreateItem>();
	Node->ContextObject = WorldContextObject;
	Node->RegisterWithGameInstance(WorldContextObject);
	return Node;
}

bool UUECPSteamWorkshopCreateItem::Start(FUECPSteamError& OutError)
{
#if UECP_WITH_STEAM
	ISteamUGC* UGC = UECPSteam::UGC();
	ISteamUtils* Utils = UECPSteam::Utils();
	if (!UGC || !Utils)
	{
		OutError = FUECPSteamError::Unavailable();
		return false;
	}

	const SteamAPICall_t Call = UGC->CreateItem(Utils->GetAppID(), k_EWorkshopFileTypeCommunity);
	if (Call == k_uAPICallInvalid)
	{
		OutError = FUECPSteamError(EUECPSteamResult::BackendFailure, TEXT("CreateItem was rejected."));
		return false;
	}

	TWeakObjectPtr<UUECPSteamWorkshopCreateItem> WeakThis(this);
	UECPSteamSetCallResult<CreateItemResult_t>(CallResultHolder, Call,
		[WeakThis](CreateItemResult_t* Result, bool bIOFailure)
		{
			const bool bOk    = Result && !bIOFailure && Result->m_eResult == k_EResultOK;
			const int32 Raw   = Result ? static_cast<int32>(Result->m_eResult) : 0;
			const int64 NewId = Result ? static_cast<int64>(Result->m_nPublishedFileId) : 0;
			const bool bLegal = Result && Result->m_bUserNeedsToAcceptWorkshopLegalAgreement;

			UECPSteam::RunOnGameThread([WeakThis, bOk, Raw, NewId, bLegal]()
			{
				UUECPSteamWorkshopCreateItem* Node = WeakThis.Get();
				if (!Node)
				{
					return;
				}
				Node->ItemId               = FUECPSteamWorkshopItemId(NewId);
				Node->bNeedsLegalAgreement = bLegal;
				bOk ? Node->CompleteSuccess()
				    : Node->CompleteFromResult(Raw, TEXT("Creating the Workshop item failed"));
			});
		});

	return true;
#else
	OutError = FUECPSteamError::Unavailable();
	return false;
#endif
}

void UUECPSteamWorkshopCreateItem::BroadcastResult(bool bSucceeded, const FUECPSteamError& Error)
{
	(bSucceeded ? OnSuccess : OnFailure).Broadcast(ItemId, bNeedsLegalAgreement, Error);
}

UUECPSteamWorkshopSubmitItem* UUECPSteamWorkshopSubmitItem::SubmitSteamWorkshopItem(
	UObject* WorldContextObject, FUECPSteamWorkshopItemId ItemId, FUECPSteamWorkshopSubmitInfo SubmitInfo)
{
	UUECPSteamWorkshopSubmitItem* Node = NewObject<UUECPSteamWorkshopSubmitItem>();
	Node->ContextObject = WorldContextObject;
	Node->ItemId        = ItemId;
	Node->SubmitInfo    = MoveTemp(SubmitInfo);
	Node->RegisterWithGameInstance(WorldContextObject);
	return Node;
}

bool UUECPSteamWorkshopSubmitItem::Start(FUECPSteamError& OutError)
{
#if UECP_WITH_STEAM
	if (!ItemId.IsValid())
	{
		OutError = FUECPSteamError(EUECPSteamResult::InvalidParameter,
			TEXT("No item id. Run Create Steam Workshop Item first."));
		return false;
	}

	ISteamUGC* UGC = UECPSteam::UGC();
	ISteamUtils* Utils = UECPSteam::Utils();
	if (!UGC || !Utils)
	{
		OutError = FUECPSteamError::Unavailable();
		return false;
	}

	const UGCUpdateHandle_t Handle = UGC->StartItemUpdate(Utils->GetAppID(), ToNativeId(ItemId));
	if (Handle == k_UGCUpdateHandleInvalid)
	{
		OutError = FUECPSteamError(EUECPSteamResult::BackendFailure, TEXT("StartItemUpdate was rejected."));
		return false;
	}
	UpdateHandle = static_cast<uint64>(Handle);

	if (!SubmitInfo.Title.IsEmpty())
	{
		UGC->SetItemTitle(Handle, TCHAR_TO_UTF8(*SubmitInfo.Title));
	}
	if (!SubmitInfo.Description.IsEmpty())
	{
		UGC->SetItemDescription(Handle, TCHAR_TO_UTF8(*SubmitInfo.Description));
	}
	if (!SubmitInfo.Metadata.IsEmpty())
	{
		UGC->SetItemMetadata(Handle, TCHAR_TO_UTF8(*SubmitInfo.Metadata));
	}
	if (!SubmitInfo.ContentFolder.IsEmpty())
	{
		UGC->SetItemContent(Handle, TCHAR_TO_UTF8(*SubmitInfo.ContentFolder));
	}
	if (!SubmitInfo.PreviewImageFile.IsEmpty())
	{
		UGC->SetItemPreview(Handle, TCHAR_TO_UTF8(*SubmitInfo.PreviewImageFile));
	}
	UGC->SetItemVisibility(Handle, ToNative(SubmitInfo.Visibility));

	if (SubmitInfo.Tags.Num() > 0)
	{
		TArray<FTCHARToUTF8> Converted;
		TArray<const char*> Raw;
		Converted.Reserve(SubmitInfo.Tags.Num());
		Raw.Reserve(SubmitInfo.Tags.Num());
		for (const FString& Tag : SubmitInfo.Tags)
		{
			Converted.Emplace(*Tag);
			Raw.Add(Converted.Last().Get());
		}

		SteamParamStringArray_t TagArray;
		TagArray.m_ppStrings   = Raw.GetData();
		TagArray.m_nNumStrings = Raw.Num();
		UGC->SetItemTags(Handle, &TagArray);
	}

	const SteamAPICall_t Call = UGC->SubmitItemUpdate(Handle,
		SubmitInfo.ChangeNote.IsEmpty() ? nullptr : TCHAR_TO_UTF8(*SubmitInfo.ChangeNote));
	if (Call == k_uAPICallInvalid)
	{
		OutError = FUECPSteamError(EUECPSteamResult::BackendFailure, TEXT("SubmitItemUpdate was rejected."));
		return false;
	}

	TWeakObjectPtr<UUECPSteamWorkshopSubmitItem> WeakThis(this);
	UECPSteamSetCallResult<SubmitItemUpdateResult_t>(CallResultHolder, Call,
		[WeakThis](SubmitItemUpdateResult_t* Result, bool bIOFailure)
		{
			const bool bOk    = Result && !bIOFailure && Result->m_eResult == k_EResultOK;
			const int32 Raw   = Result ? static_cast<int32>(Result->m_eResult) : 0;
			const bool bLegal = Result && Result->m_bUserNeedsToAcceptWorkshopLegalAgreement;

			UECPSteam::RunOnGameThread([WeakThis, bOk, Raw, bLegal]()
			{
				UUECPSteamWorkshopSubmitItem* Node = WeakThis.Get();
				if (!Node)
				{
					return;
				}
				Node->bNeedsLegalAgreement = bLegal;
				bOk ? Node->CompleteSuccess()
				    : Node->CompleteFromResult(Raw, TEXT("Submitting the Workshop item failed"));
			});
		});

	return true;
#else
	OutError = FUECPSteamError::Unavailable();
	return false;
#endif
}

void UUECPSteamWorkshopSubmitItem::GetSubmitProgress(
	float& ProgressPercent, int64& BytesProcessed, int64& BytesTotal) const
{
	ProgressPercent = 0.f;
	BytesProcessed  = 0;
	BytesTotal      = 0;

#if UECP_WITH_STEAM
	ISteamUGC* UGC = UECPSteam::UGC();
	if (!UGC || UpdateHandle == 0)
	{
		return;
	}

	uint64 Processed = 0;
	uint64 Total = 0;
	UGC->GetItemUpdateProgress(static_cast<UGCUpdateHandle_t>(UpdateHandle), &Processed, &Total);

	BytesProcessed  = static_cast<int64>(Processed);
	BytesTotal      = static_cast<int64>(Total);
	ProgressPercent = Total > 0 ? (static_cast<float>(Processed) / static_cast<float>(Total)) * 100.f : 0.f;
#endif
}

void UUECPSteamWorkshopSubmitItem::BroadcastResult(bool bSucceeded, const FUECPSteamError& Error)
{
	(bSucceeded ? OnSuccess : OnFailure).Broadcast(bNeedsLegalAgreement, Error);
}

UUECPSteamWorkshopSubscribe* UUECPSteamWorkshopSubscribe::SubscribeToSteamWorkshopItem(
	UObject* WorldContextObject, FUECPSteamWorkshopItemId ItemId, bool bUnsubscribe)
{
	UUECPSteamWorkshopSubscribe* Node = NewObject<UUECPSteamWorkshopSubscribe>();
	Node->ContextObject = WorldContextObject;
	Node->ItemId        = ItemId;
	Node->bUnsubscribe  = bUnsubscribe;
	Node->RegisterWithGameInstance(WorldContextObject);
	return Node;
}

bool UUECPSteamWorkshopSubscribe::Start(FUECPSteamError& OutError)
{
#if UECP_WITH_STEAM
	if (!ItemId.IsValid())
	{
		OutError = FUECPSteamError(EUECPSteamResult::InvalidParameter, TEXT("No Workshop item id given."));
		return false;
	}

	ISteamUGC* UGC = UECPSteam::UGC();
	if (!UGC)
	{
		OutError = FUECPSteamError::Unavailable();
		return false;
	}

	const SteamAPICall_t Call = bUnsubscribe
		? UGC->UnsubscribeItem(ToNativeId(ItemId))
		: UGC->SubscribeItem(ToNativeId(ItemId));

	if (Call == k_uAPICallInvalid)
	{
		OutError = FUECPSteamError(EUECPSteamResult::BackendFailure, TEXT("The subscription call was rejected."));
		return false;
	}

	TWeakObjectPtr<UUECPSteamWorkshopSubscribe> WeakThis(this);
	const bool bWasUnsubscribe = bUnsubscribe;

	if (bWasUnsubscribe)
	{
		UECPSteamSetCallResult<RemoteStoragePublishedFileUnsubscribed_t>(CallResultHolder, Call,
			[WeakThis](RemoteStoragePublishedFileUnsubscribed_t* Result, bool bIOFailure)
			{
				const bool bOk = Result && !bIOFailure;
				UECPSteam::RunOnGameThread([WeakThis, bOk]()
				{
					if (UUECPSteamWorkshopSubscribe* Node = WeakThis.Get())
					{
						bOk ? Node->CompleteSuccess()
						    : Node->CompleteFailure(FUECPSteamError(EUECPSteamResult::BackendFailure,
						        TEXT("Unsubscribing failed.")));
					}
				});
			});
	}
	else
	{
		UECPSteamSetCallResult<RemoteStoragePublishedFileSubscribed_t>(CallResultHolder, Call,
			[WeakThis](RemoteStoragePublishedFileSubscribed_t* Result, bool bIOFailure)
			{
				const bool bOk = Result && !bIOFailure;
				UECPSteam::RunOnGameThread([WeakThis, bOk]()
				{
					if (UUECPSteamWorkshopSubscribe* Node = WeakThis.Get())
					{
						bOk ? Node->CompleteSuccess()
						    : Node->CompleteFailure(FUECPSteamError(EUECPSteamResult::BackendFailure,
						        TEXT("Subscribing failed.")));
					}
				});
			});
	}

	return true;
#else
	OutError = FUECPSteamError::Unavailable();
	return false;
#endif
}

void UUECPSteamWorkshopSubscribe::BroadcastResult(bool bSucceeded, const FUECPSteamError& Error)
{
	(bSucceeded ? OnSuccess : OnFailure).Broadcast(Error);
}

namespace
{
	constexpr double WorkshopDownloadTimeoutSeconds = 600.0;
}

UUECPSteamWorkshopDownloadItem* UUECPSteamWorkshopDownloadItem::DownloadSteamWorkshopItem(
	UObject* WorldContextObject, FUECPSteamWorkshopItemId ItemId, bool bHighPriority)
{
	UUECPSteamWorkshopDownloadItem* Node = NewObject<UUECPSteamWorkshopDownloadItem>();
	Node->ContextObject  = WorldContextObject;
	Node->ItemId         = ItemId;
	Node->bHighPriority  = bHighPriority;
	Node->RegisterWithGameInstance(WorldContextObject);
	return Node;
}

bool UUECPSteamWorkshopDownloadItem::Start(FUECPSteamError& OutError)
{
	if (!ItemId.IsValid())
	{
		OutError = FUECPSteamError(EUECPSteamResult::InvalidParameter, TEXT("No Workshop item id given."));
		return false;
	}

	const FUECPSteamWorkshopItemState State = UUECPSteamWorkshopLibrary::GetWorkshopItemState(ItemId);
	if (State.bReadyToUse)
	{
		int64 Size = 0;
		FDateTime Stamp;
		UUECPSteamWorkshopLibrary::GetWorkshopItemInstallInfo(ItemId, InstallFolder, Size, Stamp);
		CompleteSuccess();
		return true;
	}

	if (!UUECPSteamWorkshopLibrary::StartWorkshopItemDownload(ItemId, bHighPriority))
	{
		OutError = FUECPSteamError(EUECPSteamResult::NotFound,
			TEXT("Steam refused the download. The item is usually not subscribed, or the id is wrong."));
		return false;
	}

	PollStartSeconds = FPlatformTime::Seconds();
	PollHandle = FTSTicker::GetCoreTicker().AddTicker(
		FTickerDelegate::CreateUObject(this, &UUECPSteamWorkshopDownloadItem::PollDownload), 0.5f);
	return true;
}

bool UUECPSteamWorkshopDownloadItem::PollDownload(float )
{
	const FUECPSteamWorkshopItemState State = UUECPSteamWorkshopLibrary::GetWorkshopItemState(ItemId);
	if (State.bReadyToUse)
	{
		int64 Size = 0;
		FDateTime Stamp;
		UUECPSteamWorkshopLibrary::GetWorkshopItemInstallInfo(ItemId, InstallFolder, Size, Stamp);
		CompleteSuccess();
		return false;
	}

	if (FPlatformTime::Seconds() - PollStartSeconds > WorkshopDownloadTimeoutSeconds)
	{
		CompleteFailure(FUECPSteamError(EUECPSteamResult::Timeout,
			TEXT("The Workshop item did not finish downloading in time.")));
		return false;
	}

	return true;
}

void UUECPSteamWorkshopDownloadItem::OnCleanup()
{
	if (PollHandle.IsValid())
	{
		FTSTicker::GetCoreTicker().RemoveTicker(PollHandle);
		PollHandle.Reset();
	}
}

void UUECPSteamWorkshopDownloadItem::BroadcastResult(bool bSucceeded, const FUECPSteamError& Error)
{
	(bSucceeded ? OnSuccess : OnFailure).Broadcast(InstallFolder, Error);
}
