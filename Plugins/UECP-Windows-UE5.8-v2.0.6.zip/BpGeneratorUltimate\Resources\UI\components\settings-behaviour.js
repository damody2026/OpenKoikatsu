(function () {
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  class SettingsBehaviour extends HTMLElement {
    connectedCallback() {
      this.style.cssText = 'display:flex;flex-direction:column;flex:1;min-height:0;overflow-y:auto';
      this._ts = {};
      this._savePath = '/Game/';
      this._render();
    }
    _onSettingsInit(state) {
      this._ts = (state && state.tools) || {};
      this._savePath = (state && state.chatPrefs && state.chatPrefs.defaultSavePath) || '/Game/';
      this._render();
    }

    _render() {
      const ts = this._ts;
      const discoverLimit   = ts.discoverNodesLimit   != null ? ts.discoverNodesLimit   : 200;
      const maxDepth        = ts.maxToolCallDepth      != null ? ts.maxToolCallDepth      : 10;
      const listLimit       = ts.listAssetsLimit       != null ? ts.listAssetsLimit       : 150;
      const validatePasses  = ts.autoValidateMaxPasses != null ? ts.autoValidateMaxPasses : 3;
      const loopLimit       = ts.toolCallLoopLimit     != null ? ts.toolCallLoopLimit     : 40;
      const failStreak      = ts.toolFailureStreakLimit != null ? ts.toolFailureStreakLimit : 10;
      const failWinSize     = ts.toolFailureWindowSize  != null ? ts.toolFailureWindowSize  : 12;
      const failWinLimit    = ts.toolFailureWindowLimit != null ? ts.toolFailureWindowLimit : 10;
      const failTotal       = ts.toolFailureTotalLimit  != null ? ts.toolFailureTotalLimit  : 0;
      const turnBudget      = ts.turnTokenBudget        != null ? ts.turnTokenBudget        : 1000000;
      const savePath        = this._savePath || '/Game/';
      const interMode       = ts.defaultInteractionMode || 'auto';
      const cadence         = ts.defaultAutopilotCadence || 'manual';
      const bpStrategy      = ts.blueprintGraphStrategy || 'auto';
      const destructConfirm = ts.destructiveOpsConfirm !== false;
      const waived          = Array.isArray(ts.waivedTools) ? ts.waivedTools : [];
      const loopGuard       = ts.toolCallLoopGuard !== false;
      const autoValidate    = ts.autoValidateBlueprints ? true : false;
      const preflight       = ts.enablePreFlight !== false;
      const surgicalNoPIE   = ts.surgicalNoPIE ? true : false;
      const suggestPremium  = ts.suggestPremium !== false;

      this.innerHTML =
        '<div class="content-head"><span class="crumb"><b>AI Behaviour</b></span></div>'
        + '<div class="page page-narrow">'
        + '<div class="page-title">AI Behaviour</div>'
        + '<div class="page-sub">Control how the AI operates: depth limits, default modes, and safety guards.</div>'

        + '<div class="card" style="margin-top:20px">'
        + '<div class="section-label" style="margin:0 0 14px">LIMITS</div>'
        + this._numField('sb-discover-limit',  'Discover Nodes Limit',   discoverLimit,  'Max nodes returned by discover_nodes.')
        + this._numField('sb-max-depth',        'Tool Call Depth',        maxDepth,       'Max nested tool calls per request.')
        + this._numField('sb-list-limit',       'List Assets Limit',      listLimit,      'Max assets returned by list_asset_references.')
        + this._numField('sb-validate-passes',  'Auto-Validate Passes',   validatePasses, 'Max Blueprint compile passes per auto-validate cycle.')
        + this._numField('sb-loop-limit',       'Tool Loop Limit',        loopLimit,      'Max total tool calls per agent loop.')
        + this._numField('sb-turn-budget',      'Token Budget Per Message', turnBudget,   'When one message has used this many tokens, the AI pauses and asks before going on. Cached tokens count as a fifth. 0 turns it off.', 0, 1000000000, 50000)
        + '</div>'

        + '<div class="card" style="margin-top:14px">'
        + '<div class="section-label" style="margin:0 0 14px">FAILURE GUARDS</div>'
        + '<div style="font-size:11.5px;color:var(--ue-text-lo);margin:-6px 0 14px">When almost nothing is succeeding, stopping beats burning a full prompt on every further attempt. These only apply while Tool Loop Guard is on.</div>'
        + this._numField('sb-fail-window-limit', 'Recent Failures To Stop', failWinLimit, 'Stop when this many of the last N calls failed. The main guard: it measures how DENSE failures are, so a long task that fails occasionally keeps going. 0 disables.')
        + this._numField('sb-fail-window-size',  'Recent Calls Window (N)', failWinSize,  'How many recent tool calls the check above looks at.')
        + this._numField('sb-fail-streak',       'Consecutive Failures',    failStreak,   'Stop after this many failures in a row with no success between them. 0 disables.')
        + this._numField('sb-fail-total',        'Total Failures Per Turn', failTotal,    'Absolute ceiling on failures while answering one message. 0 = off (recommended) - it stops long tasks that are still making progress.')
        + '</div>'

        + '<div class="card" style="margin-top:14px">'
        + '<div class="section-label" style="margin:0 0 14px">ASSET SAVE PATH</div>'
        + '<div style="margin-bottom:14px"><div class="field-label">Default Save Path</div>'
        + '<div class="input mono"><input id="sb-save-path" spellcheck="false" autocorrect="off" autocapitalize="off" type="text" style="background:transparent;border:none;flex:1;color:inherit;outline:none;font-family:inherit;font-size:inherit" value="' + esc(savePath) + '" placeholder="/Game/"></div>'
        + '<div style="font-size:11.5px;color:var(--ue-text-lo);margin-top:5px">Fallback path for all AI-created assets. Use /Game/ or a sub-folder like /Game/AI/.</div>'
        + '</div></div>'

        + '<div class="card" style="margin-top:14px">'
        + '<div class="section-label" style="margin:0 0 14px">DEFAULT MODES</div>'
        + '<div style="margin-bottom:0"><div class="field-label">Default Interaction Mode</div>'
        + '<div class="seg-wide" id="sb-interact-mode">'
        + [{ value:'chat', label:'Just Chat' }, { value:'ask', label:'Ask Before Edit' }, { value:'auto', label:'Auto Edit' }, { value:'plan', label:'Plan' }].map(function (o) {
            return '<span' + (o.value === interMode ? ' class="active"' : '') + ' data-value="' + esc(o.value) + '">' + esc(o.label) + '</span>';
          }).join('')
        + '</div>'
        + '<div style="font-size:11.5px;color:var(--ue-text-lo);margin-top:5px">Mode new architect chats start in.</div>'
        + '</div>'
        + '<div style="margin:14px 0 0"><div class="field-label">Default Autopilot Cadence</div>'
        + '<div class="seg-wide" id="sb-autopilot-cadence">'
        + [{ value:'manual', label:'Manual' }, { value:'per_stage', label:'Per Stage' }, { value:'full_auto', label:'Full Auto' }].map(function (o) {
            return '<span' + (o.value === cadence ? ' class="active"' : '') + ' data-value="' + esc(o.value) + '">' + esc(o.label) + '</span>';
          }).join('')
        + '</div>'
        + '<div style="font-size:11.5px;color:var(--ue-text-lo);margin-top:5px">How often the autopilot loop (delegate -> review -> advance) checks in with you once it\'s running a plan. Manual confirms every task, Per Stage only between systems, Full Auto only on repeated failure.</div>'
        + '</div>'
        + '<div style="margin:14px 0 0"><div class="field-label">Blueprint Logic Authoring</div>'
        + '<div class="seg-wide" id="sb-bp-graph-strategy">'
        + [{ value:'auto', label:'Auto (recommended)' }, { value:'synthesize', label:'Prefer synthesize_graph' }, { value:'build', label:'Prefer build_blueprint_graph' }].map(function (o) {
            return '<span' + (o.value === bpStrategy ? ' class="active"' : '') + ' data-value="' + esc(o.value) + '">' + esc(o.label) + '</span>';
          }).join('')
        + '</div>'
        + '<div style="font-size:11.5px;color:var(--ue-text-lo);margin-top:5px">Which tool the AI uses to author Blueprint function logic. Auto lets it choose (synthesize_graph for most logic, build_blueprint_graph when it needs exact node/pin control synthesize_graph can\'t express yet). The other two options force one tool for the whole session.</div>'
        + '</div></div>'

        + '<div class="toggle-card" style="margin-top:14px">'
        + this._tRow('sb-destructive-confirm', 'Destructive Op Confirmation', 'Ask before a tool deletes, moves, renames or overwrites assets, including a Python script that does.', destructConfirm)
        + this._tRow('sb-loop-guard',          'Tool Loop Guard',             'Auto-stop if tool calls exceed the loop limit.', loopGuard)
        + this._tRow('sb-auto-validate',       'Auto-Validate Blueprints',    'Compile + validate Blueprints automatically after edits.', autoValidate)
        + this._tRow('sb-preflight',           'Pre-flight System',           'Run safety checks before destructive Blueprint operations.', preflight)
        + this._tRow('sb-surgical-no-pie',     'Surgical No-PIE',             'Skip Begin Play In Editor guard during surgical edits.', surgicalNoPIE)
        + this._tRow('sb-suggest-premium',     'Suggest BpLabs Premium',      'Offer the stronger model where it helps, such as a play test (about 3x tokens). Turn off to keep every turn on the model you chose, for example while automations run.', suggestPremium)
        + '</div>'

        + (waived.length
            ? '<div class="card" id="sb-waived" style="margin-top:14px">'
              + '<div class="field-label">Tools that no longer ask</div>'
              + '<div style="font-size:11.5px;color:var(--ue-text-lo);margin-bottom:10px">You chose not to be asked before these tools. Remove one to be asked again.</div>'
              + waived.map(function (n) {
                  return '<div class="input mono sb-waived-row" style="gap:9px;margin-bottom:6px">'
                    + '<span style="font-size:12.5px;color:var(--ue-text-hi)">' + esc(n) + '</span>'
                    + '<button class="btn-ghost sb-unwaive" data-tool="' + esc(n) + '" style="margin-left:auto;font-size:11px;padding:5px 10px">Remove</button>'
                    + '</div>';
                }).join('')
              + '</div>'
            : '')

        + window.UECP.saveBar.html(this, 'sb-save')
        + '</div>';

      const self = this;
      this.querySelectorAll('.seg-wide').forEach(function (seg) {
        seg.addEventListener('click', function (e) {
          const item = e.target.closest('span[data-value]');
          if (!item) return;
          seg.querySelectorAll('span').forEach(function (s) { s.classList.remove('active'); });
          item.classList.add('active');
        });
      });

      this.querySelectorAll('.sb-unwaive').forEach(function (btn) {
        btn.addEventListener('click', function () {
          const tool = btn.dataset.tool;
          window.uecp.call('unwaive_confirm', { tool: tool });
          self._ts.waivedTools = (self._ts.waivedTools || []).filter(function (n) { return n !== tool; });
          const row = btn.closest('.sb-waived-row');
          if (row) row.remove();
          if (!self.querySelector('.sb-unwaive')) {
            const card = self.querySelector('#sb-waived');
            if (card) card.remove();
          }
        });
      });

      this.querySelector('#sb-save').addEventListener('click', function () { self._save(); });
      window.UECP.saveBar.autosave(this, function () { self._save(); });
    }

    _numField(id, label, val, desc, min, max, step) {
      return '<div style="margin-bottom:14px"><div class="field-label">' + label + '</div>'
        + '<div class="input mono"><input id="' + id + '" type="number" min="' + (min != null ? min : 1) + '" max="' + (max != null ? max : 9999) + '"'
        + (step != null ? ' step="' + step + '"' : '') + ' value="' + val + '" style="background:transparent;border:none;flex:1;color:inherit;outline:none;font-family:inherit;font-size:inherit"></div>'
        + (desc ? '<div style="font-size:11.5px;color:var(--ue-text-lo);margin-top:4px">' + esc(desc) + '</div>' : '')
        + '</div>';
    }

    _tRow(id, title, desc, checked) {
      return '<div class="toggle-row"><div class="t"><div class="t-name">' + title + '</div><div class="t-desc">' + desc + '</div></div>'
        + '<div class="toggle' + (checked ? ' on' : '') + '" id="' + id + '" onclick="this.classList.toggle(\'on\')" role="switch" aria-checked="' + (checked ? 'true' : 'false') + '" tabindex="0"><span class="knob"></span></div></div>';
    }

    _getNum(id, fallback) {
      const el = this.querySelector('#' + id);
      const v = el ? parseInt(el.value, 10) : NaN;
      return isNaN(v) ? fallback : v;
    }

    _save() {
      const interMode = (this.querySelector('#sb-interact-mode span.active') || {}).dataset.value || 'auto';
      const cadence   = (this.querySelector('#sb-autopilot-cadence span.active') || {}).dataset.value || 'manual';
      const bpStrategy = (this.querySelector('#sb-bp-graph-strategy span.active') || {}).dataset.value || 'auto';
      const savePath  = (this.querySelector('#sb-save-path') || {}).value || '/Game/';
      const budgetEl = this.querySelector('#sb-turn-budget');
      if (budgetEl) { const b = parseInt(budgetEl.value, 10); if (b > 0 && b < 20000) budgetEl.value = '20000'; }
      window.uecp.call('save_tool_settings', {
        discoverNodesLimit:      this._getNum('sb-discover-limit',  200),
        maxToolCallDepth:        this._getNum('sb-max-depth',        10),
        listAssetsLimit:         this._getNum('sb-list-limit',      150),
        autoValidateMaxPasses:   this._getNum('sb-validate-passes',   3),
        toolCallLoopLimit:       this._getNum('sb-loop-limit',       40),
        toolFailureWindowLimit:  this._getNum('sb-fail-window-limit', 10),
        toolFailureWindowSize:   this._getNum('sb-fail-window-size', 12),
        toolFailureStreakLimit:  this._getNum('sb-fail-streak',      10),
        toolFailureTotalLimit:   this._getNum('sb-fail-total',        0),
        turnTokenBudget:         this._getNum('sb-turn-budget',  1000000),
        defaultInteractionMode:  interMode,
        defaultAutopilotCadence: cadence,
        blueprintGraphStrategy:  bpStrategy,
        destructiveOpsConfirm:   this.querySelector('#sb-destructive-confirm').classList.contains('on'),
        toolCallLoopGuard:       this.querySelector('#sb-loop-guard').classList.contains('on'),
        autoValidateBlueprints:  this.querySelector('#sb-auto-validate').classList.contains('on'),
        enablePreFlight:         this.querySelector('#sb-preflight').classList.contains('on'),
        surgicalNoPIE:           this.querySelector('#sb-surgical-no-pie').classList.contains('on'),
        suggestPremium:          this.querySelector('#sb-suggest-premium').classList.contains('on'),
      });
      window.uecp.call('save_preferences', { chatPrefs: { defaultSavePath: savePath } });
      window.UECP.saveBar.flash(this);
    }
  }
  customElements.define('settings-behaviour', SettingsBehaviour);
})();
