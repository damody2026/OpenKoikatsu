// Copyright 2026, BlueprintsLab, All rights reserved
#include "Library/UECPSteamIdentityLibrary.h"

#include "UECPSteamOSS.h"

EUECPSteamLoginStatus UUECPSteamIdentityLibrary::GetSteamLoginStatus(const UObject* WorldContextObject)
{
	const IOnlineIdentityPtr Identity = UECPSteamOSS::Identity(WorldContextObject);
	if (!Identity.IsValid())
	{
		return EUECPSteamLoginStatus::NotLoggedIn;
	}

	switch (Identity->GetLoginStatus(0))
	{
	case ELoginStatus::LoggedIn:          return EUECPSteamLoginStatus::LoggedIn;
	case ELoginStatus::UsingLocalProfile: return EUECPSteamLoginStatus::UsingLocalProfile;
	case ELoginStatus::NotLoggedIn:
	default:                              return EUECPSteamLoginStatus::NotLoggedIn;
	}
}

FUECPSteamID UUECPSteamIdentityLibrary::GetSteamPlayerId(const UObject* WorldContextObject)
{
	return UECPSteamOSS::ToSteamID(UECPSteamOSS::LocalUserId(WorldContextObject));
}

FString UUECPSteamIdentityLibrary::GetSteamPlayerNickname(const UObject* WorldContextObject)
{
	const IOnlineIdentityPtr Identity = UECPSteamOSS::Identity(WorldContextObject);
	return Identity.IsValid() ? Identity->GetPlayerNickname(0) : FString();
}

FString UUECPSteamIdentityLibrary::GetSteamAuthToken(const UObject* WorldContextObject)
{
	const IOnlineIdentityPtr Identity = UECPSteamOSS::Identity(WorldContextObject);
	return Identity.IsValid() ? Identity->GetAuthToken(0) : FString();
}

FString UUECPSteamIdentityLibrary::Conv_SteamIDToString(const FUECPSteamID& SteamId)
{
	return SteamId.ToString();
}

FUECPSteamID UUECPSteamIdentityLibrary::MakeSteamIDFromString(const FString& SteamIdString)
{
	uint64 Parsed = 0;
	LexFromString(Parsed, *SteamIdString);
	return FUECPSteamID(static_cast<int64>(Parsed));
}

bool UUECPSteamIdentityLibrary::IsValidSteamID(const FUECPSteamID& SteamId)
{
	return SteamId.IsValid();
}

bool UUECPSteamIdentityLibrary::EqualEqual_SteamID(const FUECPSteamID& A, const FUECPSteamID& B)
{
	return A == B;
}
