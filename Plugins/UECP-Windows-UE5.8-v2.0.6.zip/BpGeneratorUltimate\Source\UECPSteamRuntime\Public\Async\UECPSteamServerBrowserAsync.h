// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "Containers/Ticker.h"
#include "Async/UECPSteamAsyncAction.h"
#include "UECPSteamTypes.h"
#include "UECPSteamServerBrowserAsync.generated.h"

UENUM(BlueprintType)
enum class EUECPSteamServerListType : uint8
{
	Internet   UMETA(DisplayName = "Internet"),
	LAN        UMETA(DisplayName = "LAN"),
	Friends    UMETA(DisplayName = "Friends"),
	Favorites  UMETA(DisplayName = "Favourites"),
	History    UMETA(DisplayName = "History"),
};

USTRUCT(BlueprintType)
struct UECPSTEAMRUNTIME_API FUECPSteamServerInfo
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	FString ServerName;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	FString ConnectAddress;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	FString MapName;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	FString GameDescription;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	FString GameTags;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	int32 PingMs = -1;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	int32 Players = 0;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	int32 MaxPlayers = 0;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	int32 BotPlayers = 0;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	bool bPasswordProtected = false;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	bool bSecure = false;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	int32 ServerVersion = 0;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	FUECPSteamID ServerSteamId;
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FUECPSteamServerListSignature,
	const TArray<FUECPSteamServerInfo>&, Servers, FUECPSteamError, Error);

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamFindServers : public UUECPSteamAsyncAction
{
	GENERATED_BODY()

public:
	UUECPSteamFindServers();
	virtual ~UUECPSteamFindServers() override;

	UUECPSteamFindServers(FVTableHelper& Helper);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|ServerBrowser",
		meta = (BlueprintInternalUseOnly = "true", WorldContext = "WorldContextObject",
		        DisplayName = "Find Steam Servers", AdvancedDisplay = "Filters,TimeoutSeconds"))
	static UUECPSteamFindServers* FindSteamServers(
		UObject* WorldContextObject,
		EUECPSteamServerListType ListType,
		TMap<FString, FString> Filters,
		float TimeoutSeconds = 15.f);

	UPROPERTY(BlueprintAssignable)
	FUECPSteamServerListSignature OnSuccess;

	UPROPERTY(BlueprintAssignable)
	FUECPSteamServerListSignature OnFailure;

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|ServerBrowser")
	const TArray<FUECPSteamServerInfo>& GetServersSoFar() const { return Servers; }

protected:
	virtual bool Start(FUECPSteamError& OutError) override;
	virtual void BroadcastResult(bool bSucceeded, const FUECPSteamError& Error) override;
	virtual void OnCleanup() override;

private:
	friend class FUECPSteamServerListResponder;

	EUECPSteamServerListType ListType = EUECPSteamServerListType::Internet;
	TMap<FString, FString> Filters;
	float TimeoutSeconds = 15.f;

	TArray<FUECPSteamServerInfo> Servers;

	TUniquePtr<class FUECPSteamServerListResponder> Responder;

	FTSTicker::FDelegateHandle TimeoutHandle;

	void HandleServerResponded(int32 ServerIndex);
	void HandleRefreshComplete(bool bSucceeded);
};
