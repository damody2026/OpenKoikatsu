(function () {
  function emit(type, payload) {
    if (window.uecp && typeof window.uecp.__emit === 'function') {
      window.uecp.__emit(type, payload);
    }
  }
  function notifyToast(msg, type) {
    var sev = (type === 'err') ? 'error' : (type === 'warn') ? 'info' : 'success';
    emit('toast', { message: String(msg == null ? '' : msg), severity: sev });
  }

  var G = window;

  G.onAppearanceSettings = function (d) { emit('settings.appearance', d); };

  G.applyUIConfig = function (map) {
    window._uiConfig = map || {};
    emit('config.ui', window._uiConfig);
  };

  G.onFreeTierUsage = function (d) { emit('freetier.usage', d); };

  G.onScannerTypeFilters    = function (d) { emit('scan.typefilters', d); };
  G.onScannerDirectories    = function (d) { emit('scan.directories', d); };
  G.onScannerPlugins        = function (d) { emit('scan.plugins', d); };
  G.onScannerPluginSources  = function (d) { emit('scan.pluginsources', d); };
  G.onScannerOptions        = function (d) { emit('scan.options', d); };
  G.onScannerSettings       = function (d) { emit('scan.settings', d); };

  G.onUserMcpAddResult = function (d) { emit('settings.mcp_add_result', d); };

  G.onAppendMessage = function (view, html) { emit('architect.append_bubble', { html: String(html == null ? '' : html) }); };

  G.onExtensionToggleResult = function (extensionId, d) {
    const payload = Object.assign({ extensionId: String(extensionId == null ? '' : extensionId) }, d || {});
    emit('settings.extension_toggle_result', payload);
  };

  G.onInstallResult = function (provider, success, message) {
    emit('settings.install_result', { provider: String(provider == null ? '' : provider), success: !!success, message: String(message == null ? '' : message) });
  };

  G.onUserMcpTestResult  = function (d) { emit('settings.mcp_test_result',  d); };
  G.onUserMcpOAuthResult = function (d) { emit('settings.mcp_oauth_result', d); };

  G.onExtensionsApplyResult = function (d) { emit('settings.extensions_apply_result', d); };

  G.onVoiceEnabled = function (enabled) { emit('settings.voice_enabled', { enabled: !!enabled }); };
})();
