(function () {
  if (!document.getElementById('uecp-acct-css')) {
    const s = document.createElement('style'); s.id = 'uecp-acct-css';
    s.textContent = `
uecp-screen-account .ac-kpis{display:flex;gap:10px;flex-wrap:wrap;margin-bottom:14px}
uecp-screen-account .ac-kpi{flex:1;min-width:130px;background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm);padding:14px 16px}
uecp-screen-account .ac-kpi-val{font-size:24px;font-weight:700;color:var(--ue-text-hi);font-variant-numeric:tabular-nums;line-height:1}
uecp-screen-account .ac-kpi-label{font-size:11.5px;color:var(--ue-text-mid);margin-top:5px}
uecp-screen-account .ac-note{font-size:11.5px;color:var(--ue-text-lo);line-height:1.5;margin-top:10px}
uecp-screen-account .ac-row{display:flex;align-items:center;gap:10px;padding:6px 0;font-size:12px;border-bottom:1px solid var(--ue-line-soft)}
uecp-screen-account .ac-row:last-child{border-bottom:none}
uecp-screen-account .ac-name{flex:1 1 auto;min-width:0;color:var(--ue-text-hi);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
uecp-screen-account .ac-track{flex:0 0 140px;height:6px;background:var(--ue-elev);border-radius:3px;overflow:hidden}
uecp-screen-account .ac-fill{display:block;height:100%;background:var(--ue-accent);border-radius:3px}
uecp-screen-account .ac-head{font-size:10.5px;text-transform:uppercase;letter-spacing:.05em;color:var(--ue-text-lo)}
uecp-screen-account .ac-val{flex:0 0 92px;text-align:right;color:var(--ue-text-mid);font-variant-numeric:tabular-nums}
uecp-screen-account .ac-empty{padding:20px;text-align:center;color:var(--ue-text-lo);font-size:12.5px}
uecp-screen-account .ac-heat{display:flex;gap:2px;overflow-x:auto;padding-bottom:4px}
uecp-screen-account .ac-heat-col{display:flex;flex-direction:column;gap:2px}
uecp-screen-account .ac-cell{width:10px;height:10px;border-radius:2px;background:var(--ue-elev)}
uecp-screen-account .ac-legend{display:flex;align-items:center;gap:6px;font-size:11px;color:var(--ue-text-lo);margin-top:8px}
uecp-screen-account .ac-fact{display:flex;gap:10px;padding:6px 0;font-size:12.5px}
uecp-screen-account .ac-fact-k{flex:0 0 150px;color:var(--ue-text-mid)}
uecp-screen-account .ac-fact-v{flex:1;color:var(--ue-text-hi);word-break:break-all}`;
    document.head.appendChild(s);
  }

  function t(key, vars) {
    if (window.uecp && typeof window.uecp.t === 'function') return window.uecp.t(key, vars);
    return String(key).replace(/\{(\w+)\}/g, function (m, k) {
      return vars && (k in vars) ? String(vars[k]) : m;
    });
  }

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  const STAT_TILES = [
    ['blueprints',    'Blueprints'],
    ['assets',        'Assets created'],
    ['cppFiles',      'C++ files'],
    ['pythonScripts', 'Python scripts'],
    ['materials',     'Materials'],
    ['niagara',       'Niagara systems'],
    ['animations',    'Animations'],
    ['widgets',       'Widgets']
  ];

  function fmtCount(n) {
    return Math.max(0, Math.floor(Number(n) || 0)).toLocaleString();
  }

  function effectiveStreak(d, now) {
    const s = Math.max(0, Math.floor(Number(d && d.currentStreak) || 0));
    if (!s || !d.lastLoginDate) return s;
    const last = Date.parse(d.lastLoginDate);
    if (isNaN(last)) return s;
    return ((now || Date.now()) - last) < 2 * 86400000 ? s : 0;
  }

  function statKpi(value, label) {
    return '<div class="ac-kpi"><div class="ac-kpi-val" data-i18n-skip>' + esc(value) +
      '</div><div class="ac-kpi-label">' + esc(label) + '</div></div>';
  }

  function statsHtml(d, now) {
    if (!d || typeof d !== 'object') return '';
    const made = d.creations || {};
    const tiles = [];
    STAT_TILES.forEach(function (p) {
      const v = Number(made[p[0]]) || 0;
      if (v > 0) tiles.push(statKpi(fmtCount(v), t(p[1])));
    });
    const actions = Number(d.toolCalls) || 0;
    const prompts = Number(d.prompts) || 0;
    if (!tiles.length && !actions && !prompts) return '';

    const top = [];
    if (actions) top.push(statKpi(fmtCount(actions), t('AI actions')));
    if (prompts) top.push(statKpi(fmtCount(prompts), t('Prompts')));
    const found = Number(d.distinctTools) || 0;
    const total = Number(d.toolsAvailable) || 0;
    if (found && total) {
      top.push(statKpi(t('{n} of {total}', { n: fmtCount(found), total: fmtCount(total) }),
        t('Tools discovered')));
    }
    if (Number(d.level) > 0) top.push(statKpi(String(Math.floor(d.level)), t('Level')));

    const streak = effectiveStreak(d, now);
    return (top.length ? '<div class="ac-kpis">' + top.join('') + '</div>' : '') +
      (tiles.length ? '<div class="ac-kpis">' + tiles.join('') + '</div>' : '') +
      '<div class="ac-note">' +
        (streak ? esc(t('{n} day streak', { n: streak })) + ' · ' : '') +
        esc(t('Counted while usage data sharing is on.')) +
      '</div>';
  }

  function siteUrl(u) {
    return typeof u === 'string' && u.indexOf('https://www.gamedevcore.com/') === 0 ? u : '';
  }

  let statsSeq = 0;

  function fmtTokens(n) {
    n = Number(n) || 0;
    if (n >= 1e9) return (n / 1e9).toFixed(2).replace(/\.?0+$/, '') + 'B';
    if (n >= 1e6) return (n / 1e6).toFixed(1).replace(/\.0$/, '') + 'M';
    if (n >= 1e3) return Math.round(n / 1e3) + 'K';
    return String(Math.round(n));
  }

  function fmtCost(amount, currency) {
    if (!amount) return '';
    const cur = currency || 'USD';
    const sym = cur === 'USD' ? '$' : cur === 'EUR' ? '€' : '';
    return sym ? sym + Number(amount).toFixed(2) : Number(amount).toFixed(2) + ' ' + cur;
  }

  function isAgent(r) { return r && r.source === 'acp'; }
  function splitSources(rows) {
    const keys = [], agents = [];
    (rows || []).forEach(function (r) { (isAgent(r) ? agents : keys).push(r); });
    return { keys: keys, agents: agents };
  }

  function summarise(rows) {
    const out = { tokens: 0, cached: 0, calls: 0, cost: 0, currency: '', projects: {}, days: {} };
    (rows || []).forEach(function (r) {
      const t = (Number(r.in) || 0) + (Number(r.out) || 0);
      out.tokens += t;
      out.cached += Number(r.cache) || 0;
      out.calls  += Number(r.calls) || 0;
      if (r.cost) { out.cost += Number(r.cost) || 0; out.currency = r.currency || out.currency; }
      if (r.project) out.projects[r.project] = (out.projects[r.project] || 0) + t;
      out.days[r.day] = (out.days[r.day] || 0) + (Number(r.calls) || 0);
    });
    return out;
  }

  function groupBy(rows, field) {
    const acc = {};
    (rows || []).forEach(function (r) {
      const k = r[field] || 'unknown';
      acc[k] = (acc[k] || 0) + (Number(r.in) || 0) + (Number(r.out) || 0);
    });
    return Object.keys(acc)
      .map(function (k) { return { key: k, tokens: acc[k] }; })
      .sort(function (a, b) { return b.tokens - a.tokens; });
  }

  function barsHtml(list, emptyText) {
    if (!list.length) return '<div class="ac-empty">' + esc(emptyText) + '</div>';
    const max = list[0].tokens || 1;
    return list.map(function (r) {
      const pct = Math.max(2, Math.round(r.tokens / max * 100));
      return '<div class="ac-row"><span class="ac-name">' + esc(r.key) + '</span>' +
        '<span class="ac-track"><span class="ac-fill" style="width:' + pct + '%"></span></span>' +
        '<span class="ac-val">' + fmtTokens(r.tokens) + '</span></div>';
    }).join('');
  }

  function agentsHtml(rows) {
    if (!rows || !rows.length) {
      return '<div class="ac-empty">No coding-agent sessions recorded yet.</div>';
    }
    const acc = {};
    rows.forEach(function (r) {
      const k = r.provider || 'unknown';
      const a = acc[k] || (acc[k] = { key: k, grew: 0, calls: 0, cost: 0, currency: '' });
      a.grew  += (Number(r.in) || 0) + (Number(r.out) || 0);
      a.calls += Number(r.calls) || 0;
      if (r.cost) { a.cost += Number(r.cost) || 0; a.currency = r.currency || a.currency; }
    });
    const anyCost = Object.keys(acc).some(function (k) { return acc[k].cost > 0; });
    const head = '<div class="ac-row ac-head"><span class="ac-name"></span>' +
      '<span class="ac-val">Requests</span><span class="ac-val">Context growth</span>' +
      (anyCost ? '<span class="ac-val">Reported cost</span>' : '') + '</div>';
    return head + Object.keys(acc).map(function (k) {
      const a = acc[k];
      return '<div class="ac-row"><span class="ac-name">' + esc(a.key) + '</span>' +
        '<span class="ac-val">' + fmtTokens(a.calls) + '</span>' +
        '<span class="ac-val">' + fmtTokens(a.grew) + '</span>' +
        (anyCost ? '<span class="ac-val">' + esc(a.cost ? fmtCost(a.cost, a.currency) : '—') + '</span>' : '') +
        '</div>';
    }).join('');
  }

  function heatmapHtml(days, todayIso) {
    const keys = Object.keys(days || {});
    const today = todayIso ? new Date(todayIso + 'T00:00:00Z') : new Date();
    const max = keys.reduce(function (m, k) { return Math.max(m, days[k]); }, 0);
    if (!max) return '<div class="ac-empty">No recorded activity yet.</div>';

    const WEEKS = 53;
    let cols = '';
    for (let w = WEEKS - 1; w >= 0; w--) {
      let col = '';
      for (let d = 0; d < 7; d++) {
        const dt = new Date(today.getTime());
        dt.setUTCDate(dt.getUTCDate() - (w * 7 + (6 - d)));
        const key = dt.toISOString().slice(0, 10);
        const v = days[key] || 0;
        const lvl = v <= 0 ? 0 : Math.min(4, 1 + Math.floor(v / max * 3.999));
        const bg = lvl === 0 ? '' : ';background:var(--ue-accent);opacity:' + (0.25 + lvl * 0.18).toFixed(2);
        col += '<span class="ac-cell" title="' + key + ': ' + fmtTokens(v) + '" style="' +
          bg.replace(/^;/, '') + '"></span>';
      }
      cols += '<span class="ac-heat-col">' + col + '</span>';
    }
    return '<div class="ac-heat">' + cols + '</div>' +
      '<div class="ac-legend">Less' +
        '<span class="ac-cell"></span>' +
        '<span class="ac-cell" style="background:var(--ue-accent);opacity:0.43"></span>' +
        '<span class="ac-cell" style="background:var(--ue-accent);opacity:0.61"></span>' +
        '<span class="ac-cell" style="background:var(--ue-accent);opacity:0.79"></span>' +
        '<span class="ac-cell" style="background:var(--ue-accent);opacity:0.97"></span>' +
      'More</div>';
  }

  function walletHtml(d) {
    if (!d || (!d.limit && !d.plan)) {
      return '<div class="ac-empty">No hosted allowance seen yet. Send a message on the free tier or a subscription to populate this.</div>';
    }
    const isSub = !!(d.subGranted > 0);
    const remaining = typeof d.remaining === 'number' ? d.remaining
      : Math.max(0, (d.limit || 0) - (d.used || 0));
    const rows = [
      { k: 'Plan', v: d.plan ? (d.plan.charAt(0).toUpperCase() + d.plan.slice(1)).replace('_', ' ') : 'Free tier' },
      { k: isSub ? 'Pool remaining' : 'Window remaining', v: fmtTokens(remaining) + ' of ' + fmtTokens(d.limit) },
      { k: 'Extra tokens', v: fmtTokens(d.bonusRemaining) }
    ];
    if (d.resetAt) rows.push({ k: isSub ? 'Renews' : 'Resets', v: new Date(d.resetAt).toLocaleString() });
    return rows.map(function (r) {
      return '<div class="ac-fact"><span class="ac-fact-k">' + esc(r.k) + '</span>' +
        '<span class="ac-fact-v">' + esc(r.v) + '</span></div>';
    }).join('');
  }

  const EYE_SVG = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>';
  const EYE_OFF_SVG = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"/><path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"/><line x1="2" x2="22" y1="2" y2="22"/></svg>';

  function maskCredential(v) {
    const s = String(v || '');
    return s.length > 8 ? s.substring(0, 4) + '••••' + s.slice(-4) : '••••';
  }

  function credentialHtml(info, revealed) {
    info = info || {};
    const cred = info.auth_credential || '';
    const hideable = info.auth_origin === 'fab' && !!cred;
    const rows = [
      { k: 'Signed in with', v: info.auth_origin || 'Not signed in' },
      { k: 'Credential', v: cred || '—' },
      { k: 'Activated', v: info.auth_activated || '—' },
      { k: 'Tier', v: info.tier || '—' }
    ];
    return rows.map(function (r) {
      if (r.k === 'Credential' && hideable) {
        const label = esc(t(revealed ? 'Hide' : 'Show'));
        return '<div class="ac-fact"><span class="ac-fact-k">' + esc(r.k) + '</span>' +
          '<span class="ac-fact-v" data-i18n-skip>' + esc(revealed ? cred : maskCredential(cred)) + '</span>' +
          '<button class="btn-ghost" id="ac-cred-reveal" aria-label="' + label + '" aria-pressed="' + (revealed ? 'true' : 'false') + '"' +
          ' data-tip="' + label + '" style="padding:2px 6px;display:inline-flex;align-items:center">' +
          (revealed ? EYE_OFF_SVG : EYE_SVG) + '</button></div>';
      }
      return '<div class="ac-fact"><span class="ac-fact-k">' + esc(r.k) + '</span>' +
        '<span class="ac-fact-v">' + esc(r.v) + '</span></div>';
    }).join('');
  }

  class UecpScreenAccount extends HTMLElement {
    connectedCallback() {
      this.style.cssText = 'display:flex;flex-direction:column;flex:1;min-width:0;min-height:0;background:var(--ue-bg)';
      const self = this;
      this._rows = [];
      this._credRevealed = false;
      this._subs = [
        window.uecp.on('usage.history', function (d) { self._onUsage(d); }),
        window.uecp.on('settings.info', function (d) { self._onInfo(d); }),
        window.uecp.on('freetier.usage', function (d) { self._onWallet(d); }),
        window.uecp.on('account.slots', function (d) { self._onSlots(d); }),
        window.uecp.on('learning.api_result', function (p) { self._onStatsResult(p); })
      ];
      this._build();
      this.refresh();
    }

    disconnectedCallback() {
      (this._subs || []).forEach(function (u) { u(); });
      this._subs = [];
    }

    refresh() {
      window.uecp.call('request_usage_history', { days: 400 });
      window.uecp.call('request_plugin_info', {});
      window.uecp.call('request_wallet', {});
      window.uecp.call('request_device_slots', {});
      this._statsReq = 'ac' + (++statsSeq);
      window.uecp.call('learning_api', { endpoint: 'v2/stats', req_id: this._statsReq, body: {} });
    }

    _build() {
      this.innerHTML =
        '<div class="content"><div class="page page-wide">' +
          '<div class="page-title">Account</div>' +
          '<div class="page-sub">Your plan, what you have spent, and the credential you are signed in with.</div>' +

          '<div class="card" style="margin-bottom:12px;display:none" id="ac-stats-card">' +
            '<div class="section-label" style="margin:0 0 11px">YOUR STATS</div>' +
            '<div id="ac-stats"></div>' +
            '<div class="row" style="margin-top:12px;gap:8px;display:none" id="ac-stats-actions"></div>' +
          '</div>' +

          '<div class="card" style="margin-bottom:12px">' +
            '<div class="section-label" style="margin:0 0 11px">HOSTED ALLOWANCE</div>' +
            '<div id="ac-wallet"><div class="ac-empty">Loading…</div></div>' +
            '<div class="row" style="margin-top:12px;gap:8px">' +
              '<button class="btn-soft" id="ac-manage">Manage plan</button>' +
              '<button class="btn-soft" id="ac-tokens">Get more tokens</button>' +
            '</div>' +
          '</div>' +

          '<div class="card" style="margin-bottom:12px">' +
            '<div class="section-label" style="margin:0 0 11px">YOUR OWN KEYS</div>' +
            '<div class="ac-kpis" id="ac-kpis"></div>' +
            '<div id="ac-heat"><div class="ac-empty">Loading…</div></div>' +
            '<div class="ac-note">Counted from your own API keys and the coding agents you run. ' +
              'This stays on this machine and is never uploaded.</div>' +
          '</div>' +

          '<div class="grid-2" style="margin-bottom:12px">' +
            '<div class="card"><div class="section-label" style="margin:0 0 11px">BY PROVIDER</div>' +
              '<div id="ac-providers"></div></div>' +
            '<div class="card"><div class="section-label" style="margin:0 0 11px">BY PROJECT</div>' +
              '<div id="ac-projects"></div></div>' +
          '</div>' +

          '<div class="card" style="margin-bottom:12px">' +
            '<div class="section-label" style="margin:0 0 11px">CODING AGENTS</div>' +
            '<div id="ac-agents"></div>' +
            '<div class="ac-note">These run on your own Claude, ChatGPT or Copilot subscription, so there is no per-request charge — the plan is the cost. Context growth is how far the conversation got, not tokens billed, so it is not comparable with the figures above. Any cost an agent reports is its own estimate, not money taken from you.</div>' +
          '</div>' +

          '<div class="card" style="margin-bottom:12px" id="ac-devices-card">' +
            '<div class="section-label" style="margin:0 0 11px">DEVICES</div>' +
            '<div id="ac-devices">Loading…</div>' +
            '<div class="ac-note" id="ac-devices-note"></div>' +
          '</div>' +

          '<div class="card">' +
            '<div class="section-label" style="margin:0 0 11px">CREDENTIAL</div>' +
            '<div id="ac-cred"></div>' +
            '<div class="row" style="margin-top:12px;gap:8px">' +
              '<button class="btn-soft" id="ac-account">Manage account</button>' +
              '<button class="btn-soft" id="ac-switch">Switch account</button>' +
              '<button class="btn-danger" id="ac-switch-yes" style="display:none">Sign out and re-enter</button>' +
              '<button class="btn-ghost" id="ac-switch-no" style="display:none">Cancel</button>' +
            '</div>' +
            '<div class="ac-note" id="ac-switch-warn" style="display:none">This signs you out on this machine and deletes the stored credential. You will need it again to get back in.</div>' +
          '</div>' +
        '</div></div>';

      const open = function (url) { window.uecp.call('open_external_url', { url: url }); };
      this.querySelector('#ac-manage').addEventListener('click', function () { open('https://www.gamedevcore.com/account'); });
      this.querySelector('#ac-tokens').addEventListener('click', function () { open('https://www.gamedevcore.com/shop'); });
      this.querySelector('#ac-account').addEventListener('click', function () { open('https://www.gamedevcore.com/account'); });
      const self = this;
      const arm = function (on) {
        const show = function (sel, v) {
          const n = self.querySelector(sel);
          if (n) n.style.display = v ? '' : 'none';
        };
        show('#ac-switch', !on);
        show('#ac-switch-yes', on);
        show('#ac-switch-no', on);
        show('#ac-switch-warn', on);
      };
      this.querySelector('#ac-switch').addEventListener('click', function () { arm(true); });
      this.querySelector('#ac-switch-no').addEventListener('click', function () { arm(false); });
      this.querySelector('#ac-switch-yes').addEventListener('click', function () {
        arm(false);
        window.uecp.call('reauthenticate', {});
      });
    }

    _onSlots(d) {
      const box  = this.querySelector('#ac-devices');
      const note = this.querySelector('#ac-devices-note');
      const card = this.querySelector('#ac-devices-card');
      if (!box) return;

      if (!d || d.ok === false) {
        box.textContent = 'Could not reach the server. Your access is unaffected — this list just could not load.';
        if (note) note.textContent = '';
        return;
      }

      if (d.enforced === false) { if (card) card.style.display = 'none'; return; }
      if (card) card.style.display = '';

      const devices = d.devices || [];
      const held = devices.filter(function (x) { return x.holding; }).length;

      box.innerHTML = devices.length === 0
        ? '<div class="ac-note" style="margin:0">' + esc(t('No devices recorded yet.')) + '</div>'
        : devices.map(function (x) {
            const when = x.last_seen ? new Date(x.last_seen).toLocaleString() : '—';
            const line = x.holding
              ? t('Using a seat · last used {when}', { when: when })
              : t('Idle, seat free · last used {when}', { when: when });
            const name = x.this_device
              ? t('{label} (this device)', { label: x.label })
              : x.label;
            const btn  = (x.holding && !x.this_device)
              ? '<button class="btn-soft" data-release="' + esc(x.id) + '">' + esc(t('Release')) + '</button>'
              : '';
            return '<div style="display:flex;align-items:center;gap:10px;padding:7px 0;border-bottom:1px solid var(--ue-line)">' +
                     '<div style="flex:1;min-width:0">' +
                       '<div>' + esc(name) + '</div>' +
                       '<div style="font-size:11.5px;color:var(--ue-text-lo)">' + esc(line) + '</div>' +
                     '</div>' + btn +
                   '</div>';
          }).join('');

      if (note) {
        note.textContent =
          t('Seats in use: {held} of {cap}.', { held: held, cap: d.cap }) + ' ' +
          t('A seat frees itself after {mins} minutes of inactivity, so moving between your own machines needs nothing from you.',
            { mins: d.window_minutes });
      }

      box.querySelectorAll('[data-release]').forEach(function (b) {
        b.addEventListener('click', function () {
          b.disabled = true;
          window.uecp.call('request_device_slots', { action: 'release', target: b.getAttribute('data-release') });
          setTimeout(function () { window.uecp.call('request_device_slots', {}); }, 400);
        });
      });
    }

    _onUsage(d) {
      this._rows = (d && d.rows) || [];
      const split = splitSources(this._rows);
      const keys  = summarise(split.keys);
      const all   = summarise(this._rows);

      const kpis = this.querySelector('#ac-kpis');
      if (kpis) {
        const cells = [
          { v: fmtTokens(keys.tokens), l: 'Tokens on your keys' },
          { v: fmtTokens(keys.cached) + (keys.tokens ? ' · ' + Math.round(keys.cached / keys.tokens * 100) + '%' : ''),
            l: 'Cached input' },
          { v: fmtTokens(keys.calls), l: 'Requests' },
          { v: String(Object.keys(all.projects).length), l: 'Projects' }
        ];
        kpis.innerHTML = cells.map(function (c) {
          return '<div class="ac-kpi"><div class="ac-kpi-val">' + esc(c.v) +
            '</div><div class="ac-kpi-label">' + esc(c.l) + '</div></div>';
        }).join('');
      }

      const heat = this.querySelector('#ac-heat');
      if (heat) heat.innerHTML = heatmapHtml(all.days);

      const prov = this.querySelector('#ac-providers');
      if (prov) prov.innerHTML = barsHtml(groupBy(split.keys, 'provider'), 'Nothing recorded yet.');
      const proj = this.querySelector('#ac-projects');
      if (proj) proj.innerHTML = barsHtml(groupBy(this._rows, 'project'), 'Nothing recorded yet.');

      const agents = this.querySelector('#ac-agents');
      if (agents) agents.innerHTML = agentsHtml(split.agents);
    }

    _onInfo(info) {
      this._info = info;
      this._renderCred();
    }

    _renderCred() {
      const box = this.querySelector('#ac-cred');
      if (!box) return;
      box.innerHTML = credentialHtml(this._info, this._credRevealed);
      const self = this;
      const eye = box.querySelector('#ac-cred-reveal');
      if (eye) eye.addEventListener('click', function () {
        self._credRevealed = !self._credRevealed;
        self._renderCred();
      });
    }

    _onStatsResult(p) {
      if (!p || !this._statsReq || p.req_id !== this._statsReq) return;
      const card = this.querySelector('#ac-stats-card');
      const box  = this.querySelector('#ac-stats');
      const acts = this.querySelector('#ac-stats-actions');
      if (!card || !box) return;

      const d = (p.ok && p.data) || null;
      const html = statsHtml(d);
      if (!html) { card.style.display = 'none'; return; }
      box.innerHTML = html;
      card.style.display = '';

      if (!acts) return;
      const profile = siteUrl(d.profileUrl);
      const claim   = siteUrl(d.claimUrl);
      acts.innerHTML = profile
        ? '<button class="btn-soft" data-url="' + esc(profile) + '">' + esc(t('View your profile')) + '</button>'
        : claim
          ? '<button class="btn-soft" data-url="' + esc(claim) + '">' + esc(t('Claim your profile')) + '</button>'
          : '';
      acts.style.display = acts.innerHTML ? '' : 'none';
      acts.querySelectorAll('[data-url]').forEach(function (b) {
        b.addEventListener('click', function () {
          window.uecp.call('open_external_url', { url: b.getAttribute('data-url') });
        });
      });
    }

    _onWallet(d) {
      const box = this.querySelector('#ac-wallet');
      if (box) box.innerHTML = walletHtml(d);
      const manage = this.querySelector('#ac-manage');
      if (manage) manage.style.display = (d && d.plan) ? '' : 'none';
    }
  }

  UecpScreenAccount.__pure = { summarise, splitSources, groupBy, barsHtml, agentsHtml,
    heatmapHtml, walletHtml, credentialHtml, fmtTokens, fmtCost,
    statsHtml, effectiveStreak, siteUrl };

  customElements.define('uecp-screen-account', UecpScreenAccount);

  if (window.UECP && window.UECP.router) {
    window.UECP.router.register('account', 'uecp-screen-account');
  }
})();
