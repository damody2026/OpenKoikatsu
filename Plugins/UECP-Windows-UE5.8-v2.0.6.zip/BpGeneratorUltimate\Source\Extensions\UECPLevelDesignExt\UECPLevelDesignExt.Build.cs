﻿// Copyright 2026, BlueprintsLab, All rights reserved
using UnrealBuildTool;

public class UECPLevelDesignExt : ModuleRules
{
	public UECPLevelDesignExt(ReadOnlyTargetRules Target) : base(Target)
	{
		bUsePrecompiled = true;
		if (Target.Type != TargetType.Editor) return;
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;
		bUseUnity = false;

		if (Target.Version.MinorVersion < 5)
		{
			PrivateDependencyModuleNames.Add("StructUtils");
		}

		PublicDependencyModuleNames.AddRange(new string[]
		{
			"Core", "CoreUObject", "Engine", "Json", "JsonUtilities",
			"UECPCore",
		});

		PrivateDependencyModuleNames.AddRange(new string[]
		{
			"UnrealEd", "AssetTools", "AssetRegistry", "EditorScriptingUtilities",
			"Slate", "SlateCore", "Kismet", "KismetCompiler", "BlueprintGraph",
			"LevelEditor",

			"Foliage", "FoliageEdit",
			"PCG", "PCGEditor",
			"Landscape", "LandscapeEditor",
			"DataLayerEditor",
			"CinematicCamera",
			"PhysicsCore",
			"MeshDescription", "StaticMeshDescription",
			"MeshMergeUtilities", "MeshReductionInterface",
			"Sequencer", "SequencerCore", "MovieScene", "MovieSceneTracks",
		});
	}
}

