﻿// Copyright 2026, BlueprintsLab, All rights reserved
using UnrealBuildTool;

public class UECPTools : ModuleRules
{
	public UECPTools(ReadOnlyTargetRules Target) : base(Target)
	{
		bUsePrecompiled = true;
		if (Target.Type != TargetType.Editor)
		{
			return;
		}

		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;
		bUseUnity = false;

		if (Target.Version.MinorVersion >= 6)
		{
			PrivateDependencyModuleNames.Add("PropertyBindingUtils");
		PrivateDependencyModuleNames.AddRange(new string[] { "InterchangeEngine", "InterchangeCore" });
		}

		PublicDependencyModuleNames.AddRange(new string[]
		{
			"Core",
			"CoreUObject",
			"Engine",
			"HTTP",
			"Json",
			"JsonUtilities",
			"EditorScriptingUtilities",
			"UECPCore"
		});

		PrivateDependencyModuleNames.AddRange(new string[]
		{
			"Projects",
			"InputCore",
			"EditorFramework",
			"UnrealEd",
			"LevelEditor",
			"ToolMenus",
			"Slate",
			"SlateCore",
			"Kismet",
			"AssetRegistry",
			"MeshDescription",
			"KismetCompiler",
			"BlueprintGraph",
			"GraphEditor",
			"ApplicationCore",
			"UMG",
			"UMGEditor",
			"Blutility",
			"Sockets",
			"Networking",
			"ImageCore",
			"ImageWrapper",
			"RHI",
			"ContentBrowser",
			"ContentBrowserData",
			"MaterialEditor",
			"AssetTools",
			"AIModule",
			"AIGraph",
			"BehaviorTreeEditor",
			"AnimGraph",
			"DesktopPlatform",
			"WebBrowser",
			"WebBrowserWidget",
			"EnhancedInput",
			"GameplayTags",
			"GameplayAbilities",
			"LevelSequence",
			"MovieScene",
			"MovieSceneTracks",
			"MovieSceneCapture",
			"ControlRig",
			"ControlRigEditor",
			"PhysicsUtilities",
			"PhysicsCore",
			"ClothingSystemRuntimeInterface",
			"ClothingSystemRuntimeCommon",
			"TraceServices",
			"TraceAnalysis",
			"TraceLog",
			"HairStrandsCore",
			"SourceControl",
			"CollectionManager"
		});

		if (Target.Version.MinorVersion < 5)
		{
			PrivateDependencyModuleNames.Add("Niagara");
		}
	}
}

