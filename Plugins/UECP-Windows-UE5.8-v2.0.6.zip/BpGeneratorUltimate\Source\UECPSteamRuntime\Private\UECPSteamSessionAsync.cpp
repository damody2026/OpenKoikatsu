// Copyright 2026, BlueprintsLab, All rights reserved
#include "Async/UECPSteamSessionAsync.h"

#include "Library/UECPSteamSessionLibrary.h"
#include "Online/OnlineSessionNames.h"
#include "OnlineSubsystem.h"
#include "UECPSteamOSS.h"
#include "UECPSteamRuntimeModule.h"

namespace
{
	FName ResolveSessionName(FName In)
	{
		return In.IsNone() ? NAME_GameSession : In;
	}

	void ApplySearchSettings(FOnlineSessionSearch& Search, const FUECPSteamSessionSearchSettings& In)
	{
		Search.MaxSearchResults = FMath::Max(1, In.MaxResults);
		Search.bIsLanQuery      = (In.SessionType == EUECPSteamSessionType::LAN);

		if (In.SessionType == EUECPSteamSessionType::Lobby)
		{
			Search.QuerySettings.Set(SEARCH_LOBBIES, true, EOnlineComparisonOp::Equals);
		}
		else if (In.SessionType == EUECPSteamSessionType::ServerBrowser)
		{
			Search.QuerySettings.Set(SEARCH_DEDICATED_ONLY, true, EOnlineComparisonOp::Equals);
		}

		if (In.bOnlyJoinable)
		{
			Search.QuerySettings.Set(SEARCH_MINSLOTSAVAILABLE, 1, EOnlineComparisonOp::GreaterThanEquals);
		}

		for (const TPair<FString, FString>& Pair : In.RequiredSettings)
		{
			Search.QuerySettings.Set(FName(*Pair.Key), Pair.Value, EOnlineComparisonOp::Equals);
		}
	}
}

bool UUECPSteamOSSAsyncAction::IsAvailable(FUECPSteamError& OutError) const
{
	if (UECPSteamOSS::Get(ContextObject.Get()))
	{
		return true;
	}
	OutError = UECPSteamOSS::InterfaceUnavailable(TEXT("online subsystem"));
	return false;
}

UUECPSteamCreateSession* UUECPSteamCreateSession::CreateSteamSession(
	UObject* WorldContextObject, FUECPSteamSessionSettings Settings, FName SessionName)
{
	UUECPSteamCreateSession* Node = NewObject<UUECPSteamCreateSession>();
	Node->ContextObject = WorldContextObject;
	Node->Settings           = MoveTemp(Settings);
	Node->SessionName        = ResolveSessionName(SessionName);
	Node->RegisterWithGameInstance(WorldContextObject);
	return Node;
}

bool UUECPSteamCreateSession::Start(FUECPSteamError& OutError)
{
	const IOnlineSessionPtr Sessions = UECPSteamOSS::Session(ContextObject.Get());
	if (!Sessions.IsValid())
	{
		OutError = UECPSteamOSS::InterfaceUnavailable(TEXT("session"));
		return false;
	}

	CompleteHandle = Sessions->AddOnCreateSessionCompleteDelegate_Handle(
		FOnCreateSessionCompleteDelegate::CreateUObject(this, &UUECPSteamCreateSession::HandleCreateComplete));

	const FOnlineSessionSettings OnlineSettings = Settings.ToOnlineSessionSettings();
	if (!Sessions->CreateSession(0, SessionName, OnlineSettings))
	{
		OutError = FUECPSteamError(EUECPSteamResult::BackendFailure,
			TEXT("CreateSession was rejected outright. A session with this name usually already exists -- destroy it first."));
		return false;
	}
	return true;
}

void UUECPSteamCreateSession::HandleCreateComplete(FName InSessionName, bool bWasSuccessful)
{
	if (InSessionName != SessionName)
	{
		return;
	}
	if (bWasSuccessful)
	{
		CompleteSuccess();
	}
	else
	{
		CompleteFailure(FUECPSteamError(EUECPSteamResult::BackendFailure,
			TEXT("Steam refused to create the session. Most often a session with this name already exists -- destroy it first. Otherwise check that the Steam client is running and signed in.")));
	}
}

void UUECPSteamCreateSession::OnCleanup()
{
	if (const IOnlineSessionPtr Sessions = UECPSteamOSS::Session(ContextObject.Get()))
	{
		Sessions->ClearOnCreateSessionCompleteDelegate_Handle(CompleteHandle);
	}
}

void UUECPSteamCreateSession::BroadcastResult(bool bSucceeded, const FUECPSteamError& Error)
{
	(bSucceeded ? OnSuccess : OnFailure).Broadcast(Error);
}

UUECPSteamFindSessions* UUECPSteamFindSessions::FindSteamSessions(
	UObject* WorldContextObject, FUECPSteamSessionSearchSettings SearchSettings)
{
	UUECPSteamFindSessions* Node = NewObject<UUECPSteamFindSessions>();
	Node->ContextObject = WorldContextObject;
	Node->SearchSettings     = MoveTemp(SearchSettings);
	Node->RegisterWithGameInstance(WorldContextObject);
	return Node;
}

bool UUECPSteamFindSessions::Start(FUECPSteamError& OutError)
{
	const IOnlineSessionPtr Sessions = UECPSteamOSS::Session(ContextObject.Get());
	if (!Sessions.IsValid())
	{
		OutError = UECPSteamOSS::InterfaceUnavailable(TEXT("session"));
		return false;
	}

	Search = MakeShared<FOnlineSessionSearch>();
	ApplySearchSettings(*Search, SearchSettings);

	CompleteHandle = Sessions->AddOnFindSessionsCompleteDelegate_Handle(
		FOnFindSessionsCompleteDelegate::CreateUObject(this, &UUECPSteamFindSessions::HandleFindComplete));

	if (!Sessions->FindSessions(0, Search.ToSharedRef()))
	{
		OutError = FUECPSteamError(EUECPSteamResult::BackendFailure,
			TEXT("FindSessions was rejected outright. Another search is usually still running."));
		return false;
	}
	return true;
}

void UUECPSteamFindSessions::HandleFindComplete(bool bWasSuccessful)
{
	if (bWasSuccessful && Search.IsValid())
	{
		Results.Reserve(Search->SearchResults.Num());
		for (const FOnlineSessionSearchResult& Result : Search->SearchResults)
		{
			if (Result.IsValid())
			{
				Results.Add(FUECPSteamSessionSearchResult::FromOnlineResult(Result));
			}
		}
		CompleteSuccess();
	}
	else
	{
		CompleteFailure(FUECPSteamError(EUECPSteamResult::BackendFailure,
			TEXT("The session search failed. Check that Steam is signed in and that the search type matches how the host published.")));
	}
}

void UUECPSteamFindSessions::OnCleanup()
{
	if (const IOnlineSessionPtr Sessions = UECPSteamOSS::Session(ContextObject.Get()))
	{
		Sessions->ClearOnFindSessionsCompleteDelegate_Handle(CompleteHandle);
	}
}

void UUECPSteamFindSessions::BroadcastResult(bool bSucceeded, const FUECPSteamError& Error)
{
	(bSucceeded ? OnSuccess : OnFailure).Broadcast(Results, Error);
}

UUECPSteamJoinSession* UUECPSteamJoinSession::JoinSteamSession(
	UObject* WorldContextObject, FUECPSteamSessionSearchResult SearchResult, FName SessionName)
{
	UUECPSteamJoinSession* Node = NewObject<UUECPSteamJoinSession>();
	Node->ContextObject = WorldContextObject;
	Node->SearchResult       = MoveTemp(SearchResult);
	Node->SessionName        = ResolveSessionName(SessionName);
	Node->RegisterWithGameInstance(WorldContextObject);
	return Node;
}

bool UUECPSteamJoinSession::Start(FUECPSteamError& OutError)
{
	if (!SearchResult.IsValid())
	{
		OutError = FUECPSteamError(EUECPSteamResult::InvalidParameter,
			TEXT("The search result is empty or was rebuilt in Blueprint. Pass the struct straight from Find Steam Sessions -- it carries a native handle that cannot be reconstructed."));
		return false;
	}

	const IOnlineSessionPtr Sessions = UECPSteamOSS::Session(ContextObject.Get());
	if (!Sessions.IsValid())
	{
		OutError = UECPSteamOSS::InterfaceUnavailable(TEXT("session"));
		return false;
	}

	CompleteHandle = Sessions->AddOnJoinSessionCompleteDelegate_Handle(
		FOnJoinSessionCompleteDelegate::CreateUObject(this, &UUECPSteamJoinSession::HandleJoinComplete));

	if (!Sessions->JoinSession(0, SessionName, SearchResult.OnlineResult))
	{
		OutError = FUECPSteamError(EUECPSteamResult::BackendFailure,
			TEXT("JoinSession was rejected outright. This client is usually already in a session with that name."));
		return false;
	}
	return true;
}

void UUECPSteamJoinSession::HandleJoinComplete(FName InSessionName, EOnJoinSessionCompleteResult::Type Result)
{
	if (InSessionName != SessionName)
	{
		return;
	}

	switch (Result)
	{
	case EOnJoinSessionCompleteResult::Success:
		break;

	case EOnJoinSessionCompleteResult::SessionIsFull:
		CompleteFailure(FUECPSteamError(EUECPSteamResult::AccessDenied, TEXT("The session is full.")));
		return;

	case EOnJoinSessionCompleteResult::SessionDoesNotExist:
		CompleteFailure(FUECPSteamError(EUECPSteamResult::NotFound,
			TEXT("The session no longer exists. Search results go stale as soon as the host leaves.")));
		return;

	case EOnJoinSessionCompleteResult::AlreadyInSession:
		CompleteFailure(FUECPSteamError(EUECPSteamResult::InvalidState,
			TEXT("This client is already in that session.")));
		return;

	case EOnJoinSessionCompleteResult::CouldNotRetrieveAddress:
		CompleteFailure(FUECPSteamError(EUECPSteamResult::BackendFailure,
			TEXT("Joined the session but could not resolve the host address. The host is usually behind a NAT that Steam relay could not traverse.")));
		return;

	case EOnJoinSessionCompleteResult::UnknownError:
	default:
		CompleteFailure(FUECPSteamError(EUECPSteamResult::Unknown,
			UUECPSteamSessionLibrary::IsInSteamSession(ContextObject.Get(), SessionName)
				? TEXT("Joining the session failed. This client is already in a session -- destroy or leave it before joining another.")
				: TEXT("Joining the session failed.")));
		return;
	}

	const IOnlineSessionPtr Sessions = UECPSteamOSS::Session(ContextObject.Get());
	if (!Sessions.IsValid() || !Sessions->GetResolvedConnectString(SessionName, ConnectString) || ConnectString.IsEmpty())
	{
		CompleteFailure(FUECPSteamError(EUECPSteamResult::BackendFailure,
			TEXT("Joined the session but could not build a connect string to travel to.")));
		return;
	}

	CompleteSuccess();
}

void UUECPSteamJoinSession::OnCleanup()
{
	if (const IOnlineSessionPtr Sessions = UECPSteamOSS::Session(ContextObject.Get()))
	{
		Sessions->ClearOnJoinSessionCompleteDelegate_Handle(CompleteHandle);
	}
}

void UUECPSteamJoinSession::BroadcastResult(bool bSucceeded, const FUECPSteamError& Error)
{
	(bSucceeded ? OnSuccess : OnFailure).Broadcast(ConnectString, Error);
}

UUECPSteamDestroySession* UUECPSteamDestroySession::DestroySteamSession(
	UObject* WorldContextObject, FName SessionName)
{
	UUECPSteamDestroySession* Node = NewObject<UUECPSteamDestroySession>();
	Node->ContextObject = WorldContextObject;
	Node->SessionName        = ResolveSessionName(SessionName);
	Node->RegisterWithGameInstance(WorldContextObject);
	return Node;
}

bool UUECPSteamDestroySession::Start(FUECPSteamError& OutError)
{
	const IOnlineSessionPtr Sessions = UECPSteamOSS::Session(ContextObject.Get());
	if (!Sessions.IsValid())
	{
		OutError = UECPSteamOSS::InterfaceUnavailable(TEXT("session"));
		return false;
	}

	CompleteHandle = Sessions->AddOnDestroySessionCompleteDelegate_Handle(
		FOnDestroySessionCompleteDelegate::CreateUObject(this, &UUECPSteamDestroySession::HandleDestroyComplete));

	if (!Sessions->DestroySession(SessionName))
	{
		OutError = FUECPSteamError(EUECPSteamResult::NotFound,
			TEXT("DestroySession was rejected outright. There is usually no session with that name."));
		return false;
	}
	return true;
}

void UUECPSteamDestroySession::HandleDestroyComplete(FName InSessionName, bool bWasSuccessful)
{
	if (InSessionName != SessionName)
	{
		return;
	}
	if (bWasSuccessful)
	{
		CompleteSuccess();
	}
	else
	{
		CompleteFailure(FUECPSteamError(EUECPSteamResult::BackendFailure, TEXT("Destroying the session failed.")));
	}
}

void UUECPSteamDestroySession::OnCleanup()
{
	if (const IOnlineSessionPtr Sessions = UECPSteamOSS::Session(ContextObject.Get()))
	{
		Sessions->ClearOnDestroySessionCompleteDelegate_Handle(CompleteHandle);
	}
}

void UUECPSteamDestroySession::BroadcastResult(bool bSucceeded, const FUECPSteamError& Error)
{
	(bSucceeded ? OnSuccess : OnFailure).Broadcast(Error);
}

UUECPSteamStartSession* UUECPSteamStartSession::StartSteamSession(
	UObject* WorldContextObject, FName SessionName)
{
	UUECPSteamStartSession* Node = NewObject<UUECPSteamStartSession>();
	Node->ContextObject = WorldContextObject;
	Node->SessionName        = ResolveSessionName(SessionName);
	Node->RegisterWithGameInstance(WorldContextObject);
	return Node;
}

bool UUECPSteamStartSession::Start(FUECPSteamError& OutError)
{
	const IOnlineSessionPtr Sessions = UECPSteamOSS::Session(ContextObject.Get());
	if (!Sessions.IsValid())
	{
		OutError = UECPSteamOSS::InterfaceUnavailable(TEXT("session"));
		return false;
	}

	CompleteHandle = Sessions->AddOnStartSessionCompleteDelegate_Handle(
		FOnStartSessionCompleteDelegate::CreateUObject(this, &UUECPSteamStartSession::HandleStartComplete));

	if (!Sessions->StartSession(SessionName))
	{
		OutError = FUECPSteamError(EUECPSteamResult::InvalidState,
			TEXT("StartSession was rejected outright. The session is usually not in the Pending state."));
		return false;
	}
	return true;
}

void UUECPSteamStartSession::HandleStartComplete(FName InSessionName, bool bWasSuccessful)
{
	if (InSessionName != SessionName)
	{
		return;
	}
	bWasSuccessful
		? CompleteSuccess()
		: CompleteFailure(FUECPSteamError(EUECPSteamResult::BackendFailure, TEXT("Starting the session failed.")));
}

void UUECPSteamStartSession::OnCleanup()
{
	if (const IOnlineSessionPtr Sessions = UECPSteamOSS::Session(ContextObject.Get()))
	{
		Sessions->ClearOnStartSessionCompleteDelegate_Handle(CompleteHandle);
	}
}

void UUECPSteamStartSession::BroadcastResult(bool bSucceeded, const FUECPSteamError& Error)
{
	(bSucceeded ? OnSuccess : OnFailure).Broadcast(Error);
}

UUECPSteamEndSession* UUECPSteamEndSession::EndSteamSession(
	UObject* WorldContextObject, FName SessionName)
{
	UUECPSteamEndSession* Node = NewObject<UUECPSteamEndSession>();
	Node->ContextObject = WorldContextObject;
	Node->SessionName        = ResolveSessionName(SessionName);
	Node->RegisterWithGameInstance(WorldContextObject);
	return Node;
}

bool UUECPSteamEndSession::Start(FUECPSteamError& OutError)
{
	const IOnlineSessionPtr Sessions = UECPSteamOSS::Session(ContextObject.Get());
	if (!Sessions.IsValid())
	{
		OutError = UECPSteamOSS::InterfaceUnavailable(TEXT("session"));
		return false;
	}

	CompleteHandle = Sessions->AddOnEndSessionCompleteDelegate_Handle(
		FOnEndSessionCompleteDelegate::CreateUObject(this, &UUECPSteamEndSession::HandleEndComplete));

	if (!Sessions->EndSession(SessionName))
	{
		OutError = FUECPSteamError(EUECPSteamResult::InvalidState,
			TEXT("EndSession was rejected outright. The session is usually not in the InProgress state."));
		return false;
	}
	return true;
}

void UUECPSteamEndSession::HandleEndComplete(FName InSessionName, bool bWasSuccessful)
{
	if (InSessionName != SessionName)
	{
		return;
	}
	bWasSuccessful
		? CompleteSuccess()
		: CompleteFailure(FUECPSteamError(EUECPSteamResult::BackendFailure, TEXT("Ending the session failed.")));
}

void UUECPSteamEndSession::OnCleanup()
{
	if (const IOnlineSessionPtr Sessions = UECPSteamOSS::Session(ContextObject.Get()))
	{
		Sessions->ClearOnEndSessionCompleteDelegate_Handle(CompleteHandle);
	}
}

void UUECPSteamEndSession::BroadcastResult(bool bSucceeded, const FUECPSteamError& Error)
{
	(bSucceeded ? OnSuccess : OnFailure).Broadcast(Error);
}

UUECPSteamUpdateSession* UUECPSteamUpdateSession::UpdateSteamSession(
	UObject* WorldContextObject, FUECPSteamSessionSettings Settings, FName SessionName, bool bRefreshOnlineData)
{
	UUECPSteamUpdateSession* Node = NewObject<UUECPSteamUpdateSession>();
	Node->ContextObject       = WorldContextObject;
	Node->Settings            = MoveTemp(Settings);
	Node->SessionName         = ResolveSessionName(SessionName);
	Node->bRefreshOnlineData  = bRefreshOnlineData;
	Node->RegisterWithGameInstance(WorldContextObject);
	return Node;
}

bool UUECPSteamUpdateSession::Start(FUECPSteamError& OutError)
{
	const IOnlineSessionPtr Sessions = UECPSteamOSS::Session(ContextObject.Get());
	if (!Sessions.IsValid())
	{
		OutError = UECPSteamOSS::InterfaceUnavailable(TEXT("session"));
		return false;
	}

	CompleteHandle = Sessions->AddOnUpdateSessionCompleteDelegate_Handle(
		FOnUpdateSessionCompleteDelegate::CreateUObject(this, &UUECPSteamUpdateSession::HandleUpdateComplete));

	FOnlineSessionSettings OnlineSettings = Settings.ToOnlineSessionSettings();
	if (!Sessions->UpdateSession(SessionName, OnlineSettings, bRefreshOnlineData))
	{
		OutError = FUECPSteamError(EUECPSteamResult::NotFound,
			TEXT("UpdateSession was rejected outright. There is usually no session with that name."));
		return false;
	}
	return true;
}

void UUECPSteamUpdateSession::HandleUpdateComplete(FName InSessionName, bool bWasSuccessful)
{
	if (InSessionName != SessionName)
	{
		return;
	}
	bWasSuccessful
		? CompleteSuccess()
		: CompleteFailure(FUECPSteamError(EUECPSteamResult::BackendFailure, TEXT("Updating the session failed.")));
}

void UUECPSteamUpdateSession::OnCleanup()
{
	if (const IOnlineSessionPtr Sessions = UECPSteamOSS::Session(ContextObject.Get()))
	{
		Sessions->ClearOnUpdateSessionCompleteDelegate_Handle(CompleteHandle);
	}
}

void UUECPSteamUpdateSession::BroadcastResult(bool bSucceeded, const FUECPSteamError& Error)
{
	(bSucceeded ? OnSuccess : OnFailure).Broadcast(Error);
}

UUECPSteamFindFriendSession* UUECPSteamFindFriendSession::FindSteamFriendSession(
	UObject* WorldContextObject, FUECPSteamID FriendSteamId)
{
	UUECPSteamFindFriendSession* Node = NewObject<UUECPSteamFindFriendSession>();
	Node->ContextObject = WorldContextObject;
	Node->FriendSteamId      = FriendSteamId;
	Node->RegisterWithGameInstance(WorldContextObject);
	return Node;
}

bool UUECPSteamFindFriendSession::Start(FUECPSteamError& OutError)
{
	if (!FriendSteamId.IsValid())
	{
		OutError = FUECPSteamError(EUECPSteamResult::InvalidParameter, TEXT("The friend's Steam ID is empty."));
		return false;
	}

	const IOnlineSessionPtr Sessions = UECPSteamOSS::Session(ContextObject.Get());
	const IOnlineIdentityPtr Identity = UECPSteamOSS::Identity(ContextObject.Get());
	if (!Sessions.IsValid() || !Identity.IsValid())
	{
		OutError = UECPSteamOSS::InterfaceUnavailable(TEXT("session"));
		return false;
	}

	const FUniqueNetIdPtr FriendId = Identity->CreateUniquePlayerId(FriendSteamId.ToString());
	if (!FriendId.IsValid())
	{
		OutError = FUECPSteamError(EUECPSteamResult::InvalidParameter,
			TEXT("That Steam ID could not be turned into a net id."));
		return false;
	}

	CompleteHandle = Sessions->AddOnFindFriendSessionCompleteDelegate_Handle(0,
		FOnFindFriendSessionCompleteDelegate::CreateUObject(this, &UUECPSteamFindFriendSession::HandleFindFriendComplete));

	if (!Sessions->FindFriendSession(0, *FriendId))
	{
		OutError = FUECPSteamError(EUECPSteamResult::BackendFailure,
			TEXT("FindFriendSession was rejected outright."));
		return false;
	}
	return true;
}

void UUECPSteamFindFriendSession::HandleFindFriendComplete(int32 LocalUserNum, bool bWasSuccessful,
	const TArray<FOnlineSessionSearchResult>& FriendSearchResults)
{
	if (LocalUserNum != 0)
	{
		return;
	}

	if (!bWasSuccessful)
	{
		CompleteFailure(FUECPSteamError(EUECPSteamResult::NotFound,
			TEXT("That friend is not in a joinable session. Only sessions published as a Lobby carry the presence Steam needs to find them.")));
		return;
	}

	for (const FOnlineSessionSearchResult& Result : FriendSearchResults)
	{
		if (Result.IsValid())
		{
			Results.Add(FUECPSteamSessionSearchResult::FromOnlineResult(Result));
		}
	}
	CompleteSuccess();
}

void UUECPSteamFindFriendSession::OnCleanup()
{
	if (const IOnlineSessionPtr Sessions = UECPSteamOSS::Session(ContextObject.Get()))
	{
		Sessions->ClearOnFindFriendSessionCompleteDelegate_Handle(0, CompleteHandle);
	}
}

void UUECPSteamFindFriendSession::BroadcastResult(bool bSucceeded, const FUECPSteamError& Error)
{
	(bSucceeded ? OnSuccess : OnFailure).Broadcast(Results, Error);
}
