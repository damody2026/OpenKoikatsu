(function () {
  function esc(s) {
    return (window.UECP && window.UECP.escapeHtml)
      ? window.UECP.escapeHtml(s)
      : String(s == null ? '' : s)
          .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
          .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function svgIcon(n, sz) {
    return (window.UECP && window.UECP.icon) ? window.UECP.icon(n, sz) : '';
  }

  const CAP_TABS = [
    { cap: 'image_from_text', label: 'Image' },
    { cap: 'audio_from_text', label: 'Sound' },
    { cap: 'video_from_text', label: 'Video' },
    { cap: 'mesh_from_text',  label: '3D from Text' },
    { cap: 'mesh_from_image', label: '3D from Image' },
  ];

  const KEYED = ['comfy_cloud', 'meshy', 'tripo', 'imagegen'];

  const OP_LABELS = {
    local_create_image: 'Image',
    local_create_audio: 'Sound',
    local_create_video: 'Video',
    local_create_3d_from_text: '3D from Text',
    local_create_3d_from_image: '3D from Image',
    create_3d_from_text: 'Meshy 3D from Text',
    create_3d_from_image: 'Meshy 3D from Image',
    meshy_text_to_image: 'Meshy Image',
    meshy_retexture: 'Meshy Retexture',
    meshy_remesh: 'Meshy Remesh',
    rig_model: 'Meshy Rig',
    animate_model: 'Meshy Animate',
    tripo_create_3d_from_text: 'Tripo 3D from Text',
    tripo_create_3d_from_image: 'Tripo 3D from Image',
    tripo_rig_model: 'Tripo Rig',
    tripo_animate_model: 'Tripo Animate',
    tripo_segment_model: 'Tripo Segment',
    generate_image: 'Image',
  };
  function opLabel(tool) { return OP_LABELS[tool] || tool; }

  const VENDOR_TABS = [
    { provider: 'meshy', label: 'Meshy' },
    { provider: 'tripo', label: 'Tripo' },
  ];

  if (!document.getElementById('uecp-cloudstudio-css')) {
    const st = document.createElement('style');
    st.id = 'uecp-cloudstudio-css';
    st.textContent = `
uecp-screen-cloudstudio{display:flex;flex-direction:column;flex:1;min-height:0;overflow-y:auto;padding:18px 20px}
uecp-screen-cloudstudio .cs-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;margin-bottom:4px}
uecp-screen-cloudstudio .cs-title{font-size:19px;font-weight:700;color:var(--ue-text-hi)}
uecp-screen-cloudstudio .cs-sub{font-size:12.5px;color:var(--ue-text-mid);margin-bottom:14px}
uecp-screen-cloudstudio .cs-tabs{display:flex;gap:4px;flex-wrap:wrap;margin-bottom:14px;border-bottom:1px solid var(--ue-line-soft);padding-bottom:8px}
uecp-screen-cloudstudio .cs-tab{background:none;border:none;color:var(--ue-text-mid);padding:5px 12px;font-size:12.5px;cursor:pointer;border-radius:var(--ue-r-sm)}
uecp-screen-cloudstudio .cs-tab.active{background:var(--ue-accent-soft);color:var(--ue-accent-bright)}
uecp-screen-cloudstudio .cs-card{border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-md);padding:14px;margin-bottom:12px;background:var(--ue-bg-raise)}
uecp-screen-cloudstudio .cs-field{margin-bottom:10px}
uecp-screen-cloudstudio .cs-label{font-size:11.5px;color:var(--ue-text-mid);margin-bottom:4px}
uecp-screen-cloudstudio .cs-input{width:100%;box-sizing:border-box;background:var(--ue-bg-sink);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm);color:var(--ue-text-hi);padding:7px 9px;font-size:12.5px;font-family:inherit}
uecp-screen-cloudstudio .cs-2col{display:grid;grid-template-columns:1fr 1fr;gap:10px}
uecp-screen-cloudstudio .cs-row{display:flex;gap:8px;align-items:center}
uecp-screen-cloudstudio .cs-btn{background:var(--ue-bg-sink);border:1px solid var(--ue-line-soft);color:var(--ue-text-hi);padding:7px 13px;border-radius:var(--ue-r-sm);font-size:12.5px;cursor:pointer}
uecp-screen-cloudstudio .cs-btn.primary{background:var(--ue-accent);border-color:var(--ue-accent);color:#1a1206;font-weight:600}
uecp-screen-cloudstudio .cs-cost{font-size:12px;color:var(--ue-warn,#e0a54a);margin-top:8px}
uecp-screen-cloudstudio .cs-detail{font-size:11.5px;color:var(--ue-text-mid);margin-top:6px}
uecp-screen-cloudstudio .cs-name{font-size:13px;font-weight:600;color:var(--ue-text-hi)}
uecp-screen-cloudstudio .cs-job{display:flex;justify-content:space-between;gap:10px;padding:6px 0;border-bottom:1px solid var(--ue-line-soft);font-size:12px}
`;
    document.head.appendChild(st);
  }

  const JOBS = [];

  class UecpScreenCloudStudio extends HTMLElement {
    connectedCallback() {
      if (!this._initialised) {
        this._initialised = true;
        this._tab = 'image_from_text';
        this._vendorOp = {};
        this._providers = [];
        this._pick = {};
        this._form = {};
        this._keys = {};
        this._showKey = {};
        this._reqs = {};
        this._catalogPolls = {};
        this._catalogJobs  = {};
        this._loaded = false;
      }
      this._subscribe();
      this._paint();
      KEYED.forEach((id) => window.uecp.call('request_cloud_key', { provider: id }));
      this._call('cloud_providers', {});

      this._catalogPolls[this._call('local_catalog', { refresh: false })] = true;

      (JOBS || []).forEach((j) => {
        if (j && j.state === 'running' && j.id) this._pollJob(j.id);
      });
    }

    disconnectedCallback() {
      (this._subs || []).forEach(function (u) { u(); });
      this._subs = [];
    }

    _subscribe() {
      if (!window.uecp || !window.uecp.on) return;
      this._subs = [
        window.uecp.on('cloud.result', (d) => this._onResult(d)),
        window.uecp.on('cloud.key', (d) => {
          if (!d || !d.provider) return;
          this._keys[d.provider] = d.key || '';
          this._paint();
        }),
        window.uecp.on('cloud.key_saved', (d) => {
          if (d && d.ok) {
            window.UECP.toast(d.key_set ? 'API key saved.' : 'API key cleared.', 'success');
            KEYED.forEach((id) => window.uecp.call('request_cloud_key', { provider: id }));
            this._call('cloud_providers', {});
          } else if (d) {
            window.UECP.toast(d.error || 'Could not save the key.', 'error');
          }
        }),
      ];
    }

    _call(tool, args) {
      const id = 'cs' + Math.random().toString(36).slice(2, 9);
      this._reqs[id] = tool;
      window.uecp.call('cloud_action', { tool: tool, request_id: id, args: args || {} });
      return id;
    }

    _onResult(d) {
      if (!d || !this._reqs[d.request_id]) return;
      const tool = this._reqs[d.request_id];
      const isCatalog = !!this._catalogPolls[d.request_id];
      delete this._catalogPolls[d.request_id];
      delete this._reqs[d.request_id];

      if (!d.ok) { window.UECP.toast(d.error || (tool + ' failed'), 'error'); return; }
      const data = d.data || {};

      if (tool === 'cloud_providers') {
        this._providers = data.providers || [];
        this._loaded = true;
        this._paint();
        return;
      }

      if (tool === 'tripo_get_task_status' || tool === 'get_meshy_task_status') {
        if (data.status === 'completed' || data.status === 'failed') {
          if (isCatalog || (this._catalogJobs || {})[data.job_id]) {
            if (this._catalogJobs) delete this._catalogJobs[data.job_id];
            if (data.status === 'completed') this._call('cloud_providers', {});
            return;
          }
          this._settleJob(data.job_id, data.status, data.result || {});
        }
        return;
      }

      if (data.job_id) {
        if (isCatalog) {
          this._catalogJobs = this._catalogJobs || {};
          this._catalogJobs[data.job_id] = true;
          this._pollJob(data.job_id);
          return;
        }
        JOBS.unshift({ id: data.job_id, tool: tool, state: 'running', label: 'Queued' });
        this._pollJob(data.job_id);
        this._paint();
      } else {
        window.UECP.toast(tool + ' finished.', 'success');
      }
    }

    _pollJob(jobId) {
      const h = setInterval(() => {
        if (!this.isConnected) { clearInterval(h); return; }
        if (!(this._catalogJobs || {})[jobId]) {
          const j = JOBS.find((x) => x.id === jobId);
          if (!j || j.state !== 'running') { clearInterval(h); return; }
        }
        this._call('tripo_get_task_status', { job_id: jobId });
      }, 4000);
      this._call('tripo_get_task_status', { job_id: jobId });
    }

    _settleJob(jobId, status, result) {
      const j = JOBS.find((x) => x.id === jobId);
      if (!j) return;
      j.state = status === 'completed' ? 'done' : 'failed';
      j.label = result.asset_path || result.error || result.message || status;
      if (status === 'completed' && result.asset_path) j.assetPath = result.asset_path;
      this._paint();
    }

    _provider(id) { return (this._providers || []).find((p) => p.id === id); }

    _providersFor(cap) {
      return (this._providers || []).filter((p) =>
        (p.operations || []).some((o) => o.kind === 'generate' && o.id === cap));
    }

    _op(providerId, opId) {
      const p = this._provider(providerId);
      return p ? (p.operations || []).find((o) => o.id === opId) : null;
    }

    _paint() {
      const capTabs = CAP_TABS.map((t) =>
        '<button class="cs-tab' + (this._tab === t.cap ? ' active' : '') + '" data-tab="' + t.cap + '">'
        + esc(t.label) + '</button>').join('');
      const vendorTabs = VENDOR_TABS.map((t) => {
        const key = 'vendor:' + t.provider;
        return '<button class="cs-tab' + (this._tab === key ? ' active' : '') + '" data-tab="' + key + '">'
          + esc(t.label) + '</button>';
      }).join('');

      this.innerHTML =
        '<div class="cs-head"><div>'
        + '<div class="cs-title">Cloud Studio</div>'
        + '<div class="cs-sub">Generation that runs on somebody else&rsquo;s hardware. '
        + 'Costs credits, works without a good GPU.</div>'
        + '</div><button class="cs-btn" id="cs-refresh">Refresh</button></div>'
        + '<div class="cs-tabs">' + capTabs
        + '<span style="width:1px;background:var(--ue-line-soft);margin:0 6px"></span>'
        + vendorTabs + '</div>'
        + '<div id="cs-body"></div>';

      this.querySelectorAll('.cs-tab').forEach((b) => {
        b.addEventListener('click', () => { this._tab = b.dataset.tab; this._paint(); });
      });
      this.querySelector('#cs-refresh').addEventListener('click', () => {
        this._call('cloud_providers', {});
        const id = this._call('local_catalog', { refresh: true });
        this._catalogPolls[id] = true;
        window.UECP.toast('Refreshing providers...', 'info');
      });

      this._paintBody(this.querySelector('#cs-body'));
    }

    _paintBody(host) {
      if (!this._loaded) {
        host.innerHTML = '<div class="cs-card"><div class="cs-sub">Reading providers...</div></div>';
        return;
      }
      if (String(this._tab).indexOf('vendor:') === 0) {
        this._paintVendor(host, String(this._tab).slice(7));
      } else {
        this._paintCapability(host, this._tab);
      }
    }

    _defaultProviderId(providers) {
      const hosted = providers.find((p) => p.requires === 'subscription' && p.key_set);
      if (hosted) return hosted.id;
      const configured = providers.find((p) => p.key_set);
      return (configured || providers[0]).id;
    }

    _paintCapability(host, cap) {
      const providers = this._providersFor(cap);
      if (!providers.length) {
        host.innerHTML = '<div class="cs-card"><div class="cs-name" style="margin-bottom:6px">No provider for this</div>'
          + '<div class="cs-sub">Nothing configured can do this yet.</div></div>';
        return;
      }

      const chosenId = this._pick[cap] || this._defaultProviderId(providers);
      const provider = this._provider(chosenId) || providers[0];
      const op = this._op(provider.id, cap);

      let html = '<div class="cs-card">'
        + '<div class="cs-field"><div class="cs-label">Provider</div><select class="cs-input" id="cs-prov">'
        + providers.map((p) => '<option value="' + esc(p.id) + '"' + (p.id === provider.id ? ' selected' : '') + '>'
            + esc(p.label) + (p.key_set ? '' : this._unavailableLabel(p)) + '</option>').join('')
        + '</select></div>';

      if (!provider.key_set) {
        html += '<div class="cs-cost">' + esc(this._unavailableText(provider)) + '</div>';
      }

      const models = (op && op.models) || [];
      if (models.length) {
        html += '<div class="cs-field"><div class="cs-label">Model</div><select class="cs-input" id="cs-wf">'
          + models.map((m) => '<option value="' + esc(m.id) + '">' + esc(m.label) + '</option>').join('')
          + '</select></div>';
      } else if (op && provider.id === 'comfy_cloud') {
        html += '<div class="cs-cost">ComfyUI lists no cloud model for this. Press Refresh after updating it.</div>';
      }

      const running = JOBS.some((j) => j && j.state === 'running');

      html += this._formHtml(op)
        + '<div class="cs-row"><button class="cs-btn primary" id="cs-go"'
        + (running ? ' disabled style="opacity:.55;cursor:default"' : '') + '>'
        + (running ? 'Working…' : 'Generate') + '</button></div>'
        + '<div class="cs-cost">Each run spends credits with ' + esc(provider.label)
        + '. The amount depends on the model and its settings.</div>'
        + '</div>'
        + this._keyCardHtml(provider);

      html = running ? (this._jobsHtml() + html) : (html + this._jobsHtml());

      host.innerHTML = html;

      host.querySelector('#cs-prov').addEventListener('change', (e) => {
        this._pick[cap] = e.target.value;
        this._paint();
      });
      this._wireForm(host, provider, op);
      this._wireKey(host, provider);
      this._wireViews(host);

      this._restoreForm(host, this._formKey(cap, provider, op));
    }

    _formKey(cap, provider, op) {
      return cap + '|' + (provider ? provider.id : '') + '|' + (op ? op.id : '');
    }

    _restoreForm(host, key) {
      const store = (this._form = this._form || {});
      const saved = (store[key] = store[key] || {});

      const apply = (el, name) => {
        if (!(name in saved)) return;
        if (el.type === 'checkbox') el.checked = !!saved[name];
        else el.value = saved[name];
      };
      const remember = (el, name) => {
        el.addEventListener('input', () => {
          saved[name] = el.type === 'checkbox' ? el.checked : el.value;
        });
        el.addEventListener('change', () => {
          saved[name] = el.type === 'checkbox' ? el.checked : el.value;
        });
      };

      host.querySelectorAll('.cs-param').forEach((el) => {
        const name = el.dataset.param;
        if (!name) return;
        apply(el, name);
        remember(el, name);
      });

      const wf = host.querySelector('#cs-wf');
      if (wf) {
        const opts = wf.options || [];
        if (saved.__wf && Array.prototype.some.call(opts, (o) => o.value === saved.__wf)) {
          wf.value = saved.__wf;
        }
        wf.addEventListener('change', () => { saved.__wf = wf.value; });
      }
    }

    _paintVendor(host, providerId) {
      const provider = this._provider(providerId);
      if (!provider) {
        host.innerHTML = '<div class="cs-card"><div class="cs-sub">Provider not available.</div></div>';
        return;
      }

      const tag = providerId === 'meshy' ? 'uecp-meshy-studio'
                : providerId === 'tripo' ? 'uecp-tripo-studio' : null;
      if (!tag) {
        host.innerHTML = '<div class="cs-card"><div class="cs-sub">'
          + esc(provider.label) + ' has no studio of its own.</div></div>';
        return;
      }

      host.innerHTML = '';
      if (!provider.key_set) {
        const warn = document.createElement('div');
        warn.className = 'cs-card';
        warn.innerHTML = '<div class="cs-cost">' + esc(this._unavailableText(provider)) + '</div>';
        host.appendChild(warn);
      }

      this._studios = this._studios || {};
      if (!this._studios[tag]) this._studios[tag] = document.createElement(tag);
      const studio = this._studios[tag];
      studio.classList.add('active');
      host.appendChild(studio);
      if (typeof studio.onOpened === 'function') studio.onOpened();

      const keyCard = document.createElement('div');
      keyCard.innerHTML = this._keyCardHtml(provider);
      host.appendChild(keyCard);
      this._wireKey(keyCard, provider);
    }

    _formHtml(op) {
      if (!op) return '';
      return (op.params || []).map((p) => {
        const id = 'cs-p-' + p.name;
        const req = p.required ? ' *' : '';
        const val = p.default != null ? esc(p.default) : '';
        let field;
        if (p.type === 'multiline') {
          field = '<textarea class="cs-input cs-param" data-param="' + esc(p.name) + '" id="' + id
                + '" rows="3"></textarea>';
        } else if (p.type === 'enum') {
          const opts = (p.options || []).map((o) => {
            const s = String(o), i = s.indexOf(':');
            return i > 0 ? { label: s.slice(0, i), value: s.slice(i + 1) } : { label: s, value: s };
          });
          field = '<select class="cs-input cs-param" data-param="' + esc(p.name) + '" id="' + id + '">'
                + opts.map((o) => '<option value="' + esc(o.value) + '"'
                    + (o.value === p.default ? ' selected' : '') + '>'
                    + (o.value === '' ? '(default)' : esc(o.label))
                    + '</option>').join('')
                + '</select>';
        } else if (p.type === 'bool') {
          field = '<label style="display:flex;gap:8px;align-items:center;font-size:12.5px;color:var(--ue-text-hi)">'
                + '<input type="checkbox" class="cs-param" data-param="' + esc(p.name) + '" id="' + id + '"'
                + (p.default === 'true' ? ' checked' : '') + '> ' + esc(p.label) + '</label>';
          return '<div class="cs-field">' + field + '</div>';
        } else if (p.name === 'save_path' || p.name === 'savePath') {
          field = '<input class="cs-input cs-param" data-param="' + esc(p.name) + '" id="' + id
                + '" value="/Game/CloudGen/">';
        } else if (p.type === 'number') {
          field = '<input class="cs-input cs-param" type="number" data-param="' + esc(p.name) + '" id="' + id
                + '" value="' + val + '">';
        } else if (p.type === 'image_path') {
          field = '<div class="cs-row"><input class="cs-input cs-param" style="flex:1" data-param="'
                + esc(p.name) + '" id="' + id + '" placeholder="pick a file"><button class="cs-btn" '
                + 'id="cs-browse">Browse...</button></div>';
        } else {
          const ph = p.type === 'task_id' ? 'id of a previous job with this provider'
                   : (p.type === 'asset_path' ? '/Game/...' : '');
          field = '<input class="cs-input cs-param" data-param="' + esc(p.name) + '" id="' + id
                + '" value="' + val + '" placeholder="' + esc(ph) + '">';
        }
        return '<div class="cs-field"><div class="cs-label">' + esc(p.label) + req + '</div>' + field + '</div>';
      }).join('');
    }

    _wireForm(host, provider, op) {
      const browse = host.querySelector('#cs-browse');
      if (browse) browse.addEventListener('click', () => window.uecp.call('local_browse_image', {}));

      const go = host.querySelector('#cs-go');
      if (!go || !op) return;
      go.addEventListener('click', () => {
        if (JOBS.some((j) => j && j.state === 'running')) {
          window.UECP.toast('A job is already running. Wait for it to finish.', 'info');
          return;
        }
        if (!provider.key_set) {
          window.UECP.toast(provider.requires === 'subscription'
            ? 'Hosted generation needs paid tokens: a plan or a token pack.'
            : 'Add an API key for ' + provider.label + ' first.', 'error');
          return;
        }

        const args = {};
        let missing = null;
        (op.params || []).forEach((p) => {
          const el = host.querySelector('#cs-p-' + p.name);
          if (!el) return;
          if (p.type === 'bool') { args[p.name] = !!el.checked; return; }
          const v = String(el.value || '').trim();
          if (!v) { if (p.required && !missing) missing = p.label; return; }
          args[p.name] = (p.type === 'number') ? Number(v) : v;
        });
        if (missing) { window.UECP.toast(missing + ' is required.', 'error'); return; }

        const wf = host.querySelector('#cs-wf');
        if (wf && wf.value) args.workflow = wf.value;
        if (!args.save_path) args.save_path = '/Game/CloudGen/';

        if (op.bridge) window.uecp.call(op.tool, args);
        else this._call(op.tool, args);
      });
    }

    _unavailableText(provider) {
      return provider.requires === 'subscription'
        ? 'Hosted generation needs paid tokens: a plan or a token pack. ' + (provider.key_hint || '')
        : 'No API key for ' + provider.label + '. ' + (provider.key_hint || '');
    }

    _unavailableLabel(provider) {
      return provider.requires === 'subscription' ? '  (paid tokens needed)' : '  (no key)';
    }

    _keyCardHtml(provider) {
      if (provider.requires === 'subscription') return '';
      const shown = !!this._showKey[provider.id];
      const val = this._keys[provider.id] || '';
      return '<div class="cs-card">'
        + '<div class="cs-name" style="margin-bottom:8px">' + esc(provider.label) + ' API key '
        + (provider.key_set ? '<span style="color:var(--ue-ok,#5fbf7f)">&mdash; set</span>'
                            : '<span style="color:var(--ue-warn,#e0a54a)">&mdash; not set</span>') + '</div>'
        + '<div class="cs-row">'
        + '<input class="cs-input" id="cs-key" spellcheck="false" autocorrect="off" autocapitalize="off" type="' + (shown ? 'text' : 'password') + '" '
        + 'style="flex:1" autocomplete="new-password" value="' + esc(val) + '" '
        + 'placeholder="paste the key for ' + esc(provider.label) + '">'
        + '<button class="cs-btn" id="cs-key-show">' + (shown ? 'Hide' : 'Show') + '</button>'
        + '<button class="cs-btn" id="cs-key-save">Save</button></div>'
        + (provider.key_hint ? '<div class="cs-detail">' + esc(provider.key_hint) + '</div>' : '')
        + (provider.id === 'imagegen'
            ? '<div class="cs-detail">Which service this uses, its endpoint and default model are set '
              + 'under Settings &rarr; Image &amp; 3D.</div>'
            : '')
        + '</div>';
    }

    _wireKey(host, provider) {
      if (!provider) return;
      const show = host.querySelector('#cs-key-show');
      if (show) {
        show.addEventListener('click', () => {
          const inp = host.querySelector('#cs-key');
          if (inp) this._keys[provider.id] = inp.value;
          this._showKey[provider.id] = !this._showKey[provider.id];
          this._paint();
        });
      }
      const save = host.querySelector('#cs-key-save');
      if (!save) return;
      save.addEventListener('click', () => {
        const inp = host.querySelector('#cs-key');
        const val = inp ? inp.value.trim() : '';
        this._keys[provider.id] = val;
        window.uecp.call('set_cloud_key', { provider: provider.id, key: val });
      });
    }

    _jobsHtml() {
      if (!JOBS.length) return '';
      const rows = JOBS.slice(0, 8).map((j) => {
        const view = j.assetPath
          ? '<button class="cs-btn" data-view="' + esc(j.assetPath) + '">View</button>'
          : '';
        return '<div class="cs-job"><span>' + esc(opLabel(j.tool)) + '</span>'
          + '<span style="color:var(--ue-text-mid);display:flex;gap:8px;align-items:center">'
          + esc(j.state) + ' &mdash; ' + esc(String(j.label).slice(0, 70))
          + view + '</span></div>';
      }).join('');
      return '<div class="cs-card"><div class="cs-name" style="margin-bottom:8px">Jobs</div>' + rows + '</div>';
    }

    _wireViews(host) {
      (host.querySelectorAll('[data-view]') || []).forEach((b) => {
        b.addEventListener('click', () => {
          window.uecp.call('reveal_asset', { asset_path: b.getAttribute('data-view') });
        });
      });
    }
  }

  UecpScreenCloudStudio.JOBS = JOBS;

  customElements.define('uecp-screen-cloudstudio', UecpScreenCloudStudio);
})();
