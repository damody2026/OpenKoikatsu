(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) { root.UECP = root.UECP || {}; root.UECP.i18nRuntime = api; }
}(typeof self !== 'undefined' ? self : null, function () {

  const SKIP_TAGS = { SCRIPT: 1, STYLE: 1, TEXTAREA: 1, CODE: 1, PRE: 1, SVG: 1, CANVAS: 1 };
  const OWN_ATTRS_TAGS = { TEXTAREA: 1 };
  const SKIP_ATTR = 'data-i18n-skip';
  const ATTRS = ['placeholder', 'title', 'aria-label', 'alt', 'data-tip'];

  function norm(s) { return s.replace(/\s+/g, ' ').trim(); }

  const RE_HAS_LETTER = /[A-Za-z]/;
  const RE_NUMISH = /^[\d\s.,:%+\-/()]+$/;
  const RE_PATHISH = /^(https?:|file:|\/|[A-Za-z]:\\|\/Game\/)/;

  function translatable(s) {
    if (!s || s.length < 2) return false;
    if (!RE_HAS_LETTER.test(s)) return false;
    if (RE_NUMISH.test(s)) return false;
    if (RE_PATHISH.test(s)) return false;
    return true;
  }

  function create(lookup) {
    let active = false;
    let observer = null;

    let applying = false;

    function isSkipRoot(el) {
      if (!el || el.nodeType !== 1) return false;
      if (SKIP_TAGS[el.tagName]) return true;
      return el.hasAttribute && el.hasAttribute(SKIP_ATTR);
    }

    function ownAttrsOnly(el) {
      return !!OWN_ATTRS_TAGS[el.tagName] && !(el.hasAttribute && el.hasAttribute(SKIP_ATTR));
    }

    function srcOf(textNode) {
      return textNode.__i18nSrc !== undefined ? textNode.__i18nSrc : textNode.nodeValue;
    }

    function applyText(textNode) {
      const raw = srcOf(textNode);
      const key = norm(raw);
      if (!translatable(key)) return;
      const val = lookup(key);
      if (val === undefined || val === key) {
        if (textNode.__i18nSrc !== undefined && textNode.nodeValue !== raw) textNode.nodeValue = raw;
        return;
      }
      if (textNode.__i18nSrc === undefined) textNode.__i18nSrc = raw;
      const lead = /^\s*/.exec(raw)[0];
      const trail = /\s*$/.exec(raw)[0];
      textNode.nodeValue = lead + val + trail;
    }

    function applyAttrs(el) {
      if (!el.getAttribute) return;
      for (let i = 0; i < ATTRS.length; i++) {
        const a = ATTRS[i];
        if (!el.hasAttribute(a)) continue;
        const store = el.__i18nAttrSrc || (el.__i18nAttrSrc = {});
        const raw = store[a] !== undefined ? store[a] : el.getAttribute(a);
        const key = norm(raw);
        if (!translatable(key)) continue;
        const val = lookup(key);
        if (val === undefined || val === key) {
          if (store[a] !== undefined && el.getAttribute(a) !== raw) el.setAttribute(a, raw);
          continue;
        }
        if (store[a] === undefined) store[a] = raw;
        el.setAttribute(a, val);
        if (a === 'title' && el.hasAttribute('data-tip')) el.setAttribute('data-tip', val);
      }
    }

    function inSkipSubtree(node) {
      for (let p = node && node.parentNode; p; p = p.parentNode) {
        if (p.nodeType === 1 && isSkipRoot(p)) return true;
      }
      return false;
    }

    function sweep(root) {
      if (!root || typeof document === 'undefined') return;
      if (root.nodeType === 3) { if (!inSkipSubtree(root)) applyText(root); return; }
      if (root.nodeType !== 1) return;
      if (isSkipRoot(root)) {
        if (ownAttrsOnly(root) && !inSkipSubtree(root)) applyAttrs(root);
        return;
      }

      applyAttrs(root);

      const walker = document.createTreeWalker(
        root,
        NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT,
        {
          acceptNode: function (n) {
            if (n.nodeType === 1 && isSkipRoot(n)) {
              if (ownAttrsOnly(n)) applyAttrs(n);
              return NodeFilter.FILTER_REJECT;
            }
            return NodeFilter.FILTER_ACCEPT;
          }
        }
      );
      let n;
      while ((n = walker.nextNode())) {
        if (n.nodeType === 3) applyText(n);
        else applyAttrs(n);
      }
    }

    function onMutations(records) {
      if (applying) return;
      applying = true;
      try {
        for (let i = 0; i < records.length; i++) {
          const added = records[i].addedNodes;
          for (let j = 0; j < added.length; j++) sweep(added[j]);
        }
      } finally {
        applying = false;
      }
    }

    function start() {
      if (active || typeof document === 'undefined' || !window.MutationObserver) return;
      active = true;
      sweep(document.body);
      observer = new MutationObserver(onMutations);
      observer.observe(document.body, { childList: true, subtree: true });
    }

    function stop() {
      if (observer) { observer.disconnect(); observer = null; }
      active = false;
    }

    function refresh() {
      if (typeof document === 'undefined') return;
      applying = true;
      try { sweep(document.body); } finally { applying = false; }
    }

    return { start, stop, refresh, sweep, isActive: function () { return active; } };
  }

  return { create, norm, translatable };
}));
