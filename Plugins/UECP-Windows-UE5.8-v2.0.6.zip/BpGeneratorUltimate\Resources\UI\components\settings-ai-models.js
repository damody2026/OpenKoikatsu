(function () {
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  const PROVIDERS = [
    { value: 'OpenAI',   label: 'OpenAI'   },
    { value: 'Gemini',   label: 'Gemini'   },
    { value: 'Claude',   label: 'Claude'   },
    { value: 'DeepSeek', label: 'DeepSeek' },
    { value: 'Custom',   label: 'Custom (Local)' }
  ];
  const DEFAULT_PROVIDER = PROVIDERS[0].value;
  const API_PROVIDERS = { Gemini: 1, OpenAI: 1, Claude: 1, DeepSeek: 1, Custom: 1 };
  const DEFAULTS_SCOPE = -2;

  function verParts(v) {
    return String(v || '').replace(/^v/i, '').split('.').map(function (x) { const n = parseInt(x, 10); return isNaN(n) ? 0 : n; });
  }
  function verLess(x, y) {
    const a = verParts(x), b = verParts(y);
    for (let i = 0; i < Math.max(a.length, b.length); i++) {
      const da = a[i] || 0, db = b[i] || 0;
      if (da !== db) return da < db;
    }
    return false;
  }
  function updateInfo(a) {
    const inst = (a && a.installedVersion) || '', latest = (a && a.version) || '';
    return { installed: inst, latest: latest, behind: !!(a && a.installed && inst && latest && verLess(inst, latest)) };
  }
  function updateRowHtml(u, btnId) {
    return '<div class="input" style="gap:9px;margin-bottom:13px">'
      + '<span style="font-size:11px;color:var(--ue-text-mid)">Update available: <span class="ue-code" style="font-size:9px">' + esc(u.installed) + '</span> &rarr; <span class="ue-code" style="font-size:9px">' + esc(u.latest) + '</span></span>'
      + '<button class="btn-ghost" id="' + btnId + '" style="margin-left:auto;font-size:11px;padding:5px 10px;background:var(--ue-accent-soft);border-color:var(--ue-accent);color:var(--ue-accent-bright)">Update</button>'
      + '</div>';
  }
  const FREE_TIERS = [
    { value: 'slot1',  label: 'BpLabs Standard' },
  ];

  function modeForProvider(prov) {
    if (window.SettingsFormat && window.SettingsFormat.modeForProvider) return window.SettingsFormat.modeForProvider(prov);
    if (!prov || prov === 'Free') return 'Free';
    if (API_PROVIDERS[prov]) return 'API Key';
    return 'AI Agent';
  }
  function modelKeyForProvider(prov) {
    if (window.SettingsFormat && window.SettingsFormat.modelKeyForProvider) return window.SettingsFormat.modelKeyForProvider(prov);
    if (prov === 'Gemini')   return 'geminiModel';
    if (prov === 'OpenAI')   return 'openAIModel';
    if (prov === 'Claude')   return 'claudeModel';
    if (prov === 'DeepSeek') return 'deepseekModel';
    if (prov === 'Custom')   return 'customModelName';
    return '';
  }
  function modelForProvider(slot, prov, lists, defaults) {
    if (window.SettingsFormat && window.SettingsFormat.modelForProvider) return window.SettingsFormat.modelForProvider(slot, prov, lists, defaults);
    const mk = modelKeyForProvider(prov);
    if (prov === 'Custom') return (slot && slot.customModelName) || '';
    if (slot && mk && slot.provider === prov && slot[mk]) return slot[mk];
    const lower = String(prov || '').toLowerCase();
    return (defaults && defaults[lower]) || ((lists && lists[lower]) || [])[0] || '';
  }

  if (!document.getElementById('settings-ai-models-css')) {
    const s = document.createElement('style'); s.id = 'settings-ai-models-css';
    s.textContent = `
settings-ai-models .sam-body{display:flex;flex:1;min-width:0;min-height:0}
settings-ai-models .sam-slots{width:260px;background:var(--ue-rail);flex-direction:column;overflow-y:auto}
settings-ai-models .sam-agents{width:280px;background:var(--ue-rail);flex-direction:column;overflow-y:auto}
settings-ai-models .sam-pane{flex:1;min-width:0;overflow-y:auto}
settings-ai-models .sam-form{max-width:540px}
settings-ai-models .sam-detail{max-width:520px}`;
    document.head.appendChild(s);
  }

  const SEARCH_ICON = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>';
  const PLUS_ICON   = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="var(--ue-text-lo)" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M5 12h14"/></svg>';
  const CHEV_ICON   = '<span class="chev"><svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg></span>';

  class SettingsAiModels extends HTMLElement {
    connectedCallback() {
      this.style.cssText = 'display:flex;flex-direction:column;flex:1;min-height:0';
      this._subTab    = 'keys';
      this._slots     = [];
      this._activeSlot = 0;
      this._editSlot  = 0;
      this._agents    = [];
      this._activeAgent = null;
      this._agentQuery = '';
      this._rebindTarget = null;
      this._kbHandler = null;
      this._render();
      window.uecp.call('request_acp_catalog', {});
      window.uecp.call('request_cli_status', {});
    }

    disconnectedCallback() {
      if (this._rebindTarget) {
        window.uecp.call('set_rebind_capturing', { capturing: false });
      }
      if (this._kbHandler) {
        document.removeEventListener('keydown', this._kbHandler, true);
      }
    }

    _onSettingsInit(state) {
      if (!state) return;
      const raw = (state.slots) || [];
      this._slots = raw.slice();
      this._activeSlot = state.activeSlotIndex || 0;
      this._editSlot   = this._isPresent(this._slots[this._activeSlot], this._activeSlot) ? this._activeSlot : 0;
      this._freeTierSlot        = state.freeTierSlot || 'slot1';
      this._freeTierSlot2Model  = state.freeTierSlot2Model || '';
      this._freeTierSlot2Models = Array.isArray(state.freeTierSlot2Models) ? state.freeTierSlot2Models : [];
      this._modelLists = state.modelLists || {};
      this._defaultModels = state.defaultModels || {};
      this._render();
    }

    _onAcpCatalog(data) {
      if (Array.isArray(data)) {
        this._agents = data;
      } else if (data && Array.isArray(data.agents)) {
        this._agents = data.agents;
      } else {
        this._agents = [];
      }
      if (this._subTab === 'agents') this._renderAgentPane();
      else                          this._renderKeysPane();
    }

    _onAcpProgress(data) {
      if (!data || !data.agentId) return;
      this._install = this._install || {};
      if (data.done) {
        delete this._install[data.agentId];
        window.uecp.__emit('toast', {
          message: data.success
            ? (this._agentName(data.agentId) + ' installed.')
            : (this._agentName(data.agentId) + ' install failed.'),
          severity: data.success ? 'success' : 'error'
        });
      } else {
        this._install[data.agentId] = {
          stage: data.stage || 'Working',
          fraction: typeof data.fraction === 'number' ? data.fraction : 0
        };
      }
      if (this._subTab === 'agents') this._renderAgentPane();
    }

    _onAcpConfig(data) {
      if (!data || !data.agentId) return;
      this._acpConfigs = this._acpConfigs || {};
      this._acpSlotVals = this._acpSlotVals || {};
      const cfg = data.config || {};
      if (!data.isDefaults && typeof data.slotIndex === 'number') {
        const secVals = {};
        (cfg.sections || []).forEach(function (s) { if (s && s.id) secVals[s.id] = s.slotValue || ''; });
        this._acpSlotVals[data.agentId + '|' + data.slotIndex] = {
          slotModel: data.slotModel || '', slotMode: data.slotMode || '', sections: secVals,
        };
      }
      cfg.defaultModel = data.defaultModel || '';
      cfg.defaultMode  = data.defaultMode  || '';
      this._acpConfigs[data.agentId] = cfg;
      if (this._subTab === 'keys') {
        const es = this._editSlot;
        const esl = (this._slots || [])[es];
        const key = data.agentId + '|' + es;
        this._slotReasked = this._slotReasked || {};
        if (esl && esl.provider === data.agentId && data.slotIndex !== es
            && !this._acpSlotVals[key] && !this._slotReasked[key]) {
          this._slotReasked[key] = true;
          window.uecp.call('request_acp_config', { agentId: data.agentId, slotIndex: es });
        }
      }
      if (this._subTab === 'keys') {
        const sl = (this._slots || [])[this._editSlot];
        const sig = JSON.stringify([cfg, this._acpSlotVals[data.agentId + '|' + this._editSlot] || null]);
        if (sl && sl.provider === data.agentId && this._lastCfgSig !== sig) {
          this._lastCfgSig = sig;
          this._renderKeysPane(this.querySelector('#sam-body'));
        }
      }
      if (this._cfgLoading) this._cfgLoading[data.agentId] = false;
      if (data.agentId === this._activeAgent) {
        this._renderAgentDetail();
      }
    }

    _onCli(data) {
      this._cli = data || {};
      if (this._subTab === 'agents') {
        const strip = this.querySelector('#sam-cli-strip');
        if (strip) strip.outerHTML = this._renderCliStrip();
        else this._renderAgentPane();
      }
    }

    _onInstallResult(data) {
      if (!data) return;
      const btn = this.querySelector('#sam-install-cli-btn');
      if (btn) {
        btn.disabled = false;
        btn.textContent = 'Install CLI';
      }
      window.uecp.__emit('toast', {
        message: data.message || (data.success ? (data.provider || 'CLI') + ' installed successfully!' : (data.provider || 'CLI') + ' install failed.'),
        severity: data.success ? 'success' : 'error'
      });
      window.uecp.call('request_cli_status', {});
    }

    _cliKeyForAgent(name) {
      const n = String(name || '');
      if (/claude/i.test(n))  return 'claude';
      if (/codex/i.test(n))   return 'codex';
      if (/copilot/i.test(n)) return 'copilot';
      if (/gemini/i.test(n))  return 'gemini';
      return null;
    }

    _renderCliStrip() {
      const cli  = this._cli || {};
      const node = cli.node || {};
      const npm  = cli.npm  || {};
      function pill(label, ok, ver) {
        return '<span style="display:inline-flex;align-items:center;gap:5px;font-size:11px;color:var(--ue-text-mid)">'
          + '<span class="dot' + (ok ? ' dot-ok' : '') + '" style="' + (!ok ? 'background:var(--ue-warn)' : '') + '"></span>'
          + esc(label) + (ok && ver ? ' <span class="ue-code" style="font-size:9px">' + esc(ver) + '</span>' : (ok ? '' : ' <span style="color:var(--ue-text-lo)">not found</span>'))
          + '</span>';
      }
      return '<div id="sam-cli-strip" style="display:flex;align-items:center;gap:16px;padding:9px 12px;border-bottom:1px solid var(--ue-line-soft)">'
        + pill('Node', !!node.found, node.ver)
        + pill('npm', !!npm.found, npm.ver)
        + '</div>';
    }

    _isPresent(sl, idx) {
      if (!sl) return false;
      if (idx === 0) return true;
      if (sl.bAdded || sl.added) return true;
      if (sl.provider && sl.provider !== 'Free') return true;
      if (sl.apiKey) return true;
      return false;
    }

    _editIndex() {
      const i = this._editSlot;
      return this._isPresent((this._slots || [])[i], i) ? i : 0;
    }

    _agentName(id) {
      if (window.SettingsFormat && window.SettingsFormat.agentNameForId) {
        return window.SettingsFormat.agentNameForId(id, this._agents || []);
      }
      const a = (this._agents || []).find(function (ag) { return ag.id === id; });
      return (a && a.name) || id;
    }

    _slotSummary(sl) {
      if (window.SettingsFormat && window.SettingsFormat.slotSummary) {
        return window.SettingsFormat.slotSummary(sl, this._agents || []);
      }
      const prov = (sl && sl.provider) || '';
      const mode = modeForProvider(prov);
      if (mode === 'Free') return 'Free';
      if (mode === 'AI Agent') return 'Runs ' + this._agentName(prov);
      const mk = modelKeyForProvider(prov);
      const model = mk ? (sl[mk] || '') : '';
      return model ? (prov + ' · ' + model) : prov;
    }

    _render() {
      const keysActive   = this._subTab === 'keys'   ? ' active' : '';
      const agentsActive = this._subTab === 'agents' ? ' active' : '';

      this.innerHTML =
        '<div class="content-head">'
        + '<span class="crumb"><b>AI Models</b></span>'
        + '<span class="spacer"></span>'
        + '<div class="tabs" id="sam-subtabs">'
        + '<span data-tab="keys"' + (keysActive ? ' class="active"' : '') + '>API Keys</span>'
        + '<span data-tab="agents"' + (agentsActive ? ' class="active"' : '') + '>Agents</span>'
        + '</div>'
        + '</div>'
        + '<div class="sam-body" id="sam-body"></div>';

      const self = this;
      this.querySelectorAll('#sam-subtabs span[data-tab]').forEach(function (seg) {
        seg.addEventListener('click', function () {
          self._subTab = seg.dataset.tab;
          self.querySelectorAll('#sam-subtabs span[data-tab]').forEach(function (s) { s.classList.remove('active'); });
          seg.classList.add('active');
          self._renderBody();
        });
      });
      this._renderBody();
    }

    _renderBody() {
      const body = this.querySelector('#sam-body');
      if (!body) return;
      if (this._subTab === 'keys') this._renderKeysPane(body);
      else                         this._renderAgentPane(body);
    }

    _buildSlotsListHtml() {
      const self   = this;
      const slots  = this._slots;
      const active = this._activeSlot;
      const edit   = this._editIndex();

      let listHtml = '';
      let shown = 0;
      slots.forEach(function (sl, idx) {
        if (!self._isPresent(sl, idx)) return;
        shown++;
        const isActive = idx === active;
        const isEdit   = idx === edit;
        const kb       = sl.keybind || '';
        const summary  = self._slotSummary(sl);
        listHtml += '<div class="chat-item' + (isEdit ? ' active' : '') + '" data-idx="' + idx + '" style="display:flex;align-items:center;gap:8px">'
          + '<div class="dot' + (isActive ? ' dot-ok' : '') + '" style="flex-shrink:0"></div>'
          + '<div style="flex:1;min-width:0">'
          + '<div class="chat-item-title" style="margin:0">' + esc(sl.name || ('Slot ' + (idx + 1))) + '</div>'
          + '<div class="chat-item-meta" style="margin-top:2px">' + esc(summary) + '</div>'
          + '</div>'
          + (kb ? '<span class="ue-code" style="font-size:9px">' + esc(kb) + '</span>' : '')
          + (idx > 0 ? '<button class="icon-btn" data-remove="' + idx + '" title="Remove slot" style="width:22px;height:22px;border:none;color:var(--ue-text-lo);background:transparent;cursor:pointer;flex-shrink:0">&#x2715;</button>' : '')
          + '</div>';
      });
      if (shown < 9) {
        listHtml += '<div id="sam-add-slot" class="row-hover" style="display:flex;align-items:center;gap:8px;padding:10px 12px;cursor:pointer;font-size:var(--ue-fs-xs);color:var(--ue-text-lo);border-top:1px solid var(--ue-line-soft);margin-top:auto">'
          + PLUS_ICON + 'Add slot</div>';
      }
      return listHtml;
    }

    _bindSlotsListEvents(body) {
      const self = this;
      body.querySelectorAll('.chat-item[data-idx]').forEach(function (row) {
        row.addEventListener('click', function (e) {
          if (e.target.closest('[data-remove]')) return;
          const idx = parseInt(row.dataset.idx, 10);
          self._editSlot   = idx;
          self._activeSlot = idx;
          window.uecp.call('set_active_slot', { index: idx });
          self._renderKeysPane();
        });
      });
      body.querySelectorAll('[data-remove]').forEach(function (btn) {
        btn.addEventListener('click', function (e) {
          e.stopPropagation();
          const idx = parseInt(btn.dataset.remove, 10);
          window.UECP.dialog.confirm('Remove slot', 'Remove slot ' + (idx + 1) + '?').then(function (ok) {
            if (!ok) return;
            window.uecp.call('remove_slot', { index: idx });
            if (self._editSlot === idx) self._editSlot = 0;
          });
        });
      });
      const addBtn = body.querySelector('#sam-add-slot');
      if (addBtn) {
        addBtn.addEventListener('click', function () {
          window.uecp.call('add_slot', {});
        });
      }
    }

    _refreshSlotsList(body) {
      body = body || this.querySelector('#sam-body');
      if (!body) return;
      const list = body.querySelector('#sam-slots-list .list');
      if (!list) { this._renderKeysPane(body); return; }
      list.innerHTML = this._buildSlotsListHtml();
      this._bindSlotsListEvents(body);
      const header = body.querySelector('#sam-slot-header');
      const edit   = this._editIndex();
      const sl     = this._slots[edit] || {};
      if (header) header.textContent = 'Slot ' + (edit + 1) + (sl.name ? ' — ' + sl.name : '');
    }

    _renderKeysPane(body) {
      if (this._lastCfgSlot !== this._editSlot) {
        this._lastCfgSlot = this._editSlot;
        this._lastCfgReq = null;
      }
      body = body || this.querySelector('#sam-body');
      if (!body) return;

      const self   = this;
      const slots  = this._slots;
      const active = this._activeSlot;
      const edit   = this._editIndex();
      const listHtml = this._buildSlotsListHtml();

      const sl       = slots[edit] || {};
      const mode     = modeForProvider(sl.provider);
      const provider = (sl.provider && API_PROVIDERS[sl.provider]) ? sl.provider : DEFAULT_PROVIDER;
      const model    = modelForProvider(sl, provider, this._modelLists, this._defaultModels);
      const apiKey   = sl.apiKey   || '';
      let freeTier = sl.freeTierBackend || this._freeTierSlot || 'slot1';
      if (freeTier === 'slot2') freeTier = 'slot1';
      const slotKb   = sl.keybind  || '';

      const isCapturing = this._rebindTarget === 'slot';

      const editorHtml = '<div class="sam-form">'
        + '<div class="card" style="margin-bottom:16px">'
        + '<div class="section-label" id="sam-slot-header" style="margin:0 0 13px">Slot ' + (edit + 1) + (sl.name ? ' — ' + esc(sl.name) : '') + '</div>'
        + '<div style="margin-bottom:13px"><div class="field-label">Name</div>'
        + '<div class="input mono"><input id="sam-slot-name" type="text" value="' + esc(sl.name || '') + '" placeholder="e.g. My API Key" style="flex:1;border:none;background:transparent;font-family:var(--ue-font-mono);font-size:12.5px;color:var(--ue-text-hi);outline:none"></div>'
        + '</div>'
        + '<div style="margin-bottom:13px"><div class="field-label">Connection Mode</div>'
        + '<div class="seg-wide" id="sam-mode-segs">'
        + ['Free','AI Agent','API Key'].map(function (m) { return '<span data-mode="' + m + '"' + (m === mode ? ' class="active"' : '') + '>' + m + '</span>'; }).join('')
        + '</div></div>'
        + '<div><div class="field-label">Keybind (slot switch)</div>'
        + '<div style="display:flex;align-items:center;gap:8px">'
        + '<div class="input mono" id="sam-kb-chip" style="min-width:90px;justify-content:center;' + (isCapturing ? 'border-color:var(--ue-accent);color:var(--ue-text-lo)' : '') + '">' + esc(isCapturing ? 'Press a key…' : (slotKb || 'None')) + '</div>'
        + '<button class="btn-ghost" id="sam-rebind-slot">Rebind</button>'
        + (slotKb ? '<button class="btn-ghost" id="sam-clear-kb" style="color:var(--ue-danger);border-color:rgba(207,107,90,.3)">Clear</button>' : '')
        + '</div></div>'
        + '</div>'

        + this._renderModeFields(mode, sl, provider, model, apiKey, freeTier)

        + window.UECP.saveBar.html(this, 'sam-save-slot', {
            label: 'Save Slot',
            extra: (mode === 'API Key' ? '<button class="btn-ghost" id="sam-test-connection">Test Connection</button>' : '')
                 + '<span id="sam-test-msg" style="font-size:11.5px;opacity:0;transition:opacity .15s"></span>',
          })
        + '</div>';

      body.innerHTML =
        '<div class="sidebar sam-slots" id="sam-slots-list">'
        + '<div class="list">' + listHtml + '</div>'
        + '</div>'
        + '<div class="page sam-pane" id="sam-editor">' + editorHtml + '</div>';

      this._bindSlotsListEvents(body);

      body.querySelectorAll('span[data-mode]').forEach(function (seg) {
        seg.addEventListener('click', function () {
          body.querySelectorAll('span[data-mode]').forEach(function (s) { s.classList.remove('active'); });
          seg.classList.add('active');
          const newMode = seg.dataset.mode;
          const mf = body.querySelector('#sam-mode-fields');
          if (mf) mf.outerHTML = self._renderModeFields(newMode, sl, provider, model, apiKey, freeTier);
          self._bindModeFields(body);
        });
      });

      body.querySelector('#sam-rebind-slot').addEventListener('click', function () {
        self._startSlotRebind(edit, body);
      });
      const clearKb = body.querySelector('#sam-clear-kb');
      if (clearKb) {
        clearKb.addEventListener('click', function () {
          window.uecp.call('set_slot_keybind', { index: edit, keybind: '' });
        });
      }

      this._bindModeFields(body);

      body.querySelector('#sam-save-slot').addEventListener('click', function () { self._saveSlot(edit, body); });
      const testBtn = body.querySelector('#sam-test-connection');
      if (testBtn) testBtn.addEventListener('click', function () { self._testConnection(edit, body); });
    }

    _renderModeFields(mode, sl, provider, model, apiKey, freeTier) {
      let html = '<div id="sam-mode-fields">';
      if (mode === 'Free') {
        const s2models = this._freeTierSlot2Models || [];
        const s2sel    = sl.freeTierModel || this._freeTierSlot2Model || '';
        html += '<div class="card" style="margin-top:16px">'
          + '<div class="section-label" style="margin:0 0 13px">Free Tier</div>'
          + '<div style="margin-bottom:13px"><div class="field-label">Backend</div>'
          + '<div class="input" style="padding:0 12px"><select id="sam-free-tier" style="flex:1;border:none;background:transparent;font-size:13px;color:var(--ue-text-hi);outline:none;appearance:none;cursor:pointer">'
          + FREE_TIERS.map(function (ft) { return '<option value="' + esc(ft.value) + '"' + (ft.value === freeTier ? ' selected' : '') + '>' + esc(ft.label) + '</option>'; }).join('')
          + '</select>' + CHEV_ICON + '</div></div>'
          + ((freeTier === 'slot2' && s2models.length)
              ? '<div id="sam-ft-model-row" style="margin-bottom:13px"><div class="field-label">Model</div>'
                + '<div class="input" style="padding:0 12px"><select id="sam-free-tier-model" style="flex:1;border:none;background:transparent;font-size:13px;color:var(--ue-text-hi);outline:none;appearance:none;cursor:pointer">'
                + s2models.map(function (m) { return '<option value="' + esc(m.id) + '"' + (m.id === s2sel ? ' selected' : '') + '>' + esc(m.display || m.id) + '</option>'; }).join('')
                + '</select>' + CHEV_ICON + '</div></div>'
              : '')
          + '<div style="font-size:11.5px;color:var(--ue-text-lo);margin-top:4px">No API key required. Shared resource — may be rate-limited at peak times.</div>'
          + '</div>';
      } else if (mode === 'AI Agent') {
        const boundId   = (sl.provider && sl.provider !== 'Free' && !API_PROVIDERS[sl.provider]) ? sl.provider : '';
        const installed = (this._agents || []).filter(function (a) { return a.installed; });
        html += '<div class="card" style="margin-top:16px">'
          + '<div class="section-label" style="margin:0 0 13px">AI Agent</div>';
        if (installed.length) {
          html += '<div style="margin-bottom:13px"><div class="field-label">Agent</div>'
            + '<div class="input" style="padding:0 12px"><select id="sam-agent-pick" style="flex:1;border:none;background:transparent;font-size:13px;color:var(--ue-text-hi);outline:none;appearance:none;cursor:pointer">'
            + (boundId && !installed.some(function (a) { return a.id === boundId; })
                ? '<option value="' + esc(boundId) + '" selected>' + esc(this._agentName(boundId)) + ' (not installed)</option>'
                : '')
            + installed.map(function (a) { return '<option value="' + esc(a.id) + '"' + (a.id === boundId ? ' selected' : '') + '>' + esc(a.name || a.id) + '</option>'; }).join('')
            + '</select>' + CHEV_ICON + '</div></div>'
            + '<div style="font-size:11.5px;color:var(--ue-text-lo);line-height:1.5' + (boundId ? ';margin-bottom:13px' : '') + '">Pick the agent this slot runs, then <strong>Save Slot</strong>. '
            + (boundId
                ? 'The dials below override the defaults from the <strong>Agents</strong> tab &mdash; leave one on <em>Default</em> to follow it.'
                : 'Its defaults live in the <strong>Agents</strong> tab.')
            + '</div>';
          const boundAgent = boundId && installed.find(function (a) { return a.id === boundId; });
          const upd = updateInfo(boundAgent);
          if (upd.behind) html += updateRowHtml(upd, 'sam-slot-update-btn');
        } else {
          html += '<div style="font-size:var(--ue-fs-sm);color:var(--ue-text-mid);line-height:1.5">No agents installed yet. Open the <strong>Agents</strong> tab and install one, then return here to bind it to this slot.</div>';
        }
        if (boundId) {
          const scfg = (this._acpConfigs && this._acpConfigs[boundId]) || {};
          const sv = (this._acpSlotVals && this._acpSlotVals[boundId + '|' + this._editSlot]) || {};
          const svSections = sv.sections || {};
          const nameOf = function (list, wanted) {
            const hit = (list || []).find(function (o) { return o.id === wanted; });
            return hit ? (hit.name || hit.id) : (wanted || 'agent default');
          };
          const overrideSelect = function (domId, label, list, slotVal, defVal) {
            if (!Array.isArray(list) || !list.length) return '';
            const unlisted = slotVal && !list.some(function (m) { return m.id === slotVal; });
            return '<div style="margin-bottom:13px"><div class="field-label">' + esc(label) + '</div>'
              + '<div class="input mono" style="padding:0 12px"><select id="' + domId + '" style="flex:1;border:none;background:transparent;font-family:var(--ue-font-mono);font-size:12.5px;color:var(--ue-text-hi);outline:none;appearance:none;cursor:pointer">'
              + '<option value=""' + (!slotVal ? ' selected' : '') + '>Default (' + esc(nameOf(list, defVal)) + ')</option>'
              + (unlisted ? '<option value="' + esc(slotVal) + '" selected>' + esc(slotVal) + '</option>' : '')
              + list.map(function (m) { return '<option value="' + esc(m.id) + '"' + (m.id === slotVal ? ' selected' : '') + '>' + esc(m.name || m.id) + '</option>'; }).join('')
              + '</select>' + CHEV_ICON + '</div></div>';
          };
          html += overrideSelect('sam-slot-model', 'Model', scfg.models, sv.slotModel, scfg.defaultModel);
          html += overrideSelect('sam-slot-mode',  'Mode',  scfg.modes,  sv.slotMode,  scfg.defaultMode);
          if (Array.isArray(scfg.sections)) {
            scfg.sections.forEach(function (sec) {
              if (!sec || !Array.isArray(sec.options) || !sec.options.length) return;
              html += overrideSelect('sam-slot-sec-' + esc(sec.id), sec.name || sec.id,
                sec.options, svSections[sec.id] || '', sec.defaultValue);
            });
          }
        }
        html += '</div>';
      } else {
        const lowerProv   = String(provider || '').toLowerCase();
        const knownModels = (this._modelLists && this._modelLists[lowerProv]) || [];
        const modelInList = knownModels.indexOf(model) !== -1;
        const useDropdown = provider !== 'Custom' && knownModels.length > 0;
        const showCustomModelInput = !useDropdown || !modelInList;
        html += '<div class="card" style="margin-top:16px">'
          + '<div class="section-label" style="margin:0 0 13px">API Key Connection</div>'
          + '<div style="margin-bottom:13px"><div class="field-label">Provider</div>'
          + '<div class="input" style="padding:0 12px"><select id="sam-provider" style="flex:1;border:none;background:transparent;font-size:13px;color:var(--ue-text-hi);outline:none;appearance:none;cursor:pointer">'
          + PROVIDERS.map(function (p) { return '<option value="' + esc(p.value) + '"' + (p.value === provider ? ' selected' : '') + '>' + esc(p.label) + '</option>'; }).join('')
          + '</select>' + CHEV_ICON + '</div></div>'
          + (provider === 'Custom' ? '<div style="margin-bottom:13px"><div class="field-label">Endpoint URL</div>'
            + '<div class="input mono"><input id="sam-endpoint" spellcheck="false" autocorrect="off" autocapitalize="off" type="text" value="' + esc(sl.customBaseURL || '') + '" placeholder="http://localhost:11434/v1" style="flex:1;border:none;background:transparent;font-family:var(--ue-font-mono);font-size:12.5px;color:var(--ue-text-hi);outline:none"></div></div>'
            + '<div style="margin-bottom:13px"><div class="field-label">Auth Header</div>'
            + '<div class="input" style="padding:0 12px"><select id="sam-auth-header-style" style="flex:1;border:none;background:transparent;font-size:13px;color:var(--ue-text-hi);outline:none;appearance:none;cursor:pointer">'
            + '<option value=""' + ((sl.authHeaderStyle || '') === '' ? ' selected' : '') + '>Authorization: Bearer &lt;key&gt; (default)</option>'
            + '<option value="api-key"' + (sl.authHeaderStyle === 'api-key' ? ' selected' : '') + '>api-key: &lt;key&gt; (Azure OpenAI)</option>'
            + '</select>' + CHEV_ICON + '</div>'
            + '<div style="font-size:11.5px;color:var(--ue-text-lo);margin-top:4px">Azure OpenAI needs the deployment URL + ?api-version= pasted into Endpoint URL above, plus this header style.</div>'
            + '</div>'
            + '<div style="margin-bottom:13px"><div class="field-label">Custom Request Params (JSON)</div>'
            + '<div class="input mono" style="align-items:flex-start"><textarea id="sam-custom-params" spellcheck="false" autocorrect="off" autocapitalize="off" rows="3" placeholder="{&quot;stream&quot;: true}" style="flex:1;border:none;background:transparent;resize:vertical;font-family:var(--ue-font-mono);font-size:12.5px;color:var(--ue-text-hi);outline:none">' + esc(sl.customParams || '') + '</textarea></div>'
            + '<div style="font-size:11.5px;color:var(--ue-text-lo);margin-top:4px">Merged into the request body sent to your custom endpoint — e.g. extra sampling params, or {"stream": true} to force streaming.</div>'
            + '</div>'
            + '<div style="margin-bottom:13px"><div class="field-label">Context Window Override (tokens)</div>'
            + '<div class="input mono"><input id="sam-ctx-override" type="number" min="0" step="1000" value="' + (sl.contextWindowOverrideTokens || '') + '" placeholder="e.g. 1000000" style="flex:1;border:none;background:transparent;font-family:var(--ue-font-mono);font-size:12.5px;color:var(--ue-text-hi);outline:none"></div>'
            + '<div style="font-size:11.5px;color:var(--ue-text-lo);margin-top:4px">Checked after the curated Claude/OpenAI/Gemini/DeepSeek table and the models.dev registry (which also covers GLM, Qwen, Llama, Mistral, Kimi, Grok, and more) — only needed for a model neither of those recognise, e.g. a fine-tune or a brand-new release. Leave at 0 unless the ring is still guessing wrong.</div>'
            + '</div>' : '')
          + '<div style="margin-bottom:13px"><div class="field-label">Model</div>'
          + (useDropdown
              ? ('<div class="input" style="padding:0 12px"><select id="sam-model-select" style="flex:1;border:none;background:transparent;font-size:13px;color:var(--ue-text-hi);outline:none;appearance:none;cursor:pointer">'
                  + knownModels.map(function (m) { return '<option value="' + esc(m) + '"' + (m === model ? ' selected' : '') + '>' + esc(m) + '</option>'; }).join('')
                  + '<option value="__custom__"' + (!modelInList ? ' selected' : '') + '>Custom…</option>'
                  + '</select>' + CHEV_ICON + '</div>'
                  + (showCustomModelInput ? '<div class="input mono" style="margin-top:8px"><input id="sam-model" spellcheck="false" autocorrect="off" autocapitalize="off" type="text" value="' + esc(model) + '" placeholder="custom model id" style="flex:1;border:none;background:transparent;font-family:var(--ue-font-mono);font-size:12.5px;color:var(--ue-text-hi);outline:none"></div>' : ''))
              : '<div class="input mono"><input id="sam-model" spellcheck="false" autocorrect="off" autocapitalize="off" type="text" value="' + esc(model) + '" placeholder="e.g. gemini-2.0-flash" style="flex:1;border:none;background:transparent;font-family:var(--ue-font-mono);font-size:12.5px;color:var(--ue-text-hi);outline:none"></div>')
          + '</div>'
          + '<div style="margin-bottom:13px"><div class="field-label">API Key</div>'
          + '<div class="input mono"><input id="sam-api-key" type="password" value="' + esc(apiKey) + '" placeholder="sk-…" autocomplete="new-password" style="flex:1;border:none;background:transparent;font-family:var(--ue-font-mono);font-size:12.5px;color:var(--ue-text-hi);outline:none">'
          + '<span id="sam-show-key" class="link-hover" style="font-size:11px;color:var(--ue-text-mid);cursor:pointer;flex-shrink:0;margin-left:8px">Show</span></div></div>'
          + '</div>';
      }
      html += '</div>';
      return html;
    }

    _bindModeFields(body) {

      const self2 = this;
      const editIdx = this._editSlot;

      const pick = body.querySelector('#sam-agent-pick');
      if (pick) {
        pick.addEventListener('change', function () {
          if (!pick.value) return;
          self2._lastCfgReq = pick.value + '|' + editIdx;
          window.uecp.call('request_acp_config', { agentId: pick.value, slotIndex: editIdx });
        });
        const reqKey = pick.value + '|' + editIdx;
        if (pick.value && self2._lastCfgReq !== reqKey) {
          self2._lastCfgReq = reqKey;
          window.uecp.call('request_acp_config', { agentId: pick.value, slotIndex: editIdx });
        }
      }

      const slotVals = function () {
        self2._acpSlotVals = self2._acpSlotVals || {};
        const k = pick.value + '|' + editIdx;
        return (self2._acpSlotVals[k] = self2._acpSlotVals[k] || { slotModel: '', slotMode: '', sections: {} });
      };
      const cacheSlotValue = function (field, value) {
        if (!pick || !pick.value) return;
        slotVals()[field] = value;
      };

      const slotUpdate = body.querySelector('#sam-slot-update-btn');
      if (slotUpdate) slotUpdate.addEventListener('click', function () {
        if (!pick || !pick.value) return;
        slotUpdate.textContent = 'Updating…';
        slotUpdate.disabled = true;
        window.uecp.call('install_acp_agent', { agentId: pick.value });
      });

      const slotModel = body.querySelector('#sam-slot-model');
      if (slotModel) slotModel.addEventListener('change', function () {
        if (!pick || !pick.value) return;
        cacheSlotValue('slotModel', slotModel.value);
        window.uecp.call('set_acp_agent_config',
          { agentId: pick.value, key: 'model', value: slotModel.value, slotIndex: editIdx });
      });
      const slotMode = body.querySelector('#sam-slot-mode');
      if (slotMode) slotMode.addEventListener('change', function () {
        if (!pick || !pick.value) return;
        cacheSlotValue('slotMode', slotMode.value);
        window.uecp.call('set_acp_agent_config',
          { agentId: pick.value, key: 'mode', value: slotMode.value, slotIndex: editIdx });
      });
      body.querySelectorAll('[id^="sam-slot-sec-"]').forEach(function (sel) {
        sel.addEventListener('change', function () {
          if (!pick || !pick.value) return;
          const secId = sel.id.replace('sam-slot-sec-', '');
          slotVals().sections[secId] = sel.value;
          window.uecp.call('set_acp_agent_config',
            { agentId: pick.value, key: secId, value: sel.value, slotIndex: editIdx });
        });
      });
      const self = this;
      const showKey = body.querySelector('#sam-show-key');
      if (showKey) {
        showKey.addEventListener('click', function () {
          const inp = body.querySelector('#sam-api-key');
          if (!inp) return;
          inp.type = inp.type === 'password' ? 'text' : 'password';
          showKey.textContent = inp.type === 'password' ? 'Show' : 'Hide';
        });
      }
      function clearTestResult() {
        const msg = body.querySelector('#sam-test-msg');
        if (msg) { msg.textContent = ''; msg.style.opacity = 0; }
      }
      const providerSel = body.querySelector('#sam-provider');
      if (providerSel) {
        providerSel.addEventListener('change', function () {
          const mf = body.querySelector('#sam-mode-fields');
          if (!mf) return;
          clearTestResult();
          const keyInp = body.querySelector('#sam-api-key');
          const cur = self._slots[self._editIndex()] || {};
          mf.outerHTML = self._renderModeFields(
            'API Key', cur, providerSel.value,
            modelForProvider(cur, providerSel.value, self._modelLists, self._defaultModels),
            keyInp ? keyInp.value : '', cur.freeTier);
          self._bindModeFields(body);
        });
      }
      const modelSel = body.querySelector('#sam-model-select');
      if (modelSel) {
        modelSel.addEventListener('change', function () {
          const mf = body.querySelector('#sam-mode-fields');
          if (!mf) return;
          clearTestResult();
          const keyInp = body.querySelector('#sam-api-key');
          const cur = self._slots[self._editIndex()] || {};
          mf.outerHTML = self._renderModeFields(
            'API Key', cur, providerSel ? providerSel.value : cur.provider,
            modelSel.value === '__custom__' ? '' : modelSel.value,
            keyInp ? keyInp.value : '', cur.freeTier);
          self._bindModeFields(body);
          if (modelSel.value === '__custom__') {
            const ci = body.querySelector('#sam-model');
            if (ci) ci.focus();
          }
        });
      }
      const ftSel = body.querySelector('#sam-free-tier');
      if (ftSel) {
        ftSel.addEventListener('change', function () {
          const mf  = body.querySelector('#sam-mode-fields');
          const cur = self._slots[self._editIndex()] || {};
          if (mf) {
            mf.outerHTML = self._renderModeFields('Free', cur, cur.provider || DEFAULT_PROVIDER, '', '', ftSel.value);
            self._bindModeFields(body);
          }
        });
      }
    }

    _startSlotRebind(idx, body) {
      const chip = body.querySelector('#sam-kb-chip');
      if (!chip) return;
      chip.style.borderColor = 'var(--ue-accent)';
      chip.style.color = 'var(--ue-text-lo)';
      chip.textContent = 'Press a key…';
      this._rebindTarget = 'slot';
      window.uecp.call('set_rebind_capturing', { capturing: true });

      const self = this;
      if (this._kbHandler) document.removeEventListener('keydown', this._kbHandler, true);
      this._kbHandler = function (e) {
        e.preventDefault(); e.stopPropagation();
        const step = window.SettingsFormat.rebindCaptureStep(e);
        if (step.status === 'cancel') {
          chip.style.borderColor = '';
          chip.style.color = '';
          chip.textContent = self._slots[idx] && self._slots[idx].keybind ? self._slots[idx].keybind : 'None';
          window.uecp.call('set_rebind_capturing', { capturing: false });
          document.removeEventListener('keydown', self._kbHandler, true);
          self._kbHandler = null;
          self._rebindTarget = null;
          return;
        }
        if (step.status === 'progress') { chip.textContent = step.display; return; }
        const kb = (step.modifier ? step.modifier + '+' : '') + step.key;
        chip.style.borderColor = '';
        chip.style.color = '';
        chip.textContent = kb;
        window.uecp.call('set_rebind_capturing', { capturing: false });
        window.uecp.call('set_slot_keybind', { index: idx, keybind: kb });
        document.removeEventListener('keydown', self._kbHandler, true);
        self._kbHandler = null;
        self._rebindTarget = null;
      };
      document.addEventListener('keydown', this._kbHandler, true);
    }

    _gatherSlotFields(idx, body) {
      const modeEl = body.querySelector('span[data-mode].active');
      const mode   = modeEl ? modeEl.dataset.mode : 'Free';
      const name   = (body.querySelector('#sam-slot-name') || {}).value || '';
      const kept = (this._slots || [])[idx] || {};
      const keep = function (sel, stored, empty) {
        const el = body.querySelector(sel);
        return el ? el.value : (stored === undefined ? empty : stored);
      };
      return {
        index:           idx,
        name:            name,
        mode:            mode,
        provider:        (body.querySelector('#sam-provider')        || {}).value || DEFAULT_PROVIDER,
        agentId:         (body.querySelector('#sam-agent-pick')      || {}).value || '',
        model:           (body.querySelector('#sam-model')           || {}).value
                           || ((body.querySelector('#sam-model-select') || {}).value === '__custom__' ? '' : (body.querySelector('#sam-model-select') || {}).value)
                           || '',
        apiKey:          (body.querySelector('#sam-api-key')         || {}).value || '',
        endpoint:        keep('#sam-endpoint',          kept.customBaseURL,    ''),
        customParams:    keep('#sam-custom-params',     kept.customParams,     ''),
        authHeaderStyle: keep('#sam-auth-header-style', kept.authHeaderStyle,  ''),
        contextWindowOverrideTokens:
          parseInt(keep('#sam-ctx-override', kept.contextWindowOverrideTokens, 0), 10) || 0,
        freeTierBackend: (body.querySelector('#sam-free-tier')       || {}).value || 'slot1',
        freeTierModel:   (body.querySelector('#sam-free-tier-model') || {}).value || '',
      };
    }

    _testConnection(idx, body) {
      const fields = this._gatherSlotFields(idx, body);
      const built  = (window.SettingsFormat && window.SettingsFormat.buildSaveSlotPayload)
        ? window.SettingsFormat.buildSaveSlotPayload(fields)
        : { payload: { index: idx, provider: fields.provider } };
      const payload = Object.assign({}, built.payload, {
        model: fields.model,
      });
      const msg = body.querySelector('#sam-test-msg');
      if (msg) { msg.style.color = 'var(--ue-text-lo)'; msg.textContent = 'Testing…'; msg.style.opacity = 1; }
      window.uecp.call('test_slot_connection', payload);
    }

    _onTestSlotConnectionResult(data) {
      const msg = this.querySelector('#sam-test-msg');
      if (!msg) return;
      const ok = !!(data && data.ok);
      msg.style.color = ok ? 'var(--ue-accent-bright)' : 'var(--ue-danger, #e06060)';
      msg.textContent = (data && data.message) || (ok ? 'Connected.' : 'Failed.');
      msg.style.opacity = 1;
    }

    _saveSlot(idx, body) {
      const fields = this._gatherSlotFields(idx, body);
      const mode   = fields.mode;
      const built   = (window.SettingsFormat && window.SettingsFormat.buildSaveSlotPayload)
        ? window.SettingsFormat.buildSaveSlotPayload(fields)
        : { payload: { index: idx, name: fields.name }, freeTierSlotArg: null };
      const payload = built.payload;

      if (built.freeTierSlotArg != null) {
        window.uecp.call('save_free_tier_slot', { slotIndex: idx, slot: built.freeTierSlotArg });
      }
      window.uecp.call('save_slot', payload);

      if (mode === 'AI Agent' && payload.provider) {
        const bound = (this._agents || []).find(function (a) { return a.id === payload.provider; });
        const bs = bound && (bound.authState || (bound.authRequired ? 'required' : 'unknown'));
        if (bs === 'required') {
          window.uecp.__emit('toast', {
            message: (bound.name || payload.provider) + ' needs signing in before it can run. Open the Agents tab to sign in.',
            severity: 'error'
          });
        } else if (bs === 'unknown') {
          window.uecp.__emit('toast', {
            message: (bound.name || payload.provider) + " hasn't been checked yet — use Check now in the Agents tab to confirm it can sign in.",
            severity: 'warn'
          });
        }
      }

      const merge = Object.assign({}, payload);
      delete merge.index;
      if (mode === 'Free') {
        merge.freeTierBackend = fields.freeTierBackend;
        if (fields.freeTierBackend === 'slot2' && fields.freeTierModel) merge.freeTierModel = fields.freeTierModel;
      }

      window.uecp.call('set_active_slot', { index: idx });
      this._activeSlot = idx;

      this._slots[idx] = Object.assign({}, this._slots[idx] || {}, merge);

      this._refreshSlotsList(body);
      window.UECP.saveBar.flash(this);
    }

    _renderAgentPane(body) {
      body = body || this.querySelector('#sam-body');
      if (!body) return;

      const self = this;

      const searchHtml = '<div style="padding:12px;flex:0 0 auto;display:flex;gap:8px;align-items:center">'
        + '<div class="input mono" style="font-size:12.5px;gap:8px;flex:1;min-width:0">'
        + SEARCH_ICON
        + '<input id="sam-agent-q" type="text" placeholder="Search agents…" value="' + esc(this._agentQuery) + '" style="flex:1;min-width:0;border:none;background:transparent;font-family:var(--ue-font-mono);font-size:12.5px;color:var(--ue-text-hi);outline:none">'
        + '</div>'
        + '<button class="btn-ghost" id="sam-agent-refresh" style="font-size:11px;padding:5px 10px;flex-shrink:0">Refresh</button>'
        + '</div>';

      body.innerHTML =
        '<div class="sidebar sam-agents">'
        + this._renderCliStrip()
        + searchHtml
        + '<div id="sam-agent-list" style="display:contents">' + this._agentListHtml() + '</div>'
        + '</div>'
        + '<div class="page sam-pane" id="sam-detail-pane">' + this._renderAgentDetailHtml() + '</div>';

      body.querySelector('#sam-agent-q').addEventListener('input', function (e) {
        self._agentQuery = e.target.value;
        const host = body.querySelector('#sam-agent-list');
        if (!host) return;
        host.innerHTML = self._agentListHtml();
        self._bindAgentRows(body, host);
      });

      const refresh = body.querySelector('#sam-agent-refresh');
      if (refresh) refresh.addEventListener('click', function () {
        refresh.textContent = 'Checking…';
        refresh.disabled = true;
        window.uecp.call('refresh_acp_catalog', {});
        setTimeout(function () { refresh.textContent = 'Refresh'; refresh.disabled = false; }, 4000);
      });

      this._bindAgentRows(body, body);
      this._bindDetail(body.querySelector('#sam-detail-pane'));
    }

    _agentListHtml() {
      const self   = this;
      const agents = this._agents || [];
      const q      = String(this._agentQuery || '').trim().toLowerCase();
      const filter = function (a) { return !q || (a.name || '').toLowerCase().includes(q) || (a.id || '').toLowerCase().includes(q); };

      const installed = agents.filter(function (a) { return a.installed && filter(a); });
      const available = agents.filter(function (a) { return !a.installed && filter(a); });

      let listHtml = '';

      const NATURAL = ' style="flex:0 0 auto;overflow:visible"';
      if (installed.length) {
        listHtml += '<div class="list-label">INSTALLED &middot; ' + installed.length + '</div>'
          + '<div class="list"' + NATURAL + '>';
        installed.forEach(function (a) { listHtml += self._agentRow(a); });
        listHtml += '</div>';
      }
      if (available.length) {
        listHtml += '<div class="list-label">AVAILABLE &middot; ' + available.length + '</div>'
          + '<div class="list"' + NATURAL + '>';
        available.forEach(function (a) { listHtml += self._agentRow(a); });
        listHtml += '</div>';
      }
      if (!agents.length) {
        listHtml += '<div style="padding:16px 14px;color:var(--ue-text-lo);font-size:var(--ue-fs-xs)">Loading catalog…</div>';
      }
      return listHtml;
    }

    _bindAgentRows(body, scope) {
      const self = this;
      scope.querySelectorAll('.chat-item[data-id]').forEach(function (row) {
        row.addEventListener('click', function () {
          self._activeAgent = row.dataset.id;
          body.querySelectorAll('.chat-item[data-id]').forEach(function (r) { r.classList.remove('active'); });
          row.classList.add('active');
          body.querySelector('#sam-detail-pane').innerHTML = self._renderAgentDetailHtml();
          self._bindDetail(body.querySelector('#sam-detail-pane'));
          var ag = (self._agents || []).find(function (a) { return a.id === self._activeAgent; });
          if (ag && ag.installed) {
            var cached = self._acpConfigs && self._acpConfigs[self._activeAgent] && Array.isArray(self._acpConfigs[self._activeAgent].models) && self._acpConfigs[self._activeAgent].models.length;
            if (!cached) { self._cfgLoading = self._cfgLoading || {}; self._cfgLoading[self._activeAgent] = true; self._renderAgentDetail(); }
            window.uecp.call('request_acp_config', { agentId: self._activeAgent, slotIndex: DEFAULTS_SCOPE });
          }
        });
      });
    }

    _agentRow(a) {
      const id         = a.id || '';
      const name       = a.name || id;
      const isActive   = a.active ? true : false;
      const aState = a.authState || (a.authRequired ? 'required' : 'unknown');
      const AUTH_ROW = { required: 'SIGN-IN NEEDED', checking: 'checking…', unknown: 'not checked', ok: 'ready' };
      const status     = a.status || (a.installed ? (AUTH_ROW[aState] || 'idle') : '');
      const initials   = (name.replace(/[^A-Z]/gi, '').substring(0, 2) || name.substring(0, 2)).toUpperCase();
      const isSelected = id === this._activeAgent;

      const avatarStyle = a.installed
        ? (isActive
          ? 'background:linear-gradient(150deg,var(--ue-accent),var(--ue-accent-deep));color:var(--ue-on-accent)'
          : 'background:var(--ue-elev);color:var(--ue-accent-bright);border:1px solid var(--ue-line)')
        : 'background:var(--ue-elev);color:var(--ue-accent-bright);border:1px solid var(--ue-line)';

      const statusColor = aState === 'required'
        ? 'var(--ue-warn)'
        : (isActive ? 'var(--ue-accent)' : 'var(--ue-text-lo)');

      return '<div class="chat-item' + (isSelected ? ' active' : '') + '" data-id="' + esc(id) + '" style="display:flex;align-items:center;gap:10px">'
        + '<span style="width:30px;height:30px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;flex-shrink:0;' + avatarStyle + '">' + esc(initials) + '</span>'
        + '<div style="flex:1;min-width:0"><div class="chat-item-title" style="margin:0">' + esc(name) + '</div>'
        + (status ? '<div class="chat-item-meta" style="color:' + statusColor + '">' + esc(isActive ? 'ACTIVE' : status) + '</div>' : '')
        + '</div>'
        + (!a.installed ? PLUS_ICON : this._rowUpdateMark(a))
        + '</div>';
    }

    _rowUpdateMark(a) {
      const u = updateInfo(a);
      return u.behind
        ? '<span class="ue-code sam-row-update" style="font-size:10px;color:var(--ue-accent-bright);flex-shrink:0">&#8593; ' + esc(u.latest) + '</span>'
        : '';
    }

    _renderAgentDetailHtml() {
      const id = this._activeAgent;
      if (!id) return '<div style="color:var(--ue-text-lo);font-size:var(--ue-fs-sm);padding:40px 0;text-align:center">Select an agent to view details.</div>';
      const a = (this._agents || []).find(function (ag) { return ag.id === id; });
      if (!a) return '<div style="color:var(--ue-text-lo);font-size:var(--ue-fs-sm);padding:40px 0;text-align:center">Agent not found.</div>';

      const name      = a.name      || id;
      const version   = a.version   || '';
      const vendor    = a.vendor    || '';
      const isActive  = a.active    ? true : false;
      const installed = a.installed ? true : false;
      const authState = a.authState || (a.authRequired ? 'required' : 'unknown');
      const authDetail = a.authDetail || '';
      const desc      = a.description || '';
      const initials  = (name.replace(/[^A-Z]/gi, '').substring(0, 2) || name.substring(0, 2)).toUpperCase();

      const avatarBg = isActive
        ? 'linear-gradient(150deg,var(--ue-accent),var(--ue-accent-deep))'
        : 'var(--ue-elev)';
      const avatarColor  = isActive ? 'var(--ue-on-accent)' : 'var(--ue-accent-bright)';
      const avatarBorder = isActive ? 'none' : '1px solid var(--ue-line)';

      let html = '<div class="sam-detail">'
        + '<div style="display:flex;align-items:center;gap:13px;margin-bottom:14px">'
        + '<span style="width:46px;height:46px;border-radius:11px;background:' + avatarBg + ';color:' + avatarColor + ';border:' + avatarBorder + ';display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:700;flex-shrink:0">' + esc(initials) + '</span>'
        + '<div style="flex:1;min-width:0">'
        + '<div style="display:flex;align-items:center;gap:9px">'
        + '<span style="font-size:19px;font-weight:600;letter-spacing:-.01em;color:var(--ue-text-hi)">' + esc(name) + '</span>'
        + (isActive ? '<span title="Provider of the active slot" style="font-size:9px;font-weight:700;letter-spacing:.08em;color:var(--ue-on-accent);background:var(--ue-accent);padding:2px 7px;border-radius:5px">ACTIVE SLOT</span>' : '')
        + '</div>'
        + '<div class="chat-item-meta" style="margin-top:4px">'
        +   esc([(installed && a.installedVersion) ? a.installedVersion : version, vendor].filter(Boolean).join(' · '))
        + '</div>'
        + '</div>'
        + '</div>';

      const upd = updateInfo(a);
      if (upd.behind) html += updateRowHtml(upd, 'sam-update-btn');

      if (desc) html += '<div style="font-size:13px;color:var(--ue-text-mid);line-height:1.55;margin-bottom:20px">' + esc(desc) + '</div>';

      if (installed) {
        html += '<div style="display:flex;flex-direction:column;gap:16px">';

        const AUTH_UI = {
          ok:       { dot: ' dot-ok', css: '',                            label: 'Connected',       btn: 'sam-recheck-btn', btnText: 'Recheck'   },
          required: { dot: '',        css: 'background:var(--ue-warn)',    label: 'Sign-in required', btn: 'sam-signin-btn',  btnText: 'Sign in'   },
          checking: { dot: '',        css: 'background:var(--ue-accent)',  label: 'Checking…',        btn: '',                btnText: ''          },
          unknown:  { dot: '',        css: 'background:var(--ue-text-lo)', label: 'Not checked yet',  btn: 'sam-recheck-btn', btnText: 'Check now' }
        };
        const au = AUTH_UI[authState] || AUTH_UI.unknown;
        html += '<div><div class="field-label">Authentication</div>'
          + '<div class="input" style="gap:9px">'
          + '<span class="dot' + au.dot + '" style="' + au.css + ';margin-right:9px"></span>'
          + '<span style="font-size:12.5px;color:var(--ue-text-hi)">' + au.label + '</span>'
          + (au.btn
            ? '<button class="btn-ghost" id="' + au.btn + '" style="margin-left:auto;font-size:11px;padding:5px 10px">' + au.btnText + '</button>'
            : '')
          + '</div>'
          + (authDetail
            ? '<div style="font-size:11.5px;color:var(--ue-text-mid);margin-top:6px;line-height:1.5">' + esc(authDetail) + '</div>'
            : '')
          + '';

        const methods = Array.isArray(a.authMethods) ? a.authMethods : [];
        const methodsKnown = !!a.authMethodsKnown;
        if (authState !== 'ok') {
          if (methods.length) {
            html += '<div><div class="field-label">Sign in with</div>'
              + '<div style="display:flex;flex-direction:column;gap:6px">'
              + methods.map(function (m) {
                  return '<button class="btn-ghost sam-auth-method" data-method="' + esc(m.id) + '"'
                    + ' style="text-align:left;padding:8px 11px;font-size:12px">'
                    + '<span style="color:var(--ue-text-hi);font-weight:600">' + esc(m.name || m.id) + '</span>'
                    + (m.description ? '<span style="color:var(--ue-text-mid);margin-left:8px">' + esc(m.description) + '</span>' : '')
                    + '</button>';
                }).join('')
              + '</div>'
              + (a.entrypointCommand
                ? '<div style="margin-top:8px"><button class="btn-ghost" id="sam-terminal-btn" style="font-size:11px;padding:5px 10px">Open terminal here</button></div>'
                : '')
              + '</div>';
          } else if (methodsKnown) {
            const cliName = this._cliKeyForAgent(name);
            html += '<div><div class="field-label">Sign in</div>'
              + '<div style="font-size:12px;color:var(--ue-text-mid);line-height:1.55">'
              + esc(name) + ' has no in-app sign-in — it reuses the credentials of its own CLI'
              + (cliName ? ' (<strong style="color:var(--ue-text-hi)">' + esc(cliName) + '</strong>)' : '')
              + '. Install that CLI and log in with it once; this agent then picks the login up automatically.'
              + '</div>'
              + '<div style="margin-top:8px;display:flex;gap:8px">'
              + (a.entrypointCommand ? '<button class="btn-ghost" id="sam-terminal-btn" style="font-size:11px;padding:5px 10px">Open terminal here</button>' : '')
              + '</div></div>';
          } else {
            html += '<div><div class="field-label">Sign in</div>'
              + '<div style="font-size:12px;color:var(--ue-text-mid);line-height:1.55">'
              + 'Run a check first — the agent reports which sign-in methods it accepts when it starts.'
              + '</div></div>';
          }
        }
        html += '</div>';

        const cliKey = this._cliKeyForAgent(name);
        if (cliKey) {
          const cliInfo = (this._cli && this._cli[cliKey]) || {};
          if (!cliInfo.found) {
            html += '<div><div class="field-label">CLI</div>'
              + '<div class="input" style="gap:9px">'
              + '<span class="dot" style="background:var(--ue-warn);margin-right:9px"></span>'
              + '<span style="font-size:12.5px;color:var(--ue-text-hi)">' + esc(name) + ' CLI not found</span>'
              + '<button class="btn-ghost" id="sam-install-cli-btn" data-provider="' + esc(name) + '" style="margin-left:auto;font-size:11px;padding:5px 10px;background:var(--ue-accent-soft);border-color:var(--ue-accent);color:var(--ue-accent-bright)">Install CLI</button>'
              + '</div></div>';
          }
        }

        const cfg = (this._acpConfigs && this._acpConfigs[id]) || {};

        const cfgLoading = !!(this._cfgLoading && this._cfgLoading[id]) && !(Array.isArray(cfg.models) && cfg.models.length);
        if (cfgLoading) {
          html += '<div><div class="field-label">Model</div>'
            + '<div class="input mono" style="padding:9px 12px;color:var(--ue-text-lo);gap:8px">'
            + '<span class="sam-load-dot" style="width:7px;height:7px;border-radius:50%;background:var(--ue-accent)"></span>'
            + 'Loading model list…</div></div>';
        }

        if ((Array.isArray(cfg.models) && cfg.models.length) || (Array.isArray(cfg.modes) && cfg.modes.length)) {
          html += '<div style="font-size:11.5px;color:var(--ue-text-mid);line-height:1.5;margin-top:2px">'
            + 'Defaults for ' + esc(name) + '. Any slot running it uses these unless you override them on the slot.'
            + '</div>';
        }

        if (Array.isArray(cfg.models) && cfg.models.length) {
          html += '<div><div class="field-label">Model</div>'
            + '<div class="input mono" style="padding:0 12px"><select id="sam-agent-model" style="flex:1;border:none;background:transparent;font-family:var(--ue-font-mono);font-size:12.5px;color:var(--ue-text-hi);outline:none;appearance:none;cursor:pointer">'
            + cfg.models.map(function (m) { return '<option value="' + esc(m.id) + '"' + (m.id === cfg.currentModel ? ' selected' : '') + '>' + esc(m.name || m.id) + '</option>'; }).join('')
            + '</select>' + CHEV_ICON + '</div></div>';
        }

        if (Array.isArray(cfg.modes) && cfg.modes.length) {
          html += '<div><div class="field-label">Mode</div>'
            + '<div class="input mono" style="padding:0 12px"><select id="sam-agent-mode" style="flex:1;border:none;background:transparent;font-family:var(--ue-font-mono);font-size:12.5px;color:var(--ue-text-hi);outline:none;appearance:none;cursor:pointer">'
            + cfg.modes.map(function (m) { return '<option value="' + esc(m.id) + '"' + (m.id === cfg.currentMode ? ' selected' : '') + '>' + esc(m.name || m.id) + '</option>'; }).join('')
            + '</select>' + CHEV_ICON + '</div></div>';
        }

        if (Array.isArray(cfg.sections)) {
          cfg.sections.forEach(function (sec) {
            if (!sec || !Array.isArray(sec.options) || !sec.options.length) return;
            html += '<div><div class="field-label">' + esc(sec.name || sec.id) + '</div>';
            if (sec.options.length > 6) {
              html += '<div class="input mono" style="padding:0 12px"><select class="sam-section-select" data-section="' + esc(sec.id) + '" style="flex:1;border:none;background:transparent;font-family:var(--ue-font-mono);font-size:12.5px;color:var(--ue-text-hi);outline:none;appearance:none;cursor:pointer">'
                + sec.options.map(function (o) { return '<option value="' + esc(o.id) + '"' + (o.id === sec.currentValue ? ' selected' : '') + '>' + esc(o.name || o.id) + '</option>'; }).join('')
                + '</select>' + CHEV_ICON + '</div>';
            } else {
              html += '<div class="seg-wide" data-section="' + esc(sec.id) + '">'
                + sec.options.map(function (o) {
                    return '<span data-opt="' + esc(o.id) + '"' + (o.id === sec.currentValue ? ' class="active"' : '') + '>' + esc(o.name || o.id) + '</span>';
                  }).join('')
                + '</div>';
            }
            html += '</div>';
          });
        }

        if ((this._install && this._install[id]) || a.installing) {
          const ip = (this._install && this._install[id]) || { stage: 'Installing', fraction: a.installFraction || 0 };
          html += '<div><div class="field-label">' + esc(ip.stage) + '…</div>'
            + '<div style="height:5px;border-radius:3px;background:var(--ue-elev);overflow:hidden;margin-top:8px" data-agent-id="' + esc(id) + '">'
            + '<div class="sam-progress-fill" style="height:100%;background:var(--ue-accent);border-radius:3px;transition:width .2s;width:' + Math.round((ip.fraction || 0) * 100) + '%"></div>'
            + '</div></div>';
        }

        html += '</div>';

        const allSlots = this._slots || [];
        const boundSlots = allSlots.filter(function (s) {
          return s && s.provider === id;
        });
        if (boundSlots.length) {
          const names = boundSlots.map(function (s) {
            const realIdx = allSlots.indexOf(s);
            return s.name || ('Slot ' + (realIdx + 1));
          }).join(', ');
          html += '<div style="font-size:11.5px;color:var(--ue-text-mid);margin-top:14px;line-height:1.5">'
            + 'Assigned to <strong style="color:var(--ue-accent-bright)">' + esc(names) + '</strong>. '
            + 'Change the binding in the <strong>API Keys</strong> tab.</div>';
        }
        html += '<div style="display:flex;align-items:center;gap:9px;margin-top:22px;padding-top:18px;border-top:1px solid var(--ue-line-soft)">'
          + '<span class="spacer"></span>'
          + '<button class="btn-danger" id="sam-uninstall-btn">Uninstall</button>'
          + '</div>';
      } else {
        html += '<div style="display:flex;gap:9px;margin-top:22px;padding-top:18px;border-top:1px solid var(--ue-line-soft)">'
          + '<button class="btn-ghost" id="sam-install-btn" style="background:var(--ue-accent-soft);border-color:var(--ue-accent);color:var(--ue-accent-bright)">Install</button>'
          + '</div>';
      }

      html += '</div>';
      return html;
    }

    _bindDetail(pane) {
      if (!pane) return;
      const self = this;
      const id   = this._activeAgent;
      if (!id) return;

      const signin = pane.querySelector('#sam-signin-btn');
      if (signin) signin.addEventListener('click', function () { window.uecp.call('signin_acp_agent', { agentId: id }); });

      pane.querySelectorAll('.sam-auth-method').forEach(function (b) {
        b.addEventListener('click', function () {
          b.disabled = true;
          window.uecp.call('authenticate_acp_agent', { agentId: id, methodId: b.dataset.method });
        });
      });

      const term = pane.querySelector('#sam-terminal-btn');
      if (term) term.addEventListener('click', function () { window.uecp.call('open_terminal_for_acp_agent', { agentId: id }); });

      const recheck = pane.querySelector('#sam-recheck-btn');
      if (recheck) recheck.addEventListener('click', function () { window.uecp.call('recheck_acp_agent', { agentId: id }); });

      const installCli = pane.querySelector('#sam-install-cli-btn');
      if (installCli) installCli.addEventListener('click', function () {
        installCli.textContent = 'Installing…';
        installCli.disabled = true;
        window.uecp.call('install_cli', { provider: installCli.dataset.provider });
      });

      const install = pane.querySelector('#sam-install-btn');
      if (install) install.addEventListener('click', function () {
        self._install = self._install || {};
        self._install[id] = { stage: 'Starting', fraction: 0.02 };
        install.disabled = true;
        install.textContent = 'Installing…';
        window.uecp.call('install_acp_agent', { agentId: id });
        self._renderAgentPane();
      });

      const update = pane.querySelector('#sam-update-btn');
      if (update) update.addEventListener('click', function () {
        update.textContent = 'Updating…';
        update.disabled = true;
        window.uecp.call('install_acp_agent', { agentId: id });
      });

      const uninstall = pane.querySelector('#sam-uninstall-btn');
      if (uninstall) uninstall.addEventListener('click', function () {
        window.UECP.dialog.confirm('Uninstall agent', 'Uninstall ' + id + '?').then(function (ok) {
          if (ok) window.uecp.call('uninstall_acp_agent', { agentId: id });
        });
      });

      const modelSel = pane.querySelector('#sam-agent-model');
      if (modelSel) modelSel.addEventListener('change', function () {
        window.uecp.call('set_acp_agent_config', { agentId: id, key: 'model', value: modelSel.value, slotIndex: DEFAULTS_SCOPE });
      });

      const modeSel = pane.querySelector('#sam-agent-mode');
      if (modeSel) modeSel.addEventListener('change', function () {
        window.uecp.call('set_acp_agent_config', { agentId: id, key: 'mode', value: modeSel.value, slotIndex: DEFAULTS_SCOPE });
      });

      pane.querySelectorAll('.sam-section-select').forEach(function (sel) {
        sel.addEventListener('change', function () {
          window.uecp.call('set_acp_agent_config', { agentId: id, key: sel.dataset.section, value: sel.value, slotIndex: DEFAULTS_SCOPE });
        });
      });

      pane.querySelectorAll('.seg-wide[data-section]').forEach(function (seg) {
        const sectionId = seg.dataset.section;
        seg.querySelectorAll('span[data-opt]').forEach(function (opt) {
          opt.addEventListener('click', function () {
            seg.querySelectorAll('span[data-opt]').forEach(function (s) { s.classList.remove('active'); });
            opt.classList.add('active');
            window.uecp.call('set_acp_agent_config', { agentId: id, key: sectionId, value: opt.dataset.opt, slotIndex: DEFAULTS_SCOPE });
          });
        });
      });
    }

    _renderAgentDetail() {
      const pane = this.querySelector('#sam-detail-pane');
      if (!pane) return;
      pane.innerHTML = this._renderAgentDetailHtml();
      this._bindDetail(pane);
    }
  }
  customElements.define('settings-ai-models', SettingsAiModels);
})();
