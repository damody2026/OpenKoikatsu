// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "UECPSteamTypes.h"
#include "UECPSteamStatsLibrary.generated.h"

class UTexture2D;

USTRUCT(BlueprintType)
struct UECPSTEAMRUNTIME_API FUECPSteamAchievementInfo
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	FString ApiName;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	FString DisplayName;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	FString Description;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	bool bUnlocked = false;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	bool bHidden = false;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	FDateTime UnlockTime;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	float GlobalUnlockPercent = -1.f;
};

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamStatsLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Stats")
	static TArray<FUECPSteamAchievementInfo> GetAchievements();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Stats")
	static FUECPSteamAchievementInfo GetAchievement(const FString& AchievementApiName);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Stats")
	static bool IsAchievementUnlocked(const FString& AchievementApiName);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Stats", meta = (AdvancedDisplay = "bStoreImmediately"))
	static bool UnlockAchievement(const FString& AchievementApiName, bool bStoreImmediately = true);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Stats", meta = (AdvancedDisplay = "bStoreImmediately"))
	static bool ClearAchievement(const FString& AchievementApiName, bool bStoreImmediately = true);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Stats")
	static bool IndicateAchievementProgress(const FString& AchievementApiName, int32 CurrentProgress, int32 MaxProgress);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Stats")
	static UTexture2D* GetAchievementIcon(const FString& AchievementApiName);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Stats")
	static int32 GetStatInt(const FString& StatApiName);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Stats")
	static float GetStatFloat(const FString& StatApiName);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Stats", meta = (AdvancedDisplay = "bStoreImmediately"))
	static bool SetStatInt(const FString& StatApiName, int32 Value, bool bStoreImmediately = false);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Stats", meta = (AdvancedDisplay = "bStoreImmediately"))
	static bool SetStatFloat(const FString& StatApiName, float Value, bool bStoreImmediately = false);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Stats")
	static bool UpdateAvgRateStat(const FString& StatApiName, float CountThisSession, float SessionLengthSeconds);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Stats")
	static bool StoreSteamStats();

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Stats")
	static bool ResetAllStats(bool bAlsoResetAchievements);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Stats")
	static bool RequestGlobalAchievementPercentages();
};
