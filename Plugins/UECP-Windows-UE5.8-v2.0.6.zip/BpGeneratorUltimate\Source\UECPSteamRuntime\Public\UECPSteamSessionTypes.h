// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "OnlineSessionSettings.h"
#include "UECPSteamTypes.h"
#include "UECPSteamSessionTypes.generated.h"

UENUM(BlueprintType)
enum class EUECPSteamSessionType : uint8
{
	Lobby           UMETA(DisplayName = "Lobby (friends, invites, presence)"),

	ServerBrowser   UMETA(DisplayName = "Server Browser (dedicated / master list)"),

	LAN             UMETA(DisplayName = "LAN (no Steam)"),
};

USTRUCT(BlueprintType)
struct UECPSTEAMRUNTIME_API FUECPSteamSessionSettings
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Session")
	EUECPSteamSessionType SessionType = EUECPSteamSessionType::Lobby;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Session", meta = (ClampMin = "1"))
	int32 MaxPlayers = 4;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Session", meta = (ClampMin = "0"))
	int32 PrivateSlots = 0;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Session")
	bool bAllowJoinInProgress = true;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Session")
	bool bAllowInvites = true;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Session")
	bool bFriendsOnly = false;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Session")
	bool bShouldAdvertise = true;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Session")
	bool bUsesStats = false;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Session")
	bool bAntiCheatProtected = false;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Session")
	bool bUseLobbyVoiceChat = false;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Session")
	FString MapName;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Session")
	FString GameMode;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Session")
	TMap<FString, FString> ExtraSettings;

	FOnlineSessionSettings ToOnlineSessionSettings() const;
};

USTRUCT(BlueprintType)
struct UECPSTEAMRUNTIME_API FUECPSteamSessionSearchResult
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly, Category = "Session")
	FUECPSteamID HostSteamId;

	UPROPERTY(BlueprintReadOnly, Category = "Session")
	FString HostName;

	UPROPERTY(BlueprintReadOnly, Category = "Session")
	int32 PingMs = -1;

	UPROPERTY(BlueprintReadOnly, Category = "Session")
	int32 CurrentPlayers = 0;

	UPROPERTY(BlueprintReadOnly, Category = "Session")
	int32 MaxPlayers = 0;

	UPROPERTY(BlueprintReadOnly, Category = "Session")
	int32 OpenSlots = 0;

	UPROPERTY(BlueprintReadOnly, Category = "Session")
	FString MapName;

	UPROPERTY(BlueprintReadOnly, Category = "Session")
	FString GameMode;

	UPROPERTY(BlueprintReadOnly, Category = "Session")
	bool bAllowJoinInProgress = false;

	UPROPERTY(BlueprintReadOnly, Category = "Session")
	TMap<FString, FString> ExtraSettings;

	FOnlineSessionSearchResult OnlineResult;

	bool IsValid() const { return OnlineResult.IsValid(); }

	static FUECPSteamSessionSearchResult FromOnlineResult(const FOnlineSessionSearchResult& InResult);
};

USTRUCT(BlueprintType)
struct UECPSTEAMRUNTIME_API FUECPSteamSessionSearchSettings
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Search")
	EUECPSteamSessionType SessionType = EUECPSteamSessionType::Lobby;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Search", meta = (ClampMin = "1"))
	int32 MaxResults = 50;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Search")
	bool bOnlyJoinable = true;

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "Search")
	TMap<FString, FString> RequiredSettings;
};
