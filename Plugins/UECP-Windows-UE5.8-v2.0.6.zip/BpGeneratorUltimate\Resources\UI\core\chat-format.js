(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) { root.UECP = root.UECP || {}; Object.assign(root.UECP, api); }
}(typeof self !== 'undefined' ? self : null, function () {

  const SYS_PREFIXES = [
    '[COMPACT REQUEST]',
    '[SUBAGENT BRIEFING'
  ];

  const TOOL_PREFIXES = [
    '[TOOL_RESULT:',
    '[BATCH_RESULT:',
    '[AUTO-VALIDATE]',
    '[HANDLE_REFERENCE:'
  ];

  function textOf(m) {
    return (m && m.parts && m.parts[0] && m.parts[0].text) || '';
  }

  function classifyMessage(m) {
    const role = m && m.role;

    if (role === 'model') {
      return { kind: 'model', text: textOf(m), isError: !!m.is_error,
               budgetPause: !!m.budget_pause, budgetLimit: Number(m.budget_limit) || 0 };
    }

    if (role === 'tool_bubble' && m.bubble === 'diff' && m.diff) {
      return { kind: 'diff', diff: m.diff };
    }
    if (role === 'tool_bubble' && m.bubble === 'play_test_offer') {
      return { kind: 'playtest' };
    }
    if (role === 'tool_bubble' && m.bubble === 'premium_offer') {
      const warnings = Array.isArray(m.warnings) ? m.warnings.map(String) : [];
      return { kind: 'premium', reason: String(m.reason || ''), count: Number(m.count) || warnings.length, warnings: warnings };
    }

    if (role === 'agent_thinking') {
      return { kind: 'thinking', text: textOf(m), blockId: m.block_id };
    }

    if (role === 'context') {
      return {
        kind: 'context',
        fileName: m.file_name,
        content: m.content,
        charCount: m.char_count
      };
    }

    if (role === 'compaction_marker') {
      return { kind: 'compaction', text: textOf(m) };
    }

    if (role === 'user') {
      const t = textOf(m);
      if (TOOL_PREFIXES.some(function(p) { return t.startsWith(p); })) {
        return { kind: 'tool', text: t };
      }
      if (SYS_PREFIXES.some(function(p) { return t.startsWith(p); })) {
        return { kind: 'system', text: t };
      }
      const images = (m.parts || []).slice(1)
        .filter(function(p) { return p.inline_data; })
        .map(function(p) { return p.inline_data; });
      return { kind: 'user', text: t, images: images };
    }

    return { kind: 'fallback', text: textOf(m) };
  }

  function parseToolResult(t) {
    const m = /^\[(?:TOOL|BATCH)_RESULT:([^:]+):([^\]]+)\]([\s\S]*)$/.exec(t);
    if (!m) return { tool: '', status: 'success', args: '', result: t };
    const body = m[3];
    const sep = body.indexOf('\n---\n');
    if (sep >= 0) {
      return {
        tool:   m[1],
        status: m[2],
        args:   body.slice(0, sep),
        result: body.slice(sep + 5)
      };
    }
    return { tool: m[1], status: m[2], args: '', result: body };
  }

  function normalizeModel(text) {
    const s = (text || '').trim();
    if (s.startsWith('{') || s.startsWith('[')) {
      try {
        const o = JSON.parse(s);
        const obj = Array.isArray(o) ? (o[0] || {}) : o;
        if (obj && (obj.assistant_text != null || obj.text != null || obj.tool_calls != null
                    || obj.done != null || obj.continue != null)) {
          const result = {
            text:      obj.assistant_text != null ? obj.assistant_text : (obj.text || ''),
            toolCalls: obj.tool_calls || []
          };
          if (obj.done != null)     result.done     = obj.done;
          if (obj.continue != null) result.continue = obj.continue;
          return result;
        }
      } catch (e) {  }
    }
    return { text: text || '', toolCalls: [] };
  }

  return { classifyMessage, parseToolResult, normalizeModel };
}));
