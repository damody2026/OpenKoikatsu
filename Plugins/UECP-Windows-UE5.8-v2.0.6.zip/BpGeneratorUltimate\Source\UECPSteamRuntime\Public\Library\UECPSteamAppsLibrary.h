// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "UECPSteamTypes.h"
#include "UECPSteamAppsLibrary.generated.h"

USTRUCT(BlueprintType)
struct UECPSTEAMRUNTIME_API FUECPSteamDlcInfo
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	int32 AppId = 0;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	FString Name;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	bool bAvailable = false;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	bool bOwned = false;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	bool bInstalled = false;
};

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamAppsLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Apps")
	static bool IsSubscribed();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Apps")
	static bool IsSubscribedToApp(int32 AppId);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Apps")
	static bool IsSubscribedFromFreeWeekend();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Apps")
	static bool IsSubscribedFromFamilySharing();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Apps")
	static bool IsVACBanned();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Apps")
	static bool IsDlcInstalled(int32 DlcAppId);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Apps")
	static TArray<FUECPSteamDlcInfo> GetDlcList();

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Apps")
	static void InstallDlc(int32 DlcAppId);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Apps")
	static void UninstallDlc(int32 DlcAppId);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Apps")
	static bool GetDlcDownloadProgress(int32 DlcAppId, float& ProgressPercent,
		int64& BytesDownloaded, int64& BytesTotal);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Apps")
	static FString GetCurrentGameLanguage();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Apps")
	static TArray<FString> GetAvailableGameLanguages();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Apps")
	static int32 GetAppBuildId();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Apps")
	static FString GetCurrentBetaName();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Apps")
	static FString GetAppInstallDir(int32 AppId);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Apps")
	static FString GetLaunchCommandLine();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Apps")
	static FString GetLaunchQueryParam(const FString& Key);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Apps")
	static FUECPSteamID GetAppOwner();
};
