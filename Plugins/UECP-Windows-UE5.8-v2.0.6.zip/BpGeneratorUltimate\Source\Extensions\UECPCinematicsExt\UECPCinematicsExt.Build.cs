﻿// Copyright 2026, BlueprintsLab, All rights reserved
using UnrealBuildTool;

public class UECPCinematicsExt : ModuleRules
{
	public UECPCinematicsExt(ReadOnlyTargetRules Target) : base(Target)
	{
		bUsePrecompiled = true;
		if (Target.Type != TargetType.Editor) return;
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;
		bUseUnity = false;

		PublicDependencyModuleNames.AddRange(new string[]
		{
			"Core", "CoreUObject", "Engine", "Json", "JsonUtilities",
			"UECPCore",
		});

		PrivateDependencyModuleNames.AddRange(new string[]
		{
			"UnrealEd", "AssetTools", "AssetRegistry", "EditorScriptingUtilities",
			"Slate", "SlateCore", "Kismet", "KismetCompiler", "BlueprintGraph",

			"LevelSequence", "LevelSequenceEditor", "MovieScene", "MovieSceneTools", "MovieSceneTracks",
			"Sequencer", "CinematicCamera",

			"MovieRenderPipelineCore", "MovieRenderPipelineEditor",
			"MovieRenderPipelineRenderPasses",

			"ControlRig", "ControlRigEditor", "RigVM", "RigVMDeveloper",

			"Landscape", "ImageWrapper",
		});

		PrivateDependencyModuleNames.Add("ControlRigDeveloper");
	}
}

