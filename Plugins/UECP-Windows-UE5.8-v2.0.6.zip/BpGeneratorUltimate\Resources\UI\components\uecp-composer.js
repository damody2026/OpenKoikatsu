(function () {
  var USABLE_CONTEXT_CAP = 300000;

  var t = function (key, vars) {
    if (window.uecp && typeof window.uecp.t === 'function') return window.uecp.t(key, vars);
    var out = String(key);
    if (vars) Object.keys(vars).forEach(function (k) {
      out = out.replace(new RegExp('\{' + k + '\}', 'g'), String(vars[k]));
    });
    return out;
  };

  if (!document.getElementById('uecp-composer-css')) {
    const s = document.createElement('style'); s.id = 'uecp-composer-css';
    s.textContent = `
uecp-composer{display:block;border-top:1px solid var(--ue-line-soft);background:var(--ue-bg);flex-shrink:0}
uecp-composer .composer-wrap{padding:14px 0 12px}
uecp-composer .ctx-notice{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:9px;
  padding:9px 12px;border:1px solid var(--ue-warn);border-radius:var(--ue-r);
  background:var(--ue-warn-soft);font-size:12.5px;color:var(--ue-text-hi)}
uecp-composer .ctx-notice.danger{border-color:var(--ue-danger);background:var(--ue-danger-soft)}
uecp-composer .ctx-notice-text{flex:1;min-width:180px;line-height:1.45}
uecp-composer .ctx-notice-acts{display:flex;align-items:center;gap:7px}
uecp-composer .ctx-notice button{font-size:12px;padding:5px 11px;border-radius:var(--ue-r-sm);
  border:1px solid var(--ue-line);background:var(--ue-elev);color:var(--ue-text-hi);cursor:pointer}
/* Fork is the recommended action, so it is the only filled one -- the old UI's
   single "compact" affordance implied you could always just keep going. */
uecp-composer .ctx-notice .ctx-act-fork{background:var(--ue-accent);color:var(--ue-on-accent);
  border-color:var(--ue-accent);font-weight:var(--ue-fw-semi)}
uecp-composer .ctx-notice .ctx-act-hide{border:none;background:none;color:var(--ue-text-mid);
  font-size:15px;line-height:1;padding:2px 5px}
/* Standard-or-Premium choice on a fresh chat. Neutral, not a warning: nothing is wrong. */
uecp-composer .tier-pick{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-bottom:9px;
  padding:9px 12px;border:1px solid var(--ue-line);border-radius:var(--ue-r);
  background:var(--ue-elev);font-size:12.5px;color:var(--ue-text-hi)}
uecp-composer .tier-pick-text{flex:1;min-width:180px;line-height:1.45}
uecp-composer .tier-pick-acts{display:flex;align-items:center;gap:7px}
uecp-composer .tier-pick button{font-size:12px;padding:5px 11px;border-radius:var(--ue-r-sm);
  border:1px solid var(--ue-line);background:var(--ue-panel);color:var(--ue-text-hi);cursor:pointer}
uecp-composer .tier-pick .tier-prem{background:var(--ue-accent);color:var(--ue-on-accent);
  border-color:var(--ue-accent);font-weight:var(--ue-fw-semi)}
uecp-composer .tier-pick .tier-hide{border:none;background:none;color:var(--ue-text-mid);
  font-size:15px;line-height:1;padding:2px 5px}
uecp-composer .composer-inner{max-width:var(--ue-chat-col,720px);margin:0 auto;padding:0 var(--ue-sp-7,24px)}
uecp-composer .composer{background:var(--ue-panel);border:1px solid var(--ue-line);border-radius:var(--ue-r-lg);padding:10px 12px}
/* Plan Mode structural cue (Rec #11): the server (RequestPipeline.cpp /
   UECPToolSafety::IsPlanModeAllowed) already hard-blocks mutating tool calls
   while Plan Mode is active — this tint + the .plan-mode-note below are a
   CLIENT-side legibility signal only, so the user can tell at a glance
   before they even try. Reuses the same accent-soft/accent pairing the
   queue-chip + active menu rows already use for "tinted, not alarming". */
uecp-composer .composer.plan-mode{border-color:var(--ue-accent);background:var(--ue-accent-soft)}
uecp-composer .plan-mode-note{padding:4px 0 2px;font-family:var(--ue-font-mono);font-size:10.5px;color:var(--ue-accent-bright);text-align:center}
uecp-composer .composer-top{display:flex;align-items:flex-start;gap:12px}
uecp-composer .composer-input{flex:1;border:none;outline:none;background:transparent;resize:none;font-family:var(--ue-font-sans);font-size:var(--ue-fs-base);line-height:1.5;color:var(--ue-text-hi);padding-top:3px;min-height:24px;max-height:200px;--ime-halo:var(--ue-panel)}
uecp-composer .composer-input::placeholder{color:var(--ue-text-lo)}
uecp-composer .btn-send{width:34px;height:34px;flex-shrink:0;border-radius:var(--ue-r-md);border:none;cursor:pointer;background:linear-gradient(150deg,var(--ue-accent),var(--ue-accent-deep));display:flex;align-items:center;justify-content:center}
uecp-composer .btn-send svg{stroke:var(--ue-on-accent)}
uecp-composer .btn-send:disabled{opacity:.4;cursor:not-allowed}
uecp-composer .btn-stop{width:34px;height:34px;flex-shrink:0;border-radius:var(--ue-r-md);border:none;cursor:pointer;background:var(--ue-panel);border:1px solid var(--ue-line);display:flex;align-items:center;justify-content:center}
uecp-composer .btn-stop svg{stroke:var(--ue-text-hi)}
/* ── Bottom bar: old-style ghost buttons (left) + model/ring (right). Tighter
   density than the legacy v2 segs/util-row. ── */
uecp-composer .composer-bar{display:flex;align-items:center;gap:4px;margin-top:8px;padding-top:8px;border-top:1px solid var(--ue-line-soft);flex-wrap:wrap}
/* Ghost icon+label button — borderless-ish, --ue-text-mid, hover highlight,
   accent for active state. Ported from app_shell's body.input-compact toolbar. */
uecp-composer .cbtn{display:inline-flex;align-items:center;gap:5px;padding:5px 8px;background:transparent;border:1px solid transparent;border-radius:var(--ue-r);font-family:var(--ue-font-mono);font-size:12px;line-height:1.2;font-weight:500;color:var(--ue-text-mid);cursor:pointer;white-space:nowrap;user-select:none}
uecp-composer .cbtn:hover{color:var(--ue-text-hi);background:var(--ue-panel)}
uecp-composer .cbtn svg{stroke:currentColor;flex-shrink:0}
uecp-composer .cbtn .cbtn-plus{font-size:14px;line-height:1;font-weight:600}
uecp-composer .cbtn.active{color:var(--ue-accent-bright)}
uecp-composer .cbtn.override{color:var(--ue-accent-bright)}
uecp-composer .cbtn.recording{color:var(--ue-danger,#cf6b5a)}
uecp-composer .cbtn-chev{stroke:var(--ue-text-lo)}
uecp-composer .cbtn-plan.attached{color:var(--ue-accent-bright)}
uecp-composer .cbtn-plan .plan-chip-label{max-width:140px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
uecp-composer .bar-spacer{flex:1 1 auto;min-width:6px}
uecp-composer .token{font-family:var(--ue-font-mono);font-size:11px;font-weight:500;color:var(--ue-text-mid);cursor:pointer}
uecp-composer .token-ring{flex-shrink:0;cursor:pointer}
/* Token meter wrapper: anchors the in-DOM tooltip (::after) and clusters the % label
   + ring as one click/hover target. position:relative is required for the tooltip. */
uecp-composer .ctx-ring-wrap{position:relative;display:inline-flex;align-items:center;gap:6px;cursor:pointer}
/* Warn/danger colour cues at >=70% / >=90% (ported from app_shell .ctx-ring.warn/.danger).
   The ring stroke is also driven inline in _syncTokens; these recolour the % label. */
uecp-composer .ctx-ring-wrap.warn .token{color:var(--ue-warn)}
uecp-composer .ctx-ring-wrap.danger .token{color:var(--ue-danger)}
uecp-composer .ctx-ring-wrap.warn .ring-fill{stroke:var(--ue-warn)}
uecp-composer .ctx-ring-wrap.danger .ring-fill{stroke:var(--ue-danger)}
/* Unknown context window (no real data for this slot/model) — dim rather than imply a threshold. */
uecp-composer .ctx-ring-wrap.unknown .token{color:var(--ue-text-lo)}
/* In-DOM tooltip — replaces native title= (CEF drops native tooltips). Ported from
   app_shell.html:806 onto --ue-* tokens; white-space:pre-line so embedded \\n render. */
uecp-composer .has-tip:hover::after{content:attr(data-tip);position:absolute;bottom:calc(100% + 8px);right:0;background:var(--ue-panel);color:var(--ue-text-hi);border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);padding:8px 12px;font-family:var(--ue-font-sans);font-size:12px;font-weight:400;line-height:1.4;max-width:320px;width:max-content;white-space:pre-line;z-index:10000;pointer-events:none;box-shadow:var(--ue-shadow-pop)}
uecp-composer .hint{font-family:var(--ue-font-mono);font-size:11px;font-weight:500;color:var(--ue-text-lo);margin-left:6px}
/* Small forge dropdown menus live on <body> (avoids composer overflow clipping) so
   their selectors must be GLOBAL. Shared by the Attach / Mode / Model menus — old
   "slot-menu" look: small forge panel, check-mark on the selected row. CEF-popup-safe
   (custom JS divs, never a native <select>). */
.composer-menu{position:fixed;background:var(--ue-panel);border:1px solid var(--ue-line);border-radius:var(--ue-r-md);min-width:170px;max-width:300px;z-index:500;box-shadow:0 4px 12px rgba(0,0,0,.3);overflow:hidden;padding:4px 0}
.composer-menu .cm-item{display:flex;align-items:center;gap:8px;padding:8px 12px 8px 28px;cursor:pointer;position:relative;font-size:12.5px;color:var(--ue-text-mid);white-space:nowrap}
.composer-menu .cm-item:hover{background:var(--ue-accent-soft);color:var(--ue-text-hi)}
.composer-menu .cm-item.active{color:var(--ue-accent-bright)}
.composer-menu .cm-item.active::before{content:'\\2713';position:absolute;left:10px;font-weight:700;color:var(--ue-accent-bright)}
.composer-menu .cm-item svg{flex-shrink:0;stroke:currentColor;opacity:.85}
.composer-menu .cm-item .cm-secondary{font-family:var(--ue-font-mono);font-size:10.5px;color:var(--ue-text-lo);margin-top:2px}
.composer-menu .cm-stack{display:flex;flex-direction:column}
/* Queue chips */
uecp-composer .queue-row{display:flex;flex-wrap:wrap;gap:6px;padding:8px 0 2px}
uecp-composer .queue-chip{display:flex;align-items:center;gap:4px;background:var(--ue-accent-soft);border:1px solid var(--ue-accent);color:var(--ue-accent-bright);font-family:var(--ue-font-mono);font-size:11px;padding:3px 7px;border-radius:var(--ue-r-sm)}
uecp-composer .queue-chip .chip-x{cursor:pointer;margin-left:2px;color:var(--ue-text-mid);font-size:13px;line-height:1}
/* Attachment chips */
uecp-composer .attach-row{display:flex;flex-wrap:wrap;gap:6px;padding:6px 0 2px}
uecp-composer .attach-chip{display:flex;align-items:center;gap:4px;background:var(--ue-panel);border:1px solid var(--ue-line);color:var(--ue-text-hi);font-family:var(--ue-font-mono);font-size:11px;padding:3px 7px;border-radius:var(--ue-r-sm);max-width:160px}
uecp-composer .attach-chip span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
uecp-composer .attach-chip .chip-x{cursor:pointer;margin-left:2px;color:var(--ue-text-mid);font-size:13px;line-height:1;flex-shrink:0}
/* @-mention picker dropdown */
uecp-composer .mention-popup{position:absolute;bottom:calc(100% + 6px);left:0;right:0;background:var(--ue-panel);border:1px solid var(--ue-line);border-radius:var(--ue-r-md);overflow:hidden;z-index:200;max-height:220px;overflow-y:auto}
uecp-composer .mention-item{padding:7px 12px;font-family:var(--ue-font-mono);font-size:12px;cursor:pointer;color:var(--ue-text-hi);display:flex;align-items:center;gap:8px}
uecp-composer .mention-item .mi-class{font-size:10px;color:var(--ue-text-lo);flex-shrink:0}
uecp-composer .mention-item.focused{background:var(--ue-accent-soft);color:var(--ue-accent-bright)}
uecp-composer .mention-wrap{position:relative}
/* Slash popup */
uecp-composer .slash-popup{position:absolute;bottom:calc(100% + 6px);left:0;right:0;background:var(--ue-panel);border:1px solid var(--ue-line);border-radius:var(--ue-r-md);overflow:hidden;z-index:200;max-height:220px;overflow-y:auto}
uecp-composer .slash-item{padding:7px 12px;font-family:var(--ue-font-mono);font-size:12px;cursor:pointer;color:var(--ue-text-hi);display:flex;align-items:center;gap:8px}
uecp-composer .slash-item .si-desc{font-size:10px;color:var(--ue-text-lo)}
uecp-composer .slash-item.focused{background:var(--ue-accent-soft);color:var(--ue-accent-bright)}
/* ── Working indicator ("Cooking…") ──
   Lives in the composer, NOT the thread: uecp-thread._onWindow rebuilds
   .thread-inner wholesale on every window push, which would destroy an
   in-thread bubble mid-turn, and a pinned strip stays visible however far
   the user has scrolled back. Motion-minimal per styles/base.css — liveness
   is a STATIC accent dot, never an animation.
   Containment is layout+style only: paint containment would clip the .has-tip
   tooltip, which renders outside the strip's box. */
uecp-composer .think-strip{display:none;position:relative;align-items:center;gap:7px;padding:4px 2px 6px;font-family:var(--ue-font-mono);font-size:11.5px;color:var(--ue-text-mid);contain:layout style}
uecp-composer .think-strip.visible{display:flex}
uecp-composer .think-dot{width:7px;height:7px;border-radius:50%;background:var(--ue-accent-bright);flex-shrink:0}
uecp-composer .think-label{color:var(--ue-accent-bright);font-weight:500;flex-shrink:0}
uecp-composer .think-step{color:var(--ue-text-mid);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
/* Top banner */
uecp-composer .composer-banner{display:none;background:var(--ue-accent-soft);border-bottom:1px solid var(--ue-accent);padding:7px 14px;font-family:var(--ue-font-mono);font-size:11.5px;color:var(--ue-accent-bright);align-items:center;gap:8px}
uecp-composer .composer-banner.visible{display:flex}
uecp-composer .composer-banner .banner-text{flex:1}
uecp-composer .banner-dismiss{cursor:pointer;font-size:15px;line-height:1;color:var(--ue-text-mid);flex-shrink:0}`;
    document.head.appendChild(s);
  }

  const MODES = [
    { id: 'chat', label: 'Just Chat' },
    { id: 'ask',  label: 'Ask Before Edit' },
    { id: 'auto', label: 'Auto Edit' },
    { id: 'plan', label: 'Plan' }
  ];

  function modeLabel(id) {
    var m = MODES.find(function (x) { return x.id === id; });
    return m ? m.label : id;
  }

  function isImeComposing(e) {
    return !!(e && (e.isComposing || e.keyCode === 229));
  }

  function pad2(n) { return (n < 10 ? '0' : '') + n; }

  function svg(inner, sz) {
    var s = sz || 13;
    return '<svg width="' + s + '" height="' + s + '" viewBox="0 0 24 24" fill="none" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round">' + inner + '</svg>';
  }
  var IC = {
    chevron: '<path d="m6 9 6 6 6-6"/>',
    image:   '<rect width="18" height="18" x="3" y="3" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.1-3.1a2 2 0 0 0-2.8 0L6 21"/>',
    file:    '<path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/>',
    plugin:  '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
    voice:   '<path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" x2="12" y1="19" y2="22"/>',
    plan:    '<rect width="8" height="4" x="8" y="2" rx="1"/><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"/><path d="M9 14l2 2 4-4"/>'
  };

  var BUILTIN_SLASH = [
    { name: 'compact', desc: 'Compact conversation' },
    { name: 'delete',  desc: 'Delete last message' },
    { name: 'login',   desc: 'Login agent' }
  ];

  class UecpComposer extends HTMLElement {
    connectedCallback() {
      this._thinking = false;
      this._thinkLabel = '';
      this._activeChatId = (window.UECP && window.UECP.activeChatId) || '';
      this._mode = 'auto';
      this._planTitle = '';
      this._model = '';
      this._pct = 0;
      this._tokenCount = 0;
      this._tokenBudget = 200000;
      this._slots = [];
      this._slotActiveIdx = -1;
      this._chatSlotIdx = -1;
      this._recording = false;
      this._voiceEnabled = false;
      this._images = [];
      this._files = [];
      this._queueCount = 0;
      this._queuePreviews = [];
      this._mentionResults = [];
      this._mentionFocused = -1;
      this._slashContext = {};
      this._slashCommands = {};
      this._slashFocused = -1;
      this._slashOpen = false;
      this._slashFilter = '';
      this._bannerText = '';
      this._compactMode = 'marker';
      this._autoCompact = { enabled: true, percent: 80 };
      this._sendOnEnter = true;
      this._archived = false;
      this._isSubagent = false;
      this._build();

      var self = this;
      this._u1 = window.uecp.on('chat.thinking', function (d) {
        if (d && self._slotRevert && d.chatId === self._slotRevert.chatId) {
          if (d.show) self._slotRevert.started = true;
          else if (self._slotRevert.started) { self._slotRevert.ended = true; self._maybeRevertSlot(); }
        }
        if (!d || d.chatId !== self._activeChatId) return;
        self._thinking = !!d.show;
        self._thinkLabel = self._thinking ? (d.label || '') : '';
        self._syncThinking();
      });
      this._u2 = window.uecp.on('chat.viewstate', function (d) {
        if (!d) return;
        if (d.chatId != null) self._activeChatId = d.chatId;
        if (d.interactionMode != null) { self._mode = d.interactionMode; self._syncMode(); }
        if (d.apiKeySlotIndex != null) {
          var before = self._premiumKey();
          self._chatSlotIdx = d.apiKeySlotIndex; self._syncModel(); self._syncTokens();
          self._refreshOffers(before);
        }
        self._maybeRevertSlot();
        if (d.archived != null)   { self._archived   = !!d.archived;   self._syncArchived(); }
        if (d.isSubagent != null) { self._isSubagent = !!d.isSubagent; self._syncReadOnly(); }
      });
      this._u3 = window.uecp.on('chat.tokens', function (d) {
        if (!d) return;
        self._tokenCount = d.count || 0;
        self._syncTokens();
      });
      this._uSlots = window.uecp.on('slots.list', function (d) {
        if (!d) return;
        var before = self._premiumKey();
        self._slots = Array.isArray(d.slots) ? d.slots : [];
        if (typeof d.activeIdx === 'number') self._slotActiveIdx = d.activeIdx;
        self._syncModel();
        self._syncTokens();
        self._syncTierPick();
        self._refreshOffers(before);
      });
      this._uWin = window.uecp.on('chat.window', function (d) {
        if (d && d.chatId === self._activeChatId && d.streaming === false && self._thinking) { self._thinking = false; self._syncThinking(); }
        if (d && d.chatId === self._activeChatId) {
          self._chatEmpty = !((d.messages && d.messages.length) || d.total > 0);
          self._syncTierPick();
        }
      });
      this._uTail = window.uecp.on('chat.tail', function (d) {
        if (d && d.chatId === self._activeChatId && d.streaming === false && self._thinking) { self._thinking = false; self._syncThinking(); }
        if (d && d.chatId === self._activeChatId && self._chatEmpty) { self._chatEmpty = false; self._syncTierPick(); }
      });
      this._u4 = window.uecp.on('chat.queue', function (d) {
        if (!d) return;
        self._queueCount = d.count || 0;
        self._queuePreviews = d.previews || [];
        self._syncQueue();
      });
      this._u5 = window.uecp.on('composer.images', function (d) {
        self._images = Array.isArray(d) ? d : [];
        self._syncAttachments();
      });
      this._u6 = window.uecp.on('composer.files', function (d) {
        self._files = Array.isArray(d) ? d : [];
        self._syncAttachments();
      });
      this._u7 = window.uecp.on('mention.results', function (d) {
        self._mentionResults = Array.isArray(d) ? d : [];
        self._mentionFocused = self._mentionResults.length > 0 ? 0 : -1;
        self._syncMentionPopup();
      });
      this._u8 = window.uecp.on('slash.context', function (d) {
        self._slashContext = d || {};
        self._syncSlashPopup();
      });
      this._u9 = window.uecp.on('slash.commands', function (d) {
        if (!d) return;
        if (d.agentId) self._slashCommands[d.agentId] = d.commands || [];
        self._syncSlashPopup();
      });
      this._u10 = window.uecp.on('voice.state', function (d) {
        self._recording = d && d.recording;
        self._syncVoice();
      });
      this._u11 = window.uecp.on('voice.text', function (d) {
        if (!d || !d.text) return;
        var ta = self.querySelector('.composer-input');
        if (ta) {
          ta.value = ta.value ? ta.value + ' ' + d.text : d.text;
          ta.dispatchEvent(new Event('input'));
        }
      });
      this._u12 = window.uecp.on('banner', function (d) {
        if (!d) return;
        self._bannerText = d.message || '';
        self._syncBanner();
      });
      var applySettings = function (d) {
        if (!d) return;
        var prefs = d.chatPrefs || {};
        if (prefs.compactMode === 'marker' || prefs.compactMode === 'fork' || prefs.compactMode === 'discard') {
          self._compactMode = prefs.compactMode;
        }
        self._autoCompact.enabled = !!prefs.autoCompact;
        if (typeof prefs.autoCompactPercent === 'number') self._autoCompact.percent = prefs.autoCompactPercent;
        if (typeof prefs.sendOnEnter === 'boolean') self._sendOnEnter = prefs.sendOnEnter;
        self._syncTokens();
        var voice = d.voice || {};
        self._voiceEnabled = voice.enabled === true;
        self._syncVoiceVisible();
        var tools = d.tools || {};
        var before = self._premiumKey();
        self._suggestPremium = tools.suggestPremium !== false;
        self._refreshOffers(before);
      };
      this._u13 = window.uecp.on('settings.init', applySettings);
      if (window.uecp.lastSettings) applySettings(window.uecp.lastSettings());
      this._uPlan = window.uecp.on('plan.state', function (d) {
        var hasPlan = !!(d && (d.title || d.context));
        self._planTitle = hasPlan ? (d.title || 'Plan') : '';
        self._syncPlan();
      });
      this._u14 = window.uecp.on('settings.voice_enabled', function (d) {
        self._voiceEnabled = !!(d && d.enabled);
        self._syncVoiceVisible();
      });
      window.UECP = window.UECP || {};
      this._compactFirstHook = function () { return self._compactFirstArgs(); };
      window.UECP.compactFirstArgs = this._compactFirstHook;
      window.uecp.call('request_voice_state', {});
    }

    disconnectedCallback() {
      var unsubs = [this._u1,this._u2,this._u3,this._u4,this._u5,this._u6,
                    this._u7,this._u8,this._u9,this._u10,this._u11,this._u12,this._u13,this._u14,
                    this._uSlots,this._uWin,this._uTail,this._uPlan];
      for (var i = 0; i < unsubs.length; i++) {
        if (unsubs[i]) { unsubs[i](); }
      }
      this._u1=this._u2=this._u3=this._u4=this._u5=this._u6=
      this._u7=this._u8=this._u9=this._u10=this._u11=this._u12=this._u13=this._u14=
      this._uSlots=this._uWin=this._uTail=this._uPlan=null;
      if (window.UECP && window.UECP.compactFirstArgs === this._compactFirstHook) delete window.UECP.compactFirstArgs;
      this._compactFirstHook = null;
      if (this._menuDocClick) { document.removeEventListener('click', this._menuDocClick); this._menuDocClick = null; }
      this._closeMenu();
    }

    _build() {
      this.innerHTML =
        '<div class="composer-banner" aria-live="polite">' +
          '<span class="banner-text"></span>' +
          '<span class="banner-dismiss" title="Dismiss">×</span>' +
        '</div>' +
        '<div class="composer-wrap"><div class="composer-inner">' +
          '<div class="ctx-notice" style="display:none">' +
            '<div class="ctx-notice-text"></div>' +
            '<div class="ctx-notice-acts">' +
              '<button class="ctx-act-fork">' + t('Start fresh chat') + '</button>' +
              '<button class="ctx-act-compact">' + t('Compact here') + '</button>' +
              '<button class="ctx-act-hide" title="Dismiss">×</button>' +
            '</div>' +
          '</div>' +
          '<div class="tier-pick" style="display:none">' +
            '<div class="tier-pick-text">' + t('Standard or Premium for this chat? Premium is smarter and handles difficult tasks better, and uses tokens faster.') + '</div>' +
            '<div class="tier-pick-acts">' +
              '<button class="tier-std">BpLabs Standard</button>' +
              '<button class="tier-prem"></button>' +
              '<button class="tier-hide" title="' + t("Don't ask again") + '">×</button>' +
            '</div>' +
          '</div>' +
          '<div class="queue-row" style="display:none"></div>' +
          '<div class="attach-row" style="display:none"></div>' +
          '<div class="think-strip has-tip" aria-live="polite" data-tip="Prolonged time before a response can be due to the model thinking, or it calling hidden tools such as fetching docs.">' +
            '<span class="think-dot"></span>' +
            '<span class="think-label">Cooking…</span>' +
            '<span class="think-step"></span>' +
          '</div>' +
          '<div class="mention-wrap" style="position:relative">' +
            '<div class="mention-popup" style="display:none"></div>' +
            '<div class="slash-popup" style="display:none"></div>' +
            '<div class="composer">' +
              '<uecp-task-bar></uecp-task-bar>' +
              '<div class="composer-top">' +
                '<textarea class="composer-input" rows="1" placeholder="Describe what you want me to build…"></textarea>' +
                '<button class="btn-send" aria-label="Send" title="Send" data-tip="Send">' + svg('<path d="M12 19V5"/><path d="m5 12 7-7 7 7"/>', 16) + '</button>' +
                '<button class="btn-stop" aria-label="Stop" title="Stop" data-tip="Stop" style="display:none"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect width="14" height="14" x="5" y="5" rx="2"/></svg></button>' +
              '</div>' +
              '<div class="composer-bar">' +
                '<button class="cbtn cbtn-attach" type="button" aria-label="Attach" title="Attach an image, file or plugin" data-tip="Attach an image, file or plugin"><span class="cbtn-plus">+</span>Attach' + svg(IC.chevron, 11).replace('stroke-width="1.8"','class="cbtn-chev" stroke-width="2"') + '</button>' +
                '<button class="cbtn cbtn-mode" type="button" aria-label="Interaction mode" title="Interaction mode for this chat" data-tip="Interaction mode for this chat"><span class="cbtn-mode-label">Just Chat</span>' + svg(IC.chevron, 11).replace('stroke-width="1.8"','class="cbtn-chev" stroke-width="2"') + '</button>' +
                '<button class="cbtn cbtn-voice" type="button" aria-label="Voice" aria-pressed="false" title="Voice" data-tip="Voice" style="display:none">' + svg(IC.voice) + '</button>' +
                '<button class="cbtn cbtn-plan" type="button" aria-label="Plan" title="Plan" data-tip="Plan">' + svg(IC.plan) + '<span class="plan-chip-label">Plan</span></button>' +
                '<span class="bar-spacer"></span>' +
                '<button class="cbtn cbtn-model" type="button" aria-label="Model" title="API key slot / model for this chat" data-tip="API key slot / model for this chat">' + window.UECP.icon('ic-architect', 12) + '<span class="model-text">—</span>' + svg(IC.chevron, 11).replace('stroke-width="1.8"','class="cbtn-chev" stroke-width="2"') + '</button>' +
                '<button class="cbtn cbtn-effort" type="button" aria-label="Effort" style="display:none" title="' + t('How hard the premium model thinks') + '" data-tip="' + t('How hard the premium model thinks') + '"><span class="effort-text"></span>' + svg(IC.chevron, 11).replace('stroke-width="1.8"','class="cbtn-chev" stroke-width="2"') + '</button>' +
                '<span class="ctx-ring-wrap has-tip" data-tip="Context: 0 (0%)">' +
                  '<span class="token mono">0%</span>' +
                  '<svg class="token-ring" width="22" height="22" viewBox="0 0 22 22" style="transform:rotate(-90deg)" aria-hidden="true">' +
                    '<circle cx="11" cy="11" r="9" fill="none" stroke="var(--ue-line)" stroke-width="2.5"/>' +
                    '<circle class="ring-fill" cx="11" cy="11" r="9" fill="none" stroke="var(--ue-accent)" stroke-width="2.5" pathLength="100" stroke-dasharray="0 100" stroke-linecap="round"/>' +
                  '</svg>' +
                '</span>' +
              '</div>' +
            '</div>' +
          '</div>' +
        '</div></div>';

      this._syncMode();
      this._syncModel();
      this._syncTokens();
      this._syncPlan();

      var self = this;
      var ta = this.querySelector('.composer-input');
      var btnSend = this.querySelector('.btn-send');
      var btnStop = this.querySelector('.btn-stop');

      this._imeComposing = false;
      ta.addEventListener('compositionstart', function () { self._imeComposing = true; });
      ta.addEventListener('compositionend',   function () { self._imeComposing = false; });

      ta.addEventListener('keydown', function (e) {
        if (isImeComposing(e)) return;
        if (self._isSubagent) return;
        if (self._mentionResults.length > 0) {
          if (e.key === 'ArrowDown') { e.preventDefault(); self._mentionFocused = Math.min(self._mentionFocused + 1, self._mentionResults.length - 1); self._syncMentionPopup(); return; }
          if (e.key === 'ArrowUp')   { e.preventDefault(); self._mentionFocused = Math.max(self._mentionFocused - 1, 0); self._syncMentionPopup(); return; }
          if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); self._selectMention(self._mentionFocused); return; }
          if (e.key === 'Escape') { e.preventDefault(); self._closeMention(); return; }
        }
        var slashItems = self._getSlashItems();
        if (slashItems.length > 0) {
          if (e.key === 'ArrowDown') { e.preventDefault(); self._slashFocused = Math.min(self._slashFocused + 1, slashItems.length - 1); self._syncSlashPopup(); return; }
          if (e.key === 'ArrowUp')   { e.preventDefault(); self._slashFocused = Math.max(self._slashFocused - 1, 0); self._syncSlashPopup(); return; }
          if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); self._selectSlash(self._slashFocused); return; }
          if (e.key === 'Escape') { e.preventDefault(); self._slashFilter = ''; self._syncSlashPopup(); return; }
        }
        if (e.key === 'Enter' && !e.shiftKey) {
          var mod = e.ctrlKey || e.metaKey;
          var shouldSend = self._sendOnEnter ? !mod : mod;
          if (shouldSend) {
            e.preventDefault();
            self._send();
          }
        }
      });

      ta.addEventListener('input', function () {
        ta.style.height = '';
        ta.style.height = Math.min(ta.scrollHeight, 200) + 'px';
        if (self._imeComposing) return;
        self._checkMention(ta);
        self._checkSlash(ta);
      });

      ta.addEventListener('paste', function (e) {
        var items = e.clipboardData && e.clipboardData.items;
        if (!items) return;
        for (var i = 0; i < items.length; i++) {
          if (items[i].type.indexOf('image') !== -1) {
            e.preventDefault();
            window.uecp.call('paste_image', {});
            return;
          }
        }
      });

      ta.addEventListener('dragover', function (e) { e.preventDefault(); });
      ta.addEventListener('drop', function (e) {
        e.preventDefault();
        var files = e.dataTransfer && e.dataTransfer.files;
        if (!files || !files.length) return;
        for (var i = 0; i < files.length; i++) {
          (function (f) {
            var reader = new FileReader();
            reader.onload = function (ev) {
              var dataUrl = ev.target.result;
              var comma = dataUrl.indexOf(',');
              var b64 = comma >= 0 ? dataUrl.slice(comma + 1) : dataUrl;
              var mime = f.type || 'application/octet-stream';
              window.uecp.call('add_image_data', { data: b64, mime: mime });
            };
            reader.readAsDataURL(f);
          })(files[i]);
        }
      });

      btnSend.addEventListener('click', function () { self._send(); });
      btnStop.addEventListener('click', function () {
        window.uecp.call('stop_generation', {});
      });

      var btnAttach = this.querySelector('.cbtn-attach');
      if (btnAttach) btnAttach.addEventListener('click', function (e) {
        e.stopPropagation();
        self._openAttachMenu(btnAttach);
      });

      var btnMode = this.querySelector('.cbtn-mode');
      if (btnMode) btnMode.addEventListener('click', function (e) {
        e.stopPropagation();
        self._openModeMenu(btnMode);
      });

      var btnModel = this.querySelector('.cbtn-model');
      if (btnModel) btnModel.addEventListener('click', function (e) {
        e.stopPropagation();
        self._openSlotMenu(btnModel);
      });
      var btnEffort = this.querySelector('.cbtn-effort');
      if (btnEffort) btnEffort.addEventListener('click', function (e) {
        e.stopPropagation();
        self._openEffortMenu(btnEffort);
      });
      window.uecp.call('list_slots', {});

      var btnVoice = this.querySelector('.cbtn-voice');
      if (btnVoice) btnVoice.addEventListener('click', function () {
        window.uecp.call('toggle_mic', {});
      });

      var btnPlan = this.querySelector('.cbtn-plan');
      if (btnPlan) btnPlan.addEventListener('click', function () {
        window.UECP.openPlanModal();
      });

      var ringWrap = this.querySelector('.ctx-ring-wrap');
      if (ringWrap) {
        ringWrap.setAttribute('role', 'button');
        ringWrap.addEventListener('click', function (e) {
          e.stopPropagation();
          self._onRingClick();
        });
      }

      this._bindCtxNotice();

      ta.addEventListener('blur', function () {
        setTimeout(function () { if (self._mentionResults.length > 0) self._closeMention(); self._slashOpen = false; self._slashFilter = ''; self._syncSlashPopup(); }, 150);
      });

      var pick = this.querySelector('.tier-pick');
      if (pick) {
        var choose = function (idx) {
          self._tierPicked = self._tierPicked || {};
          self._tierPicked[self._activeChatId || ''] = true;
          self._chatSlotIdx = idx; self._syncModel(); self._syncTokens();
          window.uecp.call('set_slot', { slot: idx });
          self._syncTierPick();
        };
        pick.querySelector('.tier-std').addEventListener('click', function () { choose(self._standardSlotIdx()); });
        pick.querySelector('.tier-prem').addEventListener('click', function () {
          var p = self._premiumSlot(); if (p) choose(p.index);
        });
        pick.querySelector('.tier-hide').addEventListener('click', function () {
          try { localStorage.setItem('uecp.tierPick.off', '1'); } catch (e) {}
          self._syncTierPick();
        });
      }

      var bannerDismiss = this.querySelector('.banner-dismiss');
      if (bannerDismiss) {
        bannerDismiss.addEventListener('click', function () {
          self._bannerText = '';
          self._syncBanner();
        });
      }

      this._menuDocClick = function (e) {
        var m = document.getElementById('uecp-composer-menu');
        if (!m) return;
        if (m.contains(e.target)) return;
        if (self._menuAnchor && self._menuAnchor.contains(e.target)) return;
        self._closeMenu();
      };
      document.addEventListener('click', this._menuDocClick);
    }

    _send() {
      if (this._isSubagent) return;
      var ta = this.querySelector('.composer-input');
      if (!ta) return;
      var text = ta.value.trim();
      if (!text) return;
      var typed = /^\/(\S+)$/.exec(text);
      if (typed && this._runLocalSlash(typed[1])) {
        ta.value = '';
        ta.style.height = '';
        return;
      }
      window.uecp.call('send_message', Object.assign({ text: text }, this._compactFirstArgs()));
      ta.value = '';
      ta.style.height = '';
    }

    _compactFirstArgs() {
      var ac = this._autoCompact;
      if (this._thinking || !ac || !ac.enabled) return {};
      if (this._slashContext && this._slashContext.agentId) return {};
      var budget = 0;
      try { budget = this._slotBudget(this._resolvedSlot()); } catch (e) { return {}; }
      if (!(budget > 0)) return {};
      var pct = Math.min(100, Math.round(((this._tokenCount || 0) / budget) * 100));
      if (pct < ac.percent) return {};
      return { compactFirst: true, compactMode: this._compactMode || 'marker' };
    }

    _syncThinking() {
      var btnSend = this.querySelector('.btn-send');
      var btnStop = this.querySelector('.btn-stop');
      if (!btnSend || !btnStop) return;
      if (this._thinking) {
        btnSend.style.display = '';
        btnStop.style.display = '';
      } else {
        btnSend.style.display = '';
        btnStop.style.display = 'none';
      }
      btnSend.disabled = this._archived || !!this._isSubagent;
      var sendTip = this._thinking ? t('Send (picked up as it works)') : t('Send');
      btnSend.title = sendTip;
      btnSend.setAttribute('data-tip', sendTip);
      this._syncThinkStrip();
    }

    _syncThinkStrip() {
      var strip = this.querySelector('.think-strip');
      if (!strip) return;
      var chatId = this._activeChatId || '';
      if (!this._thinking) {
        strip.classList.remove('visible');
        return;
      }
      var step = strip.querySelector('.think-step');
      if (step) {
        var detail = this._thinkLabel && !/^AI is working/i.test(this._thinkLabel) ? this._thinkLabel : '';
        step.textContent = detail ? '· ' + detail : '';
      }
      strip.classList.add('visible');
    }

    _syncMode() {
      var btn = this.querySelector('.cbtn-mode');
      var lbl = this.querySelector('.cbtn-mode-label');
      if (lbl) lbl.textContent = modeLabel(this._mode);
      if (btn) btn.classList.toggle('active', this._mode !== 'chat');

      var isPlan = this._mode === 'plan';
      var composerEl = this.querySelector('.composer');
      if (composerEl) composerEl.classList.toggle('plan-mode', isPlan);
      var note = this.querySelector('.plan-mode-note');
      if (isPlan && !note) {
        note = document.createElement('div');
        note.className = 'plan-mode-note';
        note.textContent = 'Plan Mode — read-only. Ask to switch modes to build.';
        var bar = this.querySelector('.composer-bar');
        if (bar && bar.parentNode) bar.parentNode.appendChild(note);
      } else if (!isPlan && note) {
        note.parentNode.removeChild(note);
      }
    }

    _syncPlan() {
      var btn = this.querySelector('.cbtn-plan');
      var lbl = this.querySelector('.plan-chip-label');
      if (!btn || !lbl) return;
      var attached = !!this._planTitle;
      btn.classList.toggle('attached', attached);
      lbl.textContent = attached ? this._planTitle : 'Plan';
    }

    _resolvedSlot() {
      var idx = (this._chatSlotIdx >= 0) ? this._chatSlotIdx : this._slotActiveIdx;
      if (idx < 0) return null;
      return this._slots.find(function (s) { return s.index === idx; }) || null;
    }

    _slotModelName(slot, idx) {
      if (slot && slot.provider === 'Free') return 'BpLabs Standard';
      if (slot && slot.isAcp && slot.provider) return slot.provider;
      if (slot && slot.model) return slot.model;
      if (slot && slot.name) return slot.name;
      return (typeof idx === 'number' && idx >= 0) ? ('Slot ' + (idx + 1)) : 'Default';
    }

    _slotBudget(slot) {
      if (!slot) return 0;
      if (typeof slot.usableContextTokens === 'number' && slot.usableContextTokens > 0) {
        return slot.usableContextTokens;
      }
      var win = (typeof slot.contextWindowTokens === 'number' && slot.contextWindowTokens > 0)
        ? slot.contextWindowTokens : 0;
      return win > 0 ? Math.min(win, USABLE_CONTEXT_CAP) : 0;
    }

    _slotWindow(slot) {
      return (slot && typeof slot.contextWindowTokens === 'number' && slot.contextWindowTokens > 0)
        ? slot.contextWindowTokens : 0;
    }

    _premiumSlot() {
      return (this._slots || []).find(function (s) { return s.premium; }) || null;
    }

    premiumTier() {
      var p = this._premiumSlot();
      if (!p || this._suggestPremium === false) return null;
      var cur = this._resolvedSlot();
      return { index: p.index, name: p.name || '', active: !!(cur && cur.premium) };
    }

    _premiumKey() {
      var p = this.premiumTier();
      return p ? p.index + '|' + p.name + '|' + p.active : '';
    }

    _refreshOffers(before) {
      if (this._premiumKey() === before || typeof document.querySelectorAll !== 'function') return;
      var rows = document.querySelectorAll('uecp-message[data-kind="playtest"],uecp-message[data-kind="premium"],uecp-message[data-kind="premium-none"]');
      Array.prototype.forEach.call(rows, function (m) { if (m.refreshOffer) m.refreshOffer(); });
    }

    useSlotForOneTurn(idx) {
      if (this._slotRevert) return;
      this._slotRevert = { chatId: this._activeChatId, prev: this._chatSlotIdx, started: false, ended: false };
      this._chatSlotIdx = idx; this._syncModel(); this._syncTokens(); this._syncTierPick();
      window.uecp.call('set_slot', { slot: idx });
    }

    _maybeRevertSlot() {
      var r = this._slotRevert;
      if (!r || !r.ended || r.chatId !== this._activeChatId) return;
      this._slotRevert = null;
      this._chatSlotIdx = r.prev; this._syncModel(); this._syncTokens(); this._syncTierPick();
      window.uecp.call('set_slot', { slot: r.prev });
    }

    _standardSlotIdx() {
      var self = this;
      var def = (this._slots || []).find(function (s) { return s.index === self._slotActiveIdx; });
      if (def && def.provider === 'Free') return -1;
      var std = (this._slots || []).find(function (s) { return s.provider === 'Free'; });
      return std ? std.index : -1;
    }

    _syncTierPick() {
      var el = this.querySelector('.tier-pick');
      if (!el) return;
      var prem = this._premiumSlot();
      var off = false;
      try { off = localStorage.getItem('uecp.tierPick.off') === '1'; } catch (e) {}
      var picked = this._tierPicked && this._tierPicked[this._activeChatId || ''];
      var onPremium = prem && this._chatSlotIdx >= prem.index;
      if (!prem || !this._chatEmpty || off || picked || onPremium) { el.style.display = 'none'; return; }
      var b = el.querySelector('.tier-prem');
      b.textContent = prem.name || '';
      b.title = prem.usageLabel || '';
      el.style.display = '';
    }

    _syncModel() {
      var el = this.querySelector('.model-text');
      if (!el) return;
      var slot = this._resolvedSlot();
      var idx = (this._chatSlotIdx >= 0) ? this._chatSlotIdx : this._slotActiveIdx;
      el.textContent = slot ? this._slotModelName(slot, idx) : 'Default';
      var btn = this.querySelector('.cbtn-model');
      if (btn) btn.classList.toggle('override', this._chatSlotIdx >= 0);
      this._syncEffort(slot);
    }

    _effortLabel(e) {
      return ({ low: t('Low effort'), medium: t('Medium effort'), high: t('High effort'), xhigh: t('Extra high effort'), max: t('Max effort') })[e] || e;
    }

    _syncEffort(slot) {
      var chip = this.querySelector('.cbtn-effort');
      if (!chip) return;
      var on = !!(slot && slot.premium && slot.efforts && slot.efforts.length);
      chip.style.display = on ? '' : 'none';
      if (on) chip.querySelector('.effort-text').textContent = this._effortLabel(slot.effort || slot.efforts[0]);
    }

    _openEffortMenu(anchor) {
      var self = this;
      var slot = this._resolvedSlot();
      if (!slot || !slot.efforts) return;
      var hints = {
        low: t('Fastest, for quick edits'),
        medium: t('Faster, for everyday tasks'),
        high: t('Smarter on hard tasks'),
        xhigh: t('Deeper thinking on hard tasks'),
        max: t('Deepest thinking, uses tokens fastest')
      };
      var items = slot.efforts.map(function (e) {
        return {
          primary: self._effortLabel(e),
          secondary: hints[e] || '',
          active: (slot.effort || slot.efforts[0]) === e,
          onClick: function () {
            (self._slots || []).forEach(function (s) { if (s.premium && s.efforts && s.efforts.indexOf(e) >= 0) s.effort = e; });
            self._syncModel();
            window.uecp.call('set_premium_effort', { effort: e });
          }
        };
      });
      this._openMenu(anchor, items);
    }

    _syncCtxNotice(pct, known) {
      var el = this.querySelector('.ctx-notice');
      if (!el) return;

      var chatId = this._activeChatId || '';
      this._ctxDismissed = this._ctxDismissed || {};
      var show = known && pct >= 70 && !this._ctxDismissed[chatId];

      el.style.display = show ? 'flex' : 'none';
      if (!show) return;

      el.classList.toggle('danger', pct >= 90);
      var txt = el.querySelector('.ctx-notice-text');
      if (txt) {
        txt.textContent = (pct >= 90)
          ? t('This conversation is past the range this model handles well. Answers will get less reliable from here.')
          : t('This conversation is getting long. Answers get less reliable as it grows.');
      }
    }

    _bindCtxNotice() {
      var self = this;
      var el = this.querySelector('.ctx-notice');
      if (!el) return;

      var fork = el.querySelector('.ctx-act-fork');
      if (fork) fork.addEventListener('click', function () {
        self._confirmCompact('fork');
      });

      var comp = el.querySelector('.ctx-act-compact');
      if (comp) comp.addEventListener('click', function () {
        self._confirmCompact(self._compactMode || 'marker');
      });

      var hide = el.querySelector('.ctx-act-hide');
      if (hide) hide.addEventListener('click', function () {
        self._ctxDismissed = self._ctxDismissed || {};
        self._ctxDismissed[self._activeChatId || ''] = true;
        el.style.display = 'none';
      });
    }

    _onRingClick() {
      if (this._thinking) return;
      var mode = this._compactMode || 'marker';
      this._confirmCompact(mode);
    }

    _confirmCompact(mode) {
      var title, msg;
      if (mode === 'discard') {
        title = 'Compact conversation? (Discard)';
        msg = 'Compaction will replace this chat\'s full history with a single AI-generated summary. '
            + 'The on-disk transcript is overwritten too, so only the summary remains. This frees up '
            + 'context but loses the detailed message log, and can\'t be undone.\n\nProceed?';
      } else if (mode === 'fork') {
        title = 'Compact conversation? (Archive)';
        msg = 'Compaction will summarise this conversation, freeze the current chat as a read-only '
            + 'snapshot under "Archived", and continue in a new chat seeded with the summary. '
            + 'Nothing is lost; you can reopen the archive anytime.\n\nProceed?';
      } else {
        title = 'Compact conversation?';
        msg = 'Compaction will summarise the conversation and reset the context here. Your earlier '
            + 'messages stay visible as read-only history above a "Context reset" marker, but only the '
            + 'summary (plus anything sent afterwards) goes to the model from now on.\n\nProceed?';
      }
      window.UECP.dialog.confirm(title, msg).then(function (ok) {
        if (ok) window.uecp.call('compact', { mode: mode });
      });
    }

    _syncTokens() {
      var slot = this._resolvedSlot();
      this._tokenBudget = this._slotBudget(slot);
      var count = this._tokenCount || 0;
      var known = this._tokenBudget > 0;
      var pct = known ? Math.min(100, Math.round((count / this._tokenBudget) * 100)) : 0;

      var win = this._slotWindow(slot);
      var primary = known
        ? 'Context: ' + count.toLocaleString() + ' / ' + this._tokenBudget.toLocaleString() + ' (' + pct + '%)'
        : 'Context: ' + count.toLocaleString() + ' used (context window size unknown for this model)';
      if (known && win > this._tokenBudget) {
        primary += '\n' + t('Working range. This model accepts {limit}, but answers drift well before that.',
                             { limit: win.toLocaleString() });
      }
      if (!known) {
        primary += '\n' + t('Past roughly {limit} tokens it is usually worth compacting or starting a new chat.',
                             { limit: USABLE_CONTEXT_CAP.toLocaleString() });
      }
      var secondary;
      if (!known) {
        secondary = 'Click to compact this conversation.';
      } else if (this._autoCompact.enabled) {
        var remaining = Math.max(0, this._autoCompact.percent - pct);
        secondary = (pct < this._autoCompact.percent)
          ? remaining + '% of context remaining until auto-compact.\nClick to compact now.'
          : 'Auto-compact threshold reached.\nClick to compact now.';
      } else {
        secondary = 'Click to compact this conversation.';
      }
      var tip = primary + '\n\n' + secondary;

      var tok = this.querySelector('.token');
      if (tok) tok.textContent = known ? pct + '%' : '—';
      var wrap = this.querySelector('.ctx-ring-wrap');
      if (wrap) {
        wrap.setAttribute('data-tip', tip);
        wrap.classList.toggle('warn',    known && pct >= 70 && pct < 90);
        wrap.classList.toggle('danger',  known && pct >= 90);
        wrap.classList.toggle('unknown', !known);
      }
      this._syncCtxNotice(known ? pct : 0, known);

      var fill = this.querySelector('.ring-fill');
      if (fill) {
        fill.setAttribute('stroke-dasharray', (known ? pct : 0) + ' 100');
        fill.setAttribute('stroke', 'var(--ue-accent)');
      }
    }

    _closeMenu() {
      var menu = document.getElementById('uecp-composer-menu');
      if (menu && menu.parentNode) menu.parentNode.removeChild(menu);
      this._menuAnchor = null;
    }

    _openMenu(anchor, items) {
      if (document.getElementById('uecp-composer-menu')) { this._closeMenu(); return; }
      if (!anchor) return;
      var self = this;
      var menu = document.createElement('div');
      menu.id = 'uecp-composer-menu';
      menu.className = 'composer-menu';
      menu.addEventListener('click', function (e) { e.stopPropagation(); });

      items.forEach(function (it) {
        var el = document.createElement('div');
        el.className = 'cm-item' + (it.active ? ' active' : '');
        var inner = '';
        if (it.icon) inner += svg(it.icon);
        if (it.secondary) {
          inner += '<div class="cm-stack"><div>' + window.UECP.escapeHtml(it.primary) + '</div>' +
            '<div class="cm-secondary">' + window.UECP.escapeHtml(it.secondary) + '</div></div>';
        } else {
          inner += '<span>' + window.UECP.escapeHtml(it.primary) + '</span>';
        }
        el.innerHTML = inner;
        el.addEventListener('click', function () { self._closeMenu(); if (it.onClick) it.onClick(); });
        menu.appendChild(el);
      });

      document.body.appendChild(menu);
      this._menuAnchor = anchor;

      var rect = anchor.getBoundingClientRect();
      var mw = menu.offsetWidth, mh = menu.offsetHeight;
      var left = Math.max(4, Math.min(rect.left, window.innerWidth - mw - 4));
      menu.style.left = left + 'px';
      var room = Math.max(rect.top, window.innerHeight - rect.bottom) - 8;
      if (mh > room && room > 60) {
        menu.style.maxHeight = room + 'px';
        menu.style.overflowY = 'auto';
        mh = room;
      }
      var spaceBelow = window.innerHeight - rect.bottom - 4;
      menu.style.top = (spaceBelow < mh)
        ? Math.max(4, rect.top - mh - 4) + 'px'
        : (rect.bottom + 4) + 'px';
    }

    _openAttachMenu(anchor) {
      this._openMenu(anchor, [
        { primary: 'Image',  icon: IC.image,  onClick: function () { window.uecp.call('attach_image', {}); } },
        { primary: 'File',   icon: IC.file,   onClick: function () { window.uecp.call('import_file', {}); } },
        { primary: 'Plugin', icon: IC.plugin, onClick: function () { window.uecp.call('analyze_plugin', {}); } }
      ]);
    }

    _openModeMenu(anchor) {
      var self = this;
      var items = MODES.map(function (m) {
        return {
          primary: modeLabel(m.id),
          active: self._mode === m.id,
          onClick: function () {
            self._mode = m.id;
            self._syncMode();
            window.uecp.call('set_mode', { mode: m.id });
          }
        };
      });
      this._openMenu(anchor, items);
    }

    _openSlotMenu(anchor) {
      var self = this;
      var items = [];
      var defSlot = this._slots.find(function (s) { return s.index === self._slotActiveIdx; }) || null;
      var defModel = defSlot ? this._slotModelName(defSlot, this._slotActiveIdx) : '';
      items.push({
        primary: 'Use Default',
        secondary: defModel || '',
        active: this._chatSlotIdx < 0,
        onClick: function () {
          self._chatSlotIdx = -1; self._syncModel(); self._syncTokens();
          window.uecp.call('set_slot', { slot: -1 });
        }
      });
      if (this._slots.length) {
        this._slots.forEach(function (s) {
          var primary = self._slotModelName(s, s.index);
          var label = s.premium ? (s.usageLabel || '') : ('Slot ' + (s.index + 1) + (s.name ? ' · ' + s.name : ''));
          items.push({
            primary: primary,
            secondary: label,
            active: self._chatSlotIdx === s.index,
            onClick: function () {
              self._chatSlotIdx = s.index; self._syncModel(); self._syncTokens();
              window.uecp.call('set_slot', { slot: s.index });
            }
          });
        });
      } else {
        items.push({ primary: 'No slots configured', secondary: 'Add one in Settings → API Keys', onClick: function () {} });
      }
      this._openMenu(anchor, items);
    }

    _syncQueue() {
      var row = this.querySelector('.queue-row');
      if (!row) return;
      if (!this._queueCount) { row.style.display = 'none'; row.innerHTML = ''; return; }
      var html = '';
      var previews = this._queuePreviews;
      for (var i = 0; i < previews.length; i++) {
        html += '<span class="queue-chip">' +
          window.UECP.escapeHtml(previews[i]) +
          '<span class="chip-x" data-qi="' + i + '">×</span>' +
          '</span>';
      }
      row.innerHTML = html;
      row.style.display = '';
      row.querySelectorAll('.chip-x').forEach(function (x) {
        x.addEventListener('click', function () {
          window.uecp.call('remove_queued', { index: parseInt(x.dataset.qi, 10) });
        });
      });
    }

    _syncAttachments() {
      var row = this.querySelector('.attach-row');
      if (!row) return;
      var images = this._images || [];
      var files = this._files || [];
      if (!images.length && !files.length) { row.style.display = 'none'; row.innerHTML = ''; return; }
      var html = '';
      for (var i = 0; i < images.length; i++) {
        var name = window.UECP.escapeHtml(images[i].name || ('image ' + (i + 1)));
        html += '<span class="attach-chip" title="' + name + '">' +
          '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="18" x="3" y="3" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.1-3.1a2 2 0 0 0-2.8 0L6 21"/></svg>' +
          '<span>' + name + '</span>' +
          '<span class="chip-x" data-img-i="' + i + '">×</span>' +
          '</span>';
      }
      for (var j = 0; j < files.length; j++) {
        var fname = window.UECP.escapeHtml(files[j].name || files[j].fileName || ('file ' + (j + 1)));
        var chars = files[j].chars || files[j].charCount || 0;
        html += '<span class="attach-chip" title="' + fname + (chars ? ' (' + chars + ' chars)' : '') + '">' +
          '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>' +
          '<span>' + fname + '</span>' +
          '<span class="chip-x" data-file-j="' + j + '">×</span>' +
          '</span>';
      }
      row.innerHTML = html;
      row.style.display = '';
      row.querySelectorAll('[data-img-i]').forEach(function (x) {
        x.addEventListener('click', function () {
          window.uecp.call('remove_image', { index: parseInt(x.dataset.imgI, 10) });
        });
      });
      row.querySelectorAll('[data-file-j]').forEach(function (x) {
        x.addEventListener('click', function () {
          window.uecp.call('remove_file', { index: parseInt(x.dataset.fileJ, 10) });
        });
      });
    }

    _checkMention(ta) {
      var val = ta.value;
      var pos = ta.selectionStart;
      var at = val.lastIndexOf('@', pos - 1);
      if (at === -1 || (at > 0 && !/\s/.test(val[at - 1]))) {
        if (this._mentionResults.length > 0) this._closeMention();
        return;
      }
      var q = val.slice(at + 1, pos);
      if (/\s/.test(q)) { this._closeMention(); return; }
      this._mentionAt = at;
      window.uecp.call('search_assets', { query: q });
    }

    _syncMentionPopup() {
      var popup = this.querySelector('.mention-popup');
      if (!popup) return;
      var results = this._mentionResults;
      if (!results.length) { popup.style.display = 'none'; popup.innerHTML = ''; return; }
      var html = '';
      for (var i = 0; i < results.length; i++) {
        var r = results[i];
        var cls = (i === this._mentionFocused) ? 'mention-item focused' : 'mention-item';
        html += '<div class="' + cls + '" data-mi="' + i + '">' +
          '<span>' + window.UECP.escapeHtml(r.name || '') + '</span>' +
          '<span class="mi-class">' + window.UECP.escapeHtml(r.class || '') + '</span>' +
          '</div>';
      }
      popup.innerHTML = html;
      popup.style.display = '';
      var self = this;
      popup.querySelectorAll('.mention-item').forEach(function (el) {
        el.addEventListener('mousedown', function (e) {
          e.preventDefault();
          self._selectMention(parseInt(el.dataset.mi, 10));
        });
      });
    }

    _selectMention(idx) {
      var r = this._mentionResults[idx];
      if (!r) { this._closeMention(); return; }
      window.uecp.call('select_asset', { path: r.path, name: r.name, class: r.class });
      var ta = this.querySelector('.composer-input');
      if (ta && this._mentionAt != null) {
        var val = ta.value;
        var pos = ta.selectionStart;
        ta.value = val.slice(0, this._mentionAt) + '@' + r.name + val.slice(pos);
        var newPos = this._mentionAt + 1 + r.name.length;
        ta.setSelectionRange(newPos, newPos);
      }
      this._closeMention();
    }

    _closeMention() {
      this._mentionResults = [];
      this._mentionFocused = -1;
      this._syncMentionPopup();
      window.uecp.call('dismiss_picker', {});
    }

    _getSlashItems() {
      var ta = this.querySelector('.composer-input');
      if (!ta) return [];
      var filter = (this._slashFilter || '').replace(/^\//, '').toLowerCase();
      if (!this._slashOpen) return [];
      var items = BUILTIN_SLASH.slice();
      var ctx = this._slashContext;
      if (ctx && ctx.agentId && this._slashCommands[ctx.agentId]) {
        var cmds = this._slashCommands[ctx.agentId];
        for (var i = 0; i < cmds.length; i++) {
          var name = cmds[i].name || cmds[i];
          var isBuiltinDupe = items.some(function (it) { return it.name.toLowerCase() === String(name).toLowerCase(); });
          if (!isBuiltinDupe) items.push({ name: name, desc: cmds[i].description || '' });
        }
      }
      if (filter) {
        items = items.filter(function (it) { return it.name.toLowerCase().indexOf(filter) === 0; });
      }
      return items;
    }

    _checkSlash(ta) {
      var val = ta.value;
      var pos = ta.selectionStart;
      var lineStart = val.lastIndexOf('\n', pos - 1) + 1;
      var lineVal = val.slice(lineStart, pos);
      if (lineVal === '/' || (lineVal.length > 1 && lineVal[0] === '/' && !/\s/.test(lineVal))) {
        this._slashOpen = true;
        this._slashFilter = lineVal;
        this._slashFocused = 0;
        this._syncSlashPopup();
      } else {
        this._slashOpen = false;
        this._slashFilter = '';
        this._syncSlashPopup();
      }
    }

    _syncSlashPopup() {
      var popup = this.querySelector('.slash-popup');
      if (!popup) return;
      var items = this._getSlashItems();
      if (!items.length) { popup.style.display = 'none'; popup.innerHTML = ''; return; }
      var html = '';
      for (var i = 0; i < items.length; i++) {
        var it = items[i];
        var cls = (i === this._slashFocused) ? 'slash-item focused' : 'slash-item';
        html += '<div class="' + cls + '" data-si="' + i + '">' +
          '<span>/' + window.UECP.escapeHtml(it.name) + '</span>' +
          (it.desc ? '<span class="si-desc">' + window.UECP.escapeHtml(it.desc) + '</span>' : '') +
          '</div>';
      }
      popup.innerHTML = html;
      popup.style.display = '';
      var self = this;
      popup.querySelectorAll('.slash-item').forEach(function (el) {
        el.addEventListener('mousedown', function (e) {
          e.preventDefault();
          self._selectSlash(parseInt(el.dataset.si, 10));
        });
      });
    }

    _selectSlash(idx) {
      var items = this._getSlashItems();
      var it = items[idx];
      if (!it) { this._slashOpen = false; this._syncSlashPopup(); return; }
      var ta = this.querySelector('.composer-input');
      if (it.name === 'login') {
        window.uecp.call('login_agent', { name: '' });
      } else if (this._runLocalSlash(it.name)) {
        this._clearSlashToken(ta);
      } else {
        if (ta) {
          var pos = ta.selectionStart;
          var lineStart = ta.value.lastIndexOf('\n', pos - 1) + 1;
          var insertText = '/' + it.name;
          ta.value = ta.value.slice(0, lineStart) + insertText + ' ' + ta.value.slice(pos);
          var np = lineStart + insertText.length + 1;
          ta.setSelectionRange(np, np);
        }
      }
      this._slashOpen = false;
      this._slashFilter = '';
      this._syncSlashPopup();
    }

    _runLocalSlash(name) {
      var cmd = String(name || '').toLowerCase();
      var isAgentChat = !!(this._slashContext && this._slashContext.agentId);
      if (cmd === 'compact' && !isAgentChat) {
        this._confirmCompact(this._compactMode || 'marker');
        return true;
      }
      if (cmd === 'delete') {
        var btns = document.querySelectorAll('uecp-thread uecp-message .msg-delete');
        if (btns.length) btns[btns.length - 1].click();
        return true;
      }
      return false;
    }

    _clearSlashToken(ta) {
      if (!ta) return;
      var pos = ta.selectionStart;
      var lineStart = ta.value.lastIndexOf('\n', pos - 1) + 1;
      var lineEnd = ta.value.indexOf('\n', pos);
      if (lineEnd < 0) lineEnd = ta.value.length;
      var line = ta.value.slice(lineStart, lineEnd);
      var rest = line.replace(/^\/\S*\s?/, '');
      ta.value = ta.value.slice(0, lineStart) + rest + ta.value.slice(lineEnd);
      ta.setSelectionRange(lineStart, lineStart);
    }

    _syncVoiceVisible() {
      var btn = this.querySelector('.cbtn-voice');
      if (btn) btn.style.display = this._voiceEnabled ? '' : 'none';
    }

    _syncVoice() {
      var btn = this.querySelector('.cbtn-voice');
      if (!btn) return;
      btn.setAttribute('aria-pressed', this._recording ? 'true' : 'false');
      if (this._recording) {
        btn.classList.add('recording');
        btn.title = 'Recording…'; btn.setAttribute('data-tip', 'Recording…');
      } else {
        btn.classList.remove('recording');
        btn.title = 'Voice'; btn.setAttribute('data-tip', 'Voice');
      }
    }

    _syncBanner() {
      var banner = this.querySelector('.composer-banner');
      if (!banner) return;
      var text = this.querySelector('.banner-text');
      if (!this._bannerText) {
        banner.classList.remove('visible');
        if (text) text.textContent = '';
        return;
      }
      if (text) text.textContent = this._bannerText;
      banner.classList.add('visible');
    }

    _syncPlaceholder() {
      var ta = this.querySelector('.composer-input');
      if (!ta) return;
      var src = this._isSubagent ? 'Read-only: subagent run transcript'
        : this._archived ? 'This chat is archived (read-only)'
        : 'Describe what you want me to build…';
      ta.placeholder = t(src);
      (ta.__i18nAttrSrc || (ta.__i18nAttrSrc = {})).placeholder = src;
    }

    _syncArchived() {
      var ta      = this.querySelector('.composer-input');
      var btnSend = this.querySelector('.btn-send');
      if (ta)      ta.disabled       = this._archived;
      this._syncPlaceholder();
      if (btnSend) btnSend.disabled  = this._archived;

      var existing = this.querySelector('.archived-note');
      if (this._archived && !existing) {
        var note = document.createElement('div');
        note.className = 'archived-note';
        note.style.cssText = 'padding:4px 0 2px;font-family:var(--ue-font-mono);font-size:10.5px;color:var(--ue-text-lo);text-align:center';
        note.textContent = 'Archived — read-only';
        var bar = this.querySelector('.composer-bar');
        if (bar && bar.parentNode) bar.parentNode.appendChild(note);
      } else if (!this._archived && existing) {
        existing.parentNode.removeChild(existing);
      }
    }

    _syncReadOnly() {
      var ro = !!this._isSubagent;
      var ta      = this.querySelector('.composer-input');
      var btnSend = this.querySelector('.btn-send');
      if (ta) ta.disabled = ro || this._archived;
      this._syncPlaceholder();
      if (btnSend) { btnSend.disabled = ro || this._archived; }
      this.classList.toggle('readonly', ro);
    }

    prefill(text) {
      var ta = this.querySelector('.composer-input');
      if (ta) { ta.value = text; ta.focus(); }
    }
  }
  customElements.define('uecp-composer', UecpComposer);
})();
