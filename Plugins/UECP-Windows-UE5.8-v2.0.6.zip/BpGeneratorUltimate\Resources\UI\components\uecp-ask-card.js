(function () {
  if (!document.getElementById('uecp-ask-card-css')) {
    const s = document.createElement('style'); s.id = 'uecp-ask-card-css';
    s.textContent = `
uecp-ask-card{display:none;background:var(--ue-panel);border:1px solid var(--ue-line);border-radius:var(--ue-r-md);padding:16px;margin:8px 0;box-shadow:0 4px 24px rgba(0,0,0,.3);box-sizing:border-box;height:460px}
uecp-ask-card.visible{display:flex;flex-direction:column}
uecp-ask-card .ask-header{font-family:var(--ue-font-mono);font-size:10px;font-weight:var(--ue-fw-semi);letter-spacing:.13em;color:var(--ue-text-lo);margin-bottom:10px;flex-shrink:0}
uecp-ask-card .ask-tabs{flex-wrap:wrap;margin-bottom:12px;flex-shrink:0}
/* flex:1 + overflow-y:auto (not min-height) so the CARD'S OVERALL height stays fixed
   (set once on uecp-ask-card itself, above) no matter how long a question/option list
   gets — switching tabs or hitting a longer question scrolls this region instead of
   resizing the card. min-height:0 overrides flexbox's default min-height:auto, which
   would otherwise size this to fit its content and defeat the fixed outer height. */
uecp-ask-card .ask-question{margin-bottom:14px;flex:1;min-height:0;overflow-y:auto}
uecp-ask-card .ask-q-label{font-size:13.5px;font-weight:var(--ue-fw-medium);color:var(--ue-text-hi);margin-bottom:8px}
uecp-ask-card .ask-q-sub{font-size:12.5px;color:var(--ue-text-mid);margin-bottom:8px}
uecp-ask-card .ask-options{display:flex;flex-direction:column;gap:5px}
uecp-ask-card .ask-option{display:flex;align-items:center;gap:8px;padding:7px 10px;border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);cursor:pointer;font-size:12.5px;color:var(--ue-text-mid)}
uecp-ask-card .ask-option:hover{border-color:var(--ue-accent)}
uecp-ask-card .ask-option.selected{border-color:var(--ue-accent);color:var(--ue-accent-bright);background:var(--ue-accent-soft)}
uecp-ask-card .ask-option-other{font-style:italic;border-style:dashed}
uecp-ask-card .ask-text-input{width:100%;box-sizing:border-box;background:var(--ue-bg);border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);padding:8px 10px;font-family:var(--ue-font-sans);font-size:13px;color:var(--ue-text-hi);outline:none;resize:vertical;margin-top:8px}
uecp-ask-card .ask-text-input::placeholder{color:var(--ue-text-lo)}
uecp-ask-card .ask-text-input:focus{border-color:var(--ue-accent)}
uecp-ask-card .ask-feedback{margin-top:4px;padding-top:12px;border-top:1px solid var(--ue-line-soft);flex-shrink:0}
uecp-ask-card .ask-feedback .ask-text-input{margin-top:0}
uecp-ask-card .ask-actions{display:flex;justify-content:flex-end;gap:8px;margin-top:14px;flex-shrink:0}
uecp-ask-card .btn-submit{padding:8px 18px;background:linear-gradient(150deg,var(--ue-accent),var(--ue-accent-deep));color:var(--ue-on-accent);border:none;border-radius:var(--ue-r-sm);font-size:12.5px;font-weight:var(--ue-fw-semi);cursor:pointer}
uecp-ask-card .btn-skip{padding:8px 14px;background:transparent;color:var(--ue-text-mid);border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);font-size:12.5px;cursor:pointer}`;
    document.head.appendChild(s);
  }

  function truncate(s, n) {
    s = String(s == null ? '' : s);
    return s.length > n ? s.slice(0, n - 1) + '…' : s;
  }

  class UecpAskCard extends HTMLElement {
    connectedCallback() {
      this._questions = [];
      this._questionsRef = null;
      this._currentIndex = 0;
      this._answers = [];
      this._feedback = '';
      this._allowSkip = true;
      this._allowOther = true;
      this._allowFeedback = true;
      this._activeChatId = (window.UECP && window.UECP.activeChatId) || '';
      const self = this;
      this._unsubRegistry = window.UECP.askRegistry.onChange(function () { self._reevaluate(); });
      this._unsubViewstate = window.uecp.on('chat.viewstate', function (d) {
        if (!d || !d.chatId) return;
        self._activeChatId = d.chatId;
        self._reevaluate();
      });
      this._reevaluate();
    }

    disconnectedCallback() {
      if (this._unsubRegistry) { this._unsubRegistry(); this._unsubRegistry = null; }
      if (this._unsubViewstate) { this._unsubViewstate(); this._unsubViewstate = null; }
    }

    _reevaluate() {
      const entry = window.UECP.askRegistry.get(this._activeChatId);
      if (!entry) { this.classList.remove('visible'); this.innerHTML = ''; this._questionsRef = null; return; }

      this._allowSkip = entry.allowSkip !== false;
      this._allowOther = entry.allowOther !== false;
      this._allowFeedback = entry.allowFeedback !== false;

      if (entry.questions !== this._questionsRef) {
        this._questionsRef = entry.questions;
        this._questions = entry.questions;
        this._currentIndex = 0;
        this._answers = this._questions.map(function () { return { selected: [], other: '', otherSelected: false }; });
        this._feedback = '';
      }

      this._render();
      this.classList.add('visible');
    }

    _ans(qi) {
      if (!this._answers[qi]) this._answers[qi] = { selected: [], other: '', otherSelected: false };
      return this._answers[qi];
    }

    _render() {
      const qs = this._questions;
      const self = this;
      const E = window.UECP.escapeHtml;
      const showTabs = qs.length > 1;
      const qi = Math.min(this._currentIndex, Math.max(qs.length - 1, 0));
      const isLast = qi >= qs.length - 1;
      const q = qs[qi] || {};
      const ans = this._ans(qi);

      let headerHtml;
      if (showTabs) {
        headerHtml = '<div class="ask-header">QUESTIONS · ' + (qi + 1) + '/' + qs.length + '</div>' +
          '<div class="tabs ask-tabs">' +
          qs.map(function (qq, i) {
            const label = qq.header ? truncate(qq.header, 18) : ('Q' + (i + 1));
            return '<span class="' + (i === qi ? 'active' : '') + '" data-tab-qi="' + i + '">' + E(label) + '</span>';
          }).join('') +
          '</div>';
      } else {
        headerHtml = '<div class="ask-header">QUESTION</div>';
      }

      const header = q.header ? '<div class="ask-q-label" data-i18n-skip>' + E(q.header) + '</div>' : '';
      const sub = q.question ? '<div class="ask-q-sub" data-i18n-skip>' + E(q.question) + '</div>' : '';

      let bodyHtml = '';
      if (q.options && q.options.length) {
        bodyHtml = '<div class="ask-options">' +
          q.options.map(function (opt, oi) {
            const sel = ans.selected.indexOf(oi) >= 0;
            return '<div class="ask-option' + (sel ? ' selected' : '') + '" data-oi="' + oi + '">' +
              E(opt.label || String(opt)) + '</div>';
          }).join('') +
          (self._allowOther
            ? '<div class="ask-option ask-option-other' + (ans.otherSelected ? ' selected' : '') + '" data-oi="other">Other…</div>'
            : '') +
        '</div>';
        if (ans.otherSelected) {
          bodyHtml += '<textarea class="ask-text-input ask-other-input" rows="2" placeholder="Type your own answer…">' + E(ans.other) + '</textarea>';
        }
      } else {
        bodyHtml = '<textarea class="ask-text-input ask-freetext-input" rows="3" placeholder="Type your answer…">' + E(ans.other) + '</textarea>';
      }

      const feedbackHtml = this._allowFeedback
        ? '<div class="ask-feedback"><textarea class="ask-text-input" id="ask-feedback-input" rows="2" placeholder="Anything else to add? (optional)">' + E(this._feedback) + '</textarea></div>'
        : '';

      this.innerHTML =
        headerHtml +
        '<div class="ask-question">' + header + sub + bodyHtml + '</div>' +
        feedbackHtml +
        '<div class="ask-actions">' +
          (this._allowSkip ? '<button class="btn-skip">Skip</button>' : '') +
          '<button class="btn-submit">' + (isLast ? 'Submit' : 'Next') + '</button>' +
        '</div>';

      this.querySelectorAll('.ask-tabs [data-tab-qi]').forEach(function (el) {
        el.addEventListener('click', function () {
          self._currentIndex = parseInt(el.dataset.tabQi, 10) || 0;
          self._render();
        });
      });

      const multi = !!q.multiSelect;
      this.querySelectorAll('.ask-option').forEach(function (el) {
        el.addEventListener('click', function () {
          const oiAttr = el.dataset.oi;
          if (oiAttr === 'other') {
            ans.otherSelected = !ans.otherSelected;
            if (!multi && ans.otherSelected) ans.selected = [];
          } else {
            const oi = parseInt(oiAttr, 10);
            const idx = ans.selected.indexOf(oi);
            if (multi) {
              if (idx >= 0) ans.selected.splice(idx, 1); else ans.selected.push(oi);
            } else {
              ans.selected = (idx >= 0) ? [] : [oi];
              ans.otherSelected = false;
            }
          }
          self._render();
        });
      });

      const otherInput = this.querySelector('.ask-other-input, .ask-freetext-input');
      if (otherInput) {
        otherInput.addEventListener('input', function () { ans.other = otherInput.value; });
      }
      const feedbackInput = this.querySelector('#ask-feedback-input');
      if (feedbackInput) {
        feedbackInput.addEventListener('input', function () { self._feedback = feedbackInput.value; });
      }

      this.querySelector('.btn-submit').addEventListener('click', function () { self._advanceOrSubmit(); });
      const skipBtn = this.querySelector('.btn-skip');
      if (skipBtn) skipBtn.addEventListener('click', function () { self._skip(); });
    }

    _buildAnswers() {
      return this._questions.map(function (q, qi) {
        const ans = this._ans(qi);
        const entry = { header: q.header || q.question || '' };
        if (q.options && q.options.length) {
          const labels = ans.selected.map(function (oi) {
            const opt = q.options[oi];
            return opt ? (opt.label || String(opt)) : null;
          }).filter(Boolean);
          if (labels.length) entry.selected = labels;
        }
        const customText = (ans.other || '').trim();
        if (customText) entry.custom_text = customText;
        return entry;
      }.bind(this));
    }

    _advanceOrSubmit() {
      if (this._currentIndex < this._questions.length - 1) {
        this._currentIndex += 1;
        this._render();
        return;
      }
      this._submit();
    }

    _submit() {
      const payload = { answers: this._buildAnswers(), feedback: (this._feedback || '').trim(), skipped: false };
      window.uecp.call('answer_questions', { answer: JSON.stringify(payload) });
      this._hide();
    }

    _skip() {
      window.uecp.call('answer_questions', { answer: JSON.stringify({ answers: [], feedback: '', skipped: true }) });
      this._hide();
    }

    _hide() {
      this.classList.remove('visible');
      this.innerHTML = '';
    }
  }
  customElements.define('uecp-ask-card', UecpAskCard);
})();
