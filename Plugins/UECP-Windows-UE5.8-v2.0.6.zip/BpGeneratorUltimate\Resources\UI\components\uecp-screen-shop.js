(function () {
  const CATALOGUE_URL = 'https://www.gamedevcore.com/api/plugin/catalogue';
  const CACHE_KEY = 'uecp.shop.catalogue';

  const t = function (key, vars) {
    if (window.uecp && typeof window.uecp.t === 'function') return window.uecp.t(key, vars);
    let out = String(key);
    if (vars) Object.keys(vars).forEach(function (k) {
      out = out.replace(new RegExp('\\{' + k + '\\}', 'g'), String(vars[k]));
    });
    return out;
  };

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function fmtTokens(n) {
    n = Number(n) || 0;
    if (n >= 1000000) return (n / 1000000).toFixed(n % 1000000 === 0 ? 0 : 1).replace(/\.0$/, '') + 'M';
    if (n >= 1000) return Math.round(n / 1000) + 'K';
    return String(n);
  }

  function perMillion(price, tokens) {
    const p = Number(price), m = Number(tokens) / 1000000;
    if (!isFinite(p) || !m) return '';
    return '$' + (p / m).toFixed(2) + ' / 1M';
  }

  if (!document.getElementById('uecp-screen-shop-css')) {
    const s = document.createElement('style'); s.id = 'uecp-screen-shop-css';
    s.textContent = [
'uecp-screen-shop{display:flex;flex:1;min-width:0;min-height:0;flex-direction:column;background:var(--ue-bg);overflow-y:auto;padding:22px 26px}',
'uecp-screen-shop .sh-h1{font-size:19px;font-weight:var(--ue-fw-semi);color:var(--ue-text-hi);margin:0 0 4px}',
'uecp-screen-shop .sh-sub{font-size:12.5px;color:var(--ue-text-mid);margin:0 0 18px}',
'uecp-screen-shop .sh-note{border-left:3px solid var(--ue-accent);background:var(--ue-accent-soft);border-radius:0 var(--ue-r-lg) var(--ue-r-lg) 0;padding:13px 16px;margin:0 0 22px}',
'uecp-screen-shop .sh-note h3{margin:0 0 6px;font-size:13px;font-weight:var(--ue-fw-semi);color:var(--ue-accent-bright)}',
'uecp-screen-shop .sh-note p{margin:0 0 5px;font-size:12.5px;line-height:1.55;color:var(--ue-text-mid)}',
'uecp-screen-shop .sh-note p:last-child{margin-bottom:0}',
'uecp-screen-shop .sh-note b{color:var(--ue-text-hi)}',
'uecp-screen-shop .sh-sec{font-size:11px;text-transform:uppercase;letter-spacing:.06em;color:var(--ue-text-lo);font-weight:700;margin:0 0 10px}',
'uecp-screen-shop .sh-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(190px,1fr));gap:12px;margin:0 0 26px}',
'uecp-screen-shop .sh-card{background:var(--ue-panel);border:1px solid var(--ue-line);border-radius:var(--ue-r-lg);padding:15px 16px;display:flex;flex-direction:column;gap:3px;position:relative}',
'uecp-screen-shop .sh-card.hot{border-color:var(--ue-accent)}',
'uecp-screen-shop .sh-tag{position:absolute;top:-8px;right:12px;background:var(--ue-accent);color:var(--ue-on-accent);font-size:9.5px;font-weight:700;letter-spacing:.04em;text-transform:uppercase;border-radius:999px;padding:2px 8px}',
'uecp-screen-shop .sh-name{font-size:13px;font-weight:var(--ue-fw-semi);color:var(--ue-text-hi)}',
'uecp-screen-shop .sh-price{font-size:22px;font-weight:600;color:var(--ue-text-hi);font-family:var(--ue-font-mono)}',
'uecp-screen-shop .sh-tokens{font-size:12.5px;color:var(--ue-accent-bright);font-weight:var(--ue-fw-semi)}',
'uecp-screen-shop .sh-rate{font-size:11px;color:var(--ue-text-lo);font-family:var(--ue-font-mono)}',
'uecp-screen-shop .sh-feat{list-style:none;margin:8px 0 0;padding:0}',
'uecp-screen-shop .sh-feat li{font-size:12px;color:var(--ue-text-mid);line-height:1.5;padding-left:14px;position:relative}',
'uecp-screen-shop .sh-feat li::before{content:"";position:absolute;left:2px;top:7px;width:4px;height:4px;border-radius:50%;background:var(--ue-accent)}',
'uecp-screen-shop .sh-buy{margin-top:12px}',
'uecp-screen-shop .sh-state{padding:30px 4px;color:var(--ue-text-mid);font-size:12.5px}',
'uecp-screen-shop .sh-retry{margin-top:10px}',
'uecp-screen-shop .sh-guide{border:1px solid var(--ue-line);border-radius:var(--ue-r-lg);margin:0 0 24px;overflow:hidden;flex-shrink:0}',
'uecp-screen-shop .sh-guide>summary{cursor:pointer;list-style:none;padding:13px 16px;font-size:13px;font-weight:var(--ue-fw-semi);color:var(--ue-text-hi);background:var(--ue-panel);display:flex;align-items:center;gap:9px}',
'uecp-screen-shop .sh-guide>summary::-webkit-details-marker{display:none}',
'uecp-screen-shop .sh-guide>summary::before{content:"\\25B8";color:var(--ue-text-lo);font-size:11px;transition:transform .15s}',
'uecp-screen-shop .sh-guide[open]>summary::before{transform:rotate(90deg)}',
'uecp-screen-shop .sh-guide-in{padding:4px 16px 16px}',
'uecp-screen-shop .sh-guide-sub{font-size:12px;color:var(--ue-text-mid);line-height:1.55;margin:6px 0 14px}',
'uecp-screen-shop .sh-guide table{width:100%;border-collapse:collapse;margin:0 0 18px;font-size:12px}',
'uecp-screen-shop .sh-guide th{text-align:left;font-size:10.5px;text-transform:uppercase;letter-spacing:.05em;color:var(--ue-text-lo);font-weight:700;padding:0 10px 6px 0;border-bottom:1px solid var(--ue-line)}',
'uecp-screen-shop .sh-guide th.n,uecp-screen-shop .sh-guide td.n{text-align:right;white-space:nowrap}',
'uecp-screen-shop .sh-guide td{padding:7px 10px 7px 0;color:var(--ue-text-mid);border-bottom:1px solid var(--ue-line)}',
'uecp-screen-shop .sh-guide td.n{font-family:var(--ue-font-mono);color:var(--ue-text-hi)}',
'uecp-screen-shop .sh-guide-foot{font-size:11.5px;color:var(--ue-text-lo);line-height:1.55;margin:2px 0 0}'
    ].join('\n');
    document.head.appendChild(s);
  }

  class ShopScreen extends HTMLElement {
    connectedCallback() {
      this._data = this._readCache();
      this._error = '';
      this._build();
      this._render();
      this._load();

      const self = this;
      this.addEventListener('click', function (ev) {
        const el = (ev.target && ev.target.closest) ? ev.target.closest('[data-href]') : null;
        if (el) {
          if (ev.preventDefault) ev.preventDefault();
          const url = el.getAttribute('data-href');
          if (url && window.uecp && window.uecp.call) window.uecp.call('open_external_url', { url: url });
          return;
        }
        if (ev.target && ev.target.closest && ev.target.closest('[data-act="retry"]')) {
          self._error = ''; self._render(); self._load();
        }
      });
    }

    _readCache() {
      try {
        const raw = localStorage.getItem(CACHE_KEY);
        return raw ? JSON.parse(raw) : null;
      } catch (e) { return null; }
    }
    _writeCache(d) {
      try { localStorage.setItem(CACHE_KEY, JSON.stringify(d)); } catch (e) {  }
    }

    _load() {
      const self = this;
      if (typeof fetch !== 'function') { this._fail('no-fetch'); return; }
      fetch(CATALOGUE_URL, { cache: 'no-cache' })
        .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
        .then(function (d) {
          if (!d || (!Array.isArray(d.packs) && !Array.isArray(d.plans))) {
            throw new Error('bad-payload');
          }
          self._data = d; self._error = ''; self._writeCache(d); self._render();
        })
        .catch(function (e) { self._fail(String(e && e.message ? e.message : e)); });
    }

    _fail(reason) {
      if (console && console.warn) console.warn('[shop] catalogue unavailable:', reason);
      if (!this._data) { this._error = '1'; this._render(); }
    }

    _build() {
      this.innerHTML =
        '<div class="sh-h1">' + esc(t('Get more tokens')) + '</div>' +
        '<div class="sh-sub">' + esc(t('Buying opens your browser. Nothing is charged inside the editor.')) + '</div>' +
        '<div class="sh-note">' +
          '<h3>' + esc(t('Packs are separate from your free allowance')) + '</h3>' +
          '<p>' + esc(t('The free allowance is small and resets on its own schedule.')) + '</p>' +
          '<p>' + esc(t('Pack tokens never expire, and are only spent once the free allowance runs out. Buying a pack does not change your free allowance, it sits on top of it.')) + '</p>' +
        '</div>' +
        this._costGuideHtml() +
        '<div class="sh-body"></div>';
    }

    _costGuideHtml() {
      var rowsAI = [
        [t('Change values or a small edit'),            '0.05-0.3M', '0.15-0.9M'],
        [t('Small new Blueprint, one mechanic'),        '0.3-1M',    '0.9-3M'],
        [t('Add a feature to existing logic'),          '0.4-1M',    '1.2-3M'],
        [t('A whole system (inventory, save, ability)'),'3-5M',      '9-15M']
      ];
      var rowsAsset = [
        [t('3D model (standard)'),        '~4.6M'],
        [t('3D model (high quality)'),    '~9M'],
        [t('Texture or image'),           '0.3-0.9M'],
        [t('Rig or animate a model'),     '~2.8M'],
        [t('Retexture or retopo'),        '1-2M'],
        [t('Sound effect'),               '~1.2M'],
        [t('Voice (per 1,000 characters)'),'0.5-1M'],
        [t('Music (per minute)'),         '~1.5M'],
        [t('Video (per second)'),         '~0.56M']
      ];
      var ai = rowsAI.map(function (r) {
        return '<tr><td>' + esc(r[0]) + '</td><td class="n">' + r[1] + '</td><td class="n">' + r[2] + '</td></tr>';
      }).join('');
      var as = rowsAsset.map(function (r) {
        return '<tr><td>' + esc(r[0]) + '</td><td class="n">' + r[1] + '</td></tr>';
      }).join('');
      return '<details class="sh-guide">' +
        '<summary>' + esc(t('What things cost (rough guide)')) + '</summary>' +
        '<div class="sh-guide-in">' +
          '<div class="sh-guide-sub">' + esc(t('Rough token ranges, not a bill. Real cost scales with how big the task is.')) + '</div>' +
          '<div class="sh-sec">' + esc(t('AI generation (Blueprints, systems, code)')) + '</div>' +
          '<table><tr><th>' + esc(t('Task')) + '</th><th class="n">' + esc(t('Standard')) + '</th><th class="n">' + esc(t('Premium ~3x')) + '</th></tr>' + ai + '</table>' +
          '<div class="sh-sec">' + esc(t('Asset generation (same on any plan)')) + '</div>' +
          '<table><tr><th>' + esc(t('Asset')) + '</th><th class="n">' + esc(t('Tokens')) + '</th></tr>' + as + '</table>' +
          '<div class="sh-guide-foot">' + esc(t('A single message over about 1M tokens pauses partway, with buttons to carry on or raise the limit. Premium is a smarter model for hard tasks and uses about 2.5-3.5x the tokens. Asset generation costs the same whichever plan you are on.')) + '</div>' +
        '</div>' +
      '</details>';
    }

    _render() {
      const body = this.querySelector('.sh-body');
      if (!body) return;

      if (this._error && !this._data) {
        body.innerHTML = '<div class="sh-state">' + esc(t('Could not load prices. Check your connection.')) +
          '<div class="sh-retry"><button class="ue-btn" data-act="retry">' + esc(t('Try again')) + '</button></div></div>';
        return;
      }
      if (!this._data) {
        body.innerHTML = '<div class="sh-state">' + esc(t('Loading…')) + '</div>';
        return;
      }

      const packs = Array.isArray(this._data.packs) ? this._data.packs : [];
      const plans = Array.isArray(this._data.plans) ? this._data.plans : [];
      let html = '';

      if (packs.length) {
        html += '<div class="sh-sec">' + esc(t('Token packs')) + '</div><div class="sh-grid">';
        for (let i = 0; i < packs.length; i++) html += this._packCard(packs[i]);
        html += '</div>';
      }

      if (plans.length) {
        html += '<div class="sh-sec">' + esc(t('Subscriptions')) + '</div><div class="sh-grid">';
        for (let j = 0; j < plans.length; j++) html += this._planCard(plans[j]);
        html += '</div>';
      }

      if (!html) html = '<div class="sh-state">' + esc(t('Nothing is available to buy right now.')) + '</div>';
      body.innerHTML = html;
    }

    _packCard(p) {
      const url = /^https?:\/\//i.test(p.checkout_url || '') ? p.checkout_url : '';
      return '<div class="sh-card' + (p.highlight ? ' hot' : '') + '">' +
        (p.highlight ? '<span class="sh-tag">' + esc(t('Best value')) + '</span>' : '') +
        '<div class="sh-name">' + esc(p.name || p.slug || '') + '</div>' +
        '<div class="sh-price">$' + esc(p.price || '') + '</div>' +
        '<div class="sh-tokens">' + esc(fmtTokens(p.tokens)) + ' ' + esc(t('tokens')) + '</div>' +
        '<div class="sh-rate">' + esc(perMillion(p.price, p.tokens)) + '</div>' +
        (url ? '<button class="ue-btn accent sh-buy" data-href="' + esc(url) + '">' + esc(t('Buy')) + '</button>' : '') +
      '</div>';
    }

    _planCard(p) {
      const url = /^https?:\/\//i.test(p.checkout_url || '') ? p.checkout_url : '';
      const per = p.interval === 'year' ? t('a year') : t('a month');
      let feats = '';
      const list = Array.isArray(p.features) ? p.features : [];
      for (let i = 0; i < list.length; i++) feats += '<li>' + esc(list[i]) + '</li>';
      return '<div class="sh-card' + (p.highlight ? ' hot' : '') + '">' +
        (p.highlight ? '<span class="sh-tag">' + esc(t('Recommended')) + '</span>' : '') +
        '<div class="sh-name">' + esc(p.name || p.slug || '') + '</div>' +
        '<div class="sh-price">$' + esc(p.price || '') + '</div>' +
        '<div class="sh-rate">' + esc(per) + '</div>' +
        (p.tokens_per_period
          ? '<div class="sh-tokens">' + esc(fmtTokens(p.tokens_per_period)) + ' ' + esc(t('tokens a month')) + '</div>'
          : '') +
        (feats ? '<ul class="sh-feat">' + feats + '</ul>' : '') +
        (url ? '<button class="ue-btn accent sh-buy" data-href="' + esc(url) + '">' + esc(t('Subscribe')) + '</button>' : '') +
      '</div>';
    }
  }

  customElements.define('uecp-screen-shop', ShopScreen);
})();
