// Copyright 2026, BlueprintsLab, All rights reserved
#include "Library/UECPSteamUtilsLibrary.h"

#include "UECPSteamAPI.h"

int32 UUECPSteamUtilsLibrary::GetSteamAppId()
{
#if UECP_WITH_STEAM
	if (ISteamUtils* U = UECPSteam::Utils()) { return static_cast<int32>(U->GetAppID()); }
#endif
	return 0;
}

bool UUECPSteamUtilsLibrary::IsRunningOnSteamDeck()
{
#if UECP_WITH_STEAM
	if (ISteamUtils* U = UECPSteam::Utils()) { return U->IsSteamRunningOnSteamDeck(); }
#endif
	return false;
}

bool UUECPSteamUtilsLibrary::IsSteamInBigPictureMode()
{
#if UECP_WITH_STEAM
	if (ISteamUtils* U = UECPSteam::Utils()) { return U->IsSteamInBigPictureMode(); }
#endif
	return false;
}

bool UUECPSteamUtilsLibrary::IsSteamRunningInVR()
{
#if UECP_WITH_STEAM
	if (ISteamUtils* U = UECPSteam::Utils()) { return U->IsSteamRunningInVR(); }
#endif
	return false;
}

bool UUECPSteamUtilsLibrary::IsOverlayEnabled()
{
#if UECP_WITH_STEAM
	if (ISteamUtils* U = UECPSteam::Utils()) { return U->IsOverlayEnabled(); }
#endif
	return false;
}

FString UUECPSteamUtilsLibrary::GetIPCountry()
{
#if UECP_WITH_STEAM
	if (ISteamUtils* U = UECPSteam::Utils()) { return UTF8_TO_TCHAR(U->GetIPCountry()); }
#endif
	return FString();
}

FString UUECPSteamUtilsLibrary::GetSteamUILanguage()
{
#if UECP_WITH_STEAM
	if (ISteamUtils* U = UECPSteam::Utils()) { return UTF8_TO_TCHAR(U->GetSteamUILanguage()); }
#endif
	return FString();
}

int32 UUECPSteamUtilsLibrary::GetCurrentBatteryPower()
{
#if UECP_WITH_STEAM
	if (ISteamUtils* U = UECPSteam::Utils()) { return static_cast<int32>(U->GetCurrentBatteryPower()); }
#endif
	return 255;
}

int32 UUECPSteamUtilsLibrary::GetSecondsSinceAppActive()
{
#if UECP_WITH_STEAM
	if (ISteamUtils* U = UECPSteam::Utils()) { return static_cast<int32>(U->GetSecondsSinceAppActive()); }
#endif
	return 0;
}

int64 UUECPSteamUtilsLibrary::GetServerRealTime()
{
#if UECP_WITH_STEAM
	if (ISteamUtils* U = UECPSteam::Utils()) { return static_cast<int64>(U->GetServerRealTime()); }
#endif
	return 0;
}

void UUECPSteamUtilsLibrary::SetOverlayNotificationPosition(EUECPSteamNotificationPosition Position)
{
#if UECP_WITH_STEAM
	ISteamUtils* U = UECPSteam::Utils();
	if (!U)
	{
		return;
	}

	ENotificationPosition Native = k_EPositionBottomRight;
	switch (Position)
	{
	case EUECPSteamNotificationPosition::TopLeft:     Native = k_EPositionTopLeft;     break;
	case EUECPSteamNotificationPosition::TopRight:    Native = k_EPositionTopRight;    break;
	case EUECPSteamNotificationPosition::BottomLeft:  Native = k_EPositionBottomLeft;  break;
	case EUECPSteamNotificationPosition::BottomRight: Native = k_EPositionBottomRight; break;
	}
	U->SetOverlayNotificationPosition(Native);
#else
	(void)Position;
#endif
}

void UUECPSteamUtilsLibrary::SetOverlayNotificationInset(int32 HorizontalInset, int32 VerticalInset)
{
#if UECP_WITH_STEAM
	if (ISteamUtils* U = UECPSteam::Utils()) { U->SetOverlayNotificationInset(HorizontalInset, VerticalInset); }
#endif
}

FString UUECPSteamUtilsLibrary::FilterText(const FString& Text, FUECPSteamID SpeakerSteamId)
{
#if UECP_WITH_STEAM
	ISteamUtils* U = UECPSteam::Utils();
	if (!U || Text.IsEmpty())
	{
		return Text;
	}

	const auto Utf8In = StringCast<UTF8CHAR>(*Text);
	TArray<char> Buffer;
	Buffer.SetNumZeroed(Utf8In.Length() * 2 + 64);

	const int32 Written = U->FilterText(k_ETextFilteringContextChat,
		UECPSteam::ToSteamID(SpeakerSteamId.Value),
		reinterpret_cast<const char*>(Utf8In.Get()),
		Buffer.GetData(), Buffer.Num());

	return Written > 0 ? FString(UTF8_TO_TCHAR(Buffer.GetData())) : Text;
#else
	(void)SpeakerSteamId;
	return Text;
#endif
}

bool UUECPSteamUtilsLibrary::ShowGamepadTextInput(const FString& Description, const FString& ExistingText,
	bool bPassword, bool bMultiline, int32 MaxLength)
{
#if UECP_WITH_STEAM
	if (ISteamUtils* U = UECPSteam::Utils())
	{
		return U->ShowGamepadTextInput(
			bPassword ? k_EGamepadTextInputModePassword : k_EGamepadTextInputModeNormal,
			bMultiline ? k_EGamepadTextInputLineModeMultipleLines : k_EGamepadTextInputLineModeSingleLine,
			TCHAR_TO_UTF8(*Description),
			static_cast<uint32>(FMath::Max(1, MaxLength)),
			TCHAR_TO_UTF8(*ExistingText));
	}
#endif
	return false;
}

FString UUECPSteamUtilsLibrary::GetEnteredGamepadTextInput()
{
#if UECP_WITH_STEAM
	ISteamUtils* U = UECPSteam::Utils();
	if (!U)
	{
		return FString();
	}

	const uint32 Length = U->GetEnteredGamepadTextLength();
	if (Length == 0)
	{
		return FString();
	}

	TArray<char> Buffer;
	Buffer.SetNumZeroed(Length + 1);
	return U->GetEnteredGamepadTextInput(Buffer.GetData(), Length + 1)
		? FString(UTF8_TO_TCHAR(Buffer.GetData()))
		: FString();
#else
	return FString();
#endif
}
