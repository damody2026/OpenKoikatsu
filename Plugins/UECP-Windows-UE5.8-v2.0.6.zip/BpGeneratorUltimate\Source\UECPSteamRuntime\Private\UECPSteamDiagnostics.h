// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "Async/UECPSteamLeaderboardAsync.h"
#include "Async/UECPSteamWorkshopAsync.h"
#include "UECPSteamSessionTypes.h"
#include "UECPSteamTypes.h"
#include "UECPSteamDiagnostics.generated.h"

UCLASS()
class UUECPSteamDiagnosticListener : public UObject
{
	GENERATED_BODY()

public:
	void Hold();

	UFUNCTION()
	void OnSessionResult(FUECPSteamError Error);

	UFUNCTION()
	void OnFindResult(const TArray<FUECPSteamSessionSearchResult>& Results, FUECPSteamError Error);

	UFUNCTION()
	void OnJoinResult(const FString& ConnectString, FUECPSteamError Error);

	UFUNCTION()
	void OnLeaderboardEntries(const TArray<FUECPSteamLeaderboardEntry>& Entries, FUECPSteamError Error);

	UFUNCTION()
	void OnLeaderboardUpload(bool bScoreChanged, int32 NewGlobalRank,
		int32 PreviousGlobalRank, FUECPSteamError Error);

	UFUNCTION()
	void OnWorkshopQuery(const TArray<FUECPSteamWorkshopItem>& Items,
		int32 TotalMatching, FUECPSteamError Error);

	UFUNCTION()
	void OnP2PSessionRequest(FUECPSteamID PeerSteamId);

	UFUNCTION()
	void OnP2PMessage(FUECPSteamID SenderSteamId, const TArray<uint8>& Data, int32 Channel);

	FString Label;
};
