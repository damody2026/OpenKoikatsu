(function () {
  if (!document.getElementById('uecp-thread-css')) {
    const s = document.createElement('style'); s.id = 'uecp-thread-css';
    s.textContent = `
uecp-thread{display:flex;flex-direction:column;flex:1;min-height:0;overflow-y:auto;padding:26px 0;contain:strict}
uecp-thread .thread-inner{max-width:var(--ue-chat-col,720px);margin:0 auto;padding:0 var(--ue-sp-7,24px);width:100%}
uecp-thread uecp-message.find-highlight{outline:1px solid var(--ue-accent);border-radius:var(--ue-r)}
uecp-thread .append-bubble{margin-bottom:18px}
uecp-thread .thread-loading{padding:40px 0;text-align:center;color:var(--ue-text-lo);font-size:var(--ue-fs-sm)}`;
    document.head.appendChild(s);
  }

  class UecpThread extends HTMLElement {
    connectedCallback() {
      this.innerHTML = '<div class="thread-inner"></div>';
      this._inner = this.querySelector('.thread-inner');
      this._nodes = {};
      this._msgs  = {};
      this._bubbles = [];
      this._baseIndex = 0;
      this._total = 0;
      this._loadingOlder = false;
      this._pinned = true;
      this._chatId = null;
      this._switchTo = null;
      this._batchTools = true;
      this._autoScroll = true;

      const self = this;
      this._coalescer = window.UECP.createCoalescer(function () { self._flushTail(); });
      this._pendingByIdx = {};
      this._pendingTotal = null;

      this._u1 = window.uecp.on('chat.window', function (data) { self._onWindow(data); });
      this._u2 = window.uecp.on('chat.tail',   function (data) { self._onTail(data); });
      this._u4 = window.uecp.on('architect.append_bubble', function (data) { self._onAppendBubble(data); });
      this._u5 = window.uecp.on('chat.prepend', function (data) { self._onPrepend(data); });
      this._u3 = window.uecp.on('settings.init', function (data) {
        if (!data || !data.chatPrefs) return;
        if (typeof data.chatPrefs.batchedToolBlocks === 'boolean') {
          const next = data.chatPrefs.batchedToolBlocks;
          if (next !== self._batchTools) { self._batchTools = next; self._regroupToolRuns(); }
        }
        if (typeof data.chatPrefs.autoScroll === 'boolean') self._autoScroll = data.chatPrefs.autoScroll;
        if (typeof data.chatPrefs.timestamps === 'boolean') self.classList.toggle('show-timestamps', data.chatPrefs.timestamps);
      });

      this.addEventListener('scroll', function () {
        const distFromBottom = self.scrollHeight - self.scrollTop - self.clientHeight;
        self._pinned = distFromBottom < 80;
        if (self.scrollTop < 200 && self._baseIndex > 0 && !self._loadingOlder && self._chatId) {
          self._loadingOlder = true;
          window.uecp.call('architect_load_older', { chatId: self._chatId, baseIndex: self._baseIndex });
        }
      });

      this.addEventListener('click', function (e) {
        const a = e.target && e.target.closest ? e.target.closest('a') : null;
        if (!a) return;
        const href = a.getAttribute('href') || '';
        if (href.indexOf('ue://asset?') === 0) {
          e.preventDefault();
          var ref = href.replace('ue://asset?name=', '').replace('ue://asset?path=', '');
          window.uecp.call('open_asset_link', { ref: ref });
        } else if (/^https?:\/\//i.test(href)) {
          e.preventDefault();
          window.uecp.call('open_external_url', { url: href });
        }
      });
    }

    disconnectedCallback() {
      if (this._u1) { this._u1(); this._u1 = null; }
      if (this._u2) { this._u2(); this._u2 = null; }
      if (this._u3) { this._u3(); this._u3 = null; }
      if (this._u4) { this._u4(); this._u4 = null; }
      if (this._u5) { this._u5(); this._u5 = null; }
    }

    beginSwitch(chatId) {
      if (chatId == null || chatId === (this._switchTo != null ? this._switchTo : this._chatId)) return false;
      this._switchTo = chatId;
      this._chatId = null;
      this._nodes = {};
      this._msgs = {};
      this._bubbles = [];
      this._pendingByIdx = {};
      this._pendingTotal = null;
      this._baseIndex = 0;
      this._total = 0;
      this._loadingOlder = false;
      this._inner.innerHTML = '<div class="thread-loading">Loading…</div>';
      return true;
    }

    switchingTo() {
      return this._switchTo;
    }

    _onWindow(data) {
      if (!data) return;
      if (this._switchTo != null && data.chatId !== this._switchTo) return;
      this._switchTo = null;
      this._pendingByIdx = {};
      this._pendingTotal = null;
      this._loadingOlder = false;
      const msgs = data.messages || [];
      const base = data.baseIndex || 0;
      this._baseIndex = base;
      this._total = data.total || 0;

      const isNewChat = (data.chatId == null) ? (this._chatId == null) : (data.chatId !== this._chatId);
      if (data.chatId != null) this._chatId = data.chatId;

      const newNodes = {};
      const newMsgs  = {};
      const inner = this._inner;

      const fragment = document.createDocumentFragment();
      for (let i = 0; i < msgs.length; i++) {
        const absIdx = base + i;
        let node = this._nodes[absIdx];
        if (!node) {
          node = document.createElement('uecp-message');
          node.dataset.idx = absIdx;
        }
        node.style.display = '';
        node.render(msgs[i]);
        node._toolRunSig = null;
        newNodes[absIdx] = node;
        newMsgs[absIdx]  = msgs[i];
        fragment.appendChild(node);
      }

      for (const k in this._nodes) {
        if (!newNodes[k]) {
          const n = this._nodes[k];
          if (n.parentNode) n.parentNode.removeChild(n);
        }
      }
      this._nodes = newNodes;
      this._msgs  = newMsgs;
      inner.innerHTML = '';
      inner.appendChild(fragment);
      if (isNewChat) this._bubbles = [];
      else this._reattachBubbles();

      this._regroupToolRuns();
      this._syncBudgetPauses();

      if (isNewChat) {
        this._pinned = true;
        this._scrollToBottom();
      } else if (this._autoScroll && this._pinned) {
        this._scrollToBottom();
      }
    }

    _onPrepend(data) {
      this._loadingOlder = false;
      if (!data || data.chatId !== this._chatId) return;
      const msgs = data.messages || [];
      const base = data.baseIndex || 0;
      if (!msgs.length || base >= this._baseIndex) return;

      const inner = this._inner;
      const prevH = this.scrollHeight;
      const prevTop = this.scrollTop;

      const fragment = document.createDocumentFragment();
      const end = Math.min(base + msgs.length, this._baseIndex);
      for (let absIdx = base; absIdx < end; absIdx++) {
        if (this._nodes[absIdx]) continue;
        const msg = msgs[absIdx - base];
        const node = document.createElement('uecp-message');
        node.dataset.idx = absIdx;
        node.render(msg);
        this._nodes[absIdx] = node;
        this._msgs[absIdx]  = msg;
        fragment.appendChild(node);
      }
      inner.insertBefore(fragment, inner.firstChild);
      this._baseIndex = base;

      this._regroupToolRuns();
      this._syncBudgetPauses();
      this.scrollTop = prevTop + (this.scrollHeight - prevH);
    }

    _onTail(data) {
      if (!data) return;
      if (this._switchTo != null) return;
      if (data.chatId != null && this._chatId != null && data.chatId !== this._chatId) return;
      if (Array.isArray(data.messages)) {
        for (let i = 0; i < data.messages.length; i++) {
          const e = data.messages[i];
          if (e && e.message != null && e.index != null) this._pendingByIdx[e.index] = e.message;
        }
      } else if (data.index != null && data.message != null) {
        this._pendingByIdx[data.index] = data.message;
      }
      if (typeof data.total === 'number') this._pendingTotal = data.total;
      this._coalescer.schedule();
    }

    _flushTail() {
      const pending = this._pendingByIdx;
      this._pendingByIdx = {};
      const total = this._pendingTotal;
      this._pendingTotal = null;

      const indices = Object.keys(pending).map(Number).sort(function (a, b) { return a - b; });
      if (!indices.length) return;

      if (typeof total === 'number') {
        for (const k in this._nodes) {
          const ki = Number(k);
          if (ki >= total) {
            const n = this._nodes[k];
            if (n && n.parentNode) n.parentNode.removeChild(n);
            delete this._nodes[k];
            delete this._msgs[k];
          }
        }
      }

      for (let i = 0; i < indices.length; i++) {
        const absIdx = indices[i];
        if (typeof total === 'number' && absIdx >= total) continue;
        const msg = pending[absIdx];
        let node = this._nodes[absIdx];
        if (!node) {
          node = document.createElement('uecp-message');
          node.dataset.idx = absIdx;
          this._nodes[absIdx] = node;
          this._insertNodeInOrder(node, absIdx);
        }
        node.style.display = '';
        node.render(msg);
        node._toolRunSig = null;
        this._msgs[absIdx] = msg;
      }

      this._regroupToolRuns();
      this._syncBudgetPauses();

      if (this._autoScroll && this._pinned) this._scrollToBottom();
    }

    _syncBudgetPauses() {
      const classify = window.UECP && window.UECP.classifyMessage;
      if (!classify) return;
      const idxs = Object.keys(this._nodes).map(Number).sort(function (a, b) { return a - b; });
      let answered = false;
      for (let i = idxs.length - 1; i >= 0; i--) {
        const node = this._nodes[idxs[i]];
        const msg = this._msgs[idxs[i]];
        if (!node || !msg) continue;
        if (msg.budget_pause || (msg.role === 'tool_bubble'
            && (msg.bubble === 'play_test_offer' || msg.bubble === 'premium_offer'))) {
          node.classList.toggle('bp-answered', answered);
        }
        else if (!answered && msg.role === 'user' && classify(msg).kind === 'user') answered = true;
      }
    }

    _onAppendBubble(data) {
      if (!data || !data.html) return;
      if (this._switchTo != null) return;
      if (!/^\s*<uecp-(diff-bar|validate-bubble)[\s>]/i.test(data.html)) return;
      const wrap = document.createElement('div');
      wrap.className = 'append-bubble';
      wrap.innerHTML = data.html;
      let after = this._total;
      for (const k in this._nodes) after = Math.max(after, Number(k) + 1);
      wrap._afterIdx = after;
      this._bubbles.push(wrap);
      this._inner.appendChild(wrap);
      if (this._autoScroll && this._pinned) this._scrollToBottom();
    }

    _reattachBubbles() {
      const inner = this._inner;
      for (let b = 0; b < this._bubbles.length; b++) {
        const wrap = this._bubbles[b];
        let before = null;
        for (let i = 0; i < inner.children.length; i++) {
          const kid = inner.children[i];
          const ki = parseInt(kid.dataset && kid.dataset.idx, 10);
          if (!isNaN(ki) && ki >= wrap._afterIdx) { before = kid; break; }
        }
        if (before) inner.insertBefore(wrap, before);
        else inner.appendChild(wrap);
      }
    }

    _insertNodeInOrder(node, absIdx) {
      const inner = this._inner;
      let before = null;
      const kids = inner.children;
      for (let i = 0; i < kids.length; i++) {
        const ki = parseInt(kids[i].dataset.idx, 10);
        if (!isNaN(ki) && ki > absIdx) { before = kids[i]; break; }
      }
      if (before) inner.insertBefore(node, before);
      else inner.appendChild(node);
    }

    _isTool(msg) {
      if (!msg) return false;
      const info = window.UECP.classifyMessage(msg);
      return info && info.kind === 'tool';
    }

    _isBatchTransparent(msg) {
      if (!msg) return false;
      const info = window.UECP.classifyMessage(msg);
      if (!info) return false;
      if (info.kind === 'model') {
        const norm = window.UECP.normalizeModel(info.text || '');
        return !(norm.text && norm.text.trim()) && !(norm.toolCalls && norm.toolCalls.length);
      }
      return false;
    }

    _regroupToolRuns() {
      const indices = Object.keys(this._nodes).map(Number).sort(function (a, b) { return a - b; });

      let i = 0;
      while (i < indices.length) {
        const startIdx = indices[i];
        let j = i;
        let lastTool = i;
        let toolCount = 0;
        if (this._batchTools && this._isTool(this._msgs[startIdx])) {
          toolCount = 1;
          while (j + 1 < indices.length && indices[j + 1] === indices[j] + 1) {
            const nextMsg = this._msgs[indices[j + 1]];
            if (this._isTool(nextMsg)) { j++; lastTool = j; toolCount++; }
            else if (this._isBatchTransparent(nextMsg)) { j++; }
            else break;
          }
        }
        const runEnd = lastTool;

        if (this._batchTools && toolCount >= 2) {
          const runMsgs = [];
          for (let k = i; k <= runEnd; k++) {
            const m = this._msgs[indices[k]];
            if (this._isTool(m)) runMsgs.push(m);
          }
          const head = this._nodes[indices[i]];
          head.style.display = '';
          const sig = indices[i] + ':' + indices[runEnd] + ':' + runMsgs.length;
          if (head._toolRunSig !== sig) {
            const prevTc = head.querySelector('uecp-toolcall');
            const wasOpen = !!(prevTc && prevTc.classList && prevTc.classList.contains('open'));
            head.renderToolBatch(runMsgs);
            if (wasOpen) {
              const newTc = head.querySelector('uecp-toolcall');
              if (newTc && newTc.classList) newTc.classList.add('open');
            }
            head._toolRunSig = sig;
          }
          for (let k = i + 1; k <= runEnd; k++) {
            this._nodes[indices[k]].style.display = 'none';
          }
          i = runEnd + 1;
          continue;
        }
        {
          for (let k = i; k <= j; k++) {
            const idx = indices[k];
            const n = this._nodes[idx];
            n.style.display = '';
            n._toolRunSig = null;
            const tc = n.querySelector('uecp-toolcall');
            if (tc && tc._calls && tc._calls.length > 1) n.render(this._msgs[idx]);
          }
        }
        i = j + 1;
      }
    }

    _scrollToBottom() {
      if (this._pinScheduled) return;
      this._pinScheduled = true;
      const self = this;
      const raf = (typeof requestAnimationFrame === 'function')
        ? requestAnimationFrame
        : function (cb) { return setTimeout(cb, 0); };
      raf(function () {
        self._pinScheduled = false;
        self.scrollTop = self.scrollHeight;
      });
    }

    scrollToIndex(absIdx) {
      const node = this._nodes[absIdx];
      if (!node) return;
      node.scrollIntoView({ block: 'center' });
      node.classList.add('find-highlight');
      const n = node;
      setTimeout(function () { n.classList.remove('find-highlight'); }, 1500);
    }
  }
  customElements.define('uecp-thread', UecpThread);
})();
