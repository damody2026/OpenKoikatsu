// Copyright 2026, BlueprintsLab, All rights reserved
#include "Async/UECPSteamLeaderboardAsync.h"

#include "UECPSteamAPI.h"
#include "UECPSteamCallResult.h"

#if UECP_WITH_STEAM
namespace
{
	ELeaderboardDataRequest ToNative(EUECPSteamLeaderboardRequest In)
	{
		switch (In)
		{
		case EUECPSteamLeaderboardRequest::GlobalAroundUser: return k_ELeaderboardDataRequestGlobalAroundUser;
		case EUECPSteamLeaderboardRequest::Friends:          return k_ELeaderboardDataRequestFriends;
		case EUECPSteamLeaderboardRequest::Global:
		default:                                             return k_ELeaderboardDataRequestGlobal;
		}
	}

	ELeaderboardSortMethod ToNative(EUECPSteamLeaderboardSort In)
	{
		return In == EUECPSteamLeaderboardSort::Ascending
			? k_ELeaderboardSortMethodAscending
			: k_ELeaderboardSortMethodDescending;
	}

	ELeaderboardDisplayType ToNative(EUECPSteamLeaderboardDisplay In)
	{
		switch (In)
		{
		case EUECPSteamLeaderboardDisplay::TimeSeconds:      return k_ELeaderboardDisplayTypeTimeSeconds;
		case EUECPSteamLeaderboardDisplay::TimeMilliseconds: return k_ELeaderboardDisplayTypeTimeMilliSeconds;
		case EUECPSteamLeaderboardDisplay::Numeric:
		default:                                             return k_ELeaderboardDisplayTypeNumeric;
		}
	}

	constexpr int32 MaxLeaderboardDetails = 64;
}
#endif

UUECPSteamDownloadLeaderboard* UUECPSteamDownloadLeaderboard::DownloadSteamLeaderboard(
	UObject* WorldContextObject, const FString& LeaderboardName,
	EUECPSteamLeaderboardRequest RequestType, int32 RangeStart, int32 RangeEnd)
{
	UUECPSteamDownloadLeaderboard* Node = NewObject<UUECPSteamDownloadLeaderboard>();
	Node->ContextObject    = WorldContextObject;
	Node->LeaderboardName  = LeaderboardName;
	Node->RequestType      = RequestType;
	Node->RangeStart       = RangeStart;
	Node->RangeEnd         = RangeEnd;
	Node->RegisterWithGameInstance(WorldContextObject);
	return Node;
}

bool UUECPSteamDownloadLeaderboard::Start(FUECPSteamError& OutError)
{
#if UECP_WITH_STEAM
	if (LeaderboardName.IsEmpty())
	{
		OutError = FUECPSteamError(EUECPSteamResult::InvalidParameter, TEXT("No leaderboard name given."));
		return false;
	}

	ISteamUserStats* Stats = UECPSteam::UserStats();
	if (!Stats)
	{
		OutError = FUECPSteamError::Unavailable();
		return false;
	}

	const SteamAPICall_t Call = Stats->FindLeaderboard(TCHAR_TO_UTF8(*LeaderboardName));
	if (Call == k_uAPICallInvalid)
	{
		OutError = FUECPSteamError(EUECPSteamResult::BackendFailure, TEXT("FindLeaderboard was rejected."));
		return false;
	}

	TWeakObjectPtr<UUECPSteamDownloadLeaderboard> WeakThis(this);
	UECPSteamSetCallResult<LeaderboardFindResult_t>(CallResultHolder, Call,
		[WeakThis](LeaderboardFindResult_t* Result, bool bIOFailure)
		{
			UECPSteam::RunOnGameThread([WeakThis, Found = (Result && Result->m_bLeaderboardFound && !bIOFailure),
				Handle = (Result ? Result->m_hSteamLeaderboard : 0)]()
			{
				UUECPSteamDownloadLeaderboard* Node = WeakThis.Get();
				if (!Node)
				{
					return;
				}
				if (!Found)
				{
					Node->CompleteFailure(FUECPSteamError(EUECPSteamResult::NotFound,
						TEXT("No such leaderboard. Names are case-sensitive and must exist on the Steamworks partner site.")));
					return;
				}
				Node->OnLeaderboardFound(static_cast<uint64>(Handle));
			});
		});

	return true;
#else
	OutError = FUECPSteamError::Unavailable();
	return false;
#endif
}

void UUECPSteamDownloadLeaderboard::OnLeaderboardFound(uint64 LeaderboardHandle)
{
#if UECP_WITH_STEAM
	ISteamUserStats* Stats = UECPSteam::UserStats();
	if (!Stats)
	{
		CompleteFailure(FUECPSteamError::Unavailable());
		return;
	}

	const SteamLeaderboard_t Board = static_cast<SteamLeaderboard_t>(LeaderboardHandle);
	const SteamAPICall_t Call = Stats->DownloadLeaderboardEntries(
		Board, ToNative(RequestType), RangeStart, RangeEnd);
	if (Call == k_uAPICallInvalid)
	{
		CompleteFailure(FUECPSteamError(EUECPSteamResult::BackendFailure,
			TEXT("DownloadLeaderboardEntries was rejected.")));
		return;
	}

	TWeakObjectPtr<UUECPSteamDownloadLeaderboard> WeakThis(this);
	UECPSteamSetCallResult<LeaderboardScoresDownloaded_t>(DownloadHolder, Call,
		[WeakThis](LeaderboardScoresDownloaded_t* Result, bool bIOFailure)
		{
			if (bIOFailure || !Result)
			{
				UECPSteam::RunOnGameThread([WeakThis]()
				{
					if (UUECPSteamDownloadLeaderboard* Node = WeakThis.Get())
					{
						Node->CompleteFailure(FUECPSteamError(EUECPSteamResult::BackendFailure,
							TEXT("Downloading leaderboard entries failed.")));
					}
				});
				return;
			}

			ISteamUserStats* LocalStats = UECPSteam::UserStats();
			ISteamFriends* LocalFriends = UECPSteam::Friends();
			TArray<FUECPSteamLeaderboardEntry> Rows;
			Rows.Reserve(Result->m_cEntryCount);

			for (int32 Index = 0; LocalStats && Index < Result->m_cEntryCount; ++Index)
			{
				LeaderboardEntry_t Native;
				int32 DetailBuffer[MaxLeaderboardDetails] = {};

				if (!LocalStats->GetDownloadedLeaderboardEntry(
						Result->m_hSteamLeaderboardEntries, Index, &Native,
						DetailBuffer, MaxLeaderboardDetails))
				{
					continue;
				}

				FUECPSteamLeaderboardEntry Row;
				Row.SteamId    = FUECPSteamID(UECPSteam::FromSteamID(Native.m_steamIDUser));
				Row.GlobalRank = Native.m_nGlobalRank;
				Row.Score      = Native.m_nScore;
				Row.Details.Append(DetailBuffer, FMath::Clamp(Native.m_cDetails, 0, MaxLeaderboardDetails));

				if (LocalFriends)
				{
					Row.PlayerName = UTF8_TO_TCHAR(LocalFriends->GetFriendPersonaName(Native.m_steamIDUser));
				}
				Rows.Add(MoveTemp(Row));
			}

			UECPSteam::RunOnGameThread([WeakThis, Rows = MoveTemp(Rows)]() mutable
			{
				if (UUECPSteamDownloadLeaderboard* Node = WeakThis.Get())
				{
					Node->Entries = MoveTemp(Rows);
					Node->CompleteSuccess();
				}
			});
		});
#endif
}

void UUECPSteamDownloadLeaderboard::BroadcastResult(bool bSucceeded, const FUECPSteamError& Error)
{
	(bSucceeded ? OnSuccess : OnFailure).Broadcast(Entries, Error);
}

UUECPSteamUploadLeaderboardScore* UUECPSteamUploadLeaderboardScore::UploadSteamLeaderboardScore(
	UObject* WorldContextObject, const FString& LeaderboardName, int32 Score,
	TArray<int32> Details, EUECPSteamLeaderboardUpload Method, bool bCreateIfMissing,
	EUECPSteamLeaderboardSort SortMethod, EUECPSteamLeaderboardDisplay DisplayType)
{
	UUECPSteamUploadLeaderboardScore* Node = NewObject<UUECPSteamUploadLeaderboardScore>();
	Node->ContextObject     = WorldContextObject;
	Node->LeaderboardName   = LeaderboardName;
	Node->Score             = Score;
	Node->Method            = Method;
	Node->Details           = MoveTemp(Details);
	Node->bCreateIfMissing  = bCreateIfMissing;
	Node->SortMethod        = SortMethod;
	Node->DisplayType       = DisplayType;
	Node->RegisterWithGameInstance(WorldContextObject);
	return Node;
}

bool UUECPSteamUploadLeaderboardScore::Start(FUECPSteamError& OutError)
{
#if UECP_WITH_STEAM
	if (LeaderboardName.IsEmpty())
	{
		OutError = FUECPSteamError(EUECPSteamResult::InvalidParameter, TEXT("No leaderboard name given."));
		return false;
	}
	if (Details.Num() > MaxLeaderboardDetails)
	{
		OutError = FUECPSteamError(EUECPSteamResult::InvalidParameter,
			FString::Printf(TEXT("Details has %d entries; Steam allows at most %d."),
				Details.Num(), MaxLeaderboardDetails));
		return false;
	}

	ISteamUserStats* Stats = UECPSteam::UserStats();
	if (!Stats)
	{
		OutError = FUECPSteamError::Unavailable();
		return false;
	}

	const SteamAPICall_t Call = bCreateIfMissing
		? Stats->FindOrCreateLeaderboard(TCHAR_TO_UTF8(*LeaderboardName),
			ToNative(SortMethod), ToNative(DisplayType))
		: Stats->FindLeaderboard(TCHAR_TO_UTF8(*LeaderboardName));

	if (Call == k_uAPICallInvalid)
	{
		OutError = FUECPSteamError(EUECPSteamResult::BackendFailure, TEXT("Resolving the leaderboard was rejected."));
		return false;
	}

	TWeakObjectPtr<UUECPSteamUploadLeaderboardScore> WeakThis(this);
	UECPSteamSetCallResult<LeaderboardFindResult_t>(CallResultHolder, Call,
		[WeakThis](LeaderboardFindResult_t* Result, bool bIOFailure)
		{
			UECPSteam::RunOnGameThread([WeakThis, Found = (Result && Result->m_bLeaderboardFound && !bIOFailure),
				Handle = (Result ? Result->m_hSteamLeaderboard : 0)]()
			{
				UUECPSteamUploadLeaderboardScore* Node = WeakThis.Get();
				if (!Node)
				{
					return;
				}
				if (!Found)
				{
					Node->CompleteFailure(FUECPSteamError(EUECPSteamResult::NotFound,
						TEXT("No such leaderboard. Pass bCreateIfMissing to create it, or define it on the Steamworks partner site.")));
					return;
				}
				Node->OnLeaderboardFound(static_cast<uint64>(Handle));
			});
		});

	return true;
#else
	OutError = FUECPSteamError::Unavailable();
	return false;
#endif
}

void UUECPSteamUploadLeaderboardScore::OnLeaderboardFound(uint64 LeaderboardHandle)
{
#if UECP_WITH_STEAM
	ISteamUserStats* Stats = UECPSteam::UserStats();
	if (!Stats)
	{
		CompleteFailure(FUECPSteamError::Unavailable());
		return;
	}

	const SteamAPICall_t Call = Stats->UploadLeaderboardScore(
		static_cast<SteamLeaderboard_t>(LeaderboardHandle),
		Method == EUECPSteamLeaderboardUpload::ForceUpdate
			? k_ELeaderboardUploadScoreMethodForceUpdate
			: k_ELeaderboardUploadScoreMethodKeepBest,
		Score,
		Details.Num() > 0 ? Details.GetData() : nullptr,
		Details.Num());

	if (Call == k_uAPICallInvalid)
	{
		CompleteFailure(FUECPSteamError(EUECPSteamResult::BackendFailure,
			TEXT("UploadLeaderboardScore was rejected.")));
		return;
	}

	TWeakObjectPtr<UUECPSteamUploadLeaderboardScore> WeakThis(this);
	UECPSteamSetCallResult<LeaderboardScoreUploaded_t>(UploadHolder, Call,
		[WeakThis](LeaderboardScoreUploaded_t* Result, bool bIOFailure)
		{
			const bool bOk       = Result && Result->m_bSuccess && !bIOFailure;
			const bool bChanged  = Result && Result->m_bScoreChanged != 0;
			const int32 NewRank  = Result ? Result->m_nGlobalRankNew : 0;
			const int32 PrevRank = Result ? Result->m_nGlobalRankPrevious : 0;

			UECPSteam::RunOnGameThread([WeakThis, bOk, bChanged, NewRank, PrevRank]()
			{
				UUECPSteamUploadLeaderboardScore* Node = WeakThis.Get();
				if (!Node)
				{
					return;
				}
				Node->bScoreChanged      = bChanged;
				Node->NewGlobalRank      = NewRank;
				Node->PreviousGlobalRank = PrevRank;

				if (bOk)
				{
					Node->CompleteSuccess();
				}
				else
				{
					Node->CompleteFailure(FUECPSteamError(EUECPSteamResult::BackendFailure,
						TEXT("Uploading the leaderboard score failed.")));
				}
			});
		});
#endif
}

void UUECPSteamUploadLeaderboardScore::BroadcastResult(bool bSucceeded, const FUECPSteamError& Error)
{
	(bSucceeded ? OnSuccess : OnFailure).Broadcast(bScoreChanged, NewGlobalRank, PreviousGlobalRank, Error);
}
