// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "Containers/Ticker.h"
#include "Async/UECPSteamAsyncAction.h"
#include "UECPSteamWorkshopTypes.h"
#include "UECPSteamWorkshopAsync.generated.h"

DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FUECPSteamWorkshopQuerySignature,
	const TArray<FUECPSteamWorkshopItem>&, Items, int32, TotalMatching, FUECPSteamError, Error);

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamWorkshopQuery : public UUECPSteamAsyncAction
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Workshop",
		meta = (BlueprintInternalUseOnly = "true", WorldContext = "WorldContextObject",
		        DisplayName = "Query Steam Workshop",
		        AdvancedDisplay = "Page,SearchText,RequiredTags"))
	static UUECPSteamWorkshopQuery* QuerySteamWorkshop(
		UObject* WorldContextObject,
		EUECPSteamWorkshopListType ListType,
		EUECPSteamWorkshopSort SortBy,
		int32 Page,
		const FString& SearchText,
		const TArray<FString>& RequiredTags);

	UPROPERTY(BlueprintAssignable)
	FUECPSteamWorkshopQuerySignature OnSuccess;

	UPROPERTY(BlueprintAssignable)
	FUECPSteamWorkshopQuerySignature OnFailure;

protected:
	virtual bool Start(FUECPSteamError& OutError) override;
	virtual void BroadcastResult(bool bSucceeded, const FUECPSteamError& Error) override;

private:
	EUECPSteamWorkshopListType ListType = EUECPSteamWorkshopListType::All;
	EUECPSteamWorkshopSort SortBy = EUECPSteamWorkshopSort::Vote;
	int32 Page = 1;
	FString SearchText;
	TArray<FString> RequiredTags;

	TArray<FUECPSteamWorkshopItem> Items;
	int32 TotalMatching = 0;
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_ThreeParams(FUECPSteamWorkshopItemSignature,
	FUECPSteamWorkshopItemId, ItemId, bool, bNeedsLegalAgreement, FUECPSteamError, Error);

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamWorkshopCreateItem : public UUECPSteamAsyncAction
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Workshop",
		meta = (BlueprintInternalUseOnly = "true", WorldContext = "WorldContextObject",
		        DisplayName = "Create Steam Workshop Item"))
	static UUECPSteamWorkshopCreateItem* CreateSteamWorkshopItem(UObject* WorldContextObject);

	UPROPERTY(BlueprintAssignable)
	FUECPSteamWorkshopItemSignature OnSuccess;

	UPROPERTY(BlueprintAssignable)
	FUECPSteamWorkshopItemSignature OnFailure;

protected:
	virtual bool Start(FUECPSteamError& OutError) override;
	virtual void BroadcastResult(bool bSucceeded, const FUECPSteamError& Error) override;

private:
	FUECPSteamWorkshopItemId ItemId;
	bool bNeedsLegalAgreement = false;
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FUECPSteamWorkshopSubmitSignature,
	bool, bNeedsLegalAgreement, FUECPSteamError, Error);

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamWorkshopSubmitItem : public UUECPSteamAsyncAction
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Workshop",
		meta = (BlueprintInternalUseOnly = "true", WorldContext = "WorldContextObject",
		        DisplayName = "Submit Steam Workshop Item"))
	static UUECPSteamWorkshopSubmitItem* SubmitSteamWorkshopItem(
		UObject* WorldContextObject,
		FUECPSteamWorkshopItemId ItemId,
		FUECPSteamWorkshopSubmitInfo SubmitInfo);

	UPROPERTY(BlueprintAssignable)
	FUECPSteamWorkshopSubmitSignature OnSuccess;

	UPROPERTY(BlueprintAssignable)
	FUECPSteamWorkshopSubmitSignature OnFailure;

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Workshop")
	void GetSubmitProgress(float& ProgressPercent, int64& BytesProcessed, int64& BytesTotal) const;

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Workshop")
	int64 GetUpdateHandle() const { return static_cast<int64>(UpdateHandle); }

protected:
	virtual bool Start(FUECPSteamError& OutError) override;
	virtual void BroadcastResult(bool bSucceeded, const FUECPSteamError& Error) override;

private:
	FUECPSteamWorkshopItemId ItemId;
	FUECPSteamWorkshopSubmitInfo SubmitInfo;
	bool bNeedsLegalAgreement = false;

	uint64 UpdateHandle = 0;
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FUECPSteamWorkshopSubscribeSignature, FUECPSteamError, Error);

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamWorkshopSubscribe : public UUECPSteamAsyncAction
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Workshop",
		meta = (BlueprintInternalUseOnly = "true", WorldContext = "WorldContextObject",
		        DisplayName = "Subscribe To Steam Workshop Item"))
	static UUECPSteamWorkshopSubscribe* SubscribeToSteamWorkshopItem(
		UObject* WorldContextObject, FUECPSteamWorkshopItemId ItemId, bool bUnsubscribe = false);

	UPROPERTY(BlueprintAssignable)
	FUECPSteamWorkshopSubscribeSignature OnSuccess;

	UPROPERTY(BlueprintAssignable)
	FUECPSteamWorkshopSubscribeSignature OnFailure;

protected:
	virtual bool Start(FUECPSteamError& OutError) override;
	virtual void BroadcastResult(bool bSucceeded, const FUECPSteamError& Error) override;

private:
	FUECPSteamWorkshopItemId ItemId;
	bool bUnsubscribe = false;
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FUECPSteamWorkshopDownloadSignature,
	const FString&, InstallFolder, FUECPSteamError, Error);

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamWorkshopDownloadItem : public UUECPSteamAsyncAction
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Workshop",
		meta = (BlueprintInternalUseOnly = "true", WorldContext = "WorldContextObject",
		        DisplayName = "Download Steam Workshop Item", AdvancedDisplay = "bHighPriority"))
	static UUECPSteamWorkshopDownloadItem* DownloadSteamWorkshopItem(
		UObject* WorldContextObject, FUECPSteamWorkshopItemId ItemId, bool bHighPriority = true);

	UPROPERTY(BlueprintAssignable)
	FUECPSteamWorkshopDownloadSignature OnSuccess;

	UPROPERTY(BlueprintAssignable)
	FUECPSteamWorkshopDownloadSignature OnFailure;

protected:
	virtual bool Start(FUECPSteamError& OutError) override;
	virtual void BroadcastResult(bool bSucceeded, const FUECPSteamError& Error) override;
	virtual void OnCleanup() override;

private:
	FUECPSteamWorkshopItemId ItemId;
	bool bHighPriority = true;
	FString InstallFolder;

	FTSTicker::FDelegateHandle PollHandle;
	double PollStartSeconds = 0.0;

	bool PollDownload(float DeltaTime);
};
