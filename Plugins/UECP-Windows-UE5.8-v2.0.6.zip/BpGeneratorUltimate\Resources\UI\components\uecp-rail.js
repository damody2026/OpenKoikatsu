(function () {
  const { el } = window.UECP.dom;
  const ITEMS = [
    { route: 'architect', icon: 'ic-architect', label: 'Architect' },
    { route: 'crew', icon: 'ic-crew', label: 'Crew' },
    { route: 'tools', icon: 'ic-tools', label: 'Tools' },
    { route: 'dashboard', icon: 'ic-bar-chart', label: 'Dashboard' },
    { route: 'localstudio', icon: 'ic-chip', label: 'Local Studio' },
    { route: 'cloudstudio', icon: 'ic-cloud', label: 'Cloud Studio' },
    { route: 'sourcecontrol', icon: 'ic-branch', label: 'Source Control' },
    { route: 'mcp', icon: 'ic-plug', label: 'MCP' },
    { route: 'cpppreview', icon: 'ic-code', label: 'C++ Classes' },
    { route: 'learn', icon: 'ic-learn', label: 'Learn' },
    { route: 'shop', icon: 'ic-cart', label: 'Get Tokens' },
    { route: 'inbox', icon: 'ic-mail', label: 'Inbox' }
  ];
  if (!document.getElementById('uecp-rail-css')) {
    const s = document.createElement('style'); s.id = 'uecp-rail-css';
    s.textContent = `
/* overflow-y is the last resort now: the workspace entries scroll inside .items (below),
   which keeps Account and Settings on screen. The rail itself only scrolls when even the
   brand and that pair do not fit. */
uecp-rail{width:var(--ue-rail-w);flex-shrink:0;background:var(--ue-rail);border-right:1px solid var(--ue-line-soft);display:flex;flex-direction:column;align-items:center;padding:14px 0;gap:7px;overflow-y:auto;overflow-x:hidden}
uecp-rail::-webkit-scrollbar{width:0;height:0}
/* EVERY rail entry — brand and items — is the SAME --ue-rail-item square (42px, smaller
   in a narrow/short dock), flex-centered, with the SAME 18px icon box and
   svg{display:block} (inline-svg baseline gap otherwise nudges the glyph down). The
   active highlight (background + accent bar) lives on the square itself / outside it,
   so it never shifts the centered icon. */
uecp-rail .brand{width:var(--ue-rail-item);height:var(--ue-rail-item);border-radius:10px;display:flex;align-items:center;justify-content:center;position:relative;flex-shrink:0}
/* Items are a column now (icon over label) rather than a square. The icon keeps
   its own fixed box so it stays optically centred regardless of whether the
   label runs to one line or two. */
uecp-rail .item{width:var(--ue-rail-itemw);min-height:var(--ue-rail-item);padding:5px 3px 6px;border-radius:10px;display:flex;flex-direction:column;align-items:center;justify-content:flex-start;gap:3px;position:relative;flex-shrink:0}
uecp-rail .item .ico{height:18px;display:flex;align-items:center;justify-content:center}
uecp-rail .brand svg,uecp-rail .item svg{display:block;width:18px;height:18px}
uecp-rail .item .lbl{font-size:9.5px;line-height:1.15;text-align:center;color:var(--ue-text-lo);letter-spacing:.01em;
  display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;word-break:break-word}
uecp-rail .item.active .lbl{color:var(--ue-accent-bright)}
uecp-rail .item:hover .lbl{color:var(--ue-text-mid)}
/* Brand mark: no filled square, just the glyph itself in the accent tint -- reads as a
   logo mark rather than another rail button. Sized up slightly since it no longer has a
   background shape giving it visual weight. */
uecp-rail .brand{margin-bottom:8px;cursor:pointer}
uecp-rail .brand:hover{background:var(--ue-line-soft)}
uecp-rail .brand svg{width:22px;height:22px;stroke:var(--ue-accent-bright)}
uecp-rail .item{cursor:pointer}
uecp-rail .item svg{stroke:var(--ue-text-mid)}
uecp-rail .item:hover{background:var(--ue-line-soft)}
uecp-rail .item.active{background:var(--ue-accent-soft)}
uecp-rail .item.active svg{stroke:var(--ue-accent-bright)}
/* Accent bar sits OUTSIDE the box so it never shifts the centered icon. The offset is
   the gap between square and rail edge, negated — i.e. the bar lands flush with the
   rail edge at EVERY --ue-rail-w / --ue-rail-item pair responsive.css sets. Anything
   further out is clipped by overflow-x:hidden above. */
uecp-rail .item.active::before{content:"";position:absolute;left:calc((var(--ue-rail-w) - var(--ue-rail-itemw)) / -2);top:50%;margin-top:-10px;width:3px;height:20px;border-radius:2px;background:var(--ue-accent)}
/* Get Tokens is the one rail entry that is not navigation between workspaces --
   it is the thing that keeps the plugin usable when the free allowance runs
   out. Tinted at rest so it reads as an offer rather than as another tab, and
   so it is findable at the moment someone needs it, which is exactly when they
   are least inclined to go hunting. */
uecp-rail .item[data-route="shop"] svg{stroke:var(--ue-accent-bright)}
uecp-rail .item[data-route="shop"] .lbl{color:var(--ue-accent-bright)}
/* The workspace entries are their own scroll box, between the brand and Account/Settings.
   The rail used to be the only scroller with Settings last in it. The whole rail needs
   ~800 CSS px (more at a larger Text Size), so any shorter panel put the gear below the
   fold -- and with the scrollbar hidden nothing said so; an automated click on it
   "succeeded" and hit nothing. flex:1 also does the old spacer's job of pushing the pair
   to the bottom, so nothing moves at normal heights. min-height:0 is what lets the box
   shrink below its content instead of pushing the pair out; gap:inherit follows the
   rail's own gap, including the tighter one responsive.css sets for a short dock. */
uecp-rail .items{flex:1 1 auto;min-height:0;width:100%;display:flex;flex-direction:column;align-items:center;gap:inherit;overflow-y:auto;overflow-x:hidden}
uecp-rail .items::-webkit-scrollbar{width:0;height:0}
/* Update cue. Positioned on the item box, not the svg, so it does not move when
   the icon does. */
uecp-rail .item.has-update{position:relative}
uecp-rail .item.has-update::after{content:'';position:absolute;top:4px;right:calc(50% - 16px);width:7px;height:7px;border-radius:50%;background:var(--ue-accent);box-shadow:0 0 0 2px var(--ue-rail)}
/* Unread mail. Same geometry as the update cue, deliberately a DIFFERENT colour:
   an amber dot already means "there is a newer build", and a mailbox that
   borrowed it would make both cues ambiguous. Red is used nowhere else in the
   rail, so it reads as "new", not as "error". */
uecp-rail .item.has-unread{position:relative}
uecp-rail .item.has-unread::after{content:'';position:absolute;top:4px;right:calc(50% - 16px);width:7px;height:7px;border-radius:50%;background:var(--ue-danger);box-shadow:0 0 0 2px var(--ue-rail)}`;
    document.head.appendChild(s);
  }
  class Rail extends HTMLElement {
    connectedCallback() {
      this.innerHTML = '';
      const brand = el('div', { class: 'brand', title: 'Dashboard', 'data-tip': 'Dashboard', onclick: () => this._goDashboard() });
      brand.innerHTML = window.UECP.icon('ic-infinity', 18); this.appendChild(brand);
      const mk = (it) => {
        const attrs = { class: 'item', title: it.label, 'data-tip': it.label, 'data-route': it.route, onclick: () => this._go(it.route) };
        const node = el('div', attrs);
        node.innerHTML = '<span class="ico">' + window.UECP.icon(it.icon, 18) + '</span>'
                       + '<span class="lbl">' + it.label + '</span>';
        return node;
      };
      const items = el('div', { class: 'items' });
      ITEMS.forEach((it) => items.appendChild(mk(it)));
      this.appendChild(items);
      this.appendChild(mk({ route: 'account', icon: 'ic-user', label: 'Account' }));
      this._settingsItem = mk({ route: 'settings', icon: 'ic-settings', label: 'Settings' });
      this.appendChild(this._settingsItem);
      this._sync();
      this._unsub = window.uecp.on('screen.changed', () => this._sync());

      this._unsubUpd = window.uecp.on('update.available', (p) => this._badgeUpdate(p));

      this._unsubInbox = window.uecp.on('inbox.state', (p) => this._badgeInbox(p));

      window.uecp.call('inbox_action', { verb: 'list' });
    }
    disconnectedCallback() {
      if (this._unsub) this._unsub();
      if (this._unsubUpd) this._unsubUpd();
      if (this._unsubInbox) this._unsubInbox();
    }

    _badgeInbox(p) {
      const item = this.querySelector('.item[data-route="inbox"]');
      if (!item) return;
      const n = p && typeof p.unread === 'number'
        ? p.unread
        : (p && Array.isArray(p.notices) ? p.notices.filter((x) => !x.read).length : 0);
      item.classList.toggle('has-unread', n > 0);
    }

    _badgeUpdate(p) {
      if (!this._settingsItem) return;
      this._settingsItem.classList.add('has-update');
      const v = (p && p.version) ? p.version : '';
      const staged = !!(p && p.staged);
      const tip = staged
        ? (v ? 'Settings — ' + v + ' ready, restart to apply' : 'Settings — update ready')
        : (v ? 'Settings — ' + v + ' available' : 'Settings — update available');
      this._settingsItem.title = tip;
      this._settingsItem.setAttribute('data-tip', tip);
    }
    _goDashboard() { this._go('dashboard'); }
    _go(route) {
      window.UECP.router.go(route);
      window.uecp.call('switch_view', { view: route });
      window.uecp.__emit('screen.changed', { route: route, title: '' });
      this._sync();
    }
    _sync() { const a = window.UECP.router.active(); this.querySelectorAll('.item').forEach((n) => n.classList.toggle('active', n.dataset.route === a)); }
  }
  customElements.define('uecp-rail', Rail);
})();
