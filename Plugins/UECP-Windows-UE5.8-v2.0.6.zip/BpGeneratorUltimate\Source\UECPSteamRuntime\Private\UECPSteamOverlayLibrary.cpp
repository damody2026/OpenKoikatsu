// Copyright 2026, BlueprintsLab, All rights reserved
#include "Library/UECPSteamOverlayLibrary.h"

#include "Interfaces/OnlineExternalUIInterface.h"
#include "UECPSteamAPI.h"
#include "UECPSteamOSS.h"

bool UUECPSteamOverlayLibrary::ShowSteamFriendsUI(const UObject* WorldContextObject)
{
#if UECP_WITH_STEAM
	if (ISteamFriends* F = UECPSteam::Friends())
	{
		F->ActivateGameOverlay("friends");
		return true;
	}
#endif
	const IOnlineExternalUIPtr UI = UECPSteamOSS::ExternalUI(WorldContextObject);
	return UI.IsValid() && UI->ShowFriendsUI(0);
}

bool UUECPSteamOverlayLibrary::ShowSteamInviteUI(const UObject* WorldContextObject, FName SessionName)
{
	const IOnlineExternalUIPtr UI = UECPSteamOSS::ExternalUI(WorldContextObject);
	return UI.IsValid() && UI->ShowInviteUI(0, SessionName.IsNone() ? NAME_GameSession : SessionName);
}

bool UUECPSteamOverlayLibrary::ShowSteamAchievementsUI(const UObject* WorldContextObject)
{
#if UECP_WITH_STEAM
	if (ISteamFriends* F = UECPSteam::Friends())
	{
		F->ActivateGameOverlay("achievements");
		return true;
	}
#endif
	const IOnlineExternalUIPtr UI = UECPSteamOSS::ExternalUI(WorldContextObject);
	return UI.IsValid() && UI->ShowAchievementsUI(0);
}

bool UUECPSteamOverlayLibrary::ShowSteamLeaderboardUI(
	const UObject* WorldContextObject, const FString& LeaderboardName)
{
	const IOnlineExternalUIPtr UI = UECPSteamOSS::ExternalUI(WorldContextObject);
	return UI.IsValid() && UI->ShowLeaderboardUI(LeaderboardName);
}

bool UUECPSteamOverlayLibrary::ShowSteamProfileUI(const UObject* WorldContextObject, FUECPSteamID SteamId)
{
	if (!SteamId.IsValid())
	{
		return false;
	}

#if UECP_WITH_STEAM
	if (ISteamFriends* F = UECPSteam::Friends())
	{
		F->ActivateGameOverlayToUser("steamid", UECPSteam::ToSteamID(SteamId.Value));
		return true;
	}
#endif

	const IOnlineExternalUIPtr UI = UECPSteamOSS::ExternalUI(WorldContextObject);
	const IOnlineIdentityPtr Identity = UECPSteamOSS::Identity(WorldContextObject);
	if (!UI.IsValid() || !Identity.IsValid())
	{
		return false;
	}
	const FUniqueNetIdPtr Requestor = UECPSteamOSS::LocalUserId(WorldContextObject);
	const FUniqueNetIdPtr Requestee = Identity->CreateUniquePlayerId(SteamId.ToString());
	return Requestor.IsValid() && Requestee.IsValid()
		&& UI->ShowProfileUI(*Requestor, *Requestee, FOnProfileUIClosedDelegate());
}

bool UUECPSteamOverlayLibrary::ShowSteamWebURL(
	const UObject* WorldContextObject, const FString& Url, bool bModal)
{
	if (Url.IsEmpty())
	{
		return false;
	}

#if UECP_WITH_STEAM
	if (ISteamFriends* F = UECPSteam::Friends())
	{
		F->ActivateGameOverlayToWebPage(TCHAR_TO_UTF8(*Url),
			bModal ? k_EActivateGameOverlayToWebPageMode_Modal
			       : k_EActivateGameOverlayToWebPageMode_Default);
		return true;
	}
#endif

	const IOnlineExternalUIPtr UI = UECPSteamOSS::ExternalUI(WorldContextObject);
	return UI.IsValid() && UI->ShowWebURL(Url, FShowWebUrlParams(), FOnShowWebUrlClosedDelegate());
}

bool UUECPSteamOverlayLibrary::ShowSteamStoreUI(
	const UObject* WorldContextObject, int32 AppId, bool bAddToCart)
{
#if UECP_WITH_STEAM
	if (ISteamFriends* F = UECPSteam::Friends())
	{
		AppId_t Target = static_cast<AppId_t>(AppId);
		if (Target == 0)
		{
			if (ISteamUtils* U = UECPSteam::Utils())
			{
				Target = U->GetAppID();
			}
		}
		F->ActivateGameOverlayToStore(Target,
			bAddToCart ? k_EOverlayToStoreFlag_AddToCartAndShow : k_EOverlayToStoreFlag_None);
		return true;
	}
#endif
	return false;
}

bool UUECPSteamOverlayLibrary::ShowSteamSendMessageUI(const UObject* WorldContextObject, FUECPSteamID SteamId)
{
	if (!SteamId.IsValid())
	{
		return false;
	}

#if UECP_WITH_STEAM
	if (ISteamFriends* F = UECPSteam::Friends())
	{
		F->ActivateGameOverlayToUser("chat", UECPSteam::ToSteamID(SteamId.Value));
		return true;
	}
#endif

	const IOnlineExternalUIPtr UI = UECPSteamOSS::ExternalUI(WorldContextObject);
	const IOnlineIdentityPtr Identity = UECPSteamOSS::Identity(WorldContextObject);
	if (!UI.IsValid() || !Identity.IsValid())
	{
		return false;
	}
	const FUniqueNetIdPtr Recipient = Identity->CreateUniquePlayerId(SteamId.ToString());
	return Recipient.IsValid()
		&& UI->ShowSendMessageToUserUI(0, *Recipient, FShowSendMessageParams(), FOnShowSendMessageUIClosedDelegate());
}
