// Copyright 2026, BlueprintsLab, All rights reserved
#include "Library/UECPSteamAppsLibrary.h"

#include "UECPSteamAPI.h"

bool UUECPSteamAppsLibrary::IsSubscribed()
{
#if UECP_WITH_STEAM
	if (ISteamApps* A = UECPSteam::Apps()) { return A->BIsSubscribed(); }
#endif
	return false;
}

bool UUECPSteamAppsLibrary::IsSubscribedToApp(int32 AppId)
{
#if UECP_WITH_STEAM
	if (ISteamApps* A = UECPSteam::Apps()) { return A->BIsSubscribedApp(static_cast<AppId_t>(AppId)); }
#endif
	return false;
}

bool UUECPSteamAppsLibrary::IsSubscribedFromFreeWeekend()
{
#if UECP_WITH_STEAM
	if (ISteamApps* A = UECPSteam::Apps()) { return A->BIsSubscribedFromFreeWeekend(); }
#endif
	return false;
}

bool UUECPSteamAppsLibrary::IsSubscribedFromFamilySharing()
{
#if UECP_WITH_STEAM
	if (ISteamApps* A = UECPSteam::Apps()) { return A->BIsSubscribedFromFamilySharing(); }
#endif
	return false;
}

bool UUECPSteamAppsLibrary::IsVACBanned()
{
#if UECP_WITH_STEAM
	if (ISteamApps* A = UECPSteam::Apps()) { return A->BIsVACBanned(); }
#endif
	return false;
}

bool UUECPSteamAppsLibrary::IsDlcInstalled(int32 DlcAppId)
{
#if UECP_WITH_STEAM
	if (ISteamApps* A = UECPSteam::Apps()) { return A->BIsDlcInstalled(static_cast<AppId_t>(DlcAppId)); }
#endif
	return false;
}

TArray<FUECPSteamDlcInfo> UUECPSteamAppsLibrary::GetDlcList()
{
	TArray<FUECPSteamDlcInfo> Out;
#if UECP_WITH_STEAM
	ISteamApps* A = UECPSteam::Apps();
	if (!A)
	{
		return Out;
	}

	const int32 Count = A->GetDLCCount();
	Out.Reserve(Count);

	for (int32 Index = 0; Index < Count; ++Index)
	{
		AppId_t DlcAppId = 0;
		bool bAvailable = false;
		char NameBuffer[256] = {};

		if (!A->BGetDLCDataByIndex(Index, &DlcAppId, &bAvailable, NameBuffer, UE_ARRAY_COUNT(NameBuffer)))
		{
			continue;
		}

		FUECPSteamDlcInfo Info;
		Info.AppId      = static_cast<int32>(DlcAppId);
		Info.Name       = UTF8_TO_TCHAR(NameBuffer);
		Info.bAvailable = bAvailable;
		Info.bOwned     = A->BIsSubscribedApp(DlcAppId);
		Info.bInstalled = A->BIsDlcInstalled(DlcAppId);
		Out.Add(MoveTemp(Info));
	}
#endif
	return Out;
}

void UUECPSteamAppsLibrary::InstallDlc(int32 DlcAppId)
{
#if UECP_WITH_STEAM
	if (ISteamApps* A = UECPSteam::Apps()) { A->InstallDLC(static_cast<AppId_t>(DlcAppId)); }
#endif
}

void UUECPSteamAppsLibrary::UninstallDlc(int32 DlcAppId)
{
#if UECP_WITH_STEAM
	if (ISteamApps* A = UECPSteam::Apps()) { A->UninstallDLC(static_cast<AppId_t>(DlcAppId)); }
#endif
}

bool UUECPSteamAppsLibrary::GetDlcDownloadProgress(int32 DlcAppId, float& ProgressPercent,
	int64& BytesDownloaded, int64& BytesTotal)
{
	ProgressPercent = 0.f;
	BytesDownloaded = 0;
	BytesTotal      = 0;

#if UECP_WITH_STEAM
	if (ISteamApps* A = UECPSteam::Apps())
	{
		uint64 Downloaded = 0;
		uint64 Total = 0;
		if (A->GetDlcDownloadProgress(static_cast<AppId_t>(DlcAppId), &Downloaded, &Total))
		{
			BytesDownloaded = static_cast<int64>(Downloaded);
			BytesTotal      = static_cast<int64>(Total);
			ProgressPercent = Total > 0 ? (static_cast<float>(Downloaded) / static_cast<float>(Total)) * 100.f : 0.f;
			return true;
		}
	}
#endif
	return false;
}

FString UUECPSteamAppsLibrary::GetCurrentGameLanguage()
{
#if UECP_WITH_STEAM
	if (ISteamApps* A = UECPSteam::Apps()) { return UTF8_TO_TCHAR(A->GetCurrentGameLanguage()); }
#endif
	return FString();
}

TArray<FString> UUECPSteamAppsLibrary::GetAvailableGameLanguages()
{
	TArray<FString> Out;
#if UECP_WITH_STEAM
	if (ISteamApps* A = UECPSteam::Apps())
	{
		const FString Joined = UTF8_TO_TCHAR(A->GetAvailableGameLanguages());
		Joined.ParseIntoArray(Out, TEXT(","), true);
		for (FString& Entry : Out)
		{
			Entry.TrimStartAndEndInline();
		}
	}
#endif
	return Out;
}

int32 UUECPSteamAppsLibrary::GetAppBuildId()
{
#if UECP_WITH_STEAM
	if (ISteamApps* A = UECPSteam::Apps()) { return A->GetAppBuildId(); }
#endif
	return 0;
}

FString UUECPSteamAppsLibrary::GetCurrentBetaName()
{
#if UECP_WITH_STEAM
	if (ISteamApps* A = UECPSteam::Apps())
	{
		char Buffer[256] = {};
		if (A->GetCurrentBetaName(Buffer, UE_ARRAY_COUNT(Buffer)))
		{
			return UTF8_TO_TCHAR(Buffer);
		}
	}
#endif
	return FString();
}

FString UUECPSteamAppsLibrary::GetAppInstallDir(int32 AppId)
{
#if UECP_WITH_STEAM
	if (ISteamApps* A = UECPSteam::Apps())
	{
		char Buffer[1024] = {};
		if (A->GetAppInstallDir(static_cast<AppId_t>(AppId), Buffer, UE_ARRAY_COUNT(Buffer)) > 0)
		{
			return UTF8_TO_TCHAR(Buffer);
		}
	}
#endif
	return FString();
}

FString UUECPSteamAppsLibrary::GetLaunchCommandLine()
{
#if UECP_WITH_STEAM
	if (ISteamApps* A = UECPSteam::Apps())
	{
		char Buffer[1024] = {};
		if (A->GetLaunchCommandLine(Buffer, UE_ARRAY_COUNT(Buffer)) > 0)
		{
			return UTF8_TO_TCHAR(Buffer);
		}
	}
#endif
	return FString();
}

FString UUECPSteamAppsLibrary::GetLaunchQueryParam(const FString& Key)
{
#if UECP_WITH_STEAM
	if (ISteamApps* A = UECPSteam::Apps())
	{
		return UTF8_TO_TCHAR(A->GetLaunchQueryParam(TCHAR_TO_UTF8(*Key)));
	}
#endif
	return FString();
}

FUECPSteamID UUECPSteamAppsLibrary::GetAppOwner()
{
#if UECP_WITH_STEAM
	if (ISteamApps* A = UECPSteam::Apps()) { return FUECPSteamID(UECPSteam::FromSteamID(A->GetAppOwner())); }
#endif
	return FUECPSteamID();
}
