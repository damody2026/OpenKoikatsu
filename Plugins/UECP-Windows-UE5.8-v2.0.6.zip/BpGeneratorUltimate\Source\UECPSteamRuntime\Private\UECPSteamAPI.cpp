// Copyright 2026, BlueprintsLab, All rights reserved
#include "UECPSteamAPI.h"

#include "Async/Async.h"
#include "Modules/ModuleManager.h"
#include "OnlineSubsystem.h"
#include "OnlineSubsystemNames.h"

#if UECP_WITH_STEAM
#include "SteamSharedModule.h"
#endif

namespace
{
	TSharedPtr<class FSteamClientInstanceHandler> GClientHandle;
	TSharedPtr<class FSteamServerInstanceHandler> GServerHandle;

	bool GClientAcquireAttempted = false;
	bool GServerAcquireAttempted = false;
}

bool UECPSteam::AcquireClient()
{
#if UECP_WITH_STEAM
	if (GClientHandle.IsValid())
	{
		return true;
	}
	if (GClientAcquireAttempted)
	{
		return false;
	}
	GClientAcquireAttempted = true;

	FSteamSharedModule* Shared = FModuleManager::LoadModulePtr<FSteamSharedModule>(TEXT("SteamShared"));
	if (!Shared)
	{
		UE_LOG(LogUECPSteam, Log,
			TEXT("SteamShared module is not available -- Steam features are disabled. Enable the OnlineSubsystemSteam plugin."));
		return false;
	}

	GClientHandle = Shared->ObtainSteamClientInstanceHandle();
	if (!GClientHandle.IsValid())
	{
		UE_LOG(LogUECPSteam, Log,
			TEXT("Steam client API did not initialise (client not running, or steam_appid.txt missing) -- Steam features are disabled."));
		return false;
	}

	UE_LOG(LogUECPSteam, Log, TEXT("Steam client API acquired (AppID %u, OSS Steam %s)."),
		SteamUtils() ? SteamUtils()->GetAppID() : 0,
		IsOssSteamActive() ? TEXT("active") : TEXT("inactive"));
	return true;
#else
	return false;
#endif
}

void UECPSteam::ReleaseClient()
{
	GClientHandle.Reset();
	GClientAcquireAttempted = false;
}

bool UECPSteam::IsClientAvailable()
{
#if UECP_WITH_STEAM
	if (GClientHandle.IsValid())
	{
		return true;
	}
	return IsInGameThread() && AcquireClient();
#else
	return false;
#endif
}

bool UECPSteam::IsOssSteamActive()
{
	return IOnlineSubsystem::IsLoaded(STEAM_SUBSYSTEM)
		&& IOnlineSubsystem::Get(STEAM_SUBSYSTEM) != nullptr;
}

void UECPSteam::PumpCallbacks()
{
#if UECP_WITH_STEAM
	if (!GClientHandle.IsValid())
	{
		return;
	}
	if (IsOssSteamActive())
	{
		return;
	}
	SteamAPI_RunCallbacks();
#endif
}

EUECPSteamResult UECPSteam::MapResult(int32 RawResult)
{
	switch (RawResult)
	{
	case 1:  return EUECPSteamResult::Success;
	case 8:  return EUECPSteamResult::InvalidParameter;
	case 9:  return EUECPSteamResult::NotFound;
	case 15: return EUECPSteamResult::AccessDenied;
	case 16: return EUECPSteamResult::Timeout;
	case 17: return EUECPSteamResult::AccessDenied;
	case 18: return EUECPSteamResult::NotFound;
	case 21: return EUECPSteamResult::NotLoggedIn;
	case 24: return EUECPSteamResult::AccessDenied;
	case 25: return EUECPSteamResult::RateLimited;
	case 84: return EUECPSteamResult::RateLimited;

	case 2:
	case 3:
	case 10:
	case 11:
	case 20:
		return EUECPSteamResult::BackendFailure;

	case 0:
	default:
		return EUECPSteamResult::Unknown;
	}
}

FUECPSteamError UECPSteam::MakeError(int32 RawResult, const FString& Context)
{
	const EUECPSteamResult Mapped = MapResult(RawResult);
	if (Mapped == EUECPSteamResult::Success)
	{
		return FUECPSteamError();
	}
	return FUECPSteamError(Mapped,
		FString::Printf(TEXT("%s (Steam EResult %d)"), *Context, RawResult), RawResult);
}

void UECPSteam::RunOnGameThread(TFunction<void()> Work)
{
	if (IsInGameThread())
	{
		Work();
		return;
	}
	AsyncTask(ENamedThreads::GameThread, [Work = MoveTemp(Work)]() { Work(); });
}

#if UECP_WITH_STEAM

namespace
{
	bool EnsureClient()
	{
		if (GClientHandle.IsValid())
		{
			return true;
		}
		return IsInGameThread() && UECPSteam::AcquireClient();
	}
}

#define UECP_STEAM_ACCESSOR(ReturnType, FuncName, SdkAccessor) \
	ReturnType UECPSteam::FuncName() \
	{ \
		return EnsureClient() ? SdkAccessor() : nullptr; \
	}

UECP_STEAM_ACCESSOR(ISteamApps*,               Apps,               SteamApps)
UECP_STEAM_ACCESSOR(ISteamUser*,               User,               SteamUser)
UECP_STEAM_ACCESSOR(ISteamFriends*,            Friends,            SteamFriends)
UECP_STEAM_ACCESSOR(ISteamUserStats*,          UserStats,          SteamUserStats)
UECP_STEAM_ACCESSOR(ISteamUtils*,              Utils,              SteamUtils)
UECP_STEAM_ACCESSOR(ISteamRemoteStorage*,      RemoteStorage,      SteamRemoteStorage)
UECP_STEAM_ACCESSOR(ISteamUGC*,                UGC,                SteamUGC)
UECP_STEAM_ACCESSOR(ISteamInput*,              Input,              SteamInput)
UECP_STEAM_ACCESSOR(ISteamInventory*,          Inventory,          SteamInventory)
UECP_STEAM_ACCESSOR(ISteamMatchmaking*,        Matchmaking,        SteamMatchmaking)
UECP_STEAM_ACCESSOR(ISteamMatchmakingServers*, MatchmakingServers, SteamMatchmakingServers)
UECP_STEAM_ACCESSOR(ISteamScreenshots*,        Screenshots,        SteamScreenshots)
UECP_STEAM_ACCESSOR(ISteamMusic*,              Music,              SteamMusic)
UECP_STEAM_ACCESSOR(ISteamParentalSettings*,   ParentalSettings,   SteamParentalSettings)
UECP_STEAM_ACCESSOR(ISteamRemotePlay*,         RemotePlay,         SteamRemotePlay)
UECP_STEAM_ACCESSOR(ISteamNetworkingUtils*,    NetworkingUtils,    SteamNetworkingUtils)
UECP_STEAM_ACCESSOR(ISteamNetworkingSockets*,  NetworkingSockets,  SteamNetworkingSockets)
UECP_STEAM_ACCESSOR(ISteamNetworkingMessages*, NetworkingMessages, SteamNetworkingMessages)
UECP_STEAM_ACCESSOR(ISteamHTTP*,               HTTP,               SteamHTTP)

#if UECP_STEAM_SDK_VER >= 161
UECP_STEAM_ACCESSOR(ISteamTimeline*,           Timeline,           SteamTimeline)
#endif

#undef UECP_STEAM_ACCESSOR

bool UECPSteam::AcquireServer()
{
	if (GServerHandle.IsValid())
	{
		return true;
	}
	if (GServerAcquireAttempted)
	{
		return false;
	}
	GServerAcquireAttempted = true;

	FSteamSharedModule* Shared = FModuleManager::LoadModulePtr<FSteamSharedModule>(TEXT("SteamShared"));
	if (!Shared)
	{
		UE_LOG(LogUECPSteam, Log, TEXT("SteamShared module is not available -- Steam game server features are disabled."));
		return false;
	}

	GServerHandle = Shared->ObtainSteamServerInstanceHandle();
	if (!GServerHandle.IsValid())
	{
		UE_LOG(LogUECPSteam, Log, TEXT("Steam game server API did not initialise -- Steam game server features are disabled."));
		return false;
	}

	UE_LOG(LogUECPSteam, Log, TEXT("Steam game server API acquired."));
	return true;
}

void UECPSteam::ReleaseServer()
{
	GServerHandle.Reset();
	GServerAcquireAttempted = false;
}

bool UECPSteam::IsServerAvailable()
{
	return GServerHandle.IsValid();
}

ISteamGameServer* UECPSteam::GameServer()
{
	return GServerHandle.IsValid() ? SteamGameServer() : nullptr;
}

ISteamGameServerStats* UECPSteam::GameServerStats()
{
	return GServerHandle.IsValid() ? SteamGameServerStats() : nullptr;
}

void UECPSteam::PumpServerCallbacks()
{
	if (!GServerHandle.IsValid() || IsOssSteamActive())
	{
		return;
	}
	SteamGameServer_RunCallbacks();
}

#endif
