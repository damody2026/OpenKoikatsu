(function () {
  const FLASH_MS = 1900;

  const CHECK = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" '
    + 'stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>';

  const SAVED = 'Saved';

  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  function now() { return Date.now(); }

  function paint(page) {
    if (!page || !page.querySelector) return;
    if (page._saveFlashTimer) { clearTimeout(page._saveFlashTimer); page._saveFlashTimer = null; }
    const el = page.querySelector('.save-bar [data-save-flash]');
    if (!el) return;
    const left = (page._saveFlashUntil || 0) - now();
    if (left <= 0) { el.classList.remove('on'); return; }
    el.classList.add('on');
    page._saveFlashTimer = setTimeout(function () {
      page._saveFlashTimer = null;
      const cur = page.querySelector('.save-bar [data-save-flash]');
      if (cur) cur.classList.remove('on');
    }, left);
  }

  function html(page, buttonId, opts) {
    const o = opts || {};
    const lit = ((page && page._saveFlashUntil) || 0) > now();
    if (lit) setTimeout(function () { paint(page); }, 0);
    return '<div class="save-bar">'
      + '<button class="ue-btn accent" id="' + esc(buttonId) + '">' + esc(o.label || 'Save') + '</button>'
      + (o.extra || '')
      + '<span class="save-flash' + (lit ? ' on' : '') + '" data-save-flash role="status">'
      + CHECK + SAVED + '</span>'
      + '</div>';
  }

  function flash(page) {
    if (!page) return;
    page._saveFlashUntil = now() + FLASH_MS;
    paint(page);
  }

  function autosave(root, saveFn) {
    if (!root || typeof saveFn !== 'function') return;
    const fire = function () { saveFn(); };
    const bind = function (sel, evt) {
      root.querySelectorAll(sel).forEach(function (el) {
        if (el.hasAttribute('data-no-autosave')) return;
        el.addEventListener(evt, fire);
      });
    };
    bind('.toggle', 'click');
    bind('.ue-seg', 'click');
    root.querySelectorAll('select, input, textarea').forEach(function (el) {
      if (el.hasAttribute('data-no-autosave')) return;
      const t = String(el.type || '').toLowerCase();
      if (t === 'button' || t === 'submit' || t === 'file') return;
      el.addEventListener('change', fire);
    });
  }

  window.UECP = window.UECP || {};
  window.UECP.saveBar = { html: html, flash: flash, paint: paint, autosave: autosave, FLASH_MS: FLASH_MS };
})();
