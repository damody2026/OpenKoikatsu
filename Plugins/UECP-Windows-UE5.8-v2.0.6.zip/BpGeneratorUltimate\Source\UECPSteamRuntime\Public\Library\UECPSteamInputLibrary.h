// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "UECPSteamTypes.h"
#include "UECPSteamInputLibrary.generated.h"

class UTexture2D;

USTRUCT(BlueprintType)
struct UECPSTEAMRUNTIME_API FUECPSteamInputHandle
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadWrite, EditAnywhere, Category = "UECP|Steam")
	int64 Value = 0;

	FUECPSteamInputHandle() = default;
	explicit FUECPSteamInputHandle(int64 InValue) : Value(InValue) {}

	bool IsValid() const { return Value != 0; }
	bool operator==(const FUECPSteamInputHandle& Other) const { return Value == Other.Value; }
	friend uint32 GetTypeHash(const FUECPSteamInputHandle& H) { return ::GetTypeHash(H.Value); }
};

UENUM(BlueprintType)
enum class EUECPSteamInputType : uint8
{
	Unknown         UMETA(DisplayName = "Unknown"),
	SteamController UMETA(DisplayName = "Steam Controller"),
	XBox360         UMETA(DisplayName = "Xbox 360"),
	XBoxOne         UMETA(DisplayName = "Xbox One"),
	GenericGamepad  UMETA(DisplayName = "Generic Gamepad"),
	PS4             UMETA(DisplayName = "PlayStation 4"),
	PS5             UMETA(DisplayName = "PlayStation 5"),
	SwitchPro       UMETA(DisplayName = "Switch Pro"),
	SteamDeck       UMETA(DisplayName = "Steam Deck"),
	Mobile          UMETA(DisplayName = "Mobile Touch"),
};

UENUM(BlueprintType)
enum class EUECPSteamGlyphSize : uint8
{
	Small  UMETA(DisplayName = "Small (32px)"),
	Medium UMETA(DisplayName = "Medium (128px)"),
	Large  UMETA(DisplayName = "Large (256px)"),
};

USTRUCT(BlueprintType)
struct UECPSTEAMRUNTIME_API FUECPSteamDigitalAction
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	bool bPressed = false;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	bool bActive = false;
};

USTRUCT(BlueprintType)
struct UECPSTEAMRUNTIME_API FUECPSteamAnalogAction
{
	GENERATED_BODY()

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	float X = 0.f;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	float Y = 0.f;

	UPROPERTY(BlueprintReadOnly, Category = "UECP|Steam")
	bool bActive = false;
};

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamInputLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Input")
	static TArray<FUECPSteamInputHandle> GetConnectedControllers();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Input")
	static EUECPSteamInputType GetControllerType(FUECPSteamInputHandle Controller);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Input")
	static bool ActivateActionSet(FUECPSteamInputHandle Controller, const FString& ActionSetName);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Input")
	static bool ActivateActionSetLayer(FUECPSteamInputHandle Controller, const FString& ActionSetLayerName);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Input")
	static bool DeactivateActionSetLayer(FUECPSteamInputHandle Controller, const FString& ActionSetLayerName);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Input")
	static bool DeactivateAllActionSetLayers(FUECPSteamInputHandle Controller);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Input")
	static FUECPSteamDigitalAction GetDigitalAction(FUECPSteamInputHandle Controller, const FString& ActionName);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Input")
	static FUECPSteamAnalogAction GetAnalogAction(FUECPSteamInputHandle Controller, const FString& ActionName);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Input", meta = (AdvancedDisplay = "bDigital"))
	static FString GetActionOriginText(FUECPSteamInputHandle Controller, const FString& ActionName,
		bool bDigital = true);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Input", meta = (AdvancedDisplay = "Size,bDigital"))
	static UTexture2D* GetActionGlyph(FUECPSteamInputHandle Controller, const FString& ActionName,
		EUECPSteamGlyphSize Size = EUECPSteamGlyphSize::Medium, bool bDigital = true);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Input")
	static void TriggerVibration(FUECPSteamInputHandle Controller, int32 LeftSpeed, int32 RightSpeed);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Input")
	static void SetLEDColor(FUECPSteamInputHandle Controller, FLinearColor Color);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Input")
	static bool ShowBindingPanel(FUECPSteamInputHandle Controller);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Input")
	static void GetMotionData(FUECPSteamInputHandle Controller,
		FVector& RotationVelocity, FVector& Acceleration, FQuat& Orientation);
};
