(function () {
  if (!document.getElementById('uecp-settings-highlight-css')) {
    const s = document.createElement('style'); s.id = 'uecp-settings-highlight-css';
    s.textContent = `
.setting-highlight{outline:2px solid var(--ue-accent);outline-offset:6px;border-radius:var(--ue-r)}`;
    document.head.appendChild(s);
  }

  const PAGES = {
    ai:     'settings-ai-models',
    img:    'settings-image',
    audio:  'settings-audio',
    appear: 'settings-appearance',
    a11y:   'settings-a11y',
    prefs:  'settings-prefs',
    behav:  'settings-behaviour',
    index:  'settings-project-index',
    ext:    'settings-extensions',
    info:   'settings-info',
  };

  class UecpScreenSettings extends HTMLElement {
    connectedCallback() {
      this._page  = (window.UECP && window.UECP._startupSub) || 'ai';
      if (window.UECP) window.UECP._startupSub = null;
      this._subscribe();
      this._build();
      window.uecp.call('request_settings', {});
    }

    disconnectedCallback() {
      if (this._host) { this._host.dispose(); this._host = null; }
      this._clearHighlight();
    }

    _build() {
      this.innerHTML = '';
      this.style.cssText = 'display:flex;flex:1;min-width:0;min-height:0;background:var(--ue-bg)';

      this._nav = document.createElement('uecp-settings-nav');
      this._nav.setAttribute('page', this._page);
      this.appendChild(this._nav);

      const col = document.createElement('div');
      col.style.cssText = 'flex:1;min-width:0;min-height:0;display:flex;flex-direction:column;background:var(--ue-bg)';

      this._body = document.createElement('main');
      this._body.style.cssText = 'flex:1;min-height:0;display:flex;flex-direction:column';
      col.appendChild(this._body);
      this.appendChild(col);

      const self = this;
      this._nav.addEventListener('settings-nav-change', function (e) {
        self._showPage(e.detail.page);
      });

      this._showPage(this._page);
    }

    _subscribe() {
      const self = this;
      this._host = window.UECP.settingsHost.create(function () {
        return self._body && self._body.firstElementChild;
      });
    }

    _applyPendingHighlight() {
      const id = window.UECP && window.UECP._highlightSetting;
      if (!id) return;
      window.UECP._highlightSetting = null;
      this._clearHighlight();
      const self = this;
      const until = Date.now() + 8000;
      let scrolled = false;
      const tick = function () {
        const el = self.querySelector('#' + id);
        const row = el && (el.closest('.toggle-row') || el.parentElement || el);
        if (row) {
          row.classList.add('setting-highlight');
          if (!scrolled && row.scrollIntoView) { scrolled = true; row.scrollIntoView({ block: 'center' }); }
        }
        if (Date.now() < until) { self._hlTimer = setTimeout(tick, 150); return; }
        self._hlTimer = null;
        if (row) row.classList.remove('setting-highlight');
      };
      tick();
    }

    _clearHighlight() {
      if (this._hlTimer) { clearTimeout(this._hlTimer); this._hlTimer = null; }
    }

    _showPage(id) {
      if (this._page === id && this._body.firstElementChild) { this._applyPendingHighlight(); return; }
      this._page = id;
      this._nav.page = id;

      while (this._body.firstChild) this._body.removeChild(this._body.firstChild);

      const tag = PAGES[id];
      if (!tag) {
        const errDiv = document.createElement('div');
        errDiv.style.cssText = 'padding:24px;font-size:13px;color:var(--ue-danger)';
        errDiv.textContent = 'Unknown settings page: ' + id;
        this._body.appendChild(errDiv);
        return;
      }
      try {
        const el = document.createElement(tag);
        this._body.appendChild(el);
        this._host.prime(el);
        this._applyPendingHighlight();
      } catch (err) {
        const errDiv = document.createElement('div');
        errDiv.style.cssText = 'padding:24px;font-size:13px;color:var(--ue-danger)';
        errDiv.textContent = 'Failed to load ' + tag + ': ' + String(err);
        this._body.appendChild(errDiv);
      }
    }
  }

  customElements.define('uecp-screen-settings', UecpScreenSettings);

  if (window.UECP && window.UECP.router) {
    window.UECP.router.register('settings', 'uecp-screen-settings');
  }
})();
