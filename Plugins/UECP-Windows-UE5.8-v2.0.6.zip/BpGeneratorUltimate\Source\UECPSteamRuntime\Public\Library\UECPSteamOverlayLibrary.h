// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "UECPSteamTypes.h"
#include "UECPSteamOverlayLibrary.generated.h"

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamOverlayLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Overlay",
		meta = (WorldContext = "WorldContextObject"))
	static bool ShowSteamFriendsUI(const UObject* WorldContextObject);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Overlay",
		meta = (WorldContext = "WorldContextObject", AdvancedDisplay = "SessionName"))
	static bool ShowSteamInviteUI(const UObject* WorldContextObject, FName SessionName);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Overlay",
		meta = (WorldContext = "WorldContextObject"))
	static bool ShowSteamAchievementsUI(const UObject* WorldContextObject);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Overlay",
		meta = (WorldContext = "WorldContextObject"))
	static bool ShowSteamLeaderboardUI(const UObject* WorldContextObject, const FString& LeaderboardName);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Overlay",
		meta = (WorldContext = "WorldContextObject"))
	static bool ShowSteamProfileUI(const UObject* WorldContextObject, FUECPSteamID SteamId);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Overlay",
		meta = (WorldContext = "WorldContextObject", AdvancedDisplay = "bModal"))
	static bool ShowSteamWebURL(const UObject* WorldContextObject, const FString& Url, bool bModal = false);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Overlay",
		meta = (WorldContext = "WorldContextObject", AdvancedDisplay = "AppId,bAddToCart"))
	static bool ShowSteamStoreUI(const UObject* WorldContextObject, int32 AppId = 0, bool bAddToCart = false);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Overlay",
		meta = (WorldContext = "WorldContextObject"))
	static bool ShowSteamSendMessageUI(const UObject* WorldContextObject, FUECPSteamID SteamId);
};
