(function () {
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  if (!document.getElementById('uecp-instructions-overlay-css')) {
    var s = document.createElement('style'); s.id = 'uecp-instructions-overlay-css';
    s.textContent = [
'uecp-instructions-overlay{position:fixed;inset:0;z-index:1200;display:none}',
'uecp-instructions-overlay.open{display:block}',
'uecp-instructions-overlay .overlay{position:absolute;inset:0;background:rgba(0,0,0,.5);display:flex;align-items:center;justify-content:center}',
'uecp-instructions-overlay .modal{width:640px;max-width:calc(100% - 24px);height:520px;max-height:calc(100% - 24px);display:flex;flex-direction:column;overflow:hidden;background:var(--ue-panel);border:1px solid var(--ue-line);border-radius:var(--ue-r-lg)}',
'uecp-instructions-overlay .ci-edit{flex:1;min-height:0;width:100%;box-sizing:border-box;background:var(--ue-bg);border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);color:var(--ue-text-hi);padding:12px;font-size:12.5px;font-family:var(--ue-font-mono);resize:none;line-height:1.55}',
'uecp-instructions-overlay .ci-edit:focus{outline:none;border-color:var(--ue-accent)}',
'uecp-instructions-overlay .ci-body{flex:1;min-height:0;display:flex;flex-direction:column;padding:14px 20px}',
'uecp-instructions-overlay .ci-foot{padding:12px 20px;border-top:1px solid var(--ue-line-soft);display:flex;align-items:center;gap:10px;justify-content:flex-end}'
    ].join('\n');
    document.head.appendChild(s);
  }

  class UecpInstructionsOverlay extends HTMLElement {
    connectedCallback() {
      this._text = '';
      this._build();
      var self = this;
      this._subs = [
        window.uecp.on('instructions.loaded', function (d) { self._onLoaded(d); }),
      ];
    }
    disconnectedCallback() { (this._subs || []).forEach(function (u) { u(); }); this._subs = []; }

    open() {
      this.classList.add('open');
      var ta = this.querySelector('.ci-edit');
      if (ta) ta.value = 'Loading…';
      window.uecp.call('load_custom_instructions', {});
    }
    close() { this.classList.remove('open'); }
    isOpen() { return this.classList.contains('open'); }

    _onLoaded(d) {
      this._text = (d && typeof d.text === 'string') ? d.text : '';
      var ta = this.querySelector('.ci-edit');
      if (ta) ta.value = this._text;
    }

    _build() {
      var self = this;
      this.innerHTML = '';
      var overlay = document.createElement('div');
      overlay.className = 'overlay';
      window.UECP.dom.bindBackdropClose(overlay, function () { self.close(); });
      this.appendChild(overlay);

      var box = document.createElement('div');
      box.className = 'modal';
      box.innerHTML =
        '<div class="modal-head">' +
          '<div style="flex:1">' +
            '<div class="modal-title">Custom Instructions</div>' +
            '<div class="modal-sub">Persistent guidance the Architect reads as context</div>' +
          '</div>' +
          '<button class="icon-btn" data-act="close" title="Close" aria-label="Close"><svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18M6 6l12 12"/></svg></button>' +
        '</div>' +
        '<div class="ci-body"><textarea class="ci-edit" placeholder="e.g. Always prefer Blueprint interfaces over casts. Use my project naming conventions…" spellcheck="false"></textarea></div>' +
        '<div class="ci-foot">' +
          '<button class="ue-btn" data-act="cancel">Cancel</button>' +
          '<button class="ue-btn accent" data-act="save">Save</button>' +
        '</div>';
      overlay.appendChild(box);

      box.querySelector('[data-act="close"]').addEventListener('click', function () { self.close(); });
      box.querySelector('[data-act="cancel"]').addEventListener('click', function () { self.close(); });
      box.querySelector('[data-act="save"]').addEventListener('click', function () {
        var ta = self.querySelector('.ci-edit');
        window.uecp.call('save_custom_instructions', { text: ta ? ta.value : '' });
        self.close();
      });
    }
  }

  customElements.define('uecp-instructions-overlay', UecpInstructionsOverlay);

  window.UECP = window.UECP || {};
  window.UECP.openInstructions = function () {
    var ov = document.querySelector('uecp-instructions-overlay');
    if (!ov) { ov = document.createElement('uecp-instructions-overlay'); document.body.appendChild(ov); }
    ov.open();
    return ov;
  };
})();
