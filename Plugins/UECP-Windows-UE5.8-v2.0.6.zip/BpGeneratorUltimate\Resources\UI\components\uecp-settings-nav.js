(function () {
  const ITEMS = [
    { id: 'ai',     label: 'AI Models',      svg: '<circle cx="12" cy="12" r="9"/><path d="M12 8v4"/><circle cx="12" cy="16" r=".5" fill="currentColor"/>' },
    { id: 'img',    label: 'Image & 3D',     svg: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-5-5L5 21"/>' },
    { id: 'audio',  label: 'Audio',          svg: '<rect x="9" y="2" width="6" height="11" rx="3"/><path d="M5 10a7 7 0 0 0 14 0M12 19v3"/>' },
    { id: 'appear', label: 'Appearance',     svg: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M5 5l1.5 1.5M17.5 17.5 19 19M5 19l1.5-1.5M17.5 6.5 19 5"/>' },
    { id: 'a11y',   label: 'Accessibility',  svg: '<circle cx="12" cy="4" r="2"/><path d="M12 8v6M7 11h10M8 20l4-6 4 6"/>' },
    { id: 'prefs',  label: 'Preferences',    svg: '<path d="M3 5h18M3 12h18M3 19h18"/>' },
    { id: 'behav',  label: 'AI Behaviour',   svg: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>' },
    { id: 'index',  label: 'Project Index', svg: '<circle cx="11" cy="11" r="7"/><path d="m20 20-4.3-4.3"/>' },
    { id: 'ext',    label: 'Extensions',     svg: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><path d="M14 17h7M17.5 14v7"/>' },
  ];
  const INFO  = { id: 'info',  label: 'Info',         svg: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5"/><circle cx="12" cy="8" r=".5" fill="currentColor"/>' };

  function mkSvg(path, sw) {
    return '<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="' + (sw || '1.6') + '" stroke-linecap="round" stroke-linejoin="round">' + path + '</svg>';
  }

  class UecpSettingsNav extends HTMLElement {
    get page() { return this._page || 'ai'; }
    set page(v) { this._page = v; this._sync(); }

    connectedCallback() {
      this.classList.add('settings-nav');
      this._page = this.getAttribute('page') || 'ai';
      this._build();
    }

    _build() {
      this.innerHTML = '';

      const title = document.createElement('div');
      title.className = 'title';
      title.textContent = 'Settings';
      this.appendChild(title);

      const self = this;

      function mkItem(it) {
        const node = document.createElement('div');
        node.className = 'nav-item';
        if (it.id) node.dataset.sub = it.id;
        node.title = it.label;
        node.dataset.tip = it.label;
        node.innerHTML = mkSvg(it.svg) + '<span>' + it.label + '</span>';
        return node;
      }

      ITEMS.forEach(function (it) {
        const node = mkItem(it);
        node.addEventListener('click', function () { self._select(it.id); });
        self.appendChild(node);
      });

      const spacer = document.createElement('div');
      spacer.className = 'spacer';
      this.appendChild(spacer);

      const infoNode = mkItem(INFO);
      infoNode.dataset.sub = INFO.id;
      infoNode.addEventListener('click', function () { self._select(INFO.id); });
      this.appendChild(infoNode);

      this._sync();
    }

    _select(id) {
      this._page = id;
      this._sync();
      this.dispatchEvent(new CustomEvent('settings-nav-change', { bubbles: true, detail: { page: id } }));
    }

    _sync() {
      const p = this._page || 'ai';
      this.querySelectorAll('.nav-item[data-sub]').forEach(function (n) {
        n.classList.toggle('active', n.dataset.sub === p);
      });
    }
  }
  customElements.define('uecp-settings-nav', UecpSettingsNav);
})();
