(function () {
  const esc = (s) => (window.UECP && window.UECP.escapeHtml)
    ? window.UECP.escapeHtml(s) : String(s == null ? '' : s);
  const icon = (n, sz) => (window.UECP && window.UECP.icon) ? window.UECP.icon(n, sz || 15) : '';

  if (!document.getElementById('uecp-localstudio-css')) {
    const s = document.createElement('style');
    s.id = 'uecp-localstudio-css';
    s.textContent = `
uecp-screen-localstudio{display:block;height:100%;overflow-y:auto}
uecp-screen-localstudio .ls-card{background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-md,8px);padding:16px;margin-bottom:14px}
uecp-screen-localstudio .ls-head{display:flex;align-items:center;gap:10px;margin-bottom:4px}
uecp-screen-localstudio .ls-name{font-size:14px;font-weight:var(--ue-fw-semi,600);color:var(--ue-text-hi)}
uecp-screen-localstudio .ls-dot{width:8px;height:8px;border-radius:50%;flex-shrink:0}
uecp-screen-localstudio .ls-dot.ready{background:var(--ue-ok,#4fb87a)}
uecp-screen-localstudio .ls-dot.not_detected{background:var(--ue-text-lo)}
uecp-screen-localstudio .ls-dot.error{background:var(--ue-err,#e06c6c)}
uecp-screen-localstudio .ls-dot.probing{background:var(--ue-accent-bright)}
uecp-screen-localstudio .ls-dot.unknown{background:var(--ue-text-lo)}
uecp-screen-localstudio .ls-state{font-size:11px;color:var(--ue-text-lo);margin-left:auto;font-family:var(--ue-font-mono)}
uecp-screen-localstudio .ls-blurb{font-size:12.5px;color:var(--ue-text-mid);margin-bottom:10px}
uecp-screen-localstudio .ls-detail{font-size:12px;color:var(--ue-text-lo);margin-bottom:10px}
uecp-screen-localstudio .ls-row{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
uecp-screen-localstudio .ls-url{flex:1;min-width:200px;background:var(--ue-bg);border:1px solid var(--ue-line);border-radius:var(--ue-r-sm,5px);padding:6px 9px;color:var(--ue-text-hi);font-family:var(--ue-font-mono);font-size:12px;outline:none}
uecp-screen-localstudio .ls-models{display:flex;flex-wrap:wrap;gap:5px;margin-top:10px}
uecp-screen-localstudio .ls-model{background:var(--ue-bg);border:1px solid var(--ue-line-soft);border-radius:99px;padding:3px 9px;font-size:11px;color:var(--ue-text-mid);font-family:var(--ue-font-mono)}
uecp-screen-localstudio .ls-hint{background:var(--ue-accent-soft);border:1px solid var(--ue-line);border-radius:var(--ue-r-sm,5px);padding:9px 11px;font-size:12px;color:var(--ue-text-hi);margin-top:10px}
uecp-screen-localstudio .ls-btn{background:var(--ue-panel);border:1px solid var(--ue-line);color:var(--ue-text-hi);border-radius:var(--ue-r-sm,5px);padding:6px 12px;font-size:12px;cursor:pointer}
uecp-screen-localstudio .ls-btn:hover{background:var(--ue-line-soft)}
uecp-screen-localstudio .ls-btn.primary{background:var(--ue-accent);border-color:var(--ue-accent);color:#fff}
uecp-screen-localstudio .ls-btn[disabled]{opacity:.55;cursor:default}
uecp-screen-localstudio .ls-tabs{display:flex;gap:4px;margin:18px 0 16px;border-bottom:1px solid var(--ue-line-soft);padding-bottom:8px}
uecp-screen-localstudio .ls-tab{background:none;border:none;color:var(--ue-text-mid);padding:5px 12px;font-size:12.5px;cursor:pointer;border-radius:var(--ue-r-sm,5px)}
uecp-screen-localstudio .ls-tab.active{background:var(--ue-accent-soft);color:var(--ue-accent-bright)}
uecp-screen-localstudio .ls-field{margin-bottom:11px}
uecp-screen-localstudio .ls-label{font-size:11px;color:var(--ue-text-mid);margin-bottom:4px}
uecp-screen-localstudio .ls-input{width:100%;box-sizing:border-box;background:var(--ue-bg);border:1px solid var(--ue-line);border-radius:var(--ue-r-sm,5px);padding:7px 9px;color:var(--ue-text-hi);font-size:12.5px;outline:none;font-family:inherit}
uecp-screen-localstudio .ls-2col{display:grid;grid-template-columns:1fr 1fr;gap:10px}
uecp-screen-localstudio .ls-jobs{background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r-sm,5px);padding:10px;margin-top:14px;font-size:12px;color:var(--ue-text-mid)}
uecp-screen-localstudio .ls-job{padding:6px 0;border-bottom:1px solid var(--ue-line-soft);display:flex;gap:8px;align-items:center}
uecp-screen-localstudio .ls-job:last-child{border-bottom:none}
uecp-screen-localstudio .ls-warn{font-size:11.5px;color:var(--ue-text-lo);margin-top:9px;line-height:1.45}
/* Links default to browser blue, which is both off-theme and low-contrast against this
   panel's dark background. Accent rather than red: red is what the Delete button uses, and a
   benign "see the full list" link sharing that colour would read as a warning. Underline on
   hover only, so a line of prose with a link in it is not visually noisy. */
uecp-screen-localstudio a{color:var(--ue-accent-bright);text-decoration:none;border-bottom:1px solid transparent;transition:border-color .12s}
uecp-screen-localstudio a:hover{border-bottom-color:currentColor}
`;
    document.head.appendChild(s);
  }

  const TUNABLES = [
    { key: 'seconds', label: 'Length (seconds)', step: '0.1' },
    { key: 'width',   label: 'Width',            step: '8'   },
    { key: 'height',  label: 'Height',           step: '8'   },
    { key: 'length',  label: 'Frames',           step: '1'   },
    { key: 'fps',     label: 'FPS',              step: '1'   },
    { key: 'steps',   label: 'Steps',            step: '1'   },
    { key: 'cfg',     label: 'Guidance (CFG)',   step: '0.1' },
  ];

  const isDerived = (name) => String(name || '').indexOf('-uecp') !== -1;
  const baseModels = (models) => (models || []).filter((m) => !isDerived(m));

  const PARAMS = [
    { key: 'num_ctx',        label: 'Context window',  step: '4096', hint: '32768',
      why: 'Tokens the model can see. Ollama defaults to 4096 and truncates the rest.' },
    { key: 'num_gpu',        label: 'GPU layers',      step: '1',    hint: 'all',
      why: 'Layers kept on the GPU. Lower it if the model fails to load; 0 is CPU-only.' },
    { key: 'num_thread',     label: 'CPU threads',     step: '1',    hint: 'auto',
      why: 'Threads for whatever is not on the GPU.' },
    { key: 'num_batch',      label: 'Batch size',      step: '64',   hint: '512',
      why: 'Prompt tokens processed at once. Higher is faster and uses more memory.' },
    { key: 'top_k',          label: 'Top K',           step: '1',    hint: '40',
      why: 'Not an OpenAI field, so it can only be set here.' },
    { key: 'repeat_penalty', label: 'Repeat penalty',  step: '0.05', hint: '1.1',
      why: 'Raise if the model loops; 1.0 disables it.' },
  ];

  const JOBS = [];

  class UecpScreenLocalStudio extends HTMLElement {
    connectedCallback() {
      if (!this._initialised) {
        this._initialised = true;
        this._status = null;
        this._tab = 'backends';
        this._workflows = [];
        this._reqs = {};
        this._reqN = 0;
        this._installing = null;
        this._installFrac = null;
        this._installMsg = null;
      }
      if (!this.firstChild) this._build();

      this._syncTabBar();

      (JOBS || []).forEach((j) => { if (j && !j.done && j.jobId) this._poll(j.jobId); });

      this._subs = [
        window.uecp.on('local.status', (d) => {
          this._status = d;
          if (d && d.pulling && !this._pullModel) {
            this._pullModel = d.pulling_model || '';
            this._pullFrac = -1;
            this._pullStatus = 'Downloading ' + this._pullModel + '…';
          } else if (d && !d.pulling && this._pullModel) {
            this._pullModel = null;
            this._pullFrac = null;
            this._pullStatus = null;
          }
          this._paint();
        }),
        window.uecp.on('local.result', (d) => { this._onResult(d); }),
        window.uecp.on('local.image_picked', (d) => {
          this._pickedImage = (d && d.path) || '';
          const f = this.querySelector('#lsg-image');
          if (f) f.value = this._pickedImage;
        }),
        window.uecp.on('local.workflow_picked', (d) => {
          if (!d || !d.path || !this._importCap) return;
          this._call('import_local_workflow', { path: d.path, capability: this._importCap });
          this._importCap = null;
          if (window.UECP && window.UECP.toast) window.UECP.toast('Importing workflow…', 'info');
        }),
        window.uecp.on('local.install_progress', (d) => {
          if (!d || d.id !== this._installing) return;
          this._installFrac = d.fraction || 0;
          this._installMsg = (d.stage || '') + (d.message ? ' ' + d.message : '');
          this._paint();
        }),
        window.uecp.on('local.install_done', (d) => {
          if (!d) return;
          this._installing = null;
          this._installFrac = null;
          this._installMsg = null;
          if (window.UECP && window.UECP.toast) window.UECP.toast(d.message || '', d.ok ? 'info' : 'error');
          this._paint();
        }),
        window.uecp.on('local.pull_progress', (d) => {
          if (!d || d.model !== this._pullModel) return;
          this._pullFrac = (typeof d.fraction === 'number') ? d.fraction : -1;
          this._pullStatus = d.status || '';

          const st = this.querySelector('#ls-pull-status');
          const bar = this.querySelector('#ls-pull-bar');
          if (st && bar) {
            st.textContent = this._pullStatus || ('Downloading ' + this._pullModel + '…');
            if (this._pullFrac >= 0) {
              bar.style.width = Math.round(this._pullFrac * 100) + '%';
              bar.style.opacity = '1';
            } else {
              bar.style.width = '100%';
              bar.style.opacity = '.35';
            }
            return;
          }
          this._paint();
        }),
        window.uecp.on('local.pull_done', (d) => {
          if (!d) return;
          this._pullModel = null;
          this._pullFrac = null;
          this._pullStatus = null;
          if (d.ok) this._pullDraft = '';
          if (window.UECP && window.UECP.toast) window.UECP.toast(d.message || '', d.ok ? 'info' : 'error');
          this._paint();
        }),
        window.uecp.on('local.use_result', (d) => {
          if (!d) return;
          if (window.UECP && window.UECP.toast) {
            window.UECP.toast(d.message || '', d.ok ? 'info' : 'error', { sticky: true });
          }
        }),
        window.uecp.on('local.delete_done', (d) => {
          if (!d) return;
          if (window.UECP && window.UECP.toast) {
            window.UECP.toast(d.message || '', d.ok ? 'info' : 'error', { sticky: !!d.ok });
          }
        }),
        window.uecp.on('local.model_params', (d) => {
          if (!d || d.model !== this._paramsModel) return;
          try { this._params = JSON.parse(d.params || '{}'); } catch (e) { this._params = {}; }
          this._paint();
        }),
        window.uecp.on('local.model_catalog', (d) => {
          this._catalog = (d && d.models) || [];
          this._paint();
        }),
      ];
      window.uecp.call('request_local_status', {});
      window.uecp.call('refresh_local_backends', {});
      this._call('list_local_workflows', {});
    }

    disconnectedCallback() {
      (this._subs || []).forEach((u) => u());
      this._subs = [];
    }

    _build() {
      this.innerHTML =
        '<div class="content"><div class="page page-wide">' +
          '<div style="display:flex;align-items:center;gap:12px">' +
            '<div><div class="page-title">Local Studio</div>' +
            '<div class="page-sub">AI that runs on this machine, with no API key and no per-call cost.</div></div>' +
            '<span style="flex:1"></span>' +
            '<button class="ls-btn" id="ls-refresh">Refresh</button>' +
          '</div>' +
          '<div class="ls-tabs" id="ls-tabs">' +
            '<button class="ls-tab active" data-tab="backends">Backends</button>' +
            '<button class="ls-tab" data-tab="mesh_from_image">3D from Image</button>' +
            '<button class="ls-tab" data-tab="mesh_from_text">3D from Text</button>' +
            '<button class="ls-tab" data-tab="image_from_text">Image</button>' +
            '<button class="ls-tab" data-tab="audio_from_text">Audio</button>' +
            '<button class="ls-tab" data-tab="video_from_text">Video</button>' +
          '</div>' +
          '<div id="ls-cards"></div>' +
        '</div></div>';

      this.querySelector('#ls-refresh').addEventListener('click', () => {
        window.uecp.call('refresh_local_backends', {});
        this._call('list_local_workflows', {});
      });
      this.querySelector('#ls-tabs').addEventListener('click', (e) => {
        const btn = e.target.closest('.ls-tab');
        if (!btn) return;
        this._tab = btn.dataset.tab;
        this.querySelectorAll('.ls-tab').forEach((t) => t.classList.toggle('active', t === btn));
        this._paint();
      });
    }

    _syncTabBar() {
      const tabs = Array.prototype.slice.call(this.querySelectorAll('.ls-tab'));
      if (!tabs.length) return;
      let want = tabs.filter((t) => t.dataset.tab === this._tab)[0];
      if (!want) {
        want = tabs[0];
        this._tab = want.dataset.tab;
      }
      tabs.forEach((t) => t.classList.toggle('active', t === want));
    }

    _call(tool, args) {
      const id = 'ls-' + (++this._reqN);
      this._reqs[id] = tool;
      window.uecp.call('local_action', { tool: tool, request_id: id, args: args || {} });
      return id;
    }

    _onResult(msg) {
      msg = msg || {};
      const tool = this._reqs[msg.request_id] || msg.tool;
      delete this._reqs[msg.request_id];

      if (!msg.ok) {
        if (window.UECP && window.UECP.toast) window.UECP.toast(msg.error || 'Local call failed.', 'error');
        return;
      }
      const data = msg.data || {};

      if (tool === 'list_local_workflows') {
        this._workflows = (data.workflows || []).filter(function (w) { return !w.cloud; });
        this._userDir = data.user_dir || '';
        this._paint();
        return;
      }

      if (tool === 'tripo_get_task_status') {
        if (data.status !== 'completed') return;
        const res = data.result || {};
        if (this._imports && this._imports[data.job_id]) {
          delete this._imports[data.job_id];
          if (window.UECP && window.UECP.toast) {
            window.UECP.toast(res.success ? 'Workflow imported.' : (res.error || 'Import failed.'),
                              res.success ? 'success' : 'error', { sticky: !res.success });
          }
          if (res.success) this._call('list_local_workflows', {});
          return;
        }
        const job = JOBS.find((j) => j.jobId === data.job_id);
        if (job) {
          job.done = true; job.ok = !!res.success;
          job.detail = res.asset_path || res.error || '';
          if (res.success && res.asset_path) job.assetPath = res.asset_path;
        }
        if (window.UECP && window.UECP.toast) {
          window.UECP.toast(res.success ? ('Imported ' + (res.asset_path || '')) : (res.error || 'Failed'),
                            res.success ? 'success' : 'error');
        }
        this._paint();
        return;
      }

      if (data.job_id && tool === 'import_local_workflow') {
        this._imports = this._imports || {};
        this._imports[data.job_id] = true;
        this._pollImport(data.job_id);
        return;
      }

      if (data.job_id) {
        JOBS.unshift({ jobId: data.job_id, label: data.tool || tool, done: false });
        this._paint();
        this._poll(data.job_id);
        if (window.UECP && window.UECP.toast) window.UECP.toast('Queued in ComfyUI.', 'info');
      }
    }

    _pollImport(jobId) {
      setTimeout(() => {
        if (!this._imports || !this._imports[jobId]) return;
        this._call('tripo_get_task_status', { job_id: jobId });
        this._pollImport(jobId);
      }, 1500);
    }

    _wireImport(host) {
      const btn = host.querySelector('#lsg-import');
      if (!btn) return;
      btn.addEventListener('click', () => {
        this._importCap = this._tab;
        window.uecp.call('local_browse_workflow', {});
      });
    }

    _poll(jobId) {
      setTimeout(() => {
        const job = JOBS.find((j) => j.jobId === jobId);
        if (!job || job.done) return;
        this._call('tripo_get_task_status', { job_id: jobId });
        this._poll(jobId);
      }, 4000);
    }

    _wireViews() {
      (this.querySelectorAll('[data-view]') || []).forEach((b) => {
        b.addEventListener('click', () => {
          window.uecp.call('reveal_asset', { asset_path: b.getAttribute('data-view') });
        });
      });
    }

    _catalogHtml() {
      if (!this._catalogOpen) return '';
      if (!this._catalog) {
        return '<div class="ls-detail" style="margin-top:10px">Fetching sizes from the Ollama registry&hellip;</div>';
      }
      if (!this._catalog.length) {
        return '<div class="ls-detail" style="margin-top:10px">Could not reach the Ollama registry. '
          + '<a href="#" data-ext="https://ollama.com/search?c=tools">Browse tool-capable models on ollama.com</a></div>';
      }
      const busy = !!this._pullModel;
      return '<div style="margin-top:11px;border-top:1px solid var(--ue-line-soft);padding-top:10px">'
        + this._catalog.map((m) =>
            '<div class="ls-job" style="align-items:flex-start">'
            + '<div style="flex:1">'
              + '<div style="font-family:var(--ue-font-mono);font-size:12px;color:var(--ue-text-hi)">'
                + esc(m.ref)
                + (m.size_gb > 0
                    ? '<span style="color:var(--ue-text-lo)"> &middot; ' + m.size_gb.toFixed(1) + ' GB</span>'
                    : '<span style="color:var(--ue-text-lo)"> &middot; size unknown</span>')
              + '</div>'
              + '<div style="font-size:11.5px;color:var(--ue-text-mid);margin-top:2px">' + esc(m.blurb) + '</div>'
            + '</div>'
            + '<button class="ls-btn" data-pull-ref="' + esc(m.ref) + '"' + (busy ? ' disabled' : '') + '>Pull</button>'
            + '</div>').join('')
        + '<div class="ls-warn">Every model here supports tool calling — that is the filter, not popularity. '
        + 'It has to fit in VRAM to be quick; bigger ones still run by spilling into system RAM, just slower. '
        + '<a href="#" data-ext="https://ollama.com/search?c=tools">See the full list</a></div>'
        + '</div>';
    }

    _paint() {
      const host = this.querySelector('#ls-cards');
      if (!host) return;
      if (this._tab !== 'backends') { this._paintGenerate(host); return; }
      if (!this._status) return;
      const list = this._status.backends || [];

      host.innerHTML = list.map((b) => {
        const ready = b.state === 'ready';
        const isChat = b.id === 'ollama' || b.id === 'lmstudio';
        const NEEDED = 16384;
        const rc = b.runtime_context || 0;
        const mx = b.model_max_context || 0;
        const models = (!isChat && (b.models || []).length)
          ? '<div class="ls-models">' + b.models.slice(0, 24).map(
              (m) => '<span class="ls-model">' + esc(m) + '</span>').join('') + '</div>'
          : '';

        const urlRow = b.managed ? '' :
          '<div class="ls-row" style="margin-top:10px">' +
            '<input class="ls-url" data-url-for="' + esc(b.id) + '" value="' + esc(b.base_url || '') + '" spellcheck="false">' +
            '<button class="ls-btn" data-save-url="' + esc(b.id) + '">Use this address</button>' +
          '</div>';

        const canAutoInstall = b.id === 'comfyui' || b.id === 'ollama';
        const busy = this._installing === b.id;

        const managedAction =
          '<div class="ls-row" style="margin-top:9px">' +
            '<button class="ls-btn' + (ready ? '' : ' primary') + '" data-open-audio="1">' +
              esc(ready ? 'Open Audio settings' : 'Set up dictation') +
            '</button>' +
          '</div>';

        const action = (ready && !b.managed) ? '' :
          (b.managed
            ? '<div class="ls-hint">' + esc(b.install_hint || '') + managedAction + '</div>'
            : '<div class="ls-hint">' + esc(b.install_hint || '') +
              '<div class="ls-row" style="margin-top:9px">' +
                (b.id === 'ollama'
                  ? '<button class="ls-btn primary" data-start-ollama="1">Start Ollama</button>'
                  : '') +
                (canAutoInstall
                  ? '<button class="ls-btn' + (b.id === 'ollama' ? '' : ' primary') + '" data-autoinstall="' + esc(b.id) + '"' +
                      (busy ? ' disabled' : '') + '>' +
                      esc(busy ? (this._installMsg || 'Downloading…') : 'Install for me') + '</button>'
                  : '') +
                '<button class="ls-btn" data-install="' + esc(b.install_url || '') + '">' +
                  (canAutoInstall ? 'Download manually' : 'Download ' + esc(b.name)) + '</button>' +
              '</div>' +
              (busy && this._installFrac != null
                ? '<div style="margin-top:9px;height:4px;background:var(--ue-bg);border-radius:2px;overflow:hidden">' +
                    '<div style="height:100%;width:' + Math.round(this._installFrac * 100) + '%;background:var(--ue-accent)"></div>' +
                  '</div>'
                : '') +
              '</div>');

        const stopRow = (ready && b.id === 'ollama')
          ? '<div class="ls-row" style="margin-top:10px">' +
              '<button class="ls-btn" data-stop-ollama="1" ' +
                'data-tip="Ends Ollama for everything on this machine, not just the editor, ' +
                'and frees the VRAM its model was holding.">Stop Ollama</button>' +
            '</div>'
          : '';

        const manager = (ready && b.id === 'comfyui')
          ? (b.has_manager
              ? '<div class="ls-detail" style="margin:8px 0 0">ComfyUI-Manager ' + esc(b.manager_version || '') +
                ' detected — node packs and models can be installed from here.</div>'
              : '<div class="ls-hint" style="margin-top:10px">ComfyUI-Manager is not installed. ' +
                'Without it, custom nodes and model weights have to be added by hand.' +
                '<div class="ls-row" style="margin-top:9px">' +
                  '<button class="ls-btn" data-install="https://github.com/ltdrdata/ComfyUI-Manager">Get ComfyUI-Manager</button>' +
                '</div></div>')
          : '';

        const ctxRow = (ready && b.id === 'ollama' && this._paramsOpen)
          ? '<div class="ls-hint" style="margin-top:11px">' +
              '<div style="margin-bottom:8px;color:var(--ue-text-hi)">Model settings for ' +
                '<span style="font-family:var(--ue-font-mono)">' + esc(this._paramsModel || '') + '</span></div>' +
              '<div class="ls-2col">' +
                PARAMS.map((p) => '<div class="ls-field">' +
                  '<div class="ls-label">' + esc(p.label) +
                    (p.key === 'num_ctx' && mx > 0
                      ? ' <span style="color:var(--ue-text-lo)">(max ' + mx.toLocaleString() + ')</span>'
                      : '') +
                  '</div>' +
                  '<input class="ls-input ls-param" data-param="' + esc(p.key) + '" type="number" ' +
                    'step="' + esc(p.step) + '" placeholder="' + esc(p.hint) + '" value="' +
                    esc((this._params && this._params[p.key] != null) ? this._params[p.key] : '') + '">' +
                  '<div style="font-size:11px;color:var(--ue-text-lo);margin-top:3px">' + esc(p.why) + '</div>' +
                '</div>').join('') +
              '</div>' +
              '<div class="ls-row" style="margin-top:4px">' +
                '<button class="ls-btn primary" id="ls-params-save">Save settings</button>' +
                '<button class="ls-btn" id="ls-params-reset">Clear</button>' +
              '</div>' +
              '<div class="ls-warn">Leave a field empty to let the model decide. Settings are ' +
              'baked into one copy of the model per model, so changing them overwrites rather ' +
              'than adding another entry, and a model you tuned yourself keeps its own settings.</div>' +
            '</div>'
          : '';

        const pickable = b.id === 'ollama' ? baseModels(b.models) : (b.models || []);

        const hidden = (b.models || []).length - pickable.length;
        const detail = hidden > 0
          ? String(b.detail || '').replace(/^\d+ models?\b/,
              pickable.length + (pickable.length === 1 ? ' model' : ' models'))
          : b.detail;
        const useRow = (ready && isChat) ? (
          pickable.length
            ? '<div class="ls-row" style="margin-top:11px">' +
                '<select class="ls-input" data-model-for="' + esc(b.id) + '" style="flex:1;min-width:180px">' +
                  pickable.map((m) => '<option value="' + esc(m) + '">' + esc(m) + '</option>').join('') +
                '</select>' +
                '<button class="ls-btn primary" data-use="' + esc(b.id) + '">Use in Architect</button>' +
                (b.id === 'ollama'
                  ? '<button class="ls-btn" id="ls-params-toggle">' +
                      esc(this._paramsOpen ? 'Hide settings' : 'Settings') + '</button>' +
                    '<button class="ls-btn" id="ls-del"' +
                      (this._delArmed ? ' style="border-color:var(--ue-err,#e06c6c);color:var(--ue-err,#e06c6c)"' : '') +
                      '>' + esc(this._delArmed ? 'Delete — click again' : 'Delete') + '</button>'
                  : '') +
              '</div>' +
              (b.id === 'ollama' && pickable.length
                ? '<div class="ls-detail" style="margin:7px 0 0">Architect will run ' +
                    '<span id="ls-willrun" style="font-family:var(--ue-font-mono);color:var(--ue-text-mid)">' +
                    esc(String(pickable[0]).split(':')[0]) + '-uecp</span>' +
                    ' &mdash; a copy of the selected model carrying your settings, because Ollama ' +
                    'ignores them when sent with the request.</div>'
                : '') +
              ctxRow
            : '') : '';

        const pulling = this._pullModel;
        const pullRow = (ready && b.id === 'ollama')
          ? '<div class="ls-hint" style="margin-top:11px">' +
              '<div style="margin-bottom:7px">Pull a model from ollama.com</div>' +
              '<div class="ls-row">' +
                '<input class="ls-url" id="ls-pull-name" spellcheck="false" ' +
                  'placeholder="qwen3" value="' + esc(this._pullDraft || '') + '"' +
                  (pulling ? ' disabled' : '') + '>' +
                '<button class="ls-btn primary" id="ls-pull-go"' + (pulling ? ' disabled' : '') + '>' +
                  esc(pulling ? 'Pulling…' : 'Pull') + '</button>' +
                (pulling ? '<button class="ls-btn" id="ls-pull-cancel">Cancel</button>' : '') +
                '<button class="ls-btn" id="ls-browse">' +
                  esc(this._catalogOpen ? 'Hide models' : 'Browse models') + '</button>' +
              '</div>' +
              this._catalogHtml() +
              (pulling
                ? '<div class="ls-detail" id="ls-pull-status" style="margin:8px 0 0">' +
                    esc(this._pullStatus || ('Downloading ' + pulling + '…')) + '</div>' +
                  '<div style="margin-top:7px;height:4px;background:var(--ue-bg);border-radius:2px;overflow:hidden">' +
                    '<div id="ls-pull-bar" style="height:100%;background:var(--ue-accent);width:' +
                      (this._pullFrac != null && this._pullFrac >= 0
                        ? Math.round(this._pullFrac * 100) + '%;opacity:1'
                        : '100%;opacity:.35') +
                      '"></div>' +
                  '</div>'
                : '') +
              '<div class="ls-warn">Architect drives the editor through tool calls, so pick a model ' +
              'that supports them — Qwen 3, Llama 3.1 and Mistral Nemo all do. A model without ' +
              'tool support will chat happily and never touch your project. Bigger quantisations ' +
              'follow instructions better; the model has to fit in VRAM to be fast.</div>' +
            '</div>'
          : (ready && b.id === 'lmstudio'
              ? '<div class="ls-warn" style="margin-top:10px">Load models from LM Studio\'s own ' +
                'Discover tab, then reload one and press Refresh here. Pick one whose card mentions ' +
                'tool or function calling — Architect drives the editor through tool calls.</div>'
              : '');

        const ctxWarn = ((b.id === 'ollama' || b.id === 'lmstudio') && rc > 0 && rc < NEEDED)
          ? '<div class="ls-hint" style="margin-top:11px;border-color:var(--ue-accent)">' +
              '<div style="color:var(--ue-text-hi);font-weight:600;margin-bottom:5px">' +
                (b.id === 'lmstudio'
                  ? 'LM Studio is truncating your prompts'
                  : 'Ollama is truncating your prompts') + '</div>' +
              '<div style="font-size:12px;color:var(--ue-text-hi)">' +
                esc(b.context_model || 'The loaded model') + ' is running with a <b>' +
                rc.toLocaleString() + '</b>-token context' +
                (mx > rc ? ', but supports <b>' + mx.toLocaleString() + '</b>' : '') +
                '. Architect sends around 12,000 tokens, so the tool list and most instructions ' +
                'are being cut off before the model sees them — which looks exactly like the ' +
                'model being incapable.' +
              '</div>' +
              '<div style="font-size:12px;color:var(--ue-text-mid);margin-top:7px">' +
                (b.id === 'lmstudio'
                  ? 'Eject the model and load it again from the Load panel in LM Studio with a context length of 32,768, 65,536 or 131,072 — each step costs more VRAM, so take the largest your card holds. This cannot be fixed from the plugin: the context is fixed when the model loads.'
                  : 'Set the environment variable OLLAMA_CONTEXT_LENGTH to 32768, 65536 or 131072 — each step costs more VRAM — and restart Ollama. This cannot be fixed from the plugin: Ollama ignores context settings sent in the request.') +
              '</div>' +
            '</div>'
          : '';

        return '<div class="ls-card">' +
          '<div class="ls-head">' +
            '<span class="ls-dot ' + esc(b.state) + '"></span>' +
            '<span class="ls-name">' + esc(b.name) + '</span>' +
            (b.version ? '<span class="ls-model">' + esc(b.version) + '</span>' : '') +
            '<span class="ls-state">' + esc(String(b.state || '').replace(/_/g, ' ')) + '</span>' +
          '</div>' +
          '<div class="ls-blurb">' + esc(b.blurb) + '</div>' +
          (detail ? '<div class="ls-detail">' + esc(detail) + '</div>' : '') +
          ctxWarn + models + useRow + manager + pullRow + urlRow + stopRow + action +
        '</div>';
      }).join('');

      host.querySelectorAll('[data-install]').forEach((btn) => {
        btn.addEventListener('click', () => {
          const url = btn.dataset.install;
          if (url) window.uecp.call('open_external_url', { url: url });
        });
      });
      host.querySelectorAll('[data-ext]').forEach((btn) => {
        btn.addEventListener('click', () => {
          const url = btn.dataset.ext;
          if (url) window.uecp.call('open_external_url', { url: url });
        });
      });
      host.querySelectorAll('[data-start-ollama]').forEach((btn) => {
        btn.addEventListener('click', () => {
          btn.disabled = true;
          btn.textContent = 'Starting…';
          window.uecp.call('start_ollama', {});
        });
      });
      host.querySelectorAll('[data-stop-ollama]').forEach((btn) => {
        btn.addEventListener('click', () => {
          btn.disabled = true;
          window.uecp.call('stop_ollama', {});
        });
      });
      host.querySelectorAll('[data-open-audio]').forEach((btn) => {
        btn.addEventListener('click', () => {
          if (window.UECP && window.UECP.router) window.UECP.router.goSettings('audio');
        });
      });
      host.querySelectorAll('[data-autoinstall]').forEach((btn) => {
        btn.addEventListener('click', () => {
          this._installing = btn.dataset.autoinstall;
          this._installFrac = 0;
          this._installMsg = 'Starting…';
          this._paint();
          window.uecp.call('install_local_backend', { id: btn.dataset.autoinstall });
        });
      });
      host.querySelectorAll('[data-save-url]').forEach((btn) => {
        btn.addEventListener('click', () => {
          const id = btn.dataset.saveUrl;
          const inp = host.querySelector('[data-url-for="' + id + '"]');
          window.uecp.call('set_local_backend_url', { id: id, url: inp ? inp.value.trim() : '' });
        });
      });
      host.querySelectorAll('[data-use]').forEach((btn) => {
        btn.addEventListener('click', () => {
          const id = btn.dataset.use;
          const sel = host.querySelector('[data-model-for="' + id + '"]');
          window.uecp.call('use_local_backend', { id: id, model: sel ? sel.value : '' });
        });
      });

      const pullBtn = host.querySelector('#ls-pull-go');
      if (pullBtn) {
        const nameInput = host.querySelector('#ls-pull-name');
        if (nameInput) {
          nameInput.addEventListener('input', () => { this._pullDraft = nameInput.value; });
        }
        pullBtn.addEventListener('click', () => {
          const name = (nameInput ? nameInput.value : '').trim();
          if (!name) return;
          this._pullModel = name;
          this._pullFrac = -1;
          this._pullStatus = 'Resolving ' + name + '…';
          this._paint();
          window.uecp.call('pull_ollama_model', { model: name });
        });
      }

      const delBtn = host.querySelector('#ls-del');
      if (delBtn) {
        delBtn.addEventListener('click', () => {
          const sel = host.querySelector('[data-model-for="ollama"]');
          const model = sel ? sel.value : '';
          if (!model) return;
          if (this._delArmed !== model) {
            this._delArmed = model;
            this._paint();
            clearTimeout(this._delTimer);
            this._delTimer = setTimeout(() => { this._delArmed = null; this._paint(); }, 5000);
            return;
          }
          clearTimeout(this._delTimer);
          this._delArmed = null;
          window.uecp.call('delete_ollama_model', { model: model });
        });
      }

      const modelSel = host.querySelector('[data-model-for="ollama"]');
      if (modelSel) {
        modelSel.addEventListener('change', () => {
          const willRun = host.querySelector('#ls-willrun');
          if (willRun) willRun.textContent = String(modelSel.value).split(':')[0] + '-uecp';
          if (this._paramsOpen) {
            this._paramsModel = modelSel.value;
            this._params = null;
            window.uecp.call('get_ollama_model_params', { model: this._paramsModel });
          }
          if (this._delArmed) { this._delArmed = null; this._paint(); }
        });
      }

      const paramsToggle = host.querySelector('#ls-params-toggle');
      if (paramsToggle) {
        paramsToggle.addEventListener('click', () => {
          this._paramsOpen = !this._paramsOpen;
          if (this._paramsOpen) {
            const sel = host.querySelector('[data-model-for="ollama"]');
            this._paramsModel = sel ? sel.value : '';
            window.uecp.call('get_ollama_model_params', { model: this._paramsModel });
          }
          this._paint();
        });
      }

      const paramsSave = host.querySelector('#ls-params-save');
      if (paramsSave) {
        paramsSave.addEventListener('click', () => {
          const out = {};
          host.querySelectorAll('.ls-param').forEach((inp) => {
            const raw = (inp.value || '').trim();
            if (raw === '') return;
            const n = Number(raw);
            if (!isNaN(n)) out[inp.dataset.param] = n;
          });
          this._params = out;
          window.uecp.call('set_ollama_model_params', {
            model: this._paramsModel, params: JSON.stringify(out),
          });
          if (window.UECP && window.UECP.toast) {
            window.UECP.toast('Saved. Press Use in Architect to apply them to '
              + this._paramsModel + '.', 'info', { sticky: true });
          }
        });
      }

      const paramsReset = host.querySelector('#ls-params-reset');
      if (paramsReset) {
        paramsReset.addEventListener('click', () => {
          this._params = {};
          window.uecp.call('set_ollama_model_params', { model: this._paramsModel, params: '{}' });
          this._paint();
        });
      }

      const browseBtn = host.querySelector('#ls-browse');
      if (browseBtn) {
        browseBtn.addEventListener('click', () => {
          this._catalogOpen = !this._catalogOpen;
          if (this._catalogOpen && !this._catalog) window.uecp.call('browse_ollama_models', {});
          this._paint();
        });
      }
      host.querySelectorAll('[data-pull-ref]').forEach((btn) => {
        btn.addEventListener('click', () => {
          const ref = btn.dataset.pullRef;
          this._pullDraft = ref;
          this._pullModel = ref;
          this._pullFrac = -1;
          this._pullStatus = 'Resolving ' + ref + '…';
          this._paint();
          window.uecp.call('pull_ollama_model', { model: ref });
        });
      });

      const cancelBtn = host.querySelector('#ls-pull-cancel');
      if (cancelBtn) {
        cancelBtn.addEventListener('click', () => {
          this._pullStatus = 'Cancelling…';
          const st = this.querySelector('#ls-pull-status');
          if (st) st.textContent = this._pullStatus;
          cancelBtn.disabled = true;
          window.uecp.call('cancel_ollama_pull', {});
        });
      }
    }
    _tunablesHtml(wf) {
      if (!wf) return '';
      const have = wf.params || [];
      const vals = wf.param_values || {};
      const fields = TUNABLES
        .filter((t) => have.indexOf(t.key) !== -1)
        .map((t) => '<div class="ls-field"><div class="ls-label">' + esc(t.label) + '</div>'
          + '<input class="ls-input ls-tunable" data-param="' + esc(t.key) + '" type="number" '
          + 'step="' + esc(t.step) + '" value="' + esc(vals[t.key] || '') + '"></div>');

      if (!fields.length) {
        return '<div class="ls-detail">This workflow exposes no settings beyond the prompt.</div>';
      }
      return '<div class="ls-label" style="margin-bottom:6px">Settings</div>'
        + '<div class="ls-2col">' + fields.join('') + '</div>'
        + '<div class="ls-detail">Read from the workflow itself. Lower steps and a smaller size '
        + 'finish sooner and keep the GPU cooler.</div>';
    }

    _paintGenerate(host) {
      const cap = this._tab;
      const mine = (this._workflows || []).filter((w) => w.capability === cap);
      const comfy = ((this._status || {}).backends || []).find((b) => b.id === 'comfyui') || {};
      const ready = comfy.state === 'ready';

      if (!ready) {
        host.innerHTML = '<div class="ls-card"><div class="ls-blurb">ComfyUI is not running. '
          + 'Start it, then press Refresh -- local generation happens inside it.</div></div>';
        return;
      }

      if (!mine.length) {
        host.innerHTML = '<div class="ls-card">'
          + '<div class="ls-name" style="margin-bottom:6px">No workflow for this yet</div>'
          + '<div class="ls-blurb">Nothing installed declares <b>' + esc(cap) + '</b>. '
          + 'Build or open a workflow in ComfyUI, then import it -- any ComfyUI workflow works, '
          + 'this is not tied to one model.</div>'
          + '<div class="ls-row" style="margin-top:10px"><button class="ls-btn primary" id="lsg-import">Import workflow…</button></div>'
          + (this._userDir
              ? '<div class="ls-detail">Imported workflows are saved in <span class="ue-code">' + esc(this._userDir) + '</span></div>'
              : '')
          + '</div>';
        this._wireImport(host);
        return;
      }

      const isImage = cap === 'mesh_from_image';
      const opts = mine.map((w) => '<option value="' + esc(w.id) + '">' + esc(w.label) + '</option>').join('');

      host.innerHTML = '<div class="ls-card">'
        + '<div class="ls-field"><div class="ls-label">Workflow</div>'
        + '<div class="ls-row"><select class="ls-input" id="lsg-wf" style="flex:1">' + opts + '</select>'
        + '<button class="ls-btn" id="lsg-import">Import workflow…</button></div></div>'
        + (isImage
            ? '<div class="ls-field"><div class="ls-label">Source image</div>'
              + '<div class="ls-row">'
              + '<input class="ls-input" id="lsg-image" spellcheck="false" autocorrect="off" autocapitalize="off" style="flex:1" placeholder="pick a file, or type a name already in ComfyUI">'
              + '<button class="ls-btn" id="lsg-browse">Browse…</button>'
              + '</div>'
              + '<div class="ls-warn" style="margin-top:6px">Works best on a subject with the '
              + 'background removed. A photo with a backdrop tends to produce the backdrop.</div>'
              + '</div>'
            : '<div class="ls-field"><div class="ls-label">Prompt</div>'
              + '<textarea class="ls-input" id="lsg-prompt" rows="3" placeholder="a weathered bronze temple bell"></textarea>'
              + '</div>')
        + '<div class="ls-2col">'
        + '<div class="ls-field"><div class="ls-label">Asset name</div><input class="ls-input" id="lsg-name" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="derived from the prompt"></div>'
        + '<div class="ls-field"><div class="ls-label">Save path</div><input class="ls-input" id="lsg-path" spellcheck="false" autocorrect="off" autocapitalize="off" placeholder="/Game/LocalGen/"></div>'
        + '</div>'
        + '<div class="ls-field"><div class="ls-label">Seed</div><input class="ls-input" id="lsg-seed" placeholder="blank = keep the workflow default"></div>'
        + '<div class="ls-field" id="lsg-tunables">' + this._tunablesHtml(mine[0]) + '</div>'
        + (cap === 'image_from_text'
            ? '<div class="ls-field"><label style="display:flex;gap:8px;align-items:center;font-size:12.5px;color:var(--ue-text-hi)">'
              + '<input type="checkbox" id="lsg-srgb" checked> Colour image (uncheck for a roughness, normal or mask map)'
              + '</label>'
              + '<div class="ls-warn" style="margin-top:4px">Decides sRGB and compression at import. '
              + 'It cannot be corrected afterwards without reimporting.</div></div>'
            : '')
        + '<div class="ls-row"><button class="ls-btn primary" id="lsg-go">Generate</button></div>'
        + '<div class="ls-warn">Runs on this machine. Expect minutes, not seconds, and a busy GPU '
        + 'while it works -- a laptop will get hot.'

        + (cap === 'video_from_text'
            ? ' Video is the heaviest of these by a wide margin. Unreal has no video asset type, so '
              + 'the file lands in Content/Movies and you get a MediaSource pointing at it.'
            : '')
        + '</div>'
        + '</div>'
        + this._jobsHtml();

      const imgField = host.querySelector('#lsg-image');
      if (imgField && this._pickedImage) imgField.value = this._pickedImage;

      const wfSel = host.querySelector('#lsg-wf');
      const tuneBox = host.querySelector('#lsg-tunables');
      if (wfSel && tuneBox) {
        wfSel.addEventListener('change', () => {
          const picked = mine.find((w) => w.id === wfSel.value);
          tuneBox.innerHTML = this._tunablesHtml(picked);
        });
      }

      const browse = host.querySelector('#lsg-browse');
      if (browse) browse.addEventListener('click', () => window.uecp.call('local_browse_image', {}));
      this._wireImport(host);

      this._wireViews();

      host.querySelector('#lsg-go').addEventListener('click', () => {
        const v = (id) => { const n = host.querySelector(id); return n ? n.value.trim() : ''; };
        const args = {
          workflow: v('#lsg-wf'),
          name: v('#lsg-name'),
          save_path: v('#lsg-path') || '/Game/LocalGen/',
        };
        const seed = parseInt(v('#lsg-seed'), 10);
        if (!isNaN(seed)) args.seed = seed;

        host.querySelectorAll('.ls-tunable').forEach((el) => {
          const raw = (el.value || '').trim();
          if (!raw) return;
          const num = Number(raw);
          if (!isNaN(num)) args[el.getAttribute('data-param')] = num;
        });

        if (isImage) {
          if (!v('#lsg-image')) { window.UECP.toast('Pick a source image first.', 'error'); return; }
          args.image_path = v('#lsg-image');
          this._call('local_create_3d_from_image', args);
          return;
        }

        if (!v('#lsg-prompt')) { window.UECP.toast('A prompt is required.', 'error'); return; }
        args.prompt = v('#lsg-prompt');

        if (cap === 'image_from_text') {
          const srgb = host.querySelector('#lsg-srgb');
          args.srgb = srgb ? !!srgb.checked : true;
          this._call('local_create_image', args);
        } else if (cap === 'audio_from_text') {
          this._call('local_create_audio', args);
        } else if (cap === 'video_from_text') {
          this._call('local_create_video', args);
        } else {
          this._call('local_create_3d_from_text', args);
        }
      });
    }

    _jobsHtml() {
      const jobs = (JOBS || []).slice(0, 8);
      if (!jobs.length) return '';
      return '<div class="ls-jobs"><div style="font-size:11px;font-weight:var(--ue-fw-semi,600);'
        + 'color:var(--ue-text-mid);margin-bottom:6px">Jobs this session</div>'
        + jobs.map((j) => '<div class="ls-job"><span style="flex:1">' + esc(j.label) + '</span>'
            + '<span style="color:var(--ue-text-lo)">'
            + (j.done ? (j.ok ? 'done' : 'failed') : 'running') + '</span>'
            + (j.assetPath
                ? '<button class="ls-btn" data-view="' + esc(j.assetPath) + '">View</button>'
                : '')
            + '</div>'
            + (j.detail ? '<div class="ls-detail" style="margin:0 0 6px">' + esc(j.detail) + '</div>' : ''))
          .join('')
        + '</div>';
    }
  }

  UecpScreenLocalStudio.JOBS = JOBS;

  customElements.define('uecp-screen-localstudio', UecpScreenLocalStudio);
})();
