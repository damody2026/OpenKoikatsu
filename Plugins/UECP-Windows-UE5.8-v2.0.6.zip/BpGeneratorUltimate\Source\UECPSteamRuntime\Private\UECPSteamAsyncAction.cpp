// Copyright 2026, BlueprintsLab, All rights reserved
#include "Async/UECPSteamAsyncAction.h"

#include "UECPSteamAPI.h"
#include "UECPSteamCallResult.h"

bool UUECPSteamAsyncAction::IsAvailable(FUECPSteamError& OutError) const
{
	if (UECPSteam::IsClientAvailable())
	{
		return true;
	}
	OutError = FUECPSteamError::Unavailable();
	return false;
}

void UUECPSteamAsyncAction::Activate()
{
	FUECPSteamError Error;
	if (!IsAvailable(Error))
	{
		Complete(false, Error);
		return;
	}

	if (!Start(Error))
	{
		Complete(false, Error);
	}
}

void UUECPSteamAsyncAction::SetReadyToDestroy()
{
	CallResultHolder.Reset();
	OnCleanup();
	Super::SetReadyToDestroy();
}

void UUECPSteamAsyncAction::CompleteSuccess()
{
	Complete(true, FUECPSteamError());
}

void UUECPSteamAsyncAction::CompleteFailure(const FUECPSteamError& Error)
{
	Complete(false, Error);
}

void UUECPSteamAsyncAction::CompleteFromResult(int32 RawResult, const FString& Context)
{
	const FUECPSteamError Error = UECPSteam::MakeError(RawResult, Context);
	Complete(Error.bSucceeded(), Error);
}

void UUECPSteamAsyncAction::Complete(bool bSucceeded, const FUECPSteamError& Error)
{
	if (bCompleted.AtomicSet(true))
	{
		return;
	}

	TWeakObjectPtr<UUECPSteamAsyncAction> WeakThis(this);
	UECPSteam::RunOnGameThread([WeakThis, bSucceeded, Error]()
	{
		UUECPSteamAsyncAction* Node = WeakThis.Get();
		if (!Node)
		{
			return;
		}
		Node->BroadcastResult(bSucceeded, Error);
		Node->SetReadyToDestroy();
	});
}
