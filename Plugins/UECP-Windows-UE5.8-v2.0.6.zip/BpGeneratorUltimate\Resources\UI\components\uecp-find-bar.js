(function () {
  if (!document.getElementById('uecp-find-bar-css')) {
    const s = document.createElement('style'); s.id = 'uecp-find-bar-css';
    s.textContent = `
uecp-find-bar{display:none;position:absolute;top:10px;right:14px;z-index:300;background:var(--ue-panel);border:1px solid var(--ue-line);border-radius:var(--ue-r-md);box-shadow:0 2px 8px rgba(0,0,0,.25);padding:6px 10px;min-width:280px;align-items:center;gap:8px}
uecp-find-bar.open{display:flex}
uecp-find-bar .find-input{flex:1;border:none;outline:none;background:transparent;font-family:var(--ue-font-mono);font-size:12px;color:var(--ue-text-hi);min-width:0}
uecp-find-bar .find-input::placeholder{color:var(--ue-text-lo)}
uecp-find-bar .find-count{font-family:var(--ue-font-mono);font-size:11px;color:var(--ue-text-mid);flex-shrink:0;white-space:nowrap;min-width:40px;text-align:center}
uecp-find-bar .find-btn{width:26px;height:26px;display:flex;align-items:center;justify-content:center;background:none;border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);cursor:pointer;color:var(--ue-text-mid);flex-shrink:0}
uecp-find-bar .find-btn:disabled{opacity:.35;cursor:not-allowed}
uecp-find-bar .find-btn:not(:disabled):hover{border-color:var(--ue-accent);color:var(--ue-accent-bright)}
uecp-find-bar .find-close{width:22px;height:22px;display:flex;align-items:center;justify-content:center;background:none;border:none;cursor:pointer;color:var(--ue-text-mid);font-size:16px;line-height:1;flex-shrink:0;padding:0}
uecp-find-bar .find-close:hover{color:var(--ue-text-hi)}`;
    document.head.appendChild(s);
  }

  class UecpFindBar extends HTMLElement {
    connectedCallback() {
      this._count = 0;
      this._indices = [];
      this._cursor = -1;

      this.innerHTML =
        '<input class="find-input" type="text" placeholder="Find in chat…">' +
        '<span class="find-count">—</span>' +
        '<button class="find-btn find-prev" title="Previous (Shift+Enter)" disabled>' +
          '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="m18 15-6-6-6 6"/></svg>' +
        '</button>' +
        '<button class="find-btn find-next" title="Next (Enter)" disabled>' +
          '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="m6 9 6 6 6-6"/></svg>' +
        '</button>' +
        '<button class="find-close" title="Close (Esc)">×</button>';

      const self = this;
      const input  = this.querySelector('.find-input');
      const count  = this.querySelector('.find-count');
      const btnPrev = this.querySelector('.find-prev');
      const btnNext = this.querySelector('.find-next');
      const btnClose = this.querySelector('.find-close');

      var _debounce = null;
      input.addEventListener('input', function () {
        clearTimeout(_debounce);
        _debounce = setTimeout(function () {
          var q = input.value.trim();
          if (q) {
            window.uecp.call('search_chat', { query: q });
          } else {
            self._clearResults();
            window.uecp.call('clear_find', {});
          }
        }, 250);
      });

      input.addEventListener('keydown', function (e) {
        if (e.key === 'Enter' && e.shiftKey) { e.preventDefault(); self._step(-1); return; }
        if (e.key === 'Enter')               { e.preventDefault(); self._step(1);  return; }
        if (e.key === 'Escape')              { e.preventDefault(); self.close();   return; }
      });

      btnPrev.addEventListener('click', function () { self._step(-1); });
      btnNext.addEventListener('click', function () { self._step(1);  });
      btnClose.addEventListener('click', function () { self.close(); });

      this._u1 = window.uecp.on('chat.search', function (d) {
        if (!d) return;
        self._count   = d.count   || 0;
        self._indices = d.indices || [];
        self._cursor  = self._indices.length > 0 ? 0 : -1;
        self._syncResults();
        if (self._cursor >= 0) self._jumpTo(self._cursor);
      });

      this._u2 = window.uecp.on('chat.scrollto', function (d) {
        if (!d || d.index == null) return;
        const screen = self.closest('uecp-screen-architect');
        if (!screen) return;
        const thread = screen.querySelector('uecp-thread');
        if (thread && typeof thread.scrollToIndex === 'function')
          thread.scrollToIndex(d.index);
      });
    }

    disconnectedCallback() {
      if (this._u1) { this._u1(); this._u1 = null; }
      if (this._u2) { this._u2(); this._u2 = null; }
    }

    open() {
      this.classList.add('open');
      const input = this.querySelector('.find-input');
      if (input) { input.focus(); input.select(); }
    }

    close() {
      this.classList.remove('open');
      this._clearResults();
      window.uecp.call('clear_find', {});
    }

    _step(dir) {
      if (!this._indices.length) return;
      this._cursor = (this._cursor + dir + this._indices.length) % this._indices.length;
      this._jumpTo(this._cursor);
      this._syncCursor();
    }

    _jumpTo(cursorPos) {
      const absIdx = this._indices[cursorPos];
      if (absIdx == null) return;
      window.uecp.call('jump_to', { index: absIdx });
    }

    _clearResults() {
      this._count = 0;
      this._indices = [];
      this._cursor = -1;
      this._syncResults();
    }

    _syncResults() {
      const count  = this.querySelector('.find-count');
      const btnPrev = this.querySelector('.find-prev');
      const btnNext = this.querySelector('.find-next');
      if (count) {
        count.textContent = this._count
          ? (this._cursor >= 0 ? (this._cursor + 1) + '/' + this._count : this._count + '')
          : (this.querySelector('.find-input') && this.querySelector('.find-input').value.trim() ? '0' : '—');
      }
      const hasResults = this._indices.length > 0;
      if (btnPrev) btnPrev.disabled = !hasResults;
      if (btnNext) btnNext.disabled = !hasResults;
    }

    _syncCursor() {
      const count = this.querySelector('.find-count');
      if (count && this._count)
        count.textContent = (this._cursor + 1) + '/' + this._count;
    }
  }
  customElements.define('uecp-find-bar', UecpFindBar);
})();
