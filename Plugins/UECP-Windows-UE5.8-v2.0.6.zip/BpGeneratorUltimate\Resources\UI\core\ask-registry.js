(function (root) {
  function createRegistry() {
    var entries = new Map();
    var listeners = [];
    function notify() {
      listeners.slice().forEach(function (fn) {
        try { fn(entries); } catch (e) { console.error('[uecp] ask-registry listener error', e); }
      });
    }
    return {
      set: function (chatId, questions, opts) {
        if (!chatId) return;
        opts = opts || {};
        entries.set(chatId, {
          questions: questions || [],
          allowSkip: opts.allowSkip !== false,
          allowOther: opts.allowOther !== false,
          allowFeedback: opts.allowFeedback !== false
        });
        notify();
      },
      clear: function (chatId) {
        if (!chatId) return;
        if (entries.delete(chatId)) notify();
      },
      get: function (chatId) { return entries.get(chatId) || null; },
      has: function (chatId) { return entries.has(chatId); },
      keys: function () { return Array.from(entries.keys()); },
      onChange: function (fn) {
        listeners.push(fn);
        return function () { var i = listeners.indexOf(fn); if (i >= 0) listeners.splice(i, 1); };
      }
    };
  }
  if (root) {
    root.UECP = root.UECP || {};
    root.UECP.askRegistry = createRegistry();
  }
}(typeof window !== 'undefined' ? window : null));

if (typeof window !== 'undefined' && window.uecp && window.UECP && window.UECP.askRegistry) {
  window.uecp.on('ask.questions', function (d) {
    if (d && d.chatId && d.questions && d.questions.length) window.UECP.askRegistry.set(d.chatId, d.questions, d);
  });
  window.uecp.on('ask.answered', function (d) {
    if (d && d.chatId) window.UECP.askRegistry.clear(d.chatId);
  });
}
