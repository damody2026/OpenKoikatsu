// Copyright 2026, BlueprintsLab, All rights reserved
#include "Library/UECPSteamTimelineLibrary.h"

#include "UECPSteamAPI.h"

#define UECP_TIMELINE_SUPPORTED (UECP_WITH_STEAM && UECP_STEAM_SDK_VER >= 161)

#if UECP_TIMELINE_SUPPORTED
namespace
{
	ETimelineGameMode ToNative(EUECPSteamTimelineGameMode In)
	{
		switch (In)
		{
		case EUECPSteamTimelineGameMode::Staging:       return k_ETimelineGameMode_Staging;
		case EUECPSteamTimelineGameMode::Menus:         return k_ETimelineGameMode_Menus;
		case EUECPSteamTimelineGameMode::LoadingScreen: return k_ETimelineGameMode_LoadingScreen;
		case EUECPSteamTimelineGameMode::Playing:
		default:                                        return k_ETimelineGameMode_Playing;
		}
	}

	ETimelineEventClipPriority ToNative(EUECPSteamTimelineClipPriority In)
	{
		switch (In)
		{
		case EUECPSteamTimelineClipPriority::Standard: return k_ETimelineEventClipPriority_Standard;
		case EUECPSteamTimelineClipPriority::Featured: return k_ETimelineEventClipPriority_Featured;
		case EUECPSteamTimelineClipPriority::None:
		default:                                       return k_ETimelineEventClipPriority_None;
		}
	}
}
#endif

bool UUECPSteamTimelineLibrary::IsTimelineAvailable()
{
#if UECP_TIMELINE_SUPPORTED
	return UECPSteam::Timeline() != nullptr;
#else
	return false;
#endif
}

bool UUECPSteamTimelineLibrary::SetTimelineGameMode(EUECPSteamTimelineGameMode Mode)
{
#if UECP_TIMELINE_SUPPORTED
	if (ISteamTimeline* T = UECPSteam::Timeline()) { T->SetTimelineGameMode(ToNative(Mode)); return true; }
#endif
	return false;
}

bool UUECPSteamTimelineLibrary::SetTimelineTooltip(const FString& Description, float TimeDeltaSeconds)
{
#if UECP_TIMELINE_SUPPORTED
	if (ISteamTimeline* T = UECPSteam::Timeline())
	{
		T->SetTimelineTooltip(TCHAR_TO_UTF8(*Description), TimeDeltaSeconds);
		return true;
	}
#endif
	return false;
}

bool UUECPSteamTimelineLibrary::ClearTimelineTooltip(float TimeDeltaSeconds)
{
#if UECP_TIMELINE_SUPPORTED
	if (ISteamTimeline* T = UECPSteam::Timeline()) { T->ClearTimelineTooltip(TimeDeltaSeconds); return true; }
#endif
	return false;
}

int64 UUECPSteamTimelineLibrary::AddTimelineEvent(const FString& Title, const FString& Description,
	const FString& Icon, int32 Priority, float StartOffsetSeconds,
	EUECPSteamTimelineClipPriority ClipPriority)
{
#if UECP_TIMELINE_SUPPORTED
	if (ISteamTimeline* T = UECPSteam::Timeline())
	{
		return static_cast<int64>(T->AddInstantaneousTimelineEvent(
			TCHAR_TO_UTF8(*Title), TCHAR_TO_UTF8(*Description), TCHAR_TO_UTF8(*Icon),
			static_cast<uint32>(FMath::Max(0, Priority)), StartOffsetSeconds, ToNative(ClipPriority)));
	}
#endif
	return 0;
}

int64 UUECPSteamTimelineLibrary::AddTimelineRangeEvent(const FString& Title, const FString& Description,
	const FString& Icon, float DurationSeconds, int32 Priority, float StartOffsetSeconds,
	EUECPSteamTimelineClipPriority ClipPriority)
{
#if UECP_TIMELINE_SUPPORTED
	if (ISteamTimeline* T = UECPSteam::Timeline())
	{
		return static_cast<int64>(T->AddRangeTimelineEvent(
			TCHAR_TO_UTF8(*Title), TCHAR_TO_UTF8(*Description), TCHAR_TO_UTF8(*Icon),
			static_cast<uint32>(FMath::Max(0, Priority)), StartOffsetSeconds, DurationSeconds,
			ToNative(ClipPriority)));
	}
#endif
	return 0;
}

int64 UUECPSteamTimelineLibrary::StartTimelineRangeEvent(const FString& Title, const FString& Description,
	const FString& Icon, int32 Priority, EUECPSteamTimelineClipPriority ClipPriority)
{
#if UECP_TIMELINE_SUPPORTED
	if (ISteamTimeline* T = UECPSteam::Timeline())
	{
		return static_cast<int64>(T->StartRangeTimelineEvent(
			TCHAR_TO_UTF8(*Title), TCHAR_TO_UTF8(*Description), TCHAR_TO_UTF8(*Icon),
			static_cast<uint32>(FMath::Max(0, Priority)), 0.f, ToNative(ClipPriority)));
	}
#endif
	return 0;
}

bool UUECPSteamTimelineLibrary::EndTimelineRangeEvent(int64 EventHandle, float EndOffsetSeconds)
{
#if UECP_TIMELINE_SUPPORTED
	if (ISteamTimeline* T = UECPSteam::Timeline())
	{
		if (EventHandle != 0)
		{
			T->EndRangeTimelineEvent(static_cast<TimelineEventHandle_t>(EventHandle), EndOffsetSeconds);
			return true;
		}
	}
#endif
	return false;
}

bool UUECPSteamTimelineLibrary::RemoveTimelineEvent(int64 EventHandle)
{
#if UECP_TIMELINE_SUPPORTED
	if (ISteamTimeline* T = UECPSteam::Timeline())
	{
		if (EventHandle != 0)
		{
			T->RemoveTimelineEvent(static_cast<TimelineEventHandle_t>(EventHandle));
			return true;
		}
	}
#endif
	return false;
}

bool UUECPSteamTimelineLibrary::StartGamePhase()
{
#if UECP_TIMELINE_SUPPORTED
	if (ISteamTimeline* T = UECPSteam::Timeline()) { T->StartGamePhase(); return true; }
#endif
	return false;
}

bool UUECPSteamTimelineLibrary::EndGamePhase()
{
#if UECP_TIMELINE_SUPPORTED
	if (ISteamTimeline* T = UECPSteam::Timeline()) { T->EndGamePhase(); return true; }
#endif
	return false;
}

bool UUECPSteamTimelineLibrary::SetGamePhaseID(const FString& PhaseId)
{
#if UECP_TIMELINE_SUPPORTED
	if (ISteamTimeline* T = UECPSteam::Timeline())
	{
		T->SetGamePhaseID(TCHAR_TO_UTF8(*PhaseId));
		return true;
	}
#endif
	return false;
}

bool UUECPSteamTimelineLibrary::AddGamePhaseTag(const FString& TagName, const FString& TagIcon,
	const FString& TagGroup, int32 Priority)
{
#if UECP_TIMELINE_SUPPORTED
	if (ISteamTimeline* T = UECPSteam::Timeline())
	{
		T->AddGamePhaseTag(TCHAR_TO_UTF8(*TagName), TCHAR_TO_UTF8(*TagIcon),
			TCHAR_TO_UTF8(*TagGroup), static_cast<uint32>(FMath::Max(0, Priority)));
		return true;
	}
#endif
	return false;
}

bool UUECPSteamTimelineLibrary::SetGamePhaseAttribute(const FString& AttributeGroup,
	const FString& AttributeValue, int32 Priority)
{
#if UECP_TIMELINE_SUPPORTED
	if (ISteamTimeline* T = UECPSteam::Timeline())
	{
		T->SetGamePhaseAttribute(TCHAR_TO_UTF8(*AttributeGroup), TCHAR_TO_UTF8(*AttributeValue),
			static_cast<uint32>(FMath::Max(0, Priority)));
		return true;
	}
#endif
	return false;
}

#undef UECP_TIMELINE_SUPPORTED
