// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "Async/UECPSteamAsyncAction.h"
#include "UECPSteamAPI.h"

#if UECP_WITH_STEAM

template <typename TParam>
class TUECPSteamCallResult final : public FUECPSteamCallResultHolder
{
public:
	using FOnComplete = TFunction<void(TParam*, bool)>;

	TUECPSteamCallResult(SteamAPICall_t Call, FOnComplete InOnComplete)
		: OnComplete(MoveTemp(InOnComplete))
	{
		CallResult.Set(Call, this, &TUECPSteamCallResult::OnCallResult);
	}

	virtual ~TUECPSteamCallResult() override = default;

private:
	CCallResult<TUECPSteamCallResult<TParam>, TParam> CallResult;
	FOnComplete OnComplete;

	void OnCallResult(TParam* Param, bool bIOFailure)
	{
		if (OnComplete)
		{
			OnComplete(Param, bIOFailure);
		}
	}
};

template <typename TParam>
void UECPSteamSetCallResult(TUniquePtr<FUECPSteamCallResultHolder>& Slot,
	SteamAPICall_t Call,
	typename TUECPSteamCallResult<TParam>::FOnComplete OnComplete)
{
	Slot = MakeUnique<TUECPSteamCallResult<TParam>>(Call, MoveTemp(OnComplete));
}

#endif
