(function () {
  if (!document.getElementById('uecp-toast-css')) {
    const s = document.createElement('style'); s.id = 'uecp-toast-css';
    s.textContent = `
#uecp-toast-host{position:fixed;bottom:calc(var(--ue-footer-h, 32px) + 14px);right:14px;z-index:9000;display:flex;flex-direction:column;gap:7px;pointer-events:none;max-width:340px}
#uecp-toast-host .ue-toast{display:flex;align-items:flex-start;gap:9px;padding:10px 12px;border-radius:var(--ue-r);background:var(--ue-panel);border:1px solid var(--ue-line);box-shadow:var(--ue-shadow-pop);pointer-events:all;font-size:var(--ue-fs-sm);line-height:1.45;color:var(--ue-text-hi);white-space:pre-line}
#uecp-toast-host .ue-toast.success{border-left:3px solid var(--ue-success)}
#uecp-toast-host .ue-toast.error{border-left:3px solid var(--ue-danger)}
#uecp-toast-host .ue-toast.info{border-left:3px solid var(--ue-accent)}
#uecp-toast-host .ue-toast .ic{flex-shrink:0;margin-top:1px;display:flex;color:var(--ue-text-lo)}
#uecp-toast-host .ue-toast.success .ic{color:var(--ue-success)}
#uecp-toast-host .ue-toast.error .ic{color:var(--ue-danger)}
#uecp-toast-host .ue-toast.info .ic{color:var(--ue-accent-bright)}
#uecp-toast-host .ue-toast .body{flex:1;min-width:0;word-break:break-word}
#uecp-toast-host .ue-toast .act{background:var(--ue-accent);border:none;color:#fff;cursor:pointer;font-size:11.5px;font-weight:600;padding:4px 9px;border-radius:var(--ue-r-xs);flex-shrink:0;margin-top:1px}
#uecp-toast-host .ue-toast .act:hover{filter:brightness(1.08)}
#uecp-toast-host .ue-toast .x{background:none;border:none;color:var(--ue-text-lo);cursor:pointer;font-size:15px;line-height:1;padding:0;flex-shrink:0}
#uecp-toast-host .ue-toast .x:hover{color:var(--ue-text-hi)}`;
    document.head.appendChild(s);
  }

  const ICONS = {
    success: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 6 9 17l-5-5"/></svg>',
    error: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 6 6 18"/><path d="m6 6 12 12"/></svg>',
    info: '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><path d="M12 16v-4"/><path d="M12 8h.01"/></svg>',
  };

  function host() {
    let h = document.getElementById('uecp-toast-host');
    if (!h) { h = document.createElement('div'); h.id = 'uecp-toast-host'; document.body.appendChild(h); }
    return h;
  }

  function dismissLater(t) {
    if (t._dismiss) clearTimeout(t._dismiss);
    const dur = (window.UECP && window.UECP.toastDuration) || 5000;
    t._dismiss = setTimeout(function () { if (t.parentNode) t.parentNode.removeChild(t); }, dur);
  }

  function findLive(message, sev) {
    const h = document.getElementById('uecp-toast-host');
    if (!h) return null;
    const kids = h.children || [];
    for (let i = 0; i < kids.length; i++) {
      if (kids[i]._msg === message && kids[i]._sev === sev && !kids[i]._hasAction) return kids[i];
    }
    return null;
  }

  function show(message, severity, opts) {
    if (message == null || message === '') return;
    opts = opts || {};
    let sev = String(severity || 'info').toLowerCase();
    if (sev !== 'success' && sev !== 'error') sev = 'info';
    const hasAction = !!(opts.action && opts.action.label);
    if (!hasAction) {
      const live = findLive(String(message), sev);
      if (live) {
        if (opts.sticky) { if (live._dismiss) clearTimeout(live._dismiss); live._sticky = true; }
        else if (!live._sticky) dismissLater(live);
        return;
      }
    }
    const t = document.createElement('div');
    t.className = 'ue-toast ' + sev;
    t._msg = String(message);
    t._sev = sev;
    t._hasAction = hasAction;
    t._sticky = !!opts.sticky;
    const body = document.createElement('span'); body.className = 'body'; body.textContent = String(message);
    t.innerHTML = '<span class="ic">' + (ICONS[sev] || ICONS.info) + '</span>';
    t.appendChild(body);
    if (opts.action && opts.action.label) {
      const a = document.createElement('button');
      a.className = 'act';
      a.textContent = opts.action.label;
      a.addEventListener('click', function () {
        if (t.parentNode) t.parentNode.removeChild(t);
        if (typeof opts.action.onClick === 'function') opts.action.onClick();
      });
      t.appendChild(a);
    }
    const x = document.createElement('button'); x.className = 'x'; x.innerHTML = '&times;';
    x.addEventListener('click', function () { if (t.parentNode) t.parentNode.removeChild(t); });
    t.appendChild(x);
    host().appendChild(t);
    if (!opts.sticky) dismissLater(t);
  }

  window.uecp.on('toast', function (p) {
    if (!p) return;
    show(p.message, p.severity);
  });

  let updateToastShown = '';
  window.uecp.on('update.available', function (p) {
    if (!p || !p.version || updateToastShown === p.version) return;
    updateToastShown = p.version;
    const staged = !!p.staged;
    show(
      staged
        ? window.uecp.T('Version {version} is ready to install.', { version: p.version })
        : window.uecp.T('Version {version} of the plugin is available.', { version: p.version }),
      'info',
      {
        sticky: true,
        action: {
          label: window.uecp.T(staged ? 'Finish' : 'Update'),
          onClick: function () {
            window.UECP.router.goSettings('info');
          },
        },
      }
    );
  });

  window.UECP = window.UECP || {};
  window.UECP.toast = show;
})();
