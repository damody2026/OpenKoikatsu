﻿(function () {
  if (!document.getElementById('uecp-app-css')) {
    const s = document.createElement('style'); s.id = 'uecp-app-css';
    s.textContent = `
/* height:100% (of the height:100% body), NOT 100vh — this element carries a zoom
   (Text Size), and a percentage of the unzoomed parent is the only expression
   guaranteed to land on the viewport at every scale. It is also what makes the
   height core/breakpoints.js reads off this element match what is really visible. */
uecp-app{height:100%;display:flex;overflow:hidden;background:var(--ue-bg);zoom:var(--ue-text-scale,1)}
uecp-app .col{flex:1;min-width:0;display:flex;flex-direction:column}
uecp-app .body{flex:1;min-height:0;display:flex}
uecp-app .outlet{flex:1;min-width:0;display:flex}
/* The mounted screen IS the .body content (demo's .view minus the shared topbar):
   it must fill the outlet as a flex container so .sidebar/.chat/.settings-nav get
   full height. Custom elements default to display:inline, which collapses the chat
   layout (composer floats mid-screen) — force the fill here for every screen. */
uecp-app .outlet > *{flex:1;min-width:0;min-height:0;display:flex}`;
    document.head.appendChild(s);
  }
  function shiftHex(hex, d) {
    const m = /^#?([0-9a-fA-F]{6})$/.exec(String(hex || ''));
    if (!m) return hex;
    const n = parseInt(m[1], 16);
    const c = [(n >> 16) & 255, (n >> 8) & 255, n & 255].map(function (v) {
      return Math.max(0, Math.min(255, v + d));
    });
    return '#' + c.map(function (v) { return ('0' + v.toString(16)).slice(-2); }).join('');
  }
  function applyTheme(state) {
    const root = document.documentElement;
    if (state && state.theme) root.dataset.theme = state.theme;
    let accent = state && state.accent;
    if (typeof accent === 'string') accent = { base: accent };
    if (accent && accent.base) {
      root.style.setProperty('--ue-accent', accent.base);
      root.style.setProperty('--ue-accent-deep', accent.deep || shiftHex(accent.base, -28));
      root.style.setProperty('--ue-accent-bright', accent.bright || shiftHex(accent.base, 28));
    }
  }
  const HEX_RE = /^#[0-9a-fA-F]{6}$/;
  function contrastTextFor(hex) {
    const m = /^#?([0-9a-fA-F]{6})$/.exec(String(hex || ''));
    if (!m) return '#ece6dc';
    const n = parseInt(m[1], 16);
    const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    const lin = (c) => { const v = c / 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); };
    const L = 0.2126 * lin(r) + 0.7152 * lin(g) + 0.0722 * lin(b);
    return L > 0.5 ? '#1a1a1a' : '#f0ede8';
  }
  function themeDefault(cssVar) {
    const root = document.documentElement;
    const had = root.style.getPropertyValue(cssVar);
    if (had) root.style.removeProperty(cssVar);
    const val = getComputedStyle(root).getPropertyValue(cssVar).trim();
    if (had) root.style.setProperty(cssVar, had);
    return val || '';
  }
  function applyColorOverrides(ap) {
    if (!ap) return;
    const root = document.documentElement;
    if (HEX_RE.test(ap.bgColor)) root.style.setProperty('--ue-bg', ap.bgColor);
    else root.style.removeProperty('--ue-bg');

    if (HEX_RE.test(ap.surfaceColor)) {
      root.style.setProperty('--ue-panel', ap.surfaceColor);
      root.style.setProperty('--ue-elev', shiftHex(ap.surfaceColor, 18));
    } else {
      root.style.removeProperty('--ue-panel');
      root.style.removeProperty('--ue-elev');
    }

    if (HEX_RE.test(ap.textColor)) {
      root.style.setProperty('--ue-text-hi', ap.textColor);
    } else if (ap.autoContrast !== false) {
      const bg = HEX_RE.test(ap.bgColor) ? ap.bgColor : themeDefault('--ue-bg');
      root.style.setProperty('--ue-text-hi', contrastTextFor(bg));
    } else {
      root.style.removeProperty('--ue-text-hi');
    }

    if (HEX_RE.test(ap.codeBgColor))   root.style.setProperty('--ue-code-bg', ap.codeBgColor);     else root.style.removeProperty('--ue-code-bg');
    if (HEX_RE.test(ap.codeLineColor)) root.style.setProperty('--ue-code-line', ap.codeLineColor); else root.style.removeProperty('--ue-code-line');
    if (HEX_RE.test(ap.codeTextColor)) root.style.setProperty('--ue-code-text', ap.codeTextColor); else root.style.removeProperty('--ue-code-text');
  }
  class App extends HTMLElement {
    connectedCallback() {
      window.UECP.injectSprite();
      this.innerHTML = '';
      const rail = document.createElement('uecp-rail');
      const col = document.createElement('div'); col.className = 'col';
      const top = document.createElement('uecp-topbar');
      const body = document.createElement('div'); body.className = 'body';
      const outlet = document.createElement('div'); outlet.className = 'outlet';
      const banner = document.createElement('uecp-banner');
      const footer = document.createElement('uecp-footer');
      body.appendChild(outlet);
      col.appendChild(banner); col.appendChild(top); col.appendChild(body); col.appendChild(footer);
      this.appendChild(rail); this.appendChild(col);

      window.UECP.router.setOutlet(outlet);
      window.UECP.router.register('placeholder', 'uecp-screen-placeholder');
      if (window.uecp && typeof window.uecp.on === 'function') {
        window.uecp.on('scan.index_state', function (d) {
          if (!d || typeof d.exists !== 'boolean') return;
          window.UECP._indexExists  = d.exists;
          window.UECP._indexSummary = d;
        });
      }
      window.UECP.router.register('architect', 'uecp-screen-architect');
      window.UECP.router.register('settings', 'uecp-screen-settings');
      window.UECP.router.register('learn', 'uecp-screen-learn');
      window.UECP.router.register('tools', 'uecp-screen-tools');
      window.UECP.router.register('subagents', 'uecp-screen-subagents');
      window.UECP.router.register('crew', 'uecp-screen-crew');
      window.UECP.router.register('cpppreview', 'uecp-screen-cpppreview');
      window.UECP.router.register('localstudio', 'uecp-screen-localstudio');
      window.UECP.router.register('cloudstudio', 'uecp-screen-cloudstudio');
      window.UECP.router.register('shop', 'uecp-screen-shop');
      window.UECP.router.register('inbox', 'uecp-screen-inbox');

      this._u = window.uecp.on('init', (state) => {
        applyTheme(state);
        window.UECP._startupSub = (state && state.sub) || null;
        const route = (state && state.route) || 'architect';
        if (typeof rail._go === 'function') rail._go(route);
        else window.UECP.router.go(route);
      });

      this._uVoiceSetup = window.uecp.on('voice.open_setup', () => {
        window.UECP.router.goSettings('audio');
      });

      this._uChatWidth = window.uecp.on('settings.init', (d) => {
        const root = document.documentElement;
        const cp = d && d.chatPrefs;
        if (cp) {
          if (cp.fullWidthChat === true) {
            root.style.setProperty('--ue-chat-col', '100%');
          } else if (typeof cp.chatMaxWidth === 'number' && cp.chatMaxWidth > 0) {
            root.style.setProperty('--ue-chat-col', cp.chatMaxWidth + 'px');
          } else if (typeof cp.fullWidthChat === 'boolean') {
            root.style.removeProperty('--ue-chat-col');
          }
        }
        const acc = d && d.accessibility;
        if (acc) {
          root.classList.toggle('reduced-motion', !!acc.reducedMotion);
          root.classList.toggle('high-contrast', !!acc.highContrast);
        }
        const ap = d && d.appearance;
        if (ap && typeof ap.uiFontSize === 'number' && ap.uiFontSize > 0) {
          const scale = ap.uiFontSize / 13;
          if (isFinite(scale) && scale > 0) root.style.setProperty('--ue-text-scale', scale);
        }
      });

      this._uDensity = window.uecp.on('settings.init', (d) => {
        const ap = d && d.appearance;
        if (!ap || !ap.chatDensity) return;
        const root = document.documentElement;
        if (ap.chatDensity === 'normal') root.removeAttribute('data-density');
        else root.setAttribute('data-density', ap.chatDensity);
      });

      this._uColors = window.uecp.on('settings.init', (d) => {
        applyColorOverrides(d && d.appearance);
      });

      window.uecp.call('shell_ready', {});
      this._fallback = setTimeout(() => { if (!window.UECP.router.active()) { applyTheme({ theme: 'dark' }); window.UECP.router.go('architect'); } }, 400);
    }
    disconnectedCallback() { if (this._u) this._u(); if (this._uChatWidth) this._uChatWidth(); if (this._uDensity) this._uDensity(); if (this._uColors) this._uColors(); if (this._fallback) clearTimeout(this._fallback); }
  }
  customElements.define('uecp-app', App);
})();
