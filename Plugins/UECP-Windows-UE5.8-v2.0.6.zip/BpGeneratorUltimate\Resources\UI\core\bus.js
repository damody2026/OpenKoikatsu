(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  if (root) { root.UECP = root.UECP || {}; root.UECP.createBus = api.createBus; }
}(typeof self !== 'undefined' ? self : null, function () {
  function createBus() {
    const subs = {};
    const inbuf = [];
    let unlocked = false;
    let sender = null;
    const outbuf = [];

    function deliver(type, payload) {
      const list = subs[type];
      if (!list) return;
      for (const h of list.slice()) { try { h(payload); } catch (e) { (root && root.console || console).error('[uecp] handler error', type, e); } }
    }
    return {
      on(type, handler) { (subs[type] || (subs[type] = [])).push(handler); return () => { const l = subs[type]; if (!l) return; const i = l.indexOf(handler); if (i >= 0) l.splice(i, 1); }; },
      emit(type, payload) {
        if (type === 'init') { unlocked = true; deliver('init', payload); while (inbuf.length) { const e = inbuf.shift(); deliver(e[0], e[1]); } return; }
        if (!unlocked) { inbuf.push([type, payload]); return; }
        deliver(type, payload);
      },
      setSender(fn) { sender = fn; while (outbuf.length) { const c = outbuf.shift(); sender(c[0], c[1]); } },
      call(action, payloadObj) {
        const json = JSON.stringify(payloadObj == null ? {} : payloadObj);
        if (!sender) { outbuf.push([action, json]); return; }
        sender(action, json);
      }
    };
  }
  return { createBus };
}));
