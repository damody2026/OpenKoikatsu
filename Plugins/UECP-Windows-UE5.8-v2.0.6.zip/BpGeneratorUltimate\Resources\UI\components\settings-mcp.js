(function () {
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }
  function copyText(text) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).catch(function () {});
    } else {
      const ta = document.createElement('textarea');
      ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
      document.body.appendChild(ta); ta.select(); document.execCommand('copy');
      document.body.removeChild(ta);
    }
  }

  function maskToken(token) {
    return String(token || '').substring(0, 8) + '••••';
  }
  function maskSnippet(text, token) {
    return token ? String(text).split(token).join(maskToken(token)) : String(text);
  }

  const EYE_SVG = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12s3-7 10-7 10 7 10 7-3 7-10 7-10-7-10-7Z"/><circle cx="12" cy="12" r="3"/></svg>';
  const EYE_OFF_SVG = '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><path d="M9.88 9.88a3 3 0 1 0 4.24 4.24"/><path d="M10.73 5.08A10.43 10.43 0 0 1 12 5c7 0 10 7 10 7a13.16 13.16 0 0 1-1.67 2.68"/><path d="M6.61 6.61A13.526 13.526 0 0 0 2 12s3 7 10 7a9.74 9.74 0 0 0 5.39-1.61"/><line x1="2" x2="22" y1="2" y2="22"/></svg>';

  function parseLines(text) {
    return String(text || '').split('\n').map(function (l) { return l.trim(); }).filter(Boolean);
  }
  function parseEnvLines(text) {
    const out = {};
    parseLines(text).forEach(function (line) {
      const i = line.indexOf('=');
      if (i < 0) return;
      out[line.slice(0, i).trim()] = line.slice(i + 1);
    });
    return out;
  }
  function parseHeaderLines(text) {
    const out = {};
    parseLines(text).forEach(function (line) {
      const i = line.indexOf(':');
      if (i < 0) return;
      out[line.slice(0, i).trim()] = line.slice(i + 1).trim();
    });
    return out;
  }
  function envToLines(obj) {
    if (!obj || typeof obj !== 'object') return '';
    return Object.keys(obj).map(function (k) { return k + '=' + obj[k]; }).join('\n');
  }
  function headersToLines(obj) {
    if (!obj || typeof obj !== 'object') return '';
    return Object.keys(obj).map(function (k) { return k + ': ' + obj[k]; }).join('\n');
  }

  const t = function (key, vars) {
    if (window.uecp && typeof window.uecp.t === 'function') return window.uecp.t(key, vars);
    let out = String(key);
    if (vars) Object.keys(vars).forEach(function (k) {
      out = out.replace(new RegExp('\{' + k + '\}', 'g'), String(vars[k]));
    });
    return out;
  };

  function clientSetups() {
    return {
      'Claude Code':    { field: 'cli',
                          instr: t('Run this once in a terminal:'),
                          hint: t('Run claude mcp list afterwards to check the server is connected.') },
      'Claude Desktop': { field: 'extension',
                          instr: t('Claude Desktop connects through the CoPilot extension, a one-click bundle that runs on your machine.'),
                          hint: t('Click Reveal extension file, double-click uecp-bridge.mcpb to install it in Claude Desktop, then enter the URL above and the token from the Token row when it asks. Keep this editor open.') },
      'Cursor':         { field: 'claudeConfigSnippet',
                          instr: t('Paste into ~/.cursor/mcp.json (all projects) or .cursor/mcp.json (this project):'),
                          hint: t('Cursor picks up the change on its own.') },
      'Codex':          { field: 'codexTomlSnippet',
                          instr: t('Add to ~/.codex/config.toml:'),
                          hint: t('Restart Codex after saving.') },
      'Copilot CLI':    { field: 'claudeConfigSnippet',
                          instr: t('Add to ~/.copilot/mcp-config.json (create the file if it is missing):'),
                          hint: t('Copilot CLI loads it right away.') },
      'Gemini CLI':     { field: 'geminiJsonSnippet',
                          instr: t('Add under mcpServers in ~/.gemini/settings.json:'),
                          hint: t('Gemini CLI loads it in its next session.') },
      'OpenCode':       { field: 'opencodeJsonSnippet',
                          instr: t('Add to opencode.json in your project, or ~/opencode.json for every project:'),
                          hint: '' },
      'Other':          { field: 'claudeConfigSnippet',
                          instr: t('For Cline, Windsurf, VS Code, JetBrains and other clients that read a standard mcpServers block over HTTP:'),
                          hint: t('Claude Desktop needs its own tab: its config file cannot use this.') },
    };
  }

  const FALLBACKS = {
    cli: function (url, token) {
      return 'claude mcp add --scope user --header "Authorization: Bearer ' + token + '" --transport http uecp ' + url;
    },
    extension: function (url) { return url; },
    claudeConfigSnippet: function (url, token) {
      return '{\n  "mcpServers": {\n    "uecp": {\n      "type": "http",\n      "url": "' + url + '",\n      "headers": {\n        "Authorization": "Bearer ' + token + '"\n      }\n    }\n  }\n}';
    },
    codexTomlSnippet: function (url, token) {
      return '[mcp_servers.uecp]\nurl = "' + url + '"\nhttp_headers = { Authorization = "Bearer ' + token + '" }\n';
    },
    geminiJsonSnippet: function (url, token) {
      return '{\n  "mcpServers": {\n    "uecp": {\n      "httpUrl": "' + url + '",\n      "headers": {\n        "Authorization": "Bearer ' + token + '"\n      }\n    }\n  }\n}';
    },
    opencodeJsonSnippet: function (url, token) {
      return '{\n  "$schema": "https://opencode.ai/config.json",\n  "mcp": {\n    "uecp": {\n      "type": "remote",\n      "url": "' + url + '",\n      "headers": {\n        "Authorization": "Bearer ' + token + '"\n      },\n      "enabled": true\n    }\n  }\n}';
    },
  };

  class SettingsMcp extends HTMLElement {
    connectedCallback() {
      this.style.cssText = 'display:flex;flex-direction:column;flex:1;min-height:0';
      this._status  = null;
      this._servers = [];
      this._clientTab = 'Claude Code';
      this._tokenRevealed = false;
      this._render();
      window.uecp.call('request_mcp_status', {});
      window.uecp.call('request_user_mcp', {});
    }

    _onSettingsInit(state) {
      if (!state) return;
      if (state.mcp_status) { this._status = state.mcp_status; this._renderStatus(); this._renderClientSetup(); }
      if (state.mcp_servers) { this._servers = state.mcp_servers; this._renderUpstream(); }
    }

    _onMcpStatus(data) { this._status = data; this._renderStatus(); this._renderClientSetup(); }

    _onMcpAddResult(data) {
      const slot = this.querySelector('#smcp-modal-slot');
      if (!slot || !slot.querySelector('#smcp-modal-overlay')) return;
      const added  = (data && Array.isArray(data.added)) ? data.added : [];
      const errors = (data && data.errors && typeof data.errors === 'object') ? data.errors : {};
      const errKeys = Object.keys(errors);
      if (!errKeys.length) { slot.innerHTML = ''; return; }
      const errBox = slot.querySelector('#smcp-modal-errors');
      if (!errBox) return;
      const self = this;
      errBox.innerHTML = (added.length ? '<div style="color:var(--ue-success);margin-bottom:6px">Added: ' + added.map(esc).join(', ') + '</div>' : '')
        + '<div style="color:var(--ue-danger)">'
        + errKeys.map(function (id) { return esc(id) + ': ' + esc(errors[id]); }).join('<br>')
        + '</div>';
      const addBtn = slot.querySelector('#smcp-modal-add');
      if (addBtn) { addBtn.disabled = false; addBtn.textContent = addBtn.dataset.label || 'Add'; }
    }
    _onMcpServers(data) {
      if (Array.isArray(data)) {
        this._servers = data;
      } else if (data && Array.isArray(data.servers)) {
        this._servers = data.servers;
      } else {
        this._servers = [];
      }
      this._renderUpstream();
    }

    _onMcpTestResult(data) {
      if (!data || data.status === 'testing') return;
      const server = (this._servers || []).filter(function (s) { return s && s.id === data.id; })[0];
      const name = (server && (server.displayName || server.name)) || data.id || 'Server';
      if (data.status === 'ok') {
        window.uecp.__emit('toast', { message: name + ': connected (' + (data.toolCount || 0) + ' tools).', severity: 'success' });
      } else {
        window.uecp.__emit('toast', { message: name + ': ' + (data.error || 'Test failed.'), severity: 'error' });
      }
    }

    _onMcpOauthResult(data) {
      if (!data || data.ok) return;
      const server = (this._servers || []).filter(function (s) { return s && s.id === data.id; })[0];
      const name = (server && (server.displayName || server.name)) || data.id || 'Server';
      window.uecp.__emit('toast', { message: name + ' sign-in failed: ' + (data.error || 'Unknown error.'), severity: 'error' });
    }

    _render() {
      this.innerHTML =
        '<div class="content-head"><span class="crumb"><b>MCP Server</b></span></div>'
        + '<div class="page page-narrow" style="overflow-y:auto;flex:1">'
        + '<div class="page-title">MCP Server</div>'
        + '<div class="page-sub">Expose CoPilot\'s Unreal tools to external AI clients like Claude Desktop and Cursor over the Model Context Protocol.</div>'
        + '<div id="smcp-status-slot"></div>'
        + '<div class="section-label">CLIENT SETUP</div>'
        + '<div id="smcp-client-slot"></div>'
        + '<div style="display:flex;align-items:center;margin:22px 0 11px">'
        + '<span class="section-label" style="margin:0">UPSTREAM SERVERS</span>'
        + '<span class="spacer"></span>'
        + '<button class="btn-soft" id="smcp-add-server-top">'
        + '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="margin-right:5px"><path d="M12 5v14M5 12h14"/></svg>'
        + 'Add upstream</button>'
        + '</div>'
        + '<div id="smcp-upstream-slot"></div>'
        + '<div id="smcp-modal-slot"></div>'
        + '</div>';

      const self = this;
      this.querySelector('#smcp-add-server-top').addEventListener('click', function () {
        self._showAddModal();
      });

      this._renderStatus();
      this._renderClientSetup();
      this._renderUpstream();
    }

    _renderStatus() {
      const slot = this.querySelector('#smcp-status-slot');
      if (!slot) return;
      const s = this._status;
      if (!s) { slot.innerHTML = '<div style="color:var(--ue-text-lo);font-size:var(--ue-fs-sm);padding:20px 0">Loading server status…</div>'; return; }

      const running   = typeof s.port === 'number' && s.port > 0;
      const port      = running ? s.port : 30000;
      const token     = s.token || '—';
      const mcpUrl    = running ? (s.mcpUrl || ('http://127.0.0.1:' + port + '/sse')) : '';
      const toolCount = s.toolCount  || 0;
      const clients   = s.clients    || 0;
      const lan       = s.lan        ? true : false;
      const streaming = s.streaming  ? true : false;

      slot.innerHTML =
        '<div class="card" style="margin-top:20px">'
        + '<div style="display:flex;align-items:center;gap:10px;margin-bottom:14px">'
        + '<span class="dot' + (running ? ' dot-ok' : '') + '" style="' + (running ? '' : 'background:var(--ue-danger)') + '"></span>'
        + '<span class="card-title" style="font-size:14px">' + (running ? 'Server running' : 'Server offline') + '</span>'
        + '<span class="chat-item-meta" style="margin-left:6px">' + toolCount + ' tools exposed · ' + clients + ' clients</span>'
        + '<span class="spacer"></span>'
        + '</div>'
        + '<div class="input mono" style="gap:8px">'
        + (running
          ? '<svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="2.5"/><circle cx="4" cy="5" r="2"/><circle cx="20" cy="5" r="2"/><path d="M6 6.5 10 10M18 6.5 14 10"/></svg>'
            + '<span style="color:var(--ue-code-text);flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(mcpUrl) + '</span>'
            + '<button class="btn-ghost" id="smcp-copy-url" style="padding:4px 10px;font-size:11px">Copy</button>'
          : '<span style="color:var(--ue-danger);flex:1">All ports 30000-30009 are in use — close another editor or app using those ports, then reopen this panel.</span>')
        + '</div>'
        + (running && s.routedElsewhere
          ? '<div style="font-size:11.5px;color:var(--ue-text-mid);margin-top:6px">This project is open in another editor too, and the shared address reaches that one. The address above is this editor\'s own.</div>'
          : '')
        + '<div style="display:flex;align-items:center;gap:8px;background:var(--ue-bg);border:1px solid var(--ue-line);border-radius:var(--ue-r);padding:9px 12px;margin-top:8px">'
        + '<span style="flex:1;font-family:var(--ue-font-mono);font-size:11px;color:var(--ue-text-mid);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">Token: ' + esc(maskToken(token)) + '</span>'
        + '<button class="btn-ghost" id="smcp-copy-token" style="padding:4px 10px;font-size:11px">Copy</button>'
        + '<button class="btn-ghost" id="smcp-rotate-token" style="padding:4px 10px;font-size:11px">Rotate</button>'
        + '</div>'
        + '<div style="display:flex;align-items:center;gap:14px;padding:10px 0;border-top:1px solid var(--ue-line-soft);margin-top:12px">'
        + '<div style="flex:1"><div style="font-size:var(--ue-fs-sm);font-weight:var(--ue-fw-medium);color:var(--ue-text-hi)">LAN Access</div><div style="font-size:11.5px;color:var(--ue-text-mid);margin-top:2px">Allow connections from other machines on your local network.</div></div>'
        + '<div class="toggle' + (lan ? ' on' : '') + '" id="smcp-lan" role="switch" aria-checked="' + (lan ? 'true' : 'false') + '" tabindex="0"><span class="knob"></span></div>'
        + '</div>'
        + '<div style="display:flex;align-items:center;gap:14px;padding:10px 0;border-top:1px solid var(--ue-line-soft)">'
        + '<div style="flex:1"><div style="font-size:var(--ue-fs-sm);font-weight:var(--ue-fw-medium);color:var(--ue-text-hi)">Streaming Transport</div><div style="font-size:11.5px;color:var(--ue-text-mid);margin-top:2px">Use raw-socket SSE instead of HTTP polling. Restart required.</div></div>'
        + '<div class="toggle' + (streaming ? ' on' : '') + '" id="smcp-streaming" role="switch" aria-checked="' + (streaming ? 'true' : 'false') + '" tabindex="0"><span class="knob"></span></div>'
        + '</div>'
        + '</div>';

      const copyUrlBtn = slot.querySelector('#smcp-copy-url');
      if (copyUrlBtn) copyUrlBtn.addEventListener('click', function () { copyText(mcpUrl); });
      slot.querySelector('#smcp-copy-token').addEventListener('click', function () { copyText(token); });
      slot.querySelector('#smcp-rotate-token').addEventListener('click', function () {
        window.uecp.call('rotate_mcp_token', {});
      });
      slot.querySelector('#smcp-lan').addEventListener('click', function () {
        window.uecp.call('mcp_set_lan', { enabled: !this.classList.contains('on') });
      });
      slot.querySelector('#smcp-streaming').addEventListener('click', function () {
        window.uecp.call('mcp_set_streaming', { enabled: !this.classList.contains('on') });
      });
    }

    _renderClientSetup() {
      const slot = this.querySelector('#smcp-client-slot');
      if (!slot) return;
      const s = this._status;
      const port  = (s && s.port)  || 30000;
      const token = (s && s.token) || '';
      const url   = (s && s.mcpUrl) || ('http://127.0.0.1:' + port + '/sse');
      const setups = clientSetups();
      const clients = Object.keys(setups);
      const self  = this;
      const activeTab = setups[this._clientTab] ? this._clientTab : 'Claude Code';
      const recipe = setups[activeTab];
      const revealed = !!(this._tokenRevealed && token);

      let snippet = this._cppSnippet(recipe.field, s);
      if (!snippet) snippet = FALLBACKS[recipe.field](url, token);
      const shown = revealed ? snippet : maskSnippet(snippet, token);
      const hasToken = !!(token && snippet.indexOf(token) >= 0);
      const isExtension = recipe.field === 'extension';

      let html = '<div class="card" style="padding:0;overflow:hidden">'
        + '<div style="display:flex;flex-wrap:wrap;gap:2px;padding:4px 6px;border-bottom:1px solid var(--ue-line-soft)">'
        + clients.map(function (c) {
            return '<span class="seg' + (c === activeTab ? ' active' : '') + '" data-client="' + esc(c) + '" style="padding:7px 13px;cursor:pointer">' + esc(c === 'Other' ? t('Other') : c) + '</span>';
          }).join('')
        + '</div>'
        + '<div style="padding:14px 16px">'
        + '<div style="font-size:12px;color:var(--ue-text-hi);margin-bottom:8px">' + esc(recipe.instr) + '</div>'
        + '<div style="display:flex;align-items:center;gap:6px;margin-bottom:8px">'
        + '<span style="flex:1;min-width:0;font-size:11px;color:var(--ue-text-lo)">'
        + (hasToken && !revealed ? 'Token hidden. Copy includes the full token.' : '') + '</span>'
        + (hasToken
            ? '<button class="btn-ghost" id="smcp-snip-reveal" aria-label="Show token" aria-pressed="' + (revealed ? 'true' : 'false') + '"'
              + ' data-tip="' + (revealed ? 'Hide token' : 'Show token') + '"'
              + ' style="padding:4px 8px;display:inline-flex;align-items:center">' + (revealed ? EYE_OFF_SVG : EYE_SVG) + '</button>'
            : '')
        + '<button class="btn-ghost" id="smcp-snip-copy" style="padding:4px 10px;font-size:11px">Copy</button>'
        + '</div>'
        + '<pre class="mono" style="margin:0;font-size:12px;line-height:1.7;color:var(--ue-text-mid);white-space:pre-wrap">' + esc(shown) + '</pre>'
        + (recipe.hint ? '<div style="font-size:11.5px;color:var(--ue-text-mid);margin-top:10px">' + esc(recipe.hint) + '</div>' : '')
        + (isExtension ? '<button class="btn-soft" id="smcp-reveal-ext" style="margin-top:10px">Reveal extension file</button>' : '')
        + '</div>'
        + '</div>';

      slot.innerHTML = html;

      slot.querySelectorAll('.seg[data-client]').forEach(function (tab) {
        tab.addEventListener('click', function () {
          self._clientTab = tab.dataset.client;
          self._renderClientSetup();
        });
      });
      const reveal = slot.querySelector('#smcp-snip-reveal');
      if (reveal) reveal.addEventListener('click', function () {
        self._tokenRevealed = !self._tokenRevealed;
        self._renderClientSetup();
      });
      slot.querySelector('#smcp-snip-copy').addEventListener('click', function () { copyText(snippet); });
      const revealExt = slot.querySelector('#smcp-reveal-ext');
      if (revealExt) revealExt.addEventListener('click', function () {
        window.uecp.call('reveal_claude_ext', {});
      });
    }

    _cppSnippet(field, s) {
      if (!s) return '';
      if (field === 'cli') {
        const hit = Array.isArray(s.cliCommands)
          ? s.cliCommands.filter(function (c) { return c && c.client === 'Claude Code'; })[0] : null;
        return (hit && hit.command) || '';
      }
      if (field === 'extension') return s.mcpUrl || '';
      return s[field] || '';
    }

    _renderUpstream() {
      const slot = this.querySelector('#smcp-upstream-slot');
      if (!slot) return;
      const self = this;
      const servers = this._servers || [];

      let html = '';
      if (!servers.length) {
        html += '<div style="color:var(--ue-text-lo);font-size:var(--ue-fs-sm)">No upstream servers configured. Add one above.</div>';
      }
      const SF = window.SettingsFormat;
      servers.forEach(function (raw) {
        const m = SF && SF.mapUpstreamServer ? SF.mapUpstreamServer(raw)
          : { id: raw.id || '', name: raw.displayName || raw.name || (raw.id || ''), enabled: raw.enabled !== false,
              ok: false, failed: false, statusLabel: 'idle', meta: raw.url || '', url: raw.url || '',
              useOAuth: !!raw.useOAuth, hasOAuthGrant: !!raw.hasOAuthGrant };
        const id      = m.id;
        const statusColor = m.ok ? 'var(--ue-success)' : m.failed ? 'var(--ue-danger)' : 'var(--ue-text-lo)';
        const dotClass = m.ok ? 'dot dot-ok' : 'dot';
        const oauthBtn = m.useOAuth
          ? '<button class="btn-ghost" data-action="' + (m.hasOAuthGrant ? 'oauth_signout' : 'oauth_signin') + '" data-id="' + esc(id) + '" style="padding:4px 9px;font-size:11px">' + (m.hasOAuthGrant ? 'Sign out' : 'Sign in') + '</button>'
          : '';

        html += '<div class="card" style="display:flex;align-items:center;gap:11px;padding:11px 14px;margin-bottom:10px;min-width:0">'
          + '<span class="' + dotClass + '" style="' + (!m.ok ? 'background:' + statusColor : '') + '"></span>'
          + '<div style="flex:1;min-width:0">'
          + '<div style="font-size:12.5px;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(m.name) + '</div>'
          + (m.meta ? '<div class="chat-item-meta" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(m.meta) + '</div>' : '')
          + (m.lastError ? '<div class="chat-item-meta" style="color:var(--ue-danger);overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(m.lastError) + '</div>' : '')
          + '</div>'
          + '<span class="chat-item-meta" style="color:' + statusColor + ';flex-shrink:0">' + esc(m.statusLabel) + '</span>'
          + oauthBtn
          + '<button class="btn-ghost" data-action="edit" data-id="' + esc(id) + '" style="padding:4px 9px;font-size:11px;flex-shrink:0">Edit</button>'
          + '<button class="btn-ghost" data-action="test" data-id="' + esc(id) + '" style="padding:4px 9px;font-size:11px;flex-shrink:0">Test</button>'
          + '<button class="btn-ghost" data-action="restart" data-id="' + esc(id) + '" style="padding:4px 9px;font-size:11px;flex-shrink:0">Restart</button>'
          + '<div class="toggle sm' + (m.enabled ? ' on' : '') + '" data-action="toggle" data-id="' + esc(id) + '" data-enabled="' + (m.enabled ? '1' : '0') + '" role="switch" aria-checked="' + (m.enabled ? 'true' : 'false') + '" tabindex="0"><span class="knob"></span></div>'
          + '<button class="btn-ghost" data-action="remove" data-id="' + esc(id) + '" style="padding:4px 9px;font-size:11px;color:var(--ue-danger)">Remove</button>'
          + '</div>';
      });

      slot.innerHTML = html;

      slot.querySelectorAll('[data-action][data-id]').forEach(function (btn) {
        btn.addEventListener('click', function () {
          const action = btn.dataset.action;
          const id     = btn.dataset.id;
          if (action === 'edit') {
            const found = (self._servers || []).filter(function (s) { return s && s.id === id; })[0];
            self._showEditModal(found || { id: id });
          }
          if (action === 'test')    window.uecp.call('test_user_mcp',    { id: id });
          if (action === 'restart') window.uecp.call('restart_user_mcp', { id: id });
          if (action === 'remove')  window.uecp.call('remove_user_mcp',  { id: id });
          if (action === 'oauth_signin')  window.uecp.call('oauth_signin_user_mcp',  { id: id });
          if (action === 'oauth_signout') window.uecp.call('oauth_signout_user_mcp', { id: id });
          if (action === 'toggle') {
            const wasOn = btn.dataset.enabled === '1';
            window.uecp.call('set_user_mcp_enabled', { id: id, enabled: !wasOn });
          }
        });
      });
    }

    _showAddModal() {
      this._renderServerModal(null);
    }

    _showEditModal(raw) {
      this._renderServerModal(raw || {});
    }

    _renderServerModal(raw) {
      const slot = this.querySelector('#smcp-modal-slot');
      if (!slot) return;
      const isEdit = !!raw;
      if (!isEdit && !this._addTab) this._addTab = 'json';
      const tab = isEdit ? 'manual' : this._addTab;
      const self = this;

      const tabsHtml = isEdit ? '' :
        '<div style="display:flex;gap:2px;margin-bottom:16px">'
        + '<span class="seg' + (tab === 'json' ? ' active' : '') + '" data-tab="json" style="padding:6px 13px;cursor:pointer">Paste JSON</span>'
        + '<span class="seg' + (tab === 'manual' ? ' active' : '') + '" data-tab="manual" style="padding:6px 13px;cursor:pointer">Manual setup</span>'
        + '</div>';

      const bodyHtml = tab === 'json'
        ? '<div style="margin-bottom:13px">'
          + '<div class="field-label">Paste mcpServers JSON block (Claude Desktop / Cursor / other)</div>'
          + '<textarea class="input mono" id="smcp-mcp-block" placeholder=\'{"uecp-search":{"command":"npx","args":["-y","@upstash/context7-mcp"]}}\' spellcheck="false" style="width:100%;box-sizing:border-box;min-height:100px;resize:vertical;background:var(--ue-bg)"></textarea>'
          + '<div style="font-size:11.5px;color:var(--ue-text-lo);margin-top:6px">Paste the entire mcpServers object (not just one entry) to import all servers at once.</div>'
          + '</div>'
        : this._serverFormHtml(raw || {}, isEdit);

      const label = isEdit ? 'Save' : 'Add';
      slot.innerHTML = '<div class="ue-overlay" id="smcp-modal-overlay">'
        + '<div class="ue-modal" style="padding:22px;min-width:min(440px,100%);max-width:min(' + (tab === 'manual' ? '560px' : '520px') + ',calc(100% - 24px));max-height:calc(100% - 40px);overflow-y:auto">'
        + '<div style="font-size:var(--ue-fs-md);font-weight:var(--ue-fw-semi);color:var(--ue-text-hi);margin-bottom:16px">' + (isEdit ? 'Edit Upstream Server' : 'Add Upstream MCP Server') + '</div>'
        + tabsHtml
        + bodyHtml
        + '<div id="smcp-modal-errors" style="font-size:11.5px;margin-top:10px"></div>'
        + '<div style="display:flex;justify-content:flex-end;gap:8px;margin-top:16px">'
        + '<button class="btn-ghost" id="smcp-modal-cancel">Cancel</button>'
        + '<button class="btn-soft" id="smcp-modal-add" data-label="' + label + '">' + label + '</button>'
        + '</div></div></div>';

      slot.querySelector('#smcp-modal-cancel').addEventListener('click', function () { slot.innerHTML = ''; });
      window.UECP.dom.bindBackdropClose(slot.querySelector('#smcp-modal-overlay'), function () { slot.innerHTML = ''; });

      if (!isEdit) {
        slot.querySelectorAll('.seg[data-tab]').forEach(function (t) {
          t.addEventListener('click', function () {
            self._addTab = t.dataset.tab;
            self._renderServerModal(null);
          });
        });
      }

      if (tab === 'json') {
        slot.querySelector('#smcp-modal-add').addEventListener('click', function () {
          const block = (slot.querySelector('#smcp-mcp-block') || {}).value || '';
          if (!block.trim()) return;
          this.disabled = true;
          this.textContent = 'Adding…';
          window.uecp.call('add_user_mcp', { block: block });
        });
      } else {
        this._wireServerForm(slot, raw || {});
        slot.querySelector('#smcp-modal-add').addEventListener('click', function () {
          const payload = self._collectServerFormValues(slot, raw || {});
          if (!payload) return;
          this.disabled = true;
          this.textContent = isEdit ? 'Saving…' : 'Adding…';
          window.uecp.call('update_user_mcp', payload);
        });
      }
    }

    _serverFormHtml(raw, isEdit) {
      const transport = raw.url ? 'http' : 'stdio';
      return '<div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:10px 12px">'
        + '<div style="grid-column:1/-1">'
        + '<div class="field-label">Server ID (alphanumeric + underscores)</div>'
        + '<input class="input mono" id="smcp-f-id" spellcheck="false" autocorrect="off" autocapitalize="off" style="width:100%;box-sizing:border-box" value="' + esc(raw.id || '') + '"' + (isEdit ? ' disabled' : '') + '>'
        + '</div>'
        + '<div>'
        + '<div class="field-label">Display Name</div>'
        + '<input class="input" id="smcp-f-name" style="width:100%;box-sizing:border-box" value="' + esc(raw.displayName || '') + '">'
        + '</div>'
        + '<div>'
        + '<div class="field-label">Description</div>'
        + '<input class="input" id="smcp-f-desc" style="width:100%;box-sizing:border-box" value="' + esc(raw.description || '') + '">'
        + '</div>'
        + '</div>'
        + '<div style="display:flex;gap:2px;margin:14px 0 10px">'
        + '<span class="seg' + (transport === 'stdio' ? ' active' : '') + '" data-transport="stdio" style="padding:6px 13px;cursor:pointer">Command (stdio)</span>'
        + '<span class="seg' + (transport === 'http' ? ' active' : '') + '" data-transport="http" style="padding:6px 13px;cursor:pointer">URL (HTTP)</span>'
        + '</div>'
        + '<div id="smcp-f-stdio" style="display:' + (transport === 'stdio' ? '' : 'none') + '">'
        + '<div class="field-label">Command</div>'
        + '<input class="input mono" id="smcp-f-command" spellcheck="false" autocorrect="off" autocapitalize="off" style="width:100%;box-sizing:border-box" placeholder="npx" value="' + esc(raw.command || '') + '">'
        + '<div class="field-label" style="margin-top:9px">Arguments (one per line)</div>'
        + '<textarea class="input mono" id="smcp-f-args" spellcheck="false" autocorrect="off" autocapitalize="off" style="width:100%;box-sizing:border-box;min-height:56px;resize:vertical">' + esc((raw.args || []).join('\n')) + '</textarea>'
        + '<div class="field-label" style="margin-top:9px">Environment variables (KEY=value, one per line)</div>'
        + '<textarea class="input mono" id="smcp-f-env" spellcheck="false" autocorrect="off" autocapitalize="off" style="width:100%;box-sizing:border-box;min-height:56px;resize:vertical">' + esc(envToLines(raw.env)) + '</textarea>'
        + '<div class="field-label" style="margin-top:9px">Working directory (optional)</div>'
        + '<input class="input mono" id="smcp-f-cwd" spellcheck="false" autocorrect="off" autocapitalize="off" style="width:100%;box-sizing:border-box" value="' + esc(raw.cwd || '') + '">'
        + '</div>'
        + '<div id="smcp-f-http" style="display:' + (transport === 'http' ? '' : 'none') + '">'
        + '<div class="field-label">URL</div>'
        + '<input class="input mono" id="smcp-f-url" spellcheck="false" autocorrect="off" autocapitalize="off" style="width:100%;box-sizing:border-box" placeholder="https://example.com/sse" value="' + esc(raw.url || '') + '">'
        + '<div class="field-label" style="margin-top:9px">Headers (Name: value, one per line)</div>'
        + '<textarea class="input mono" id="smcp-f-headers" spellcheck="false" autocorrect="off" autocapitalize="off" style="width:100%;box-sizing:border-box;min-height:56px;resize:vertical">' + esc(headersToLines(raw.headers)) + '</textarea>'
        + (isEdit && raw.headers && Object.keys(raw.headers).length
            ? '<div style="font-size:11px;color:var(--ue-text-lo);margin-top:4px">Secret values are shown masked. Leave a line untouched to keep it, or retype the full value to replace it.</div>'
            : '')
        + '</div>'
        + '<div style="display:flex;align-items:center;gap:14px;padding:10px 0;border-top:1px solid var(--ue-line-soft);margin-top:14px">'
        + '<div style="flex:1"><div style="font-size:var(--ue-fs-sm);font-weight:var(--ue-fw-medium);color:var(--ue-text-hi)">Always confirm</div><div style="font-size:11.5px;color:var(--ue-text-mid);margin-top:2px">Prompt before every destructive call through this server, regardless of its own annotations.</div></div>'
        + '<div class="toggle' + (raw.alwaysConfirm ? ' on' : '') + '" id="smcp-f-alwaysconfirm" role="switch" aria-checked="' + (raw.alwaysConfirm ? 'true' : 'false') + '" tabindex="0"><span class="knob"></span></div>'
        + '</div>'
        + '<div id="smcp-f-oauth-row" style="display:' + (transport === 'http' ? 'flex' : 'none') + ';align-items:center;gap:14px;padding:10px 0;border-top:1px solid var(--ue-line-soft)">'
        + '<div style="flex:1"><div style="font-size:var(--ue-fs-sm);font-weight:var(--ue-fw-medium);color:var(--ue-text-hi)">Use OAuth sign-in</div><div style="font-size:11.5px;color:var(--ue-text-mid);margin-top:2px">Sign in interactively instead of a static header (HTTP servers only).</div></div>'
        + '<div class="toggle' + (raw.useOAuth ? ' on' : '') + '" id="smcp-f-oauth" role="switch" aria-checked="' + (raw.useOAuth ? 'true' : 'false') + '" tabindex="0"><span class="knob"></span></div>'
        + '</div>';
    }

    _wireServerForm(slot) {
      slot.querySelectorAll('.seg[data-transport]').forEach(function (t) {
        t.addEventListener('click', function () {
          slot.querySelectorAll('.seg[data-transport]').forEach(function (o) { o.classList.remove('active'); });
          t.classList.add('active');
          const isStdio = t.dataset.transport === 'stdio';
          slot.querySelector('#smcp-f-stdio').style.display = isStdio ? '' : 'none';
          slot.querySelector('#smcp-f-http').style.display = isStdio ? 'none' : '';
          const oauthRow = slot.querySelector('#smcp-f-oauth-row');
          if (oauthRow) oauthRow.style.display = isStdio ? 'none' : 'flex';
        });
      });
      const acEl = slot.querySelector('#smcp-f-alwaysconfirm');
      if (acEl) acEl.addEventListener('click', function () { this.classList.toggle('on'); });
      const oaEl = slot.querySelector('#smcp-f-oauth');
      if (oaEl) oaEl.addEventListener('click', function () { this.classList.toggle('on'); });
    }

    _collectServerFormValues(slot, raw) {
      const typedId = ((slot.querySelector('#smcp-f-id') || {}).value || '').trim();
      const id = raw.id || typedId;
      if (!id) {
        const errBox = slot.querySelector('#smcp-modal-errors');
        if (errBox) errBox.innerHTML = '<div style="color:var(--ue-danger)">Server id is required.</div>';
        return null;
      }
      const activeSeg = slot.querySelector('.seg[data-transport].active');
      const transport = activeSeg ? activeSeg.dataset.transport : (raw.url ? 'http' : 'stdio');
      const acEl = slot.querySelector('#smcp-f-alwaysconfirm');
      const oaEl = slot.querySelector('#smcp-f-oauth');
      return {
        id: id,
        displayName: (slot.querySelector('#smcp-f-name') || {}).value || '',
        description: (slot.querySelector('#smcp-f-desc') || {}).value || '',
        command: transport === 'stdio' ? ((slot.querySelector('#smcp-f-command') || {}).value || '') : '',
        args: transport === 'stdio' ? parseLines((slot.querySelector('#smcp-f-args') || {}).value) : [],
        env: transport === 'stdio' ? parseEnvLines((slot.querySelector('#smcp-f-env') || {}).value) : {},
        cwd: transport === 'stdio' ? ((slot.querySelector('#smcp-f-cwd') || {}).value || '') : '',
        url: transport === 'http' ? ((slot.querySelector('#smcp-f-url') || {}).value || '') : '',
        headers: transport === 'http' ? parseHeaderLines((slot.querySelector('#smcp-f-headers') || {}).value) : {},
        enabled: raw.enabled !== false,
        alwaysConfirm: !!(acEl && acEl.classList.contains('on')),
        useOAuth: !!(oaEl && oaEl.classList.contains('on')),
      };
    }
  }
  customElements.define('settings-mcp', SettingsMcp);
})();
