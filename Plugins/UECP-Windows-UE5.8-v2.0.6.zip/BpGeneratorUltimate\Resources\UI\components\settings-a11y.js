(function () {
  class SettingsA11y extends HTMLElement {
    connectedCallback() {
      this.style.cssText = 'display:flex;flex-direction:column;flex:1;min-height:0';
      this._prefs = {};
      this._uiFontSize = 13;
      this._render();
    }

    _onSettingsInit(state) {
      if (!state) return;
      this._prefs = (state.accessibility) || {};
      const ap = state.appearance;
      if (ap && typeof ap.uiFontSize === 'number' && ap.uiFontSize > 0) this._uiFontSize = ap.uiFontSize;
      this._render();
    }

    _render() {
      const p = this._prefs;
      let fontSize = Math.round((this._uiFontSize / 13) * 100);
      fontSize = Math.max(75, Math.min(140, fontSize));
      const reducedMotion = p.reducedMotion ? true : false;
      const highContrast  = p.highContrast  ? true : false;

      this.innerHTML =
        '<div class="content-head"><span class="crumb"><b>Accessibility</b></span></div>'
        + '<div class="page page-narrow" style="overflow-y:auto">'
        + '<div class="page-title">Accessibility</div>'
        + '<div class="page-sub">Make the interface easier to read and use.</div>'

        + '<div class="card" style="margin-top:20px">'
        + '<div style="display:flex;align-items:baseline;justify-content:space-between;margin-bottom:12px">'
        + '<span class="card-title" style="font-size:13px">Text size</span>'
        + '<span class="mono" style="font-size:11.5px;color:var(--ue-code-text)" id="sa-font-val">' + fontSize + '%</span>'
        + '</div>'
        + '<div style="display:flex;align-items:center;gap:12px">'
        + '<span style="font-size:12px;color:var(--ue-text-lo)">A</span>'
        + '<div style="flex:1;height:5px;border-radius:3px;background:var(--ue-line);position:relative" id="sa-slider-track">'
        + '<div id="sa-slider-fill" style="position:absolute;left:0;top:0;bottom:0;width:' + (((fontSize - 75) / (140 - 75)) * 100) + '%;background:var(--ue-accent);border-radius:3px"></div>'
        + '<input type="range" id="sa-font-size" min="75" max="140" step="5" value="' + fontSize + '" style="position:absolute;inset:0;opacity:0;width:100%;cursor:pointer">'
        + '</div>'
        + '<span style="font-size:18px;color:var(--ue-text-mid)">A</span>'
        + '</div></div>'

        + '<div class="toggle-card" style="margin-top:14px">'
        + this._tRow('sa-reduced-motion', 'Reduced Motion',  'Disable animations and transitions.',                reducedMotion)
        + this._tRow('sa-high-contrast',  'High Contrast',   'Boost border and text contrast for readability.',    highContrast)
        + '</div>'

        + window.UECP.saveBar.html(this, 'sa-save-btn')
        + '</div>';

      const self   = this;
      const slider = this.querySelector('#sa-font-size');
      const valEl  = this.querySelector('#sa-font-val');
      const fill   = this.querySelector('#sa-slider-fill');

      slider.addEventListener('input', function () {
        valEl.textContent = slider.value + '%';
        const pct = ((slider.value - 75) / (140 - 75)) * 100;
        if (fill) fill.style.width = pct + '%';
      });

      this.querySelectorAll('.toggle').forEach(function (t) {
        t.addEventListener('click', function () {
          t.classList.toggle('on');
        });
      });

      this.querySelector('#sa-save-btn').addEventListener('click', function () { self._save(); });
      window.UECP.saveBar.autosave(this, function () { self._save(); });
    }

    _tRow(id, title, desc, checked) {
      return '<div class="toggle-row">'
        + '<div class="t"><div class="t-name">' + title + '</div><div class="t-desc">' + desc + '</div></div>'
        + '<div class="toggle' + (checked ? ' on' : '') + '" id="' + id + '"><span class="knob"></span></div>'
        + '</div>';
    }

    _save() {
      const fontSizePct   = parseInt(this.querySelector('#sa-font-size').value, 10) || 100;
      const reducedMotion = this.querySelector('#sa-reduced-motion').classList.contains('on');
      const highContrast  = this.querySelector('#sa-high-contrast').classList.contains('on');
      const uiFontSize = Math.round((13 * (fontSizePct / 100)) * 10) / 10;
      this._uiFontSize = uiFontSize;

      window.uecp.call('save_preferences', {
        appearance: { uiFontSize: uiFontSize },
        accessibility: { reducedMotion: reducedMotion, highContrast: highContrast },
      });

      const root = document.documentElement;
      root.style.setProperty('--ue-text-scale', uiFontSize / 13);
      root.classList.toggle('reduced-motion', reducedMotion);
      root.classList.toggle('high-contrast',  highContrast);
      window.UECP.saveBar.flash(this);
    }
  }

  customElements.define('settings-a11y', SettingsA11y);
})();
