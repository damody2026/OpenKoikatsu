(function () {
  if (!document.getElementById('uecp-confirm-bar-css')) {
    const s = document.createElement('style'); s.id = 'uecp-confirm-bar-css';
    s.textContent = `
uecp-confirm-bar{display:none;align-items:center;flex-wrap:wrap;gap:10px 12px;padding:10px 16px;background:var(--ue-panel);border:1px solid var(--ue-danger,#e06060);border-radius:var(--ue-r);margin:8px 0}
uecp-confirm-bar.visible{display:flex}
uecp-confirm-bar .confirm-icon{flex-shrink:0;color:var(--ue-danger,#e06060)}
uecp-confirm-bar .confirm-icon svg{stroke:currentColor}
uecp-confirm-bar .confirm-body{flex:1 1 240px;min-width:0}
uecp-confirm-bar .confirm-name{font-family:var(--ue-font-mono);font-size:12px;font-weight:var(--ue-fw-semi);color:var(--ue-text-hi);margin-bottom:2px}
uecp-confirm-bar .confirm-preview{font-family:var(--ue-font-mono);font-size:11px;color:var(--ue-text-mid);overflow:hidden;display:-webkit-box;-webkit-box-orient:vertical;-webkit-line-clamp:2;overflow-wrap:anywhere;white-space:pre-wrap}
uecp-confirm-bar .confirm-preview.open{display:block;-webkit-line-clamp:unset;max-height:45vh;overflow:auto;margin-top:4px;padding:8px 10px;background:var(--ue-bg,rgba(0,0,0,.25));border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);user-select:text}
uecp-confirm-bar .confirm-paths{font-family:var(--ue-font-mono);font-size:11px;color:var(--ue-text-hi);margin-top:4px;overflow-wrap:anywhere;user-select:text}
uecp-confirm-bar .confirm-paths .lbl{color:var(--ue-text-lo);margin-right:6px}
uecp-confirm-bar .btn-more{margin-top:3px;padding:0;background:none;border:none;color:var(--ue-accent);font-size:11px;cursor:pointer}
/* The buttons wrap onto their own line rather than off the edge: at the chat panel's default width
   (719 px) Proceed was past the right border and could only be reached with Tab. */
uecp-confirm-bar .confirm-actions{display:flex;flex-wrap:wrap;justify-content:flex-end;gap:7px;margin-left:auto}
uecp-confirm-bar .btn-proceed{padding:7px 14px;background:linear-gradient(150deg,var(--ue-accent),var(--ue-accent-deep));color:var(--ue-on-accent);border:none;border-radius:var(--ue-r-sm);font-size:12px;font-weight:var(--ue-fw-semi);cursor:pointer}
uecp-confirm-bar .btn-skip{padding:7px 14px;background:transparent;color:var(--ue-text-mid);border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);font-size:12px;cursor:pointer}
uecp-confirm-bar .btn-stop{padding:7px 14px;background:transparent;color:var(--ue-danger,#e06060);border:1px solid var(--ue-danger,#e06060);border-radius:var(--ue-r-sm);font-size:12px;cursor:pointer}
uecp-confirm-bar .btn-unattended{padding:7px 14px;background:var(--ue-danger,#e06060);color:#fff;border:none;border-radius:var(--ue-r-sm);font-size:12px;font-weight:var(--ue-fw-semi);cursor:pointer}`;
    document.head.appendChild(s);
  }

  function t(key) {
    return (window.uecp && typeof window.uecp.t === 'function') ? window.uecp.t(key) : key;
  }

  const PATH_RE = /(?:^|[\s'"(\[,=:])(\/(?!Script\/)[A-Za-z0-9_][A-Za-z0-9_-]*\/[^\s'",)\]}]+)/g;
  function assetPaths(text) {
    const seen = [];
    let m;
    PATH_RE.lastIndex = 0;
    while ((m = PATH_RE.exec(text)) !== null) {
      if (seen.indexOf(m[1]) === -1) seen.push(m[1]);
    }
    return seen;
  }
  const MAX_PATHS = 10;

  class UecpConfirmBar extends HTMLElement {
    connectedCallback() {
      const self = this;
      this._chatId = '';
      this._activeChatId = window.UECP.activeChatId || '';
      this._unsubRegistry = window.UECP.confirmRegistry.onChange(function () { self._reevaluate(); });
      this._unsubViewstate = window.uecp.on('chat.viewstate', function (d) {
        if (!d || !d.chatId) return;
        self._activeChatId = d.chatId;
        self._reevaluate();
      });
      this._reevaluate();
    }

    disconnectedCallback() {
      if (this._unsubRegistry) { this._unsubRegistry(); this._unsubRegistry = null; }
      if (this._unsubViewstate) { this._unsubViewstate(); this._unsubViewstate = null; }
    }

    _reevaluate() {
      const entry = window.UECP.confirmRegistry.get(this._activeChatId);
      if (!entry) { this._chatId = ''; this.classList.remove('visible'); this.innerHTML = ''; return; }
      this._chatId = this._activeChatId;
      this._show(entry.name, entry.preview || '', entry.kind || '');
    }

    _respond(action) {
      window.uecp.call('confirm_tool', { action: action, chatId: this._chatId });
      this.classList.remove('visible');
      this.innerHTML = '';
    }

    _show(name, preview, kind) {
      const warnIcon = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/><path d="M12 9v4"/><path d="M12 17h.01"/></svg>';
      const canWaive = kind === 'destructive';
      const esc = window.UECP.escapeHtml;

      const paths = assetPaths(preview);
      const pathsHtml = paths.length
        ? '<div class="confirm-paths"><span class="lbl">' + esc(t('Paths')) + '</span><span data-i18n-skip>'
          + paths.slice(0, MAX_PATHS).map(esc).join(', ') + '</span>'
          + (paths.length > MAX_PATHS ? ' +' + (paths.length - MAX_PATHS) : '') + '</div>'
        : '';
      const long = preview.split('\n').length > 2 || preview.length > 140;

      this.innerHTML =
        '<div class="confirm-icon">' + warnIcon + '</div>' +
        '<div class="confirm-body">' +
          '<div class="confirm-name">' + esc(name) + '</div>' +
          '<div class="confirm-preview" data-i18n-skip>' + esc(preview) + '</div>' +
          pathsHtml +
          (long ? '<button class="btn-more">' + esc(t('Show all')) + '</button>' : '') +
        '</div>' +
        '<div class="confirm-actions">' +
          (canWaive
            ? '<button class="btn-unattended" title="' + window.UECP.escapeHtml(t('Runs it now and stops asking before this tool. You can undo this in Settings, under AI Behaviour.')) + '">'
              + window.UECP.escapeHtml(t('Don\'t ask again')) + '</button>'
            : '') +
          '<button class="btn-stop">Stop All</button>' +
          '<button class="btn-skip">Skip</button>' +
          '<button class="btn-proceed">Proceed</button>' +
        '</div>';

      const self = this;
      this.querySelector('.btn-proceed').addEventListener('click', function () { self._respond('proceed'); });
      this.querySelector('.btn-skip').addEventListener('click', function () { self._respond('skip'); });
      this.querySelector('.btn-stop').addEventListener('click', function () { self._respond('stop'); });
      const more = this.querySelector('.btn-more');
      if (more) more.addEventListener('click', function () {
        const box = self.querySelector('.confirm-preview');
        const open = !box.classList.contains('open');
        box.classList.toggle('open', open);
        more.textContent = t(open ? 'Show less' : 'Show all');
      });
      const waive = this.querySelector('.btn-unattended');
      if (waive) waive.addEventListener('click', function () {
        window.uecp.call('confirm_tool', { action: 'always', chatId: self._chatId, tool: name });
        self.classList.remove('visible');
        self.innerHTML = '';
      });

      this.classList.add('visible');
    }
  }
  customElements.define('uecp-confirm-bar', UecpConfirmBar);
})();
