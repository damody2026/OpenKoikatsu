// Copyright 2026, BlueprintsLab, All rights reserved
using System;
using System.IO;
using System.Text.RegularExpressions;
using EpicGames.Core;
using UnrealBuildTool;

public class UECPSteamRuntime : ModuleRules
{
	[ConfigFile(ConfigHierarchyType.Engine, "UECPSteam")]
	bool bEnableSteamRuntime = false;

	public UECPSteamRuntime(ReadOnlyTargetRules Target) : base(Target)
	{
		if (Target.LinkType == TargetLinkType.Monolithic)
		{
			bUsePrecompiled = false;
		}

		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;
		bUseUnity = false;

		PublicDependencyModuleNames.AddRange(new string[]
		{
			"Core",
			"CoreUObject",
			"Engine",
			"DeveloperSettings",
			"OnlineSubsystem",
			"OnlineSubsystemUtils",
			"OnlineBase",
		});

		PrivateDependencyModuleNames.AddRange(new string[]
		{
			"Json",
			"JsonUtilities",
			"Projects",
			"Sockets",
			"NetCore",
		});

		bool bSteam = ResolveSteamSupport(Target);
		PublicDefinitions.Add("UECP_WITH_STEAM=" + (bSteam ? "1" : "0"));

		if (bSteam)
		{
			AddEngineThirdPartyPrivateStaticDependencies(Target, "Steamworks");

			PrivateDependencyModuleNames.Add("SteamShared");
			if (Target.Type == TargetType.Editor && Target.LinkType == TargetLinkType.Modular
				&& Target.Platform == UnrealTargetPlatform.Win64)
			{
				PublicDelayLoadDLLs.Add("UnrealEditor-SteamShared.dll");
			}
			PrivateDependencyModuleNames.Add("Voice");
		}

		PublicDefinitions.Add("UECP_STEAM_SDK_VER=" + DetectSteamSdkVersion(Target));
	}

	private bool ResolveSteamSupport(ReadOnlyTargetRules Target)
	{
		bool bPlatformSupported =
			(Target.Platform == UnrealTargetPlatform.Win64 && Target.Architecture != UnrealArch.Arm64)
			|| Target.Platform == UnrealTargetPlatform.Mac
			|| Target.Platform == UnrealTargetPlatform.Linux;

		if (!bPlatformSupported)
		{
			return false;
		}

		ConfigCache.ReadSettings(DirectoryReference.FromFile(Target.ProjectFile), Target.Platform, this);
		return bEnableSteamRuntime;
	}

	private static string DetectSteamSdkVersion(ReadOnlyTargetRules Target)
	{
		try
		{
			string Root = Path.Combine(Target.UEThirdPartySourceDirectory, "Steamworks");
			if (!Directory.Exists(Root))
			{
				return "0";
			}

			int Best = 0;
			foreach (string Dir in Directory.GetDirectories(Root))
			{
				Match M = Regex.Match(Path.GetFileName(Dir), @"^Steamv(\d+)$");
				if (M.Success && int.TryParse(M.Groups[1].Value, out int Ver) && Ver > Best)
				{
					Best = Ver;
				}
			}
			return Best.ToString();
		}
		catch (Exception)
		{
			return "0";
		}
	}
}
