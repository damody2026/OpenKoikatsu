// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "Async/UECPSteamAsyncAction.h"
#include "Interfaces/OnlineSessionInterface.h"
#include "UECPSteamSessionTypes.h"
#include "UECPSteamSessionAsync.generated.h"

UCLASS(Abstract)
class UECPSTEAMRUNTIME_API UUECPSteamOSSAsyncAction : public UUECPSteamAsyncAction
{
	GENERATED_BODY()

protected:
	virtual bool IsAvailable(FUECPSteamError& OutError) const override;
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_OneParam(FUECPSteamSessionResultSignature, FUECPSteamError, Error);

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamCreateSession : public UUECPSteamOSSAsyncAction
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Session",
		meta = (BlueprintInternalUseOnly = "true", WorldContext = "WorldContextObject",
		        DisplayName = "Create Steam Session", AdvancedDisplay = "SessionName"))
	static UUECPSteamCreateSession* CreateSteamSession(
		UObject* WorldContextObject,
		FUECPSteamSessionSettings Settings,
		FName SessionName = NAME_None);

	UPROPERTY(BlueprintAssignable)
	FUECPSteamSessionResultSignature OnSuccess;

	UPROPERTY(BlueprintAssignable)
	FUECPSteamSessionResultSignature OnFailure;

protected:
	virtual bool Start(FUECPSteamError& OutError) override;
	virtual void BroadcastResult(bool bSucceeded, const FUECPSteamError& Error) override;
	virtual void OnCleanup() override;

private:
	void HandleCreateComplete(FName InSessionName, bool bWasSuccessful);

	FUECPSteamSessionSettings Settings;
	FName SessionName = NAME_GameSession;
	FDelegateHandle CompleteHandle;
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FUECPSteamFindSessionsSignature,
	const TArray<FUECPSteamSessionSearchResult>&, Results, FUECPSteamError, Error);

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamFindSessions : public UUECPSteamOSSAsyncAction
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Session",
		meta = (BlueprintInternalUseOnly = "true", WorldContext = "WorldContextObject",
		        DisplayName = "Find Steam Sessions"))
	static UUECPSteamFindSessions* FindSteamSessions(
		UObject* WorldContextObject,
		FUECPSteamSessionSearchSettings SearchSettings);

	UPROPERTY(BlueprintAssignable)
	FUECPSteamFindSessionsSignature OnSuccess;

	UPROPERTY(BlueprintAssignable)
	FUECPSteamFindSessionsSignature OnFailure;

protected:
	virtual bool Start(FUECPSteamError& OutError) override;
	virtual void BroadcastResult(bool bSucceeded, const FUECPSteamError& Error) override;
	virtual void OnCleanup() override;

private:
	void HandleFindComplete(bool bWasSuccessful);

	FUECPSteamSessionSearchSettings SearchSettings;
	TSharedPtr<FOnlineSessionSearch> Search;
	TArray<FUECPSteamSessionSearchResult> Results;
	FDelegateHandle CompleteHandle;
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FUECPSteamJoinSessionSignature,
	const FString&, ConnectString, FUECPSteamError, Error);

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamJoinSession : public UUECPSteamOSSAsyncAction
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Session",
		meta = (BlueprintInternalUseOnly = "true", WorldContext = "WorldContextObject",
		        DisplayName = "Join Steam Session", AdvancedDisplay = "SessionName"))
	static UUECPSteamJoinSession* JoinSteamSession(
		UObject* WorldContextObject,
		FUECPSteamSessionSearchResult SearchResult,
		FName SessionName = NAME_None);

	UPROPERTY(BlueprintAssignable)
	FUECPSteamJoinSessionSignature OnSuccess;

	UPROPERTY(BlueprintAssignable)
	FUECPSteamJoinSessionSignature OnFailure;

protected:
	virtual bool Start(FUECPSteamError& OutError) override;
	virtual void BroadcastResult(bool bSucceeded, const FUECPSteamError& Error) override;
	virtual void OnCleanup() override;

private:
	void HandleJoinComplete(FName InSessionName, EOnJoinSessionCompleteResult::Type Result);

	FUECPSteamSessionSearchResult SearchResult;
	FName SessionName = NAME_GameSession;
	FString ConnectString;
	FDelegateHandle CompleteHandle;
};

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamDestroySession : public UUECPSteamOSSAsyncAction
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Session",
		meta = (BlueprintInternalUseOnly = "true", WorldContext = "WorldContextObject",
		        DisplayName = "Destroy Steam Session", AdvancedDisplay = "SessionName"))
	static UUECPSteamDestroySession* DestroySteamSession(
		UObject* WorldContextObject,
		FName SessionName = NAME_None);

	UPROPERTY(BlueprintAssignable)
	FUECPSteamSessionResultSignature OnSuccess;

	UPROPERTY(BlueprintAssignable)
	FUECPSteamSessionResultSignature OnFailure;

protected:
	virtual bool Start(FUECPSteamError& OutError) override;
	virtual void BroadcastResult(bool bSucceeded, const FUECPSteamError& Error) override;
	virtual void OnCleanup() override;

private:
	void HandleDestroyComplete(FName InSessionName, bool bWasSuccessful);

	FName SessionName = NAME_GameSession;
	FDelegateHandle CompleteHandle;
};

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamStartSession : public UUECPSteamOSSAsyncAction
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Session",
		meta = (BlueprintInternalUseOnly = "true", WorldContext = "WorldContextObject",
		        DisplayName = "Start Steam Session", AdvancedDisplay = "SessionName"))
	static UUECPSteamStartSession* StartSteamSession(
		UObject* WorldContextObject,
		FName SessionName = NAME_None);

	UPROPERTY(BlueprintAssignable)
	FUECPSteamSessionResultSignature OnSuccess;

	UPROPERTY(BlueprintAssignable)
	FUECPSteamSessionResultSignature OnFailure;

protected:
	virtual bool Start(FUECPSteamError& OutError) override;
	virtual void BroadcastResult(bool bSucceeded, const FUECPSteamError& Error) override;
	virtual void OnCleanup() override;

private:
	void HandleStartComplete(FName InSessionName, bool bWasSuccessful);

	FName SessionName = NAME_GameSession;
	FDelegateHandle CompleteHandle;
};

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamEndSession : public UUECPSteamOSSAsyncAction
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Session",
		meta = (BlueprintInternalUseOnly = "true", WorldContext = "WorldContextObject",
		        DisplayName = "End Steam Session", AdvancedDisplay = "SessionName"))
	static UUECPSteamEndSession* EndSteamSession(
		UObject* WorldContextObject,
		FName SessionName = NAME_None);

	UPROPERTY(BlueprintAssignable)
	FUECPSteamSessionResultSignature OnSuccess;

	UPROPERTY(BlueprintAssignable)
	FUECPSteamSessionResultSignature OnFailure;

protected:
	virtual bool Start(FUECPSteamError& OutError) override;
	virtual void BroadcastResult(bool bSucceeded, const FUECPSteamError& Error) override;
	virtual void OnCleanup() override;

private:
	void HandleEndComplete(FName InSessionName, bool bWasSuccessful);

	FName SessionName = NAME_GameSession;
	FDelegateHandle CompleteHandle;
};

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamUpdateSession : public UUECPSteamOSSAsyncAction
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Session",
		meta = (BlueprintInternalUseOnly = "true", WorldContext = "WorldContextObject",
		        DisplayName = "Update Steam Session", AdvancedDisplay = "SessionName,bRefreshOnlineData"))
	static UUECPSteamUpdateSession* UpdateSteamSession(
		UObject* WorldContextObject,
		FUECPSteamSessionSettings Settings,
		FName SessionName = NAME_None,
		bool bRefreshOnlineData = true);

	UPROPERTY(BlueprintAssignable)
	FUECPSteamSessionResultSignature OnSuccess;

	UPROPERTY(BlueprintAssignable)
	FUECPSteamSessionResultSignature OnFailure;

protected:
	virtual bool Start(FUECPSteamError& OutError) override;
	virtual void BroadcastResult(bool bSucceeded, const FUECPSteamError& Error) override;
	virtual void OnCleanup() override;

private:
	void HandleUpdateComplete(FName InSessionName, bool bWasSuccessful);

	FUECPSteamSessionSettings Settings;
	FName SessionName = NAME_GameSession;
	bool bRefreshOnlineData = true;
	FDelegateHandle CompleteHandle;
};

DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FUECPSteamFindFriendSessionSignature,
	const TArray<FUECPSteamSessionSearchResult>&, Results, FUECPSteamError, Error);

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamFindFriendSession : public UUECPSteamOSSAsyncAction
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Session",
		meta = (BlueprintInternalUseOnly = "true", WorldContext = "WorldContextObject",
		        DisplayName = "Find Steam Friend Session"))
	static UUECPSteamFindFriendSession* FindSteamFriendSession(
		UObject* WorldContextObject,
		FUECPSteamID FriendSteamId);

	UPROPERTY(BlueprintAssignable)
	FUECPSteamFindFriendSessionSignature OnSuccess;

	UPROPERTY(BlueprintAssignable)
	FUECPSteamFindFriendSessionSignature OnFailure;

protected:
	virtual bool Start(FUECPSteamError& OutError) override;
	virtual void BroadcastResult(bool bSucceeded, const FUECPSteamError& Error) override;
	virtual void OnCleanup() override;

private:
	void HandleFindFriendComplete(int32 LocalUserNum, bool bWasSuccessful,
		const TArray<FOnlineSessionSearchResult>& FriendSearchResults);

	FUECPSteamID FriendSteamId;
	TArray<FUECPSteamSessionSearchResult> Results;
	FDelegateHandle CompleteHandle;
};
