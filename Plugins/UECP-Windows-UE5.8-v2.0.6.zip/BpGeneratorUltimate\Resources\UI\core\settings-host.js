(function () {
  const EVENTS = [
    'settings.cli',
    'settings.extensions',
    'settings.extensions_pending',
    'settings.extension_toggle_result',
    'settings.extensions_apply_result',
    'settings.mcp_servers',
    'settings.mcp_add_result',
    'settings.mcp_status',
    'settings.mcp_test_result',
    'settings.mcp_oauth_result',
    'settings.acp_catalog',
    'settings.acp_progress',
    'settings.acp_config',
    'settings.mesh_providers',
    'settings.info',
    'settings.update_status',
    'settings.appearance',
    'settings.install_result',
    'settings.test_slot_connection_result',
  ];

  function methodFor(event) {
    const stem = event.replace('settings.', '').replace(/_([a-z])/g, function (_, c) { return c.toUpperCase(); });
    return '_on' + stem.charAt(0).toUpperCase() + stem.slice(1);
  }

  function create(getPage) {
    const cache = {};
    let state = null;

    const relay = function (event, data) {
      cache[event] = data;
      const pg = getPage();
      if (!pg) return;
      const m = methodFor(event);
      if (typeof pg[m] === 'function') pg[m](data);
    };

    const subs = [window.uecp.on('settings.init', function (data) {
      state = data;
      const pg = getPage();
      if (pg && typeof pg._onSettingsInit === 'function') pg._onSettingsInit(state);
      replayInto(pg);
    })];

    EVENTS.forEach(function (event) {
      subs.push(window.uecp.on(event, function (data) { relay(event, data); }));
    });

    function replayInto(pg) {
      if (!pg) return;
      Object.keys(cache).forEach(function (event) {
        const m = methodFor(event);
        if (typeof pg[m] === 'function') pg[m](cache[event]);
      });
    }

    return {
      prime: function (pg) {
        if (!pg) return;
        if (state && typeof pg._onSettingsInit === 'function') pg._onSettingsInit(state);
        replayInto(pg);
      },
      dispose: function () {
        subs.forEach(function (u) { try { u(); } catch (e) {} });
        subs.length = 0;
      },
    };
  }

  window.UECP = window.UECP || {};
  window.UECP.settingsHost = { create: create, EVENTS: EVENTS, methodFor: methodFor };
})();
