(function () {
  if (!document.getElementById('uecp-banner-css')) {
    const s = document.createElement('style'); s.id = 'uecp-banner-css';
    s.textContent = `
uecp-banner{display:none;flex-shrink:0;align-items:center;gap:8px;padding:7px 16px;background:var(--ue-accent-soft);border-bottom:1px solid var(--ue-accent);font-family:var(--ue-font-mono);font-size:var(--ue-fs-meta);line-height:1.4;color:var(--ue-accent-bright)}
uecp-banner.visible{display:flex}
uecp-banner .banner-text{flex:1;min-width:0}
uecp-banner .banner-text strong{font-weight:600;color:var(--ue-accent-bright)}
uecp-banner .banner-text em{font-style:italic}
uecp-banner .banner-text code{font-family:var(--ue-font-mono);background:var(--ue-elev);padding:0 4px;border-radius:3px}
uecp-banner .banner-text a{color:var(--ue-accent-bright);text-decoration:underline;cursor:pointer}
uecp-banner .banner-text .c-accent{color:var(--ue-accent-bright)}
uecp-banner .banner-text .c-warn{color:var(--ue-warn)}
uecp-banner .banner-text .c-danger{color:var(--ue-danger)}
uecp-banner .banner-text .c-muted{color:var(--ue-text-lo)}
uecp-banner .banner-x{flex-shrink:0;background:none;border:none;cursor:pointer;color:var(--ue-accent-bright);font-size:15px;line-height:1;padding:0 2px;opacity:.7}
uecp-banner .banner-x:hover{opacity:1}`;
    document.head.appendChild(s);
  }

  function escapeHtml(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  }

  var COLOURS = { accent: 1, warn: 1, danger: 1, muted: 1 };
  var COLOUR_RE = new RegExp('\\{(' + Object.keys(COLOURS).join('|') + ')\\}([\\s\\S]*?)\\{\\/\\1\\}', 'g');

  function inlineMarkdown(raw) {
    var s = escapeHtml(raw);
    s = s.replace(/`([^`]+)`/g, '<code>$1</code>');
    s = s.replace(/\*\*([^*]+?)\*\*/g, '<strong>$1</strong>');
    s = s.replace(/\*([^*]+?)\*/g, '<em>$1</em>');
    s = s.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, function (m, txt, url) {
      return '<a href="#" data-href="' + encodeURI(url) + '">' + txt + '</a>';
    });
    s = s.replace(COLOUR_RE, function (m, name, text) {
      return '<span class="c-' + name + '">' + text + '</span>';
    });
    return s;
  }

  class Banner extends HTMLElement {
    connectedCallback() {
      this.innerHTML = '<span class="banner-text"></span>' +
        '<button class="banner-x" title="Dismiss" aria-label="Dismiss">✕</button>';
      var self = this;
      this._dismissedText = null;
      this._lastText = null;
      this.querySelector('.banner-x').addEventListener('click', function () { self._dismiss(); });
      this.addEventListener('click', function (e) {
        var a = (e.target && e.target.closest) ? e.target.closest('a[data-href]') : null;
        if (!a) return;
        if (e.preventDefault) e.preventDefault();
        var url = a.getAttribute('data-href');
        if (url && window.uecp && window.uecp.call) window.uecp.call('open_external_url', { url: url });
      });
      this._uCfg = window.uecp.on('config.ui', function (map) { self._apply(map); });
      if (window._uiConfig) this._apply(window._uiConfig);
    }
    _inline(raw) { return inlineMarkdown(raw); }
    _muted(map) {
      if (map && map.hide_announcements === true) return true;
      try { if (localStorage.getItem('hide_announcements') === '1') return true; } catch (e) {}
      return false;
    }
    _apply(map) {
      if (!map) return;
      var text = map.header_notice_v2;
      if (!text || this._muted(map) || this._dismissedText === text) {
        this.classList.remove('visible');
        return;
      }
      this._lastText = text;
      this.querySelector('.banner-text').innerHTML = inlineMarkdown(text);
      this.classList.add('visible');
    }
    _dismiss() {
      this._dismissedText = this._lastText || '1';
      this.classList.remove('visible');
    }
    disconnectedCallback() { if (this._uCfg) this._uCfg(); }
  }
  customElements.define('uecp-banner', Banner);
})();
