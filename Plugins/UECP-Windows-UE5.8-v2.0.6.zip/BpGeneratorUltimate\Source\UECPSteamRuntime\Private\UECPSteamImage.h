// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"

class UTexture2D;

namespace UECPSteam
{
	UTexture2D* CreateTextureFromImageHandle(int32 ImageHandle);

	void FlushImageCache();
}
