(function () {
  if (typeof document === 'undefined') return;

  if (!document.getElementById('uecp-tae-css')) {
    const s = document.createElement('style'); s.id = 'uecp-tae-css';
    s.textContent = `
.uecp-tae{border:1px solid var(--ue-line-soft);border-radius:var(--ue-r);padding:8px 10px;max-height:220px;display:flex;flex-direction:column;min-height:0}
.uecp-tae-bar{display:flex;gap:6px;margin-bottom:6px}
.uecp-tae-bar input{flex:1;font-size:11.5px;background:var(--ue-elev);border:1px solid var(--ue-line);border-radius:var(--ue-r-sm);padding:4px 7px;color:var(--ue-text-hi)}
.uecp-tae-bar button{font-size:10.5px;border:1px solid var(--ue-line);background:var(--ue-elev);color:var(--ue-text-mid);border-radius:var(--ue-r-sm);padding:3px 8px;cursor:pointer}
.uecp-tae-list{overflow-y:auto;flex:1}
.uecp-tae-group{font-size:10px;text-transform:uppercase;letter-spacing:.4px;color:var(--ue-text-lo);margin:6px 0 2px}
.uecp-tae-item{display:flex;align-items:center;gap:6px;font-size:11.5px;color:var(--ue-text-mid);padding:2px 0}
.uecp-tae-item code{font-family:var(--ue-font-mono);font-size:11px;color:var(--ue-text-hi)}`;
    document.head.appendChild(s);
  }

  let _catalog = null;
  let _fetching = false;
  const _waiters = [];

  function fetchCatalog(cb) {
    if (_catalog) { cb(_catalog); return; }
    _waiters.push(cb);
    if (_fetching) return;
    _fetching = true;
    window.uecp.on('tools.catalog', function (d) {
      _catalog = (d && d.tools) || [];
      _fetching = false;
      _waiters.splice(0).forEach(function (w) { w(_catalog); });
    });
    window.uecp.call('list_tool_catalog', {});
  }

  function prefetch() { fetchCatalog(function () {}); }

  function mount(containerEl, selected, onChange) {
    if (!containerEl) return;
    const esc = window.UECP.escapeHtml;
    let selectedSet = new Set(selected || []);

    containerEl.innerHTML = '<div class="uecp-tae">'
      + '<div class="uecp-tae-bar"><input type="text" placeholder="Filter tools…" id="tae-filter">'
      + '<button id="tae-all">All</button><button id="tae-none">None</button></div>'
      + '<div class="uecp-tae-list" id="tae-list"><div style="color:var(--ue-text-lo);font-size:11px">Loading…</div></div>'
      + '</div>';

    const list = containerEl.querySelector('#tae-list');
    const filterInput = containerEl.querySelector('#tae-filter');

    function renderList(catalog, filter) {
      const f = (filter || '').toLowerCase();
      const byUmbrella = {};
      catalog.forEach(function (t) {
        if (f && t.action.toLowerCase().indexOf(f) === -1 && (t.umbrella || '').toLowerCase().indexOf(f) === -1) return;
        const key = t.umbrella || '(standalone)';
        (byUmbrella[key] = byUmbrella[key] || []).push(t);
      });
      const groups = Object.keys(byUmbrella).sort();
      if (!groups.length) { list.innerHTML = '<div style="color:var(--ue-text-lo);font-size:11px">No matching tools.</div>'; return; }
      let html = '';
      groups.forEach(function (g) {
        html += '<div class="uecp-tae-group">' + esc(g) + '</div>';
        byUmbrella[g].forEach(function (t) {
          const checked = selectedSet.has(t.action) ? ' checked' : '';
          html += '<label class="uecp-tae-item"><input type="checkbox" value="' + esc(t.action) + '"' + checked + '><code>' + esc(t.action) + '</code></label>';
        });
      });
      list.innerHTML = html;
      list.querySelectorAll('input[type=checkbox]').forEach(function (cb) {
        cb.addEventListener('change', function () {
          if (cb.checked) selectedSet.add(cb.value); else selectedSet.delete(cb.value);
          if (typeof onChange === 'function') onChange(Array.from(selectedSet));
        });
      });
    }

    fetchCatalog(function (catalog) {
      renderList(catalog, '');
      filterInput.addEventListener('input', function () { renderList(catalog, filterInput.value); });
      containerEl.querySelector('#tae-all').addEventListener('click', function () {
        catalog.forEach(function (t) { selectedSet.add(t.action); });
        renderList(catalog, filterInput.value);
        if (typeof onChange === 'function') onChange(Array.from(selectedSet));
      });
      containerEl.querySelector('#tae-none').addEventListener('click', function () {
        selectedSet.clear();
        renderList(catalog, filterInput.value);
        if (typeof onChange === 'function') onChange(Array.from(selectedSet));
      });
    });
  }

  window.UECP = window.UECP || {};
  window.UECP.toolAllowlistEditor = { mount: mount, prefetch: prefetch };
})();
