(function () {
  'use strict';

  if (typeof document === 'undefined') return;

  if (!document.getElementById('uecp-crew-cp-detail-css')) {
    var st = document.createElement('style'); st.id = 'uecp-crew-cp-detail-css';
    st.textContent =
      '#uecp-crew-cp-detail{position:fixed;z-index:9500;display:none;width:360px;max-height:70vh;overflow-y:auto;' +
      'background:var(--ue-panel);color:var(--ue-text-hi);border:1px solid var(--ue-line);border-radius:var(--ue-r);' +
      'padding:14px 16px;font-family:var(--ue-font-sans);font-size:12.5px;line-height:1.5;' +
      'box-shadow:var(--ue-shadow-pop,0 8px 24px rgba(0,0,0,.35))}' +
      '#uecp-crew-cp-detail.open{display:block}' +
      '#uecp-crew-cp-detail h4{margin:0 0 6px;font-size:13px;color:var(--ue-text-hi)}' +
      '#uecp-crew-cp-detail .cpd-sec{margin-top:10px}' +
      '#uecp-crew-cp-detail .cpd-lbl{font-size:10.5px;text-transform:uppercase;letter-spacing:.4px;color:var(--ue-text-lo);margin-bottom:3px}' +
      '#uecp-crew-cp-detail .cpd-body{color:var(--ue-text-mid);white-space:pre-wrap}' +
      '#uecp-crew-cp-detail .cpd-run{display:flex;justify-content:space-between;align-items:center;gap:8px;padding:5px 0;border-top:1px solid var(--ue-line-soft)}' +
      '#uecp-crew-cp-detail .cpd-run a{color:var(--ue-accent-bright);cursor:pointer;text-decoration:none;font-size:11.5px}' +
      '#uecp-crew-cp-detail .cpd-run a:hover{text-decoration:underline}' +
      '#uecp-crew-cp-detail .cpd-close{position:absolute;top:8px;right:10px;cursor:pointer;color:var(--ue-text-lo);font-size:14px}';
    document.head.appendChild(st);
  }

  var _el = null;
  var _anchorEl = null;

  function ensureEl() {
    if (_el) return _el;
    _el = document.createElement('div');
    _el.id = 'uecp-crew-cp-detail';
    document.body.appendChild(_el);
    return _el;
  }

  function esc(s) { return window.UECP && window.UECP.escapeHtml ? window.UECP.escapeHtml(s) : String(s == null ? '' : s); }

  function render(checkpoint, onOpenChat) {
    var cp = checkpoint || {};
    var reasons = (cp.attemptReasons || []).map(function (r) {
      return '<div class="cpd-body">' + esc(r) + '</div>';
    }).join('');
    var runs = (cp.linkedRuns || []).map(function (r) {
      return '<div class="cpd-run"><span>' + esc(r.phase) + ' (' + esc(r.roleId) + ') — attempt ' + esc(r.attempt) + ' — ' + esc(r.status) + '</span>'
        + (r.chatId ? '<a data-chat-id="' + esc(r.chatId) + '">Open chat</a>' : '') + '</div>';
    }).join('');

    var html = '<span class="cpd-close" id="cpd-close">✕</span>'
      + '<h4>' + esc(cp.description || cp.id || '') + '</h4>'
      + '<div class="cpd-sec"><div class="cpd-lbl">Success criteria</div><div class="cpd-body">' + esc(cp.successCriteria || '(none)') + '</div></div>';

    if (reasons) {
      html += '<div class="cpd-sec"><div class="cpd-lbl">Attempt history</div>' + reasons + '</div>';
    }
    if (runs) {
      html += '<div class="cpd-sec"><div class="cpd-lbl">Linked runs</div>' + runs + '</div>';
    }
    if ((cp.toolAllowlistOverride || []).length) {
      html += '<div class="cpd-sec"><div class="cpd-lbl">Tool override</div><div class="cpd-body">' + esc(cp.toolAllowlistOverride.join(', ')) + '</div></div>';
    }

    var el = ensureEl();
    el.innerHTML = html;

    var closeBtn = el.querySelector('#cpd-close');
    if (closeBtn) closeBtn.addEventListener('click', close);
    el.querySelectorAll('a[data-chat-id]').forEach(function (a) {
      a.addEventListener('click', function () {
        if (typeof onOpenChat === 'function') onOpenChat(a.getAttribute('data-chat-id'));
        close();
      });
    });
  }

  function open(anchorEl, checkpoint, onOpenChat) {
    if (!anchorEl) return;
    _anchorEl = anchorEl;
    render(checkpoint, onOpenChat);
    var el = ensureEl();
    el.classList.add('open');

    var a = anchorEl.getBoundingClientRect();
    var rect = el.getBoundingClientRect();
    var vw = window.innerWidth, vh = window.innerHeight;
    var margin = 8;

    var left = a.right + margin;
    if (left + rect.width + margin > vw) left = a.left - rect.width - margin;
    if (left < margin) left = margin;

    var top = a.top;
    if (top + rect.height + margin > vh) top = Math.max(margin, vh - rect.height - margin);

    el.style.left = left + 'px';
    el.style.top = top + 'px';
  }

  function close() {
    if (_el) _el.classList.remove('open');
  }

  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') close(); });
  document.addEventListener('click', function (e) {
    if (!_el || !_el.classList.contains('open')) return;
    if (_el.contains(e.target)) return;
    if (e.target === _anchorEl || (_anchorEl && _anchorEl.contains && _anchorEl.contains(e.target))) return;
    close();
  });
  window.addEventListener('scroll', close, true);
  window.addEventListener('resize', close);

  window.UECP = window.UECP || {};
  window.UECP.crewCheckpointDetail = { open: open, close: close };
})();
