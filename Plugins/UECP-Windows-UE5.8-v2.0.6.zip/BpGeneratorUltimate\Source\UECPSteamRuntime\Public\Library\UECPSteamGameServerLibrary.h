// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "UECPSteamTypes.h"
#include "UECPSteamGameServerLibrary.generated.h"

UENUM(BlueprintType)
enum class EUECPSteamAuthResult : uint8
{
	OK                  UMETA(DisplayName = "OK"),
	InvalidTicket       UMETA(DisplayName = "Invalid Ticket"),
	DuplicateRequest    UMETA(DisplayName = "Duplicate Request"),
	ExpiredTicket       UMETA(DisplayName = "Expired Ticket"),
	VACBanned           UMETA(DisplayName = "VAC Banned"),
	PublisherBanned     UMETA(DisplayName = "Publisher Banned"),
	NoLicense           UMETA(DisplayName = "No License"),
	LoggedInElsewhere   UMETA(DisplayName = "Logged In Elsewhere"),
	Unavailable         UMETA(DisplayName = "Unavailable"),
};

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamGameServerLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintPure, Category = "UECP|Steam|GameServer")
	static bool IsGameServerAvailable();

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|GameServer")
	static bool LogOnAnonymous();

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|GameServer")
	static bool LogOn(const FString& Token);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|GameServer")
	static void LogOff();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|GameServer")
	static bool IsLoggedOn();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|GameServer")
	static bool IsSecure();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|GameServer")
	static FUECPSteamID GetGameServerSteamID();

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|GameServer",
		meta = (AdvancedDisplay = "BotCount,bPasswordProtected,GameTags"))
	static void SetServerDetails(const FString& ServerName, const FString& MapName,
		int32 MaxPlayers, int32 BotCount = 0, bool bPasswordProtected = false,
		const FString& GameTags = TEXT(""));

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|GameServer")
	static void SetAdvertiseServerActive(bool bActive);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|GameServer")
	static EUECPSteamAuthResult BeginAuthSession(const FString& Ticket, FUECPSteamID ClientId);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|GameServer")
	static void EndAuthSession(FUECPSteamID ClientId);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|GameServer")
	static bool UserHasLicenseForApp(FUECPSteamID ClientId);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|GameServer")
	static FString GetSteamAuthTicket();

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|GameServer")
	static void CancelSteamAuthTicket();

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|GameServer")
	static bool RequestUserStats(FUECPSteamID PlayerSteamId);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|GameServer")
	static int32 GetUserStatInt(FUECPSteamID PlayerSteamId, const FString& StatApiName);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|GameServer")
	static float GetUserStatFloat(FUECPSteamID PlayerSteamId, const FString& StatApiName);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|GameServer")
	static bool SetUserStatInt(FUECPSteamID PlayerSteamId, const FString& StatApiName, int32 Value);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|GameServer")
	static bool SetUserStatFloat(FUECPSteamID PlayerSteamId, const FString& StatApiName, float Value);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|GameServer")
	static bool SetUserAchievement(FUECPSteamID PlayerSteamId, const FString& AchievementApiName);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|GameServer")
	static bool StoreUserStats(FUECPSteamID PlayerSteamId);
};
