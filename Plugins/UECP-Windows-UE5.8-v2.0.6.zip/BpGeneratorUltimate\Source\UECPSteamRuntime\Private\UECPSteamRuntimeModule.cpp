// Copyright 2026, BlueprintsLab, All rights reserved
#include "UECPSteamRuntimeModule.h"
#include "UECPSteamAPI.h"
#include "UECPSteamP2PInternal.h"

DEFINE_LOG_CATEGORY(LogUECPSteam);

#define LOCTEXT_NAMESPACE "FUECPSteamRuntimeModule"

void FUECPSteamRuntimeModule::StartupModule()
{
	UE_LOG(LogUECPSteam, Log, TEXT("UECPSteamRuntime loaded (Steam support compiled %s)."),
		IsCompiledWithSteam() ? TEXT("IN") : TEXT("OUT"));

	PumpHandle = FTSTicker::GetCoreTicker().AddTicker(
		FTickerDelegate::CreateRaw(this, &FUECPSteamRuntimeModule::Tick));
}

void FUECPSteamRuntimeModule::ShutdownModule()
{
	if (PumpHandle.IsValid())
	{
		FTSTicker::GetCoreTicker().RemoveTicker(PumpHandle);
		PumpHandle.Reset();
	}

	UECPSteamP2P::Reset();

	UECPSteam::ReleaseClient();
}

bool FUECPSteamRuntimeModule::Tick(float )
{
	UECPSteam::PumpCallbacks();

	UECPSteamP2P::PumpMessages();
	return true;
}

bool FUECPSteamRuntimeModule::IsCompiledWithSteam()
{
#if UECP_WITH_STEAM
	return true;
#else
	return false;
#endif
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FUECPSteamRuntimeModule, UECPSteamRuntime)
