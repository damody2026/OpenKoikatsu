// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "UECPSteamTypes.h"
#include "UECPSteamVoiceLibrary.generated.h"

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamVoiceLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Voice")
	static bool StartVoiceRecording();

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Voice")
	static bool StopVoiceRecording();

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Voice")
	static bool GetCompressedVoice(TArray<uint8>& OutCompressedData);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Voice", meta = (AdvancedDisplay = "SampleRate"))
	static bool DecompressVoice(const TArray<uint8>& CompressedData, TArray<uint8>& OutPcmData,
		int32 SampleRate = 0);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Voice")
	static int32 GetVoiceOptimalSampleRate();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Voice")
	static bool IsVoiceRecordingAvailable();
};
