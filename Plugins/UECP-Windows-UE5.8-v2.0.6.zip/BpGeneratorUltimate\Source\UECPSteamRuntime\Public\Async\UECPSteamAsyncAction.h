// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "HAL/ThreadSafeBool.h"
#include "Kismet/BlueprintAsyncActionBase.h"
#include "UECPSteamTypes.h"
#include "UECPSteamAsyncAction.generated.h"

class FUECPSteamCallResultHolder
{
public:
	virtual ~FUECPSteamCallResultHolder() = default;
};

UCLASS(Abstract)
class UECPSTEAMRUNTIME_API UUECPSteamAsyncAction : public UBlueprintAsyncActionBase
{
	GENERATED_BODY()

public:
	virtual void Activate() override;
	virtual void SetReadyToDestroy() override;

protected:
	virtual bool Start(FUECPSteamError& OutError)
		PURE_VIRTUAL(UUECPSteamAsyncAction::Start, return false;);

	virtual bool IsAvailable(FUECPSteamError& OutError) const;

	virtual void BroadcastResult(bool bSucceeded, const FUECPSteamError& Error)
		PURE_VIRTUAL(UUECPSteamAsyncAction::BroadcastResult, );

	void CompleteSuccess();

	void CompleteFailure(const FUECPSteamError& Error);

	void CompleteFromResult(int32 RawResult, const FString& Context);

	virtual void OnCleanup() {}

	UPROPERTY()
	TWeakObjectPtr<UObject> ContextObject;

	TUniquePtr<FUECPSteamCallResultHolder> CallResultHolder;

private:
	FThreadSafeBool bCompleted = false;

	void Complete(bool bSucceeded, const FUECPSteamError& Error);
};
