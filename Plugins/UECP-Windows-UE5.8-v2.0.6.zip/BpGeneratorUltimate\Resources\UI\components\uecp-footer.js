(function () {
  if (!document.getElementById('uecp-footer-css')) {
    const s = document.createElement('style'); s.id = 'uecp-footer-css';
    s.textContent = `
uecp-footer{height:var(--ue-footer-h);flex-shrink:0;background:var(--ue-rail);border-top:1px solid var(--ue-line-soft);display:flex;align-items:center;padding:0 16px;font-family:var(--ue-font-mono);font-size:var(--ue-fs-sm);color:var(--ue-text-lo)}
uecp-footer .msg{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
/* Carries .foot-btn as well now, so it inherits the icon/font/padding treatment
   above and only adds what is specific to it. It sits in the same row after a
   separator; styling it apart made it read as a label rather than the third
   group. */
uecp-footer .mem-open{position:relative}
uecp-footer .mem-open svg{stroke:currentColor}
uecp-footer .mem-badge{display:none;min-width:14px;height:14px;line-height:14px;text-align:center;font-size:9.5px;border-radius:8px;background:var(--ue-accent);color:var(--ue-on-accent);padding:0 3px}
uecp-footer .mem-badge.show{display:inline-block}
/* These are ACTIONS, and they have to look like it.
   Three things were making them read as a status line the editor prints at you
   rather than a row of controls, and spacing was not one of them:
     - the mono face, which signals machine output everywhere else in this UI,
     - no icon, so each item was a bare word among other bare words,
     - --ue-text-lo inherited from the bar, which is placeholder grey.
   The icon does most of the work; the font and the contrast do the rest. The
   separator can then go back to being narrow, because grouping no longer has to
   be carried by whitespace alone. */
uecp-footer .foot-btn{display:inline-flex;align-items:center;gap:6px;background:none;border:none;color:var(--ue-text-mid);cursor:pointer;font-family:var(--ue-font);font-size:var(--ue-fs-sm);font-weight:var(--ue-fw-semi);padding:4px 8px;border-radius:6px}
uecp-footer .foot-btn svg{stroke:currentColor;opacity:.8;flex-shrink:0}
/* A background on hover, not just a colour shift: these are buttons sitting in a
   row with no borders, and until one lights up there is nothing to show where
   one ends and the next begins. */
uecp-footer .foot-btn:hover{color:var(--ue-text-hi);background:var(--ue-line-soft)}
uecp-footer .foot-btn:hover svg{opacity:1}
uecp-footer .foot-sep{width:1px;height:16px;background:var(--ue-line);margin:0 7px}
/* Unread What's New is the one footer item that has to compete for attention: it
   is the only place a release note lands for someone who never opens a dialog.
   Read, it is a quiet button like Docs or Discord. Unread, it becomes an accent
   pill with a count -- a 6px dot next to grey text was invisible, which is how
   the first build of this shipped. */
/* Vertical padding matches .foot-btn so the pill does not sit shorter than the
   buttons beside it; only the radius and the fill change. */
uecp-footer .foot-btn[data-foot="whatsnew"].unread{background:var(--ue-accent-soft);color:var(--ue-accent-bright);border-radius:999px;padding:4px 10px;font-weight:var(--ue-fw-semi)}
uecp-footer .foot-btn[data-foot="whatsnew"].unread:hover{filter:brightness(1.12)}
uecp-footer .wn-dot{display:none;min-width:15px;height:15px;line-height:15px;text-align:center;font-size:9.5px;font-weight:700;border-radius:8px;background:var(--ue-accent);color:var(--ue-on-accent);padding:0 4px;margin-left:5px}
uecp-footer .wn-dot.show{display:inline-block}
uecp-footer .ft-usage{display:none;align-items:center;gap:6px;margin-left:6px;position:relative;cursor:pointer}
uecp-footer .ft-usage.visible{display:inline-flex}
uecp-footer .ft-usage:hover .ft-label{color:var(--ue-text-hi)}
uecp-footer .ft-track{width:64px;height:5px;border-radius:3px;background:var(--ue-elev);overflow:hidden}
uecp-footer .ft-bar{height:100%;border-radius:3px;background:var(--ue-success);width:0;transition:width .2s}
uecp-footer .ft-bar.yellow{background:var(--ue-warn)}
uecp-footer .ft-bar.red{background:var(--ue-danger)}
uecp-footer .ft-label{color:var(--ue-text-lo)}
uecp-footer .ft-bonus{display:none;color:var(--ue-accent-bright);font-weight:600}
uecp-footer .ft-bonus.show{display:inline}
uecp-footer .ft-peak{display:none;width:7px;height:7px;border-radius:50%;background:var(--ue-success);flex-shrink:0}
uecp-footer .ft-peak.show{display:inline-block}
uecp-footer .ft-peak.is-peak{background:var(--ue-warn)}
uecp-footer .ft-pop{display:none;position:absolute;bottom:calc(100% + 8px);right:0;z-index:40;width:236px;background:var(--ue-elev);border:1px solid var(--ue-line-soft);border-radius:8px;padding:12px;box-shadow:0 6px 24px rgba(0,0,0,.35);font-family:var(--ue-font);color:var(--ue-text-hi);cursor:default}
uecp-footer .ft-pop.show{display:block}
uecp-footer .ft-pop h4{margin:0 0 3px;font-size:10px;text-transform:uppercase;letter-spacing:.05em;color:var(--ue-text-lo);font-weight:700}
uecp-footer .ft-pop .ft-row{margin-bottom:11px}
uecp-footer .ft-pop .ft-big{font-size:15px;font-weight:600;font-family:var(--ue-font-mono)}
uecp-footer .ft-pop .ft-sub{color:var(--ue-text-lo);font-size:11px;margin-top:1px}
uecp-footer .ft-pop .ft-acts{display:flex;gap:8px}
uecp-footer .ft-pop .ft-acts button{flex:1;background:var(--ue-accent);color:var(--ue-on-accent);border:none;border-radius:6px;padding:7px 6px;font:inherit;font-size:11px;font-weight:600;cursor:pointer}
uecp-footer .ft-pop .ft-acts button.ft-sec{background:transparent;color:var(--ue-text-hi);border:1px solid var(--ue-line-soft)}
uecp-footer .ft-pop .ft-acts button:hover{filter:brightness(1.08)}
uecp-footer .ft-pop .ft-acts .ft-manage{display:none}
uecp-footer .ft-pop .ft-acts .ft-manage.show{display:block}
uecp-footer .ft-warn{display:none;width:7px;height:7px;border-radius:50%;background:var(--ue-warn);flex-shrink:0}
uecp-footer .ft-warn.show{display:inline-block}
uecp-footer .ft-alert{display:none;margin-bottom:11px;padding:8px;border-radius:6px;border:1px solid var(--ue-warn);background:rgba(0,0,0,.16);font-size:11px;line-height:1.45;color:var(--ue-text-hi)}
uecp-footer .ft-alert.show{display:block}
uecp-footer .ft-alert b{display:block;margin-bottom:2px;color:var(--ue-warn)}`;
    document.head.appendChild(s);
  }
  function ico(id) {
    return (window.UECP && window.UECP.icon) ? window.UECP.icon(id, 13) : '';
  }

  function fbtn(key, icon, label, tip, extra) {
    return '<button class="foot-btn" data-foot="' + key + '" title="' + tip + '">'
         + ico(icon) + '<span>' + label + '</span>' + (extra || '') + '</button>';
  }

  class Footer extends HTMLElement {
    connectedCallback() {
      this.innerHTML =
        fbtn('instructions', 'ic-file-text', 'Instructions', 'Custom Instructions') +
        fbtn('gdd', 'ic-book', 'GDD', 'Game Design Document') +
        fbtn('bug', 'ic-bug', 'Report', 'Report a bug') +
        '<span class="foot-sep"></span>' +
        fbtn('docs', 'ic-learn', 'Docs', 'Documentation') +
        fbtn('discord', 'ic-message', 'Discord', 'Discord') +
        fbtn('whatsnew', 'ic-megaphone', 'What\'s New', 'What\'s New', '<span class="wn-dot"></span>') +
        '<span class="foot-sep"></span>' +
        '<button class="mem-open foot-btn" title="AI Memory">' +
          ico('ic-architect') +
          '<span>Memory</span> <span class="mem-badge">0</span></button>' +
        '<span class="msg"></span>' +
        '<span class="ft-usage" title="Free tier — click for detail">' +
          '<span class="ft-track"><span class="ft-bar"></span></span>' +
          '<span class="ft-label mono"></span>' +
          '<span class="ft-bonus mono"></span>' +
          '<span class="ft-peak"></span>' +
          '<span class="ft-warn"></span>' +
          '<span class="ft-pop">' +
            '<div class="ft-alert"></div>' +
            '<div class="ft-row"><h4>Free allowance</h4><div class="ft-big ft-daily"></div><div class="ft-sub ft-daily-sub"></div></div>' +
            '<div class="ft-row"><h4>Extra tokens</h4><div class="ft-big ft-extra"></div><div class="ft-sub ft-extra-sub">Never expire, used after the free allowance</div></div>' +
            '<div class="ft-acts"><button class="ft-manage ft-sec">Manage plan</button><button class="ft-shop">Get more tokens</button><button class="ft-sec ft-refer">Refer</button></div>' +
          '</span>' +
        '</span>';
      var self = this;
      this.querySelector('.mem-open').addEventListener('click', function () {
        if (window.UECP && window.UECP.openMemory) window.UECP.openMemory();
      });
      this.querySelector('[data-foot="instructions"]').addEventListener('click', function () {
        if (window.UECP && window.UECP.openInstructions) window.UECP.openInstructions();
      });
      this.querySelector('[data-foot="gdd"]').addEventListener('click', function () {
        if (window.UECP && window.UECP.openGdd) window.UECP.openGdd();
      });
      this.querySelector('[data-foot="bug"]').addEventListener('click', function () {
        if (window.UECP && window.UECP.openBugReport) window.UECP.openBugReport();
      });
      this.querySelector('[data-foot="docs"]').addEventListener('click', function () {
        window.uecp.call('open_external_url', { url: 'https://www.gamedevcore.com/docs/bpgenerator-ultimate' });
      });
      this.querySelector('[data-foot="discord"]').addEventListener('click', function () {
        window.uecp.call('open_external_url', { url: 'https://discord.gg/w65xMuxEhb' });
      });
      this.querySelector('[data-foot="whatsnew"]').addEventListener('click', function () {
        if (window.UECP && window.UECP.openWhatsNew) window.UECP.openWhatsNew();
      });
      this._uWn = window.uecp.on('whatsnew.feed', function (d) { self._onWhatsNew(d); });
      this._uWnSeen = window.uecp.on('whatsnew.seen', function () { self._setUnread(0); });
      window.uecp.call('request_whatsnew', {});
      this._uStatus = window.uecp.on('status.changed', function (p) {
        if (p && p.footer != null) self.querySelector('.msg').textContent = p.footer;
      });
      this._uPending = window.uecp.on('memory.pending_count', function (p) {
        var n = (p && typeof p.count === 'number') ? p.count : (typeof p === 'number' ? p : 0);
        var badge = self.querySelector('.mem-badge');
        if (!badge) return;
        badge.textContent = n > 99 ? '99+' : String(n);
        badge.classList.toggle('show', n > 0);
      });
      this._uFt = window.uecp.on('freetier.usage', function (d) { self._renderFreeTier(d); });

      this._refreshWallet = function () {
        var now = Date.now();
        if (self._lastWalletAsk && (now - self._lastWalletAsk) < 60000) return;
        self._lastWalletAsk = now;
        try { window.uecp.call('request_wallet', {}); } catch (e) {  }
      };
      this._refreshWallet();
      this._onWalletWake = function () {
        if (document.visibilityState === 'hidden') return;
        self._refreshWallet();
      };
      document.addEventListener('visibilitychange', this._onWalletWake);
      window.addEventListener('focus', this._onWalletWake);

      var pop = this.querySelector('.ft-pop');
      this.querySelector('.ft-usage').addEventListener('click', function (e) {
        if (pop && pop.contains(e.target)) return;
        if (pop) pop.classList.toggle('show');
      });
      this.querySelector('.ft-shop').addEventListener('click', function () {
        if (window.UECP && window.UECP.router) window.UECP.router.go('shop');
        else window.uecp.call('open_external_url', { url: 'https://www.gamedevcore.com/shop' });
        if (pop) pop.classList.remove('show');
      });
      this.querySelector('.ft-manage').addEventListener('click', function () {
        window.uecp.call('open_external_url', { url: 'https://www.gamedevcore.com/account' });
      });
      this.querySelector('.ft-refer').addEventListener('click', function () {
        window.uecp.call('open_external_url', { url: 'https://www.gamedevcore.com/refer' });
      });
      this._onDocClick = function (e) {
        var strip = self.querySelector('.ft-usage');
        if (pop && strip && !strip.contains(e.target)) pop.classList.remove('show');
      };
      document.addEventListener('click', this._onDocClick, true);
    }

    _onWhatsNew(d) {
      var entries = (d && Array.isArray(d.entries)) ? d.entries : [];
      if (!entries.length) { this._setUnread(0); return; }
      var lastSeen = (d && typeof d.last_seen === 'string') ? d.last_seen : '';
      if (!lastSeen) {
        window.uecp.call('mark_whatsnew_seen', { entry_id: entries[0].entry_id });
        this._setUnread(0);
        return;
      }
      var unread = 0;
      for (var i = 0; i < entries.length; i++) {
        if (entries[i].entry_id === lastSeen) { unread = i; break; }
      }
      this._setUnread(unread);
      if (unread > 0 && !Footer._autoOpened) {
        Footer._autoOpened = true;
        if (window.UECP && window.UECP.openWhatsNew) window.UECP.openWhatsNew();
      }
    }
    _setUnread(n) {
      var dot = this.querySelector('.wn-dot');
      if (dot) {
        dot.textContent = n > 9 ? '9+' : String(n);
        dot.classList.toggle('show', n > 0);
      }
      var btn = this.querySelector('[data-foot="whatsnew"]');
      if (btn) btn.classList.toggle('unread', n > 0);
    }

    _fmtTokens(n) {
      n = n || 0;
      if (n >= 1000000) return (n / 1000000).toFixed(1).replace(/\.0$/, '') + 'M';
      if (n >= 1000) return (n / 1000).toFixed(0) + 'K';
      return String(n);
    }
    _fmtBonus(n) {
      n = n || 0;
      if (n >= 1000000) return (n / 1000000).toFixed(3).replace(/\.?0+$/, '') + 'M';
      if (n >= 1000) return (n / 1000).toFixed(0) + 'K';
      return String(n);
    }
    _scheduleFreeTierReset(d, resetMs) {
      if (this._ftTimer) { clearTimeout(this._ftTimer); this._ftTimer = null; }
      this._ftLast = d;
      if (isNaN(resetMs)) return;
      var delay = resetMs - Date.now();
      if (delay <= 0 || delay > 25 * 3600000) return;
      var self = this;
      this._ftTimer = setTimeout(function () {
        self._ftTimer = null;
        self._renderFreeTier(self._ftLast);
      }, delay + 1000);
    }
    _renderFreeTier(d) {
      var wrap = this.querySelector('.ft-usage');
      var bar  = this.querySelector('.ft-bar');
      var label = this.querySelector('.ft-label');
      if (!wrap || !bar || !label) return;
      var bonus = (d && typeof d.bonusRemaining === 'number') ? d.bonusRemaining : 0;
      var hasDaily = !!(d && d.limit > 0);
      if (!d || (!hasDaily && bonus <= 0)) {
        if (this._ftTimer) { clearTimeout(this._ftTimer); this._ftTimer = null; }
        wrap.classList.remove('visible');
        return;
      }
      wrap.classList.add('visible');

      var fmt = this._fmtTokens, fmtB = this._fmtBonus;
      var unlimited = (d.enforced === false);
      var hasPlan  = !!(d && d.plan);
      var isSub    = !!(d && d.subGranted > 0);
      var subState = (d && d.subState) || '';
      var planLabel = hasPlan ? (d.plan.charAt(0).toUpperCase() + d.plan.slice(1)).replace('_',' ') : '';

      var resetMs = d.resetAt ? new Date(d.resetAt).getTime() : NaN;
      var rolledOver = !isSub && !isNaN(resetMs) && resetMs <= Date.now();
      var subRenewing = isSub && !isNaN(resetMs) && resetMs <= Date.now();
      if (!isSub) this._scheduleFreeTierReset(d, resetMs);

      var remaining = rolledOver ? (d.limit || 0)
        : (typeof d.remaining === 'number') ? d.remaining : Math.max(0, (d.limit || 0) - (d.used || 0));

      var used = rolledOver ? 0
        : (typeof d.used === 'number') ? d.used : Math.max(0, (d.limit || 0) - remaining);
      if (!hasDaily) {
        bar.style.width = '0'; label.textContent = '';
      } else if (unlimited) {
        bar.className = 'ft-bar'; bar.style.width = '100%';
        label.textContent = fmt(used) + ' • ∞';
      } else {
        var pctUsed = Math.max(0, Math.min(100, Math.round((used / d.limit) * 100)));
        bar.style.width = pctUsed + '%';
        bar.className = ('ft-bar ' + (pctUsed < 50 ? '' : pctUsed < 80 ? 'yellow' : 'red')).trim();
        label.textContent = fmt(used) + '/' + fmt(d.limit);
      }

      var bChip = this.querySelector('.ft-bonus');
      if (bChip) { bChip.textContent = '+' + fmtB(bonus); bChip.classList.toggle('show', bonus > 0); }

      var peakDot = this.querySelector('.ft-peak');
      if (peakDot) {
        peakDot.classList.toggle('show', !rolledOver && !isSub);
        peakDot.classList.toggle('is-peak', !!d.peak);
        peakDot.title = d.peak ? 'Peak hours: the free ceiling is lower now, and more is free off-peak' : 'Off-peak';
      }

      var resetIn = '';
      if (d.resetAt && !rolledOver && !subRenewing) {
        var diff = new Date(d.resetAt) - new Date();
        if (diff > 0) { var h = Math.floor(diff / 3600000), m = Math.floor((diff % 3600000) / 60000); resetIn = (h > 0 ? h + 'h ' : '') + m + 'm'; }
        else resetIn = 'now';
      }
      var dailyBig = this.querySelector('.ft-daily');
      var dailySub = this.querySelector('.ft-daily-sub');
      var extraBig = this.querySelector('.ft-extra');
      if (wrap) wrap.title = (isSub ? planLabel + ' subscription' : 'Free tier') + ' — click for detail';
      var popHead = this.querySelector('.ft-pop .ft-row h4');
      if (popHead) popHead.textContent = isSub ? (planLabel + ' plan') : 'Free allowance';
      if (dailyBig) dailyBig.textContent = !hasDaily ? '—' : unlimited ? (fmt(used) + ' used · no limit') : (fmt(used) + ' / ' + fmt(d.limit) + ' used');
      var ending = (subState === 'ending');
      if (dailySub) dailySub.textContent = unlimited ? 'Limits off'
        : isSub ? (subRenewing ? (ending ? 'Ending…' : 'Renewing…')
                  : (resetIn ? (ending ? 'Ends in ' : 'Renews in ') + resetIn
                             : (ending ? 'Ends soon' : 'Renews soon')))
        : rolledOver ? 'Window reset · full quota'
        : ((resetIn ? 'Resets in ' + resetIn : 'Resets soon') + (d.peak ? ' · peak — higher off-peak' : ''));
      var manageBtn = this.querySelector('.ft-manage');
      if (manageBtn) manageBtn.classList.toggle('show', hasPlan);
      if (extraBig) extraBig.textContent = fmtB(bonus);
      var extraSub = this.querySelector('.ft-extra-sub');
      if (extraSub) extraSub.textContent = isSub ? 'Never expire, used after your plan tokens' : 'Never expire, used after the free allowance';

      var alertEl = this.querySelector('.ft-alert');
      var warnDot = this.querySelector('.ft-warn');
      var showAlert = (subState === 'grace' || ending);
      if (warnDot) {
        warnDot.classList.toggle('show', showAlert);
        warnDot.title = subState === 'grace' ? 'Payment failed — action needed' : 'Subscription ending';
      }
      if (alertEl) {
        alertEl.classList.toggle('show', showAlert);
        if (showAlert) {
          var untilTxt = '';
          if (d.subUntil) {
            var u = new Date(d.subUntil);
            if (!isNaN(u.getTime())) untilTxt = u.toLocaleDateString();
          }
          alertEl.innerHTML = (subState === 'grace'
            ? '<b>Payment failed</b>Update your payment method to keep your plan.'
            : '<b>Subscription ending</b>This plan will not renew.')
            + (untilTxt ? ' Access continues until ' + untilTxt + '.' : '');
        }
      }
    }
    disconnectedCallback() {
      if (this._uStatus) this._uStatus();
      if (this._uPending) this._uPending();
      if (this._uFt) this._uFt();
      if (this._uWn) this._uWn();
      if (this._uWnSeen) this._uWnSeen();
      if (this._ftTimer) { clearTimeout(this._ftTimer); this._ftTimer = null; }
      if (this._onWalletWake) {
        document.removeEventListener('visibilitychange', this._onWalletWake);
        window.removeEventListener('focus', this._onWalletWake);
        this._onWalletWake = null;
      }
      if (this._onDocClick) document.removeEventListener('click', this._onDocClick, true);
    }
  }
  customElements.define('uecp-footer', Footer);
})();
