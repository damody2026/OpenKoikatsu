(function () {
  const bus = window.UECP.createBus();

  function resolveShell() {
    const sh = window.ue && window.ue.shell;
    const fn = sh && (sh.call || sh.Call);
    return (typeof fn === 'function') ? { sh: sh, fn: fn } : null;
  }

  let outPending = [];
  let polling = false;
  function flushWhenReady() {
    if (polling) return;
    polling = true;
    let tries = 0;
    const iv = setInterval(function () {
      const r = resolveShell();
      if (r) {
        clearInterval(iv); polling = false;
        const q = outPending; outPending = [];
        q.forEach(function (c) { r.fn.call(r.sh, c[0], c[1]); });
      } else if (++tries > 200) {
        clearInterval(iv); polling = false;
        outPending.forEach(function (c) { console.info('[uecp] (no bridge) call', c[0], c[1]); });
        outPending = [];
      }
    }, 50);
  }
  bus.setSender(function (action, json) {
    const r = resolveShell();
    if (r) { r.fn.call(r.sh, action, json); return; }
    outPending.push([action, json]);
    flushWhenReady();
  });

  const i18n = window.UECP.createI18n({ en: {} }, 'en');

  const domI18n = window.UECP.i18nRuntime
    ? window.UECP.i18nRuntime.create(function (key) { return i18n.t(key); })
    : null;

  function syncRuntime(code) {
    if (!domI18n) return;
    if (!code || code === 'en') {
      if (domI18n.isActive()) { domI18n.refresh(); domI18n.stop(); }
      return;
    }
    if (domI18n.isActive()) domI18n.refresh(); else domI18n.start();
  }

  function applyLanguageNow(code) {
    i18n.setLang(code || 'en');
    if (typeof document === 'undefined') return;
    document.documentElement.setAttribute('dir', code === 'ar' ? 'rtl' : 'ltr');
    syncRuntime(i18n.getLang());
  }

  const loadingBundle = {};
  function loadBundle(code, then) {
    const tables = (window.UECP.i18nTables = window.UECP.i18nTables || {});
    if (tables[code]) { then(true); return; }
    if (loadingBundle[code]) { loadingBundle[code].push(then); return; }
    loadingBundle[code] = [then];
    const s = document.createElement('script');
    s.src = 'i18n/' + encodeURIComponent(code) + '.js';
    s.async = true;
    const finish = function () {
      const waiters = loadingBundle[code] || [];
      delete loadingBundle[code];
      waiters.forEach(function (w) { w(!!tables[code]); });
    };
    s.onload = finish;
    s.onerror = finish;
    document.head.appendChild(s);
  }

  bus.on('i18n.dict', function (p) {
    if (!p || !p.lang || !p.table) return;
    i18n.merge(p.lang, p.table);
    if (i18n.getLang() === p.lang) applyLanguageNow(p.lang);
  });

  function applyLanguage(code) {
    applyLanguageNow(code);
    if (!code || code === 'en') return;
    loadBundle(code, function (ok) {
      if (!ok) return;
      i18n.merge(code, window.UECP.i18nTables[code]);
      if (i18n.getLang() === code) applyLanguageNow(code);
    });
    bus.call('get_i18n_dict', { language: code });
  }

  bus.on('init', function (state) {
    if (state && state.i18n) {
      if (state.i18n.dict) for (const lang in state.i18n.dict) i18n.merge(lang, state.i18n.dict[lang]);
      if (state.i18n.lang) applyLanguage(state.i18n.lang);
    }
  });
  let lastSettings = null;
  bus.on('settings.init', function (s) {
    if (s) lastSettings = s;
    if (s && s.language) applyLanguage(s.language);
  });
  bus.on('language.changed', function (p) {
    if (p && p.lang) applyLanguage(p.lang);
  });

  window.uecp = {
    on: bus.on,
    call: bus.call,
    t: i18n.t,
    T: function (text, vars) { return i18n.t(text, vars); },
    setLang: applyLanguage,
    getLang: i18n.getLang,
    lastSettings: function () { return lastSettings; },
    __emit: function (type, payload) { bus.emit(type, payload || {}); }
  };
})();
