// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "UECPSteamTypes.h"
#include "UECPSteamLobbyLibrary.generated.h"

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamLobbyLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Lobby")
	static TArray<FUECPSteamID> GetLobbyMembers(FUECPSteamID LobbyId);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Lobby")
	static int32 GetLobbyMemberLimit(FUECPSteamID LobbyId);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Lobby")
	static FUECPSteamID GetLobbyOwner(FUECPSteamID LobbyId);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Lobby")
	static FString GetLobbyData(FUECPSteamID LobbyId, const FString& Key);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Lobby")
	static TMap<FString, FString> GetAllLobbyData(FUECPSteamID LobbyId);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Lobby")
	static bool SetLobbyData(FUECPSteamID LobbyId, const FString& Key, const FString& Value);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Lobby")
	static FString GetLobbyMemberData(FUECPSteamID LobbyId, FUECPSteamID MemberId, const FString& Key);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Lobby")
	static bool SetLobbyMemberData(FUECPSteamID LobbyId, const FString& Key, const FString& Value);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Lobby")
	static bool SendLobbyChatMessage(FUECPSteamID LobbyId, const FString& Message);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Lobby")
	static bool SetLobbyOwner(FUECPSteamID LobbyId, FUECPSteamID NewOwnerId);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Lobby")
	static bool SetLobbyJoinable(FUECPSteamID LobbyId, bool bJoinable);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Lobby")
	static bool InviteUserToLobby(FUECPSteamID LobbyId, FUECPSteamID FriendId);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Lobby")
	static void LeaveLobby(FUECPSteamID LobbyId);
};
