(function (root) {
  function createRegistry() {
    var entries = new Map();
    var listeners = [];
    function notify() {
      listeners.slice().forEach(function (fn) {
        try { fn(entries); } catch (e) { console.error('[uecp] confirm-registry listener error', e); }
      });
    }
    return {
      set: function (chatId, name, preview, kind) {
        if (!chatId) return;
        entries.set(chatId, { name: name, preview: preview || '', kind: kind || '' });
        notify();
      },
      clear: function (chatId) {
        if (!chatId) return;
        if (entries.delete(chatId)) notify();
      },
      get: function (chatId) { return entries.get(chatId) || null; },
      has: function (chatId) { return entries.has(chatId); },
      keys: function () { return Array.from(entries.keys()); },
      onChange: function (fn) {
        listeners.push(fn);
        return function () { var i = listeners.indexOf(fn); if (i >= 0) listeners.splice(i, 1); };
      }
    };
  }
  if (root) {
    root.UECP = root.UECP || {};
    root.UECP.confirmRegistry = createRegistry();
  }
}(typeof window !== 'undefined' ? window : null));

if (typeof window !== 'undefined' && window.uecp && window.UECP && window.UECP.confirmRegistry) {
  window.UECP.activeChatId = '';
  window.uecp.on('tool.confirm', function (d) {
    if (d && d.chatId) window.UECP.confirmRegistry.set(d.chatId, d.name, d.preview, d.kind);
  });
  window.uecp.on('tool.confirmResolved', function (d) {
    if (d && d.chatId) window.UECP.confirmRegistry.clear(d.chatId);
  });
  window.uecp.on('chat.viewstate', function (d) {
    if (d && d.chatId) window.UECP.activeChatId = d.chatId;
  });
}
