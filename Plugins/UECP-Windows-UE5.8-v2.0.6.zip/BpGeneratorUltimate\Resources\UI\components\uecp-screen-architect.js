(function () {
  if (!document.getElementById('uecp-screen-architect-css')) {
    const s = document.createElement('style'); s.id = 'uecp-screen-architect-css';
    s.textContent = `
uecp-screen-architect{display:flex;flex:1;min-width:0;min-height:0}
uecp-screen-architect .arch-chat{flex:1;min-width:0;min-height:0;display:flex;flex-direction:column;background:var(--ue-bg)}
uecp-screen-architect .arch-main{flex:1;min-height:0;display:flex;flex-direction:column;overflow:hidden;position:relative}
uecp-screen-architect .arch-overlay{padding:0 var(--ue-sp-7,24px);flex-shrink:0;max-width:var(--ue-chat-col,720px);margin:0 auto}`;
    document.head.appendChild(s);
  }

  class UecpScreenArchitect extends HTMLElement {
    connectedCallback() {
      if (!this.hasAttribute('tabindex')) this.setAttribute('tabindex', '-1');
      this._empty = true;
      this._build();

      window.uecp.call('request_chat', {});

      const self = this;
      this._u1 = window.uecp.on('chat.window', function (data) {
        const pending = self._thread.switchingTo ? self._thread.switchingTo() : null;
        if (pending != null && (!data || data.chatId !== pending)) return;
        const isEmpty = !data || !data.messages || data.messages.length === 0 && data.total === 0;
        if (isEmpty !== self._empty) {
          self._empty = isEmpty;
          self._syncWelcome();
        }
      });
      this._u3 = window.uecp.on('chat.tail', function (data) {
        const hasMsgs = data && ((data.messages && data.messages.length)
          || (data.message != null && data.index != null)
          || (typeof data.total === 'number' && data.total > 0));
        if (hasMsgs && self._empty) {
          self._empty = false;
          self._syncWelcome();
        }
      });
      this._u2 = window.uecp.on('chat.viewstate', function (data) {
        if (!data) return;
      });

      this._prefillHandler = function (e) {
        const composer = self.querySelector('uecp-composer');
        if (composer && composer.prefill) composer.prefill(e.detail.text);
      };
      this.addEventListener('welcome-prefill', this._prefillHandler);

      this._switchHandler = function (e) {
        if (self._thread.beginSwitch && self._thread.beginSwitch(e.detail && e.detail.chatId)) {
          self._empty = false;
          self._syncWelcome();
        }
      };
      this.addEventListener('chat-switch', this._switchHandler);

      this._ctrlFHandler = function (e) {
        if ((e.ctrlKey || e.metaKey) && e.key === 'f') {
          const findBar = self.querySelector('uecp-find-bar');
          if (findBar) {
            e.preventDefault();
            findBar.open();
          }
        }
      };
      this.addEventListener('keydown', this._ctrlFHandler);
    }

    disconnectedCallback() {
      if (this._u1) { this._u1(); this._u1 = null; }
      if (this._u2) { this._u2(); this._u2 = null; }
      if (this._u3) { this._u3(); this._u3 = null; }
      if (this._prefillHandler) {
        this.removeEventListener('welcome-prefill', this._prefillHandler);
        this._prefillHandler = null;
      }
      if (this._switchHandler) {
        this.removeEventListener('chat-switch', this._switchHandler);
        this._switchHandler = null;
      }
      if (this._ctrlFHandler) {
        this.removeEventListener('keydown', this._ctrlFHandler);
        this._ctrlFHandler = null;
      }
    }

    _build() {
      this.innerHTML = '';

      const chatList = document.createElement('uecp-chat-list');
      this.appendChild(chatList);

      const chatCol = document.createElement('div'); chatCol.className = 'arch-chat';

      const main = document.createElement('div'); main.className = 'arch-main';
      this._thread = document.createElement('uecp-thread');
      this._welcome = document.createElement('uecp-welcome');
      const findBar = document.createElement('uecp-find-bar');
      main.appendChild(this._thread);
      main.appendChild(this._welcome);
      main.appendChild(findBar);

      const overlay = document.createElement('div'); overlay.className = 'arch-overlay';
      const askCard = document.createElement('uecp-ask-card');
      const confirmBar = document.createElement('uecp-confirm-bar');
      overlay.appendChild(askCard);
      overlay.appendChild(confirmBar);

      const composer = document.createElement('uecp-composer');

      chatCol.appendChild(main);
      chatCol.appendChild(overlay);
      chatCol.appendChild(composer);
      this.appendChild(chatCol);

      this._syncWelcome();
    }

    _syncWelcome() {
      const thread  = this.querySelector('uecp-thread');
      const welcome = this.querySelector('uecp-welcome');
      if (!thread || !welcome) return;
      if (this._empty) {
        thread.style.display = 'none';
        welcome.style.display = '';
      } else {
        thread.style.display = '';
        welcome.style.display = 'none';
      }
    }
  }
  customElements.define('uecp-screen-architect', UecpScreenArchitect);
})();
