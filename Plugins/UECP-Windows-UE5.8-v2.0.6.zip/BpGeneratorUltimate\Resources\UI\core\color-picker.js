(function () {
  'use strict';

  function clamp01(v) { return v < 0 ? 0 : (v > 1 ? 1 : v); }

  function hexToRgb(hex) {
    var m = /^#?([0-9a-fA-F]{6})$/.exec(String(hex == null ? '' : hex));
    if (!m) return null;
    var n = parseInt(m[1], 16);
    return { r: (n >> 16) & 255, g: (n >> 8) & 255, b: n & 255 };
  }
  function rgbToHex(r, g, b) {
    function h2(v) { v = Math.max(0, Math.min(255, Math.round(v))); return ('0' + v.toString(16)).slice(-2); }
    return '#' + h2(r) + h2(g) + h2(b);
  }
  function rgbToHsv(r, g, b) {
    r /= 255; g /= 255; b /= 255;
    var max = Math.max(r, g, b), min = Math.min(r, g, b), d = max - min;
    var h = 0;
    if (d !== 0) {
      if (max === r)      h = ((g - b) / d) % 6;
      else if (max === g) h = (b - r) / d + 2;
      else                 h = (r - g) / d + 4;
      h *= 60;
      if (h < 0) h += 360;
    }
    var s = max === 0 ? 0 : d / max;
    var v = max;
    return { h: h, s: s, v: v };
  }
  function hsvToRgb(h, s, v) {
    h = ((h % 360) + 360) % 360;
    s = clamp01(s); v = clamp01(v);
    var c = v * s;
    var x = c * (1 - Math.abs((h / 60) % 2 - 1));
    var m = v - c;
    var r1, g1, b1;
    if      (h < 60)  { r1 = c; g1 = x; b1 = 0; }
    else if (h < 120) { r1 = x; g1 = c; b1 = 0; }
    else if (h < 180) { r1 = 0; g1 = c; b1 = x; }
    else if (h < 240) { r1 = 0; g1 = x; b1 = c; }
    else if (h < 300) { r1 = x; g1 = 0; b1 = c; }
    else               { r1 = c; g1 = 0; b1 = x; }
    return { r: (r1 + m) * 255, g: (g1 + m) * 255, b: (b1 + m) * 255 };
  }
  function hexToHsv(hex) {
    var rgb = hexToRgb(hex);
    return rgb ? rgbToHsv(rgb.r, rgb.g, rgb.b) : null;
  }
  function hsvToHex(h, s, v) {
    var rgb = hsvToRgb(h, s, v);
    return rgbToHex(rgb.r, rgb.g, rgb.b);
  }

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = { hexToRgb: hexToRgb, rgbToHex: rgbToHex, rgbToHsv: rgbToHsv, hsvToRgb: hsvToRgb, hexToHsv: hexToHsv, hsvToHex: hsvToHex };
  }

  if (typeof document === 'undefined') return;

  if (!document.getElementById('uecp-cpicker-css')) {
    var st = document.createElement('style'); st.id = 'uecp-cpicker-css';
    st.textContent =
      '.uecp-cp-panel{position:fixed;display:none;z-index:9500;width:200px;box-sizing:border-box;' +
        'background:var(--ue-panel,#191714);border:1px solid var(--ue-line,#2a2620);' +
        'border-radius:var(--ue-r,8px);box-shadow:var(--ue-shadow-pop,0 12px 34px rgba(0,0,0,.45));' +
        'padding:12px;font-family:var(--ue-font-sans)}' +
      '.uecp-cp-panel.open{display:block}' +
      '.uecp-cp-sv{position:relative;width:100%;height:120px;border-radius:var(--ue-r-sm,6px);' +
        'cursor:crosshair;border:1px solid var(--ue-line,#2a2620);' +
        'background-image:linear-gradient(to top,#000,rgba(0,0,0,0)),linear-gradient(to right,#fff,rgba(255,255,255,0))}' +
      '.uecp-cp-sv-dot{position:absolute;width:12px;height:12px;border-radius:50%;border:2px solid #fff;' +
        'box-shadow:0 0 0 1px rgba(0,0,0,.5);transform:translate(-50%,-50%);pointer-events:none}' +
      '.uecp-cp-hue{position:relative;width:100%;height:14px;margin-top:10px;border-radius:var(--ue-r-pill,999px);' +
        'cursor:pointer;border:1px solid var(--ue-line,#2a2620);' +
        'background:linear-gradient(to right,#f00,#ff0,#0f0,#0ff,#00f,#f0f,#f00)}' +
      '.uecp-cp-hue-thumb{position:absolute;top:50%;width:14px;height:14px;border-radius:50%;background:#fff;' +
        'border:2px solid var(--ue-panel,#191714);box-shadow:0 0 0 1px rgba(0,0,0,.5);' +
        'transform:translate(-50%,-50%);pointer-events:none}' +
      '.uecp-cp-hex-row{display:flex;align-items:center;gap:8px;margin-top:12px}' +
      '.uecp-cp-hex-swatch{width:24px;height:24px;border-radius:6px;border:1px solid var(--ue-line,#2a2620);flex-shrink:0}' +
      '.uecp-cp-hex-input{flex:1;min-width:0;background:var(--ue-bg,#14110d);border:1px solid var(--ue-line,#2a2620);' +
        'border-radius:var(--ue-r,8px);color:var(--ue-text-hi,#ece6dc);font-family:var(--ue-font-mono);' +
        'font-size:12.5px;padding:7px 10px;box-sizing:border-box;outline:none}' +
      '.uecp-cp-hex-input:focus{border-color:var(--ue-accent,#e0a458)}';
    document.head.appendChild(st);
  }

  var _panel = null;
  var _cb = null;
  var _anchorEl = null;
  var _hsv = { h: 0, s: 0, v: 0 };

  function ensurePanel() {
    if (_panel) return _panel;
    _panel = document.createElement('div');
    _panel.className = 'uecp-cp-panel';
    _panel.innerHTML =
      '<div class="uecp-cp-sv"><div class="uecp-cp-sv-dot"></div></div>' +
      '<div class="uecp-cp-hue"><div class="uecp-cp-hue-thumb"></div></div>' +
      '<div class="uecp-cp-hex-row">' +
        '<span class="uecp-cp-hex-swatch"></span>' +
        '<input class="uecp-cp-hex-input" type="text" maxlength="7" spellcheck="false" autocomplete="off">' +
      '</div>';
    document.body.appendChild(_panel);
    wire(_panel);
    return _panel;
  }

  function render(skipInputSync) {
    var hex = hsvToHex(_hsv.h, _hsv.s, _hsv.v);
    var sv = _panel.querySelector('.uecp-cp-sv');
    sv.style.backgroundColor = hsvToHex(_hsv.h, 1, 1);
    var dot = _panel.querySelector('.uecp-cp-sv-dot');
    dot.style.left = (_hsv.s * 100) + '%';
    dot.style.top = ((1 - _hsv.v) * 100) + '%';
    var thumb = _panel.querySelector('.uecp-cp-hue-thumb');
    thumb.style.left = (_hsv.h / 360 * 100) + '%';
    var swatch = _panel.querySelector('.uecp-cp-hex-swatch');
    if (swatch) swatch.style.background = hex;
    if (!skipInputSync) {
      var input = _panel.querySelector('.uecp-cp-hex-input');
      if (input) input.value = hex;
    }
    return hex;
  }

  function fireChange() {
    var hex = render(false);
    if (_cb && _cb.onChange) _cb.onChange(hex);
  }

  function wireDragArea(el, onRatio) {
    el.addEventListener('mousedown', function (e) {
      e.preventDefault();
      var rect = el.getBoundingClientRect();
      function apply(ev) {
        var x = clamp01((ev.clientX - rect.left) / rect.width);
        var y = clamp01((ev.clientY - rect.top) / rect.height);
        onRatio(x, y);
        fireChange();
      }
      apply(e);
      function onMove(ev) { apply(ev); }
      function onUp() {
        document.removeEventListener('mousemove', onMove);
        document.removeEventListener('mouseup', onUp);
      }
      document.addEventListener('mousemove', onMove);
      document.addEventListener('mouseup', onUp);
    });
  }

  function wire(panel) {
    var sv = panel.querySelector('.uecp-cp-sv');
    var hue = panel.querySelector('.uecp-cp-hue');
    var input = panel.querySelector('.uecp-cp-hex-input');

    wireDragArea(sv, function (x, y) { _hsv.s = x; _hsv.v = 1 - y; });
    wireDragArea(hue, function (x ) { _hsv.h = x * 360; });

    input.addEventListener('input', function () {
      var v = input.value.trim();
      if (!/^#[0-9a-fA-F]{6}$/.test(v)) return;
      var hsv = hexToHsv(v);
      if (!hsv) return;
      _hsv = hsv;
      render(true);
      if (_cb && _cb.onChange) _cb.onChange(v);
    });
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); input.blur(); }
      else if (e.key === 'Escape') { e.preventDefault(); close(); }
    });
  }

  function position(anchorEl) {
    var a = anchorEl.getBoundingClientRect();
    var pr = _panel.getBoundingClientRect();
    var vw = window.innerWidth, vh = window.innerHeight, m = 8;
    var left = a.left;
    if (left + pr.width + m > vw) left = Math.max(m, vw - pr.width - m);
    var top = a.bottom + 6;
    if (top + pr.height + m > vh) {
      top = a.top - pr.height - 6;
      if (top < m) top = Math.max(m, vh - pr.height - m);
    }
    _panel.style.left = left + 'px';
    _panel.style.top = top + 'px';
  }

  function open(anchorEl, currentHex, onChange, onClose) {
    if (!anchorEl) return;
    ensurePanel();
    if (_panel.classList.contains('open')) close();

    _cb = { onChange: onChange, onClose: onClose };
    _anchorEl = anchorEl;
    _hsv = hexToHsv(currentHex) || { h: 0, s: 0, v: 0 };

    _panel.style.visibility = 'hidden';
    _panel.style.display = 'block';
    render(false);
    position(anchorEl);
    _panel.style.visibility = '';
    _panel.classList.add('open');
  }

  function close() {
    if (!_panel || !_panel.classList.contains('open')) return;
    _panel.classList.remove('open');
    _panel.style.display = 'none';
    var cb = _cb;
    _cb = null; _anchorEl = null;
    if (cb && cb.onClose) cb.onClose();
  }

  document.addEventListener('click', function (e) {
    if (!_panel || !_panel.classList.contains('open')) return;
    if (_panel.contains(e.target) || e.target === _anchorEl || (_anchorEl && _anchorEl.contains && _anchorEl.contains(e.target))) return;
    close();
  });
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape') return;
    if (!_panel || !_panel.classList.contains('open')) return;
    close();
  });
  window.addEventListener('scroll', function () { close(); }, true);
  window.addEventListener('resize', function () { close(); });

  window.UECP = window.UECP || {};
  window.UECP.openColorPicker = open;
  window.UECP.closeColorPicker = close;
})();
