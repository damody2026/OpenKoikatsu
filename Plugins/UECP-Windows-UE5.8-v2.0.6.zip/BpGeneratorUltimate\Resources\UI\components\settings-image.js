(function () {
  function esc(s) {
    return String(s == null ? '' : s)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;').replace(/'/g, '&#39;');
  }

  const IMG_PROVIDERS = ['OpenAI','Gemini','StabilityAI','Flux','Ideogram','Recraft','Custom'];

  const CHEV_SVG = '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><polyline points="6 9 12 15 18 9"/></svg>';

  class SettingsImage extends HTMLElement {
    connectedCallback() {
      this.style.cssText = 'display:flex;flex-direction:column;flex:1;min-height:0;overflow-y:auto';
      this._ig = {};
      this._meshy = {};
      this._tripo = {};
      this._providers = [];
      this._render();
    }

    _onSettingsInit(state) {
      if (!state) return;
      this._ig = (state.imageGen) || {};
      const slotIdx = state.activeSlotIndex || 0;
      this._activeSlotIdx = slotIdx;
      const activeSlot = (state.slots && state.slots[slotIdx]) || {};
      const slots = Array.isArray(state.slots) ? state.slots : [];
      const keyFor = function (field) {
        const own = activeSlot[field] || {};
        if (own.apiKey) return own;
        const other = slots.find(function (s) { return s && s[field] && s[field].apiKey; });
        return other ? Object.assign({}, own, { apiKey: other[field].apiKey }) : own;
      };
      this._meshy = keyFor('meshGen');
      this._tripo = keyFor('tripo');
      this._render();
    }

    _onMeshProviders(data) {
      this._providers = Array.isArray(data) ? data : [];
      const mc = this.querySelector('#sim-meshy-card');
      if (!mc) return;
    }

    _render() {
      const ig    = this._ig;
      const meshy = this._meshy;
      const tripo = this._tripo;
      const provider  = ig.provider    || 'OpenAI';
      const endpoint  = ig.endpoint    || '';
      const model     = ig.model       || '';
      const textMode  = ig.textureMode !== false;

      this.innerHTML =
        '<div class="content-head"><span class="crumb"><b>Image &amp; 3D</b></span></div>'
        + '<div class="page page-narrow">'
        + '<div class="page-title">Image &amp; 3D Generation</div>'
        + '<div class="page-sub">Providers for generating textures, images, and 3D meshes. Used by Image Studio and Meshy Studio in Tools.</div>'

        + '<div class="card" style="margin-top:20px">'
        + '<div style="display:flex;align-items:center;gap:9px;margin-bottom:15px">'
        + '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--ue-accent-bright)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-5-5L5 21"/></svg>'
        + '<span class="card-title" style="font-size:14px">Image Generation</span>'
        + '</div>'
        + '<div style="display:flex;flex-direction:column;gap:13px">'

        + '<div><div class="field-label">Provider</div>'
        + '<div class="input"><select id="sim-provider" style="background:transparent;border:none;flex:1;color:var(--ue-text-hi);outline:none;font-size:13px;appearance:none">'
        + IMG_PROVIDERS.map(function (p) { return '<option value="' + esc(p) + '"' + (p === provider ? ' selected' : '') + '>' + esc(p) + '</option>'; }).join('')
        + '</select><span class="chev">' + CHEV_SVG + '</span></div></div>'

        + '<div><div class="field-label">Endpoint</div>'
        + '<div class="input mono"><input id="sim-endpoint" spellcheck="false" autocorrect="off" autocapitalize="off" type="text" style="background:transparent;border:none;flex:1;color:inherit;outline:none;font-family:inherit;font-size:inherit" value="' + esc(endpoint) + '" placeholder="https://api.openai.com/v1"></div></div>'

        + '<div><div class="field-label">API Key</div>'
        + '<div class="input mono"><input id="sim-api-key" type="password" style="background:transparent;border:none;flex:1;color:inherit;outline:none;font-family:inherit;font-size:inherit" value="' + esc(ig.apiKey || '') + '" placeholder="sk-…" autocomplete="new-password"><span class="link-hover" style="color:var(--ue-text-mid);font-family:var(--ue-font-sans);font-size:11px;cursor:pointer;margin-left:8px;flex-shrink:0" id="sim-show-key">Show</span></div></div>'

        + '<div><div class="field-label">Default Model</div>'
        + '<div class="input mono"><input id="sim-model" spellcheck="false" autocorrect="off" autocapitalize="off" type="text" style="background:transparent;border:none;flex:1;color:inherit;outline:none;font-family:inherit;font-size:inherit" value="' + esc(model) + '" placeholder="gpt-image-1"></div></div>'

        + '</div></div>'

        + '<div class="card" id="sim-meshy-card" style="margin-top:14px">'
        + '<div style="display:flex;align-items:center;gap:9px;margin-bottom:15px">'
        + '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--ue-accent-bright)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.7l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.7l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><path d="m3.3 7 8.7 5 8.7-5M12 22V12"/></svg>'
        + '<span class="card-title" style="font-size:14px">3D Generation</span><span style="font-size:11px;color:var(--ue-text-lo);font-weight:400;margin-left:2px">Meshy</span>'
        + '</div>'
        + '<div style="display:flex;flex-direction:column;gap:13px">'

        + '<div><div class="field-label">Meshy API Key</div>'
        + '<div class="input mono"><input id="sim-meshy-key" type="password" style="background:transparent;border:none;flex:1;color:inherit;outline:none;font-family:inherit;font-size:inherit" value="' + esc(meshy.apiKey || '') + '" placeholder="msy_…" autocomplete="new-password"><span class="link-hover" style="color:var(--ue-text-mid);font-family:var(--ue-font-sans);font-size:11px;cursor:pointer;margin-left:8px;flex-shrink:0" id="sim-show-meshy">Show</span></div></div>'

        + '<div class="toggle-row" style="border:none;padding:0">'
        + '<div class="t"><div class="t-name">Tiling texture mode</div><div class="t-desc">Generate seamless tiling textures. Off = general (non-tiling) images.</div></div>'
        + '<div class="toggle' + (textMode ? ' on' : '') + '" id="sim-tex-mode"><span class="knob"></span></div>'
        + '</div>'

        + '</div></div>'

        + '<div class="card" id="sim-tripo-card" style="margin-top:14px">'
        + '<div style="display:flex;align-items:center;gap:9px;margin-bottom:15px">'
        + '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--ue-accent-bright)" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2 2 7l10 5 10-5-10-5z"/><path d="m2 17 10 5 10-5"/><path d="m2 12 10 5 10-5"/></svg>'
        + '<span class="card-title" style="font-size:14px">3D Generation</span><span style="font-size:11px;color:var(--ue-text-lo);font-weight:400;margin-left:2px">Tripo3D</span>'
        + '</div>'
        + '<div style="display:flex;flex-direction:column;gap:13px">'

        + '<div><div class="field-label">Tripo API Key</div>'
        + '<div class="input mono"><input id="sim-tripo-key" type="password" style="background:transparent;border:none;flex:1;color:inherit;outline:none;font-family:inherit;font-size:inherit" value="' + esc(tripo.apiKey || '') + '" placeholder="tsk_\u2026" autocomplete="new-password"><span class="link-hover" style="color:var(--ue-text-mid);font-family:var(--ue-font-sans);font-size:11px;cursor:pointer;margin-left:8px;flex-shrink:0" id="sim-show-tripo">Show</span></div>'
        + '<div class="t-desc" style="margin-top:5px">Create one at tripo3d.ai \u2192 Console \u2192 API Keys. Shown once, so store it somewhere.</div></div>'

        + '<div><div class="field-label">Model</div>'
        + '<div class="input mono"><input id="sim-tripo-model" spellcheck="false" autocorrect="off" autocapitalize="off" type="text" style="background:transparent;border:none;flex:1;color:inherit;outline:none;font-family:inherit;font-size:inherit" value="' + esc(tripo.model || '') + '" placeholder="leave blank to auto-detect"></div>'
        + '<div class="t-desc" style="margin-top:5px">Leave empty for the current default.</div></div>'

        + '</div></div>'

        + window.UECP.saveBar.html(this, 'sim-save')
        + '</div>';

      const self = this;

      this.querySelector('#sim-show-key').addEventListener('click', function () {
        const inp = self.querySelector('#sim-api-key');
        inp.type = inp.type === 'password' ? 'text' : 'password';
        this.textContent = inp.type === 'password' ? 'Show' : 'Hide';
      });
      const tripoShow = this.querySelector('#sim-show-tripo');
      if (tripoShow) tripoShow.addEventListener('click', function () {
        const inp = self.querySelector('#sim-tripo-key');
        if (!inp) return;
        const hidden = inp.type === 'password';
        inp.type = hidden ? 'text' : 'password';
        tripoShow.textContent = hidden ? 'Hide' : 'Show';
      });

      this.querySelector('#sim-show-meshy').addEventListener('click', function () {
        const inp = self.querySelector('#sim-meshy-key');
        inp.type = inp.type === 'password' ? 'text' : 'password';
        this.textContent = inp.type === 'password' ? 'Show' : 'Hide';
      });

      const texToggle = this.querySelector('#sim-tex-mode');
      if (texToggle) texToggle.addEventListener('click', function () { this.classList.toggle('on'); });

      this.querySelector('#sim-save').addEventListener('click', function () { self._save(); });
      window.UECP.saveBar.autosave(this, function () { self._save(); });
    }

    _save() {
      const texEl = this.querySelector('#sim-tex-mode');
      const texMode = !!(texEl && texEl.classList.contains('on'));
      window.uecp.call('save_image_gen', {
        endpoint:    (this.querySelector('#sim-endpoint')  || {}).value || '',
        apiKey:      (this.querySelector('#sim-api-key')   || {}).value || '',
        model:       (this.querySelector('#sim-model')     || {}).value || '',
        textureMode: texMode,
      });
      const idx = this._activeSlotIdx || 0;
      window.uecp.call('save_slot', {
        index:   idx,
        meshGen: { apiKey: (this.querySelector('#sim-meshy-key') || {}).value || '' },
        tripo: {
          apiKey: (this.querySelector('#sim-tripo-key')   || {}).value || '',
          model:  (this.querySelector('#sim-tripo-model') || {}).value || '',
        },
      });
      window.UECP.saveBar.flash(this);
    }
  }
  customElements.define('settings-image', SettingsImage);
})();
