(function () {
  if (typeof document !== 'undefined' && !document.getElementById('uecp-screen-cpppreview-css')) {
    const s = document.createElement('style'); s.id = 'uecp-screen-cpppreview-css';
    s.textContent = `
uecp-screen-cpppreview{display:flex;flex:1;min-width:0;min-height:0;background:var(--ue-bg)}
uecp-screen-cpppreview .cpp-side{width:250px;flex-shrink:0;display:flex;flex-direction:column;min-height:0;border-right:1px solid var(--ue-line-soft);background:var(--ue-panel)}
uecp-screen-cpppreview .cpp-side-head{display:flex;align-items:center;gap:8px;padding:11px 12px;border-bottom:1px solid var(--ue-line-soft)}
uecp-screen-cpppreview .cpp-side-head .lbl{font-family:var(--ue-font-mono);font-size:11px;letter-spacing:.08em;color:var(--ue-text-mid);flex:1}
uecp-screen-cpppreview .cpp-refresh{width:26px;height:26px;display:flex;align-items:center;justify-content:center;background:transparent;border:1px solid var(--ue-line);color:var(--ue-text-mid);border-radius:var(--ue-r);cursor:pointer}
uecp-screen-cpppreview .cpp-refresh:hover{background:var(--ue-line-soft);color:var(--ue-text-hi)}
uecp-screen-cpppreview .cpp-search{margin:8px 10px 4px;padding:6px 9px;background:var(--ue-bg);border:1px solid var(--ue-line);border-radius:var(--ue-r);color:var(--ue-text-hi);font-size:12px;outline:none}
uecp-screen-cpppreview .cpp-search:focus{border-color:var(--ue-accent)}
uecp-screen-cpppreview .cpp-list{flex:1;min-height:0;overflow-y:auto;padding:4px 8px 10px}
uecp-screen-cpppreview .cpp-mod{font-family:var(--ue-font-mono);font-size:10px;letter-spacing:.06em;color:var(--ue-text-lo);padding:10px 6px 4px;text-transform:uppercase}
uecp-screen-cpppreview .cpp-item{display:flex;align-items:center;gap:8px;padding:7px 9px;border-radius:var(--ue-r);cursor:pointer;color:var(--ue-text-mid)}
uecp-screen-cpppreview .cpp-item:hover{background:var(--ue-line-soft);color:var(--ue-text-hi)}
uecp-screen-cpppreview .cpp-item.active{background:var(--ue-accent-soft);color:var(--ue-accent-bright)}
uecp-screen-cpppreview .cpp-item .nm{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:12.5px}
uecp-screen-cpppreview .cpp-item .dot{width:6px;height:6px;border-radius:50%;background:var(--ue-accent);flex-shrink:0;opacity:.55}
uecp-screen-cpppreview .cpp-item.active .dot{opacity:1}
uecp-screen-cpppreview .cpp-main{flex:1;min-width:0;min-height:0;display:flex;flex-direction:column}
uecp-screen-cpppreview .cpp-bar{display:flex;align-items:center;gap:10px;padding:9px 14px;border-bottom:1px solid var(--ue-line-soft);flex-shrink:0}
uecp-screen-cpppreview .cpp-title{font-weight:var(--ue-fw-semi);color:var(--ue-text-hi);font-size:14px}
uecp-screen-cpppreview .cpp-sub{font-family:var(--ue-font-mono);font-size:11px;color:var(--ue-text-lo)}
uecp-screen-cpppreview .cpp-tabs{display:flex;gap:2px;margin-left:6px}
uecp-screen-cpppreview .cpp-tab{padding:5px 12px;border-radius:var(--ue-r);cursor:pointer;font-family:var(--ue-font-mono);font-size:12px;color:var(--ue-text-mid);border:1px solid transparent}
uecp-screen-cpppreview .cpp-tab:hover{background:var(--ue-line-soft)}
uecp-screen-cpppreview .cpp-tab.active{background:var(--ue-accent-soft);color:var(--ue-accent-bright);border-color:var(--ue-line-soft)}
uecp-screen-cpppreview .cpp-spacer{flex:1}
uecp-screen-cpppreview .cpp-copy{padding:5px 11px;border-radius:var(--ue-r);cursor:pointer;background:transparent;border:1px solid var(--ue-line);color:var(--ue-text-mid);font-size:12px}
uecp-screen-cpppreview .cpp-copy:hover{background:var(--ue-line-soft);color:var(--ue-text-hi)}
uecp-screen-cpppreview .cpp-code{flex:1;min-height:0;overflow:auto;background:var(--ue-code-bg,var(--ue-bg));font-family:var(--ue-font-mono);font-size:12.5px;line-height:1.55;padding:6px 0 40px}
uecp-screen-cpppreview .cpp-row{display:flex;white-space:pre}
uecp-screen-cpppreview .cpp-num{position:sticky;left:0;flex-shrink:0;width:46px;text-align:right;padding:0 12px 0 6px;color:var(--ue-text-lo);opacity:.6;background:var(--ue-code-bg,var(--ue-bg));user-select:none}
uecp-screen-cpppreview .cpp-txt{color:var(--ue-code-text,var(--ue-text-hi));padding-right:24px}
uecp-screen-cpppreview .cpp-row.com .cpp-txt{color:var(--ue-text-lo)}
uecp-screen-cpppreview .cpp-row.pre .cpp-txt{color:var(--ue-accent-bright)}
uecp-screen-cpppreview .cpp-empty{flex:1;display:flex;align-items:center;justify-content:center;flex-direction:column;gap:8px;color:var(--ue-text-lo);font-size:13px;text-align:center;padding:20px}
uecp-screen-cpppreview .cpp-empty .mono{font-family:var(--ue-font-mono);font-size:11px}`;
    document.head.appendChild(s);
  }

  class UecpScreenCppPreview extends HTMLElement {
    connectedCallback() {
      this._classes = [];
      this._active = null;
      this._files = {};
      this._tab = 'h';
      this._filter = '';
      this._build();
      const self = this;
      this._uClasses = window.uecp.on('cpp.classes', function (d) { self._onClasses(d); });
      this._uFile = window.uecp.on('cpp.file', function (d) { self._onFile(d); });
      window.uecp.call('request_cpp_classes', {});
    }
    disconnectedCallback() {
      if (this._uClasses) { this._uClasses(); this._uClasses = null; }
      if (this._uFile) { this._uFile(); this._uFile = null; }
    }

    _build() {
      this.innerHTML = '';
      const self = this;

      const side = document.createElement('aside'); side.className = 'cpp-side';
      const head = document.createElement('div'); head.className = 'cpp-side-head';
      const lbl = document.createElement('div'); lbl.className = 'lbl'; lbl.textContent = 'C++ CLASSES';
      const refresh = document.createElement('button'); refresh.className = 'cpp-refresh';
      refresh.title = 'Refresh'; refresh.setAttribute('data-tip', 'Rescan project C++');
      refresh.innerHTML = '<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 12a9 9 0 0 1 15-6.7L21 8"/><path d="M21 3v5h-5"/><path d="M21 12a9 9 0 0 1-15 6.7L3 16"/><path d="M3 21v-5h5"/></svg>';
      refresh.addEventListener('click', function () { window.uecp.call('request_cpp_classes', {}); });
      head.appendChild(lbl); head.appendChild(refresh);

      const search = document.createElement('input'); search.className = 'cpp-search';
      search.type = 'text'; search.placeholder = 'Filter classes…';
      search.addEventListener('input', function () { self._filter = (search.value || '').toLowerCase(); self._renderList(); });

      this._listEl = document.createElement('div'); this._listEl.className = 'cpp-list';
      side.appendChild(head); side.appendChild(search); side.appendChild(this._listEl);
      this.appendChild(side);

      const main = document.createElement('div'); main.className = 'cpp-main';
      const bar = document.createElement('div'); bar.className = 'cpp-bar';
      this._titleEl = document.createElement('span'); this._titleEl.className = 'cpp-title'; this._titleEl.textContent = 'C++ Preview';
      this._subEl = document.createElement('span'); this._subEl.className = 'cpp-sub';

      this._tabsEl = document.createElement('div'); this._tabsEl.className = 'cpp-tabs';
      this._tabH = document.createElement('span'); this._tabH.className = 'cpp-tab active'; this._tabH.textContent = '.h';
      this._tabH.addEventListener('click', function () { self._setTab('h'); });
      this._tabC = document.createElement('span'); this._tabC.className = 'cpp-tab'; this._tabC.textContent = '.cpp';
      this._tabC.addEventListener('click', function () { self._setTab('cpp'); });
      this._tabsEl.appendChild(this._tabH); this._tabsEl.appendChild(this._tabC);
      this._tabsEl.style.display = 'none';

      const spacer = document.createElement('div'); spacer.className = 'cpp-spacer';
      this._copyBtn = document.createElement('button'); this._copyBtn.className = 'cpp-copy'; this._copyBtn.textContent = 'Copy';
      this._copyBtn.style.display = 'none';
      this._copyBtn.addEventListener('click', function () { self._copy(); });

      bar.appendChild(this._titleEl); bar.appendChild(this._subEl); bar.appendChild(this._tabsEl);
      bar.appendChild(spacer); bar.appendChild(this._copyBtn);

      this._codeEl = document.createElement('div'); this._codeEl.className = 'cpp-code';
      this._renderEmpty('Select a C++ class on the left to preview its header and source.');

      main.appendChild(bar); main.appendChild(this._codeEl);
      this.appendChild(main);
    }

    _onClasses(d) {
      this._classes = (d && Array.isArray(d.classes)) ? d.classes : [];
      this._renderList();
    }

    _renderList() {
      if (!this._listEl) return;
      const self = this;
      this._listEl.innerHTML = '';
      const filtered = this._classes.filter(function (c) {
        return !self._filter || (c.name || '').toLowerCase().indexOf(self._filter) !== -1;
      });
      if (filtered.length === 0) {
        const none = document.createElement('div'); none.className = 'cpp-mod';
        none.textContent = this._classes.length ? 'No match' : 'No C++ classes found';
        this._listEl.appendChild(none);
        return;
      }
      let lastMod = null;
      filtered.forEach(function (c) {
        if (c.module && c.module !== lastMod) {
          lastMod = c.module;
          const m = document.createElement('div'); m.className = 'cpp-mod'; m.textContent = c.module;
          self._listEl.appendChild(m);
        }
        const item = document.createElement('div');
        item.className = 'cpp-item' + (self._active && self._active.header === c.header ? ' active' : '');
        const dot = document.createElement('span'); dot.className = 'dot';
        const nm = document.createElement('span'); nm.className = 'nm'; nm.textContent = c.name || '(unnamed)';
        item.appendChild(dot); item.appendChild(nm);
        item.addEventListener('click', function () { self._select(c); });
        self._listEl.appendChild(item);
      });
    }

    _select(c) {
      this._active = c;
      this._tab = 'h';
      if (c.header && this._files[c.header] === undefined) window.uecp.call('request_cpp_file', { path: c.header });
      if (c.source && this._files[c.source] === undefined) window.uecp.call('request_cpp_file', { path: c.source });
      this._titleEl.textContent = c.name || 'C++ Class';
      this._subEl.textContent = c.module ? ('  ' + c.module) : '';
      this._tabsEl.style.display = c.source ? 'flex' : 'none';
      this._copyBtn.style.display = 'inline-block';
      this._tabC.style.display = c.source ? '' : 'none';
      this._syncTabs();
      this._renderList();
      this._renderCode();
    }

    _onFile(d) {
      if (!d || !d.path) return;
      this._files[d.path] = (d.ok === false) ? ('// Could not read ' + d.path) : (d.content || '');
      if (this._active && d.path === this._currentPath()) this._renderCode();
    }

    _currentPath() {
      if (!this._active) return null;
      return this._tab === 'cpp' ? this._active.source : this._active.header;
    }

    _setTab(t) {
      if (t === 'cpp' && (!this._active || !this._active.source)) return;
      this._tab = t;
      this._syncTabs();
      this._renderCode();
    }

    _syncTabs() {
      if (this._tabH) this._tabH.classList.toggle('active', this._tab === 'h');
      if (this._tabC) this._tabC.classList.toggle('active', this._tab === 'cpp');
    }

    _renderEmpty(msg) {
      this._codeEl.className = 'cpp-empty';
      this._codeEl.innerHTML = '';
      const icon = document.createElement('div'); icon.className = 'mono'; icon.textContent = '{ }';
      const t = document.createElement('div'); t.textContent = msg;
      this._codeEl.appendChild(icon); this._codeEl.appendChild(t);
    }

    _renderCode() {
      const path = this._currentPath();
      if (!path) { this._renderEmpty('This class has no ' + (this._tab === 'cpp' ? 'source' : 'header') + ' file.'); return; }
      const content = this._files[path];
      if (content === undefined) {
        this._codeEl.className = 'cpp-empty'; this._codeEl.innerHTML = '';
        const t = document.createElement('div'); t.textContent = 'Loading…'; this._codeEl.appendChild(t);
        return;
      }
      this._codeEl.className = 'cpp-code';
      this._codeEl.innerHTML = '';
      const lines = content.replace(/\r\n/g, '\n').split('\n');
      let inBlock = false;
      const frag = document.createDocumentFragment();
      for (let i = 0; i < lines.length; i++) {
        const line = lines[i];
        const trimmed = line.replace(/^\s+/, '');
        let isCom = inBlock;
        if (inBlock) { if (line.indexOf('*/') !== -1) inBlock = false; }
        else if (trimmed.indexOf('//') === 0) { isCom = true; }
        else if (trimmed.indexOf('/*') === 0) { isCom = true; if (line.indexOf('*/') === -1) inBlock = true; }
        const isPre = !isCom && trimmed.charAt(0) === '#';

        const row = document.createElement('div');
        row.className = 'cpp-row' + (isCom ? ' com' : (isPre ? ' pre' : ''));
        const num = document.createElement('span'); num.className = 'cpp-num'; num.textContent = String(i + 1);
        const txt = document.createElement('span'); txt.className = 'cpp-txt'; txt.textContent = line.length ? line : ' ';
        row.appendChild(num); row.appendChild(txt);
        frag.appendChild(row);
      }
      this._codeEl.appendChild(frag);
      this._codeEl.scrollTop = 0;
    }

    _copy() {
      const path = this._currentPath();
      const content = path && this._files[path];
      if (content == null) return;
      const done = () => { const o = this._copyBtn.textContent; this._copyBtn.textContent = 'Copied'; setTimeout(() => { this._copyBtn.textContent = o; }, 1200); };
      try {
        if (navigator.clipboard && navigator.clipboard.writeText) { navigator.clipboard.writeText(content).then(done, () => this._copyFallback(content, done)); return; }
      } catch (e) {  }
      this._copyFallback(content, done);
    }
    _copyFallback(text, done) {
      try {
        const ta = document.createElement('textarea'); ta.value = text; ta.style.position = 'fixed'; ta.style.opacity = '0';
        document.body.appendChild(ta); ta.select(); document.execCommand('copy'); document.body.removeChild(ta); done();
      } catch (e) {  }
    }
  }

  customElements.define('uecp-screen-cpppreview', UecpScreenCppPreview);
})();
