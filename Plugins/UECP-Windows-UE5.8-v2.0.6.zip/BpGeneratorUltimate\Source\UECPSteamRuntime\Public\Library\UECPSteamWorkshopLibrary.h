// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "UECPSteamWorkshopTypes.h"
#include "UECPSteamWorkshopLibrary.generated.h"

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamWorkshopLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Workshop")
	static TArray<FUECPSteamWorkshopItemId> GetSubscribedItems();

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Workshop")
	static FUECPSteamWorkshopItemState GetWorkshopItemState(FUECPSteamWorkshopItemId ItemId);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Workshop")
	static bool GetWorkshopItemInstallInfo(FUECPSteamWorkshopItemId ItemId,
		FString& InstallFolder, int64& SizeOnDisk, FDateTime& TimeStamp);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Workshop")
	static bool GetWorkshopDownloadProgress(FUECPSteamWorkshopItemId ItemId,
		float& ProgressPercent, int64& BytesDownloaded, int64& BytesTotal);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Workshop", meta = (AdvancedDisplay = "bHighPriority"))
	static bool StartWorkshopItemDownload(FUECPSteamWorkshopItemId ItemId, bool bHighPriority = false);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Workshop")
	static bool SetWorkshopItemVote(FUECPSteamWorkshopItemId ItemId, bool bVoteUp);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Workshop")
	static bool AddWorkshopItemToFavorites(FUECPSteamWorkshopItemId ItemId);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Workshop")
	static bool RemoveWorkshopItemFromFavorites(FUECPSteamWorkshopItemId ItemId);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Workshop")
	static bool ShowWorkshopItemPage(FUECPSteamWorkshopItemId ItemId);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Workshop")
	static bool ShowWorkshopHub();

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Workshop")
	static bool StartTrackingWorkshopPlaytime(const TArray<FUECPSteamWorkshopItemId>& ItemIds);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Workshop")
	static bool StopTrackingWorkshopPlaytime(const TArray<FUECPSteamWorkshopItemId>& ItemIds);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Workshop",
		meta = (CompactNodeTitle = "->", BlueprintAutocast))
	static FString Conv_WorkshopItemIdToString(const FUECPSteamWorkshopItemId& ItemId);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Workshop")
	static FUECPSteamWorkshopItemId MakeWorkshopItemIdFromString(const FString& ItemIdString);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Workshop")
	static bool AddWorkshopDependency(FUECPSteamWorkshopItemId ParentItemId,
		FUECPSteamWorkshopItemId ChildItemId);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Workshop")
	static bool RemoveWorkshopDependency(FUECPSteamWorkshopItemId ParentItemId,
		FUECPSteamWorkshopItemId ChildItemId);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Workshop", meta = (AdvancedDisplay = "bIsVideo"))
	static bool AddWorkshopPreview(int64 UpdateHandle, const FString& PreviewFileOrUrl,
		bool bIsVideo = false);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Workshop")
	static bool AddWorkshopKeyValueTag(int64 UpdateHandle, const FString& Key, const FString& Value);
};
