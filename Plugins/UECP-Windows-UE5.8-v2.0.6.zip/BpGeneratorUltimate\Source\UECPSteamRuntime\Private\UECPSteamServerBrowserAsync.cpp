// Copyright 2026, BlueprintsLab, All rights reserved
#include "Async/UECPSteamServerBrowserAsync.h"

#include "UECPSteamAPI.h"

#if UECP_WITH_STEAM

class FUECPSteamServerListResponder final : public ISteamMatchmakingServerListResponse
{
public:
	explicit FUECPSteamServerListResponder(UUECPSteamFindServers* InOwner)
		: Owner(InOwner)
	{
	}

	HServerListRequest Request = nullptr;

	virtual void ServerResponded(HServerListRequest hRequest, int iServer) override
	{
		Forward([iServer](UUECPSteamFindServers& Node) { Node.HandleServerResponded(iServer); });
	}

	virtual void ServerFailedToRespond(HServerListRequest , int ) override
	{
	}

	virtual void RefreshComplete(HServerListRequest , EMatchMakingServerResponse Response) override
	{
		const bool bOk = (Response == eServerResponded || Response == eNoServersListedOnMasterServer);
		Forward([bOk](UUECPSteamFindServers& Node) { Node.HandleRefreshComplete(bOk); });
	}

private:
	TWeakObjectPtr<UUECPSteamFindServers> Owner;

	void Forward(TFunction<void(UUECPSteamFindServers&)> Work)
	{
		TWeakObjectPtr<UUECPSteamFindServers> WeakOwner = Owner;
		UECPSteam::RunOnGameThread([WeakOwner, Work = MoveTemp(Work)]()
		{
			if (UUECPSteamFindServers* Node = WeakOwner.Get())
			{
				Work(*Node);
			}
		});
	}
};

#else

class FUECPSteamServerListResponder
{
public:
	explicit FUECPSteamServerListResponder(UUECPSteamFindServers*) {}
};

#endif

UUECPSteamFindServers::UUECPSteamFindServers() = default;
UUECPSteamFindServers::UUECPSteamFindServers(FVTableHelper& Helper) : Super(Helper) {}
UUECPSteamFindServers::~UUECPSteamFindServers() = default;

UUECPSteamFindServers* UUECPSteamFindServers::FindSteamServers(
	UObject* WorldContextObject, EUECPSteamServerListType ListType,
	TMap<FString, FString> Filters, float TimeoutSeconds)
{
	UUECPSteamFindServers* Node = NewObject<UUECPSteamFindServers>();
	Node->ContextObject   = WorldContextObject;
	Node->ListType        = ListType;
	Node->Filters         = MoveTemp(Filters);
	Node->TimeoutSeconds  = TimeoutSeconds;
	Node->RegisterWithGameInstance(WorldContextObject);
	return Node;
}

bool UUECPSteamFindServers::Start(FUECPSteamError& OutError)
{
#if UECP_WITH_STEAM
	ISteamMatchmakingServers* Servers_ = UECPSteam::MatchmakingServers();
	ISteamUtils* Utils = UECPSteam::Utils();
	if (!Servers_ || !Utils)
	{
		OutError = FUECPSteamError::Unavailable();
		return false;
	}

	Responder = MakeUnique<FUECPSteamServerListResponder>(this);
	const AppId_t AppId = Utils->GetAppID();

	TArray<MatchMakingKeyValuePair_t> Pairs;
	Pairs.Reserve(Filters.Num());
	for (const TPair<FString, FString>& Filter : Filters)
	{
		MatchMakingKeyValuePair_t Pair;
		FCStringAnsi::Strncpy(Pair.m_szKey, TCHAR_TO_UTF8(*Filter.Key), UE_ARRAY_COUNT(Pair.m_szKey));
		FCStringAnsi::Strncpy(Pair.m_szValue, TCHAR_TO_UTF8(*Filter.Value), UE_ARRAY_COUNT(Pair.m_szValue));
		Pairs.Add(Pair);
	}
	TArray<MatchMakingKeyValuePair_t*> PairPtrs;
	PairPtrs.Reserve(Pairs.Num());
	for (MatchMakingKeyValuePair_t& Pair : Pairs)
	{
		PairPtrs.Add(&Pair);
	}
	MatchMakingKeyValuePair_t** FilterArg = PairPtrs.Num() > 0 ? PairPtrs.GetData() : nullptr;
	const uint32 FilterCount = static_cast<uint32>(PairPtrs.Num());

	switch (ListType)
	{
	case EUECPSteamServerListType::LAN:
		Responder->Request = Servers_->RequestLANServerList(AppId, Responder.Get());
		break;
	case EUECPSteamServerListType::Friends:
		Responder->Request = Servers_->RequestFriendsServerList(AppId, FilterArg, FilterCount, Responder.Get());
		break;
	case EUECPSteamServerListType::Favorites:
		Responder->Request = Servers_->RequestFavoritesServerList(AppId, FilterArg, FilterCount, Responder.Get());
		break;
	case EUECPSteamServerListType::History:
		Responder->Request = Servers_->RequestHistoryServerList(AppId, FilterArg, FilterCount, Responder.Get());
		break;
	case EUECPSteamServerListType::Internet:
	default:
		Responder->Request = Servers_->RequestInternetServerList(AppId, FilterArg, FilterCount, Responder.Get());
		break;
	}

	if (Responder->Request == nullptr)
	{
		OutError = FUECPSteamError(EUECPSteamResult::BackendFailure,
			TEXT("Steam refused the server list request."));
		return false;
	}

	if (TimeoutSeconds > 0.f)
	{
		TWeakObjectPtr<UUECPSteamFindServers> WeakThis(this);
		TimeoutHandle = FTSTicker::GetCoreTicker().AddTicker(
			FTickerDelegate::CreateLambda([WeakThis](float) -> bool
			{
				if (UUECPSteamFindServers* Node = WeakThis.Get())
				{
					Node->HandleRefreshComplete(true);
				}
				return false;
			}), TimeoutSeconds);
	}

	return true;
#else
	OutError = FUECPSteamError::Unavailable();
	return false;
#endif
}

void UUECPSteamFindServers::HandleServerResponded(int32 ServerIndex)
{
#if UECP_WITH_STEAM
	ISteamMatchmakingServers* Servers_ = UECPSteam::MatchmakingServers();
	if (!Servers_ || !Responder.IsValid() || Responder->Request == nullptr)
	{
		return;
	}

	gameserveritem_t* Item = Servers_->GetServerDetails(Responder->Request, ServerIndex);
	if (!Item)
	{
		return;
	}

	FUECPSteamServerInfo Info;
	Info.ServerName        = UTF8_TO_TCHAR(Item->GetName());
	Info.MapName           = UTF8_TO_TCHAR(Item->m_szMap);
	Info.GameDescription   = UTF8_TO_TCHAR(Item->m_szGameDescription);
	Info.GameTags          = UTF8_TO_TCHAR(Item->m_szGameTags);
	Info.PingMs            = Item->m_nPing;
	Info.Players           = Item->m_nPlayers;
	Info.MaxPlayers        = Item->m_nMaxPlayers;
	Info.BotPlayers        = Item->m_nBotPlayers;
	Info.bPasswordProtected = Item->m_bPassword;
	Info.bSecure           = Item->m_bSecure;
	Info.ServerVersion     = Item->m_nServerVersion;
	Info.ServerSteamId     = FUECPSteamID(UECPSteam::FromSteamID(Item->m_steamID));

	if (const char* Address = Item->m_NetAdr.GetConnectionAddressString())
	{
		Info.ConnectAddress = UTF8_TO_TCHAR(Address);
	}

	Servers.Add(MoveTemp(Info));
#endif
}

void UUECPSteamFindServers::HandleRefreshComplete(bool bSucceeded)
{
	if (bSucceeded)
	{
		CompleteSuccess();
	}
	else
	{
		CompleteFailure(FUECPSteamError(EUECPSteamResult::BackendFailure,
			TEXT("The server list query failed. Steam's master server is usually unreachable.")));
	}
}

void UUECPSteamFindServers::OnCleanup()
{
	if (TimeoutHandle.IsValid())
	{
		FTSTicker::GetCoreTicker().RemoveTicker(TimeoutHandle);
		TimeoutHandle.Reset();
	}

#if UECP_WITH_STEAM
	if (Responder.IsValid() && Responder->Request != nullptr)
	{
		if (ISteamMatchmakingServers* Servers_ = UECPSteam::MatchmakingServers())
		{
			Servers_->CancelQuery(Responder->Request);
			Servers_->ReleaseRequest(Responder->Request);
		}
		Responder->Request = nullptr;
	}
#endif
	Responder.Reset();
}

void UUECPSteamFindServers::BroadcastResult(bool bSucceeded, const FUECPSteamError& Error)
{
	(bSucceeded ? OnSuccess : OnFailure).Broadcast(Servers, Error);
}
