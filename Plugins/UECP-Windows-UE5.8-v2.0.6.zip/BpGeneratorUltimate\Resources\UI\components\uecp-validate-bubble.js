(function () {
  if (!document.getElementById('uecp-validate-bubble-css')) {
    const s = document.createElement('style'); s.id = 'uecp-validate-bubble-css';
    s.textContent = `
uecp-validate-bubble{display:block;margin:8px 0}
uecp-validate-bubble .validate-card{background:var(--ue-panel);border:1px solid var(--ue-line-soft);border-radius:var(--ue-r)}
uecp-validate-bubble .validate-head{display:flex;align-items:center;gap:10px;padding:9px 13px;cursor:pointer;border-left:3px solid var(--ue-line-soft);border-radius:var(--ue-r) var(--ue-r) 0 0}
uecp-validate-bubble .validate-head.ok{border-left-color:var(--ue-success)}
uecp-validate-bubble .validate-head.err{border-left-color:var(--ue-danger,#f85149)}
uecp-validate-bubble .validate-icon{flex-shrink:0;width:17px;height:17px;border-radius:50%;display:flex;align-items:center;justify-content:center}
uecp-validate-bubble .validate-icon.ok{background:var(--ue-success-soft);color:var(--ue-success)}
uecp-validate-bubble .validate-icon.err{background:var(--ue-danger-soft,#3a1a1a);color:var(--ue-danger,#f85149)}
uecp-validate-bubble .validate-name{font-size:12.5px;font-weight:var(--ue-fw-semi);color:var(--ue-text-hi);flex:1;min-width:0}
uecp-validate-bubble .validate-chevron{flex-shrink:0;transition:transform .18s;color:var(--ue-text-lo)}
uecp-validate-bubble.open .validate-chevron{transform:rotate(90deg)}
uecp-validate-bubble .validate-content{display:none;border-top:1px solid var(--ue-line-soft);padding:10px 13px}
uecp-validate-bubble.open .validate-content{display:block}
uecp-validate-bubble .validate-content pre{margin:0;font-family:var(--ue-font-mono);font-size:11.5px;line-height:1.5;color:var(--ue-text-mid);white-space:pre-wrap;word-break:break-word}`;
    document.head.appendChild(s);
  }

  function decodeValidateAttr(raw) {
    if (!raw) return null;
    try { return JSON.parse(decodeURIComponent(raw)); }
    catch (e) { return null; }
  }

  const ERR_SVG = '<svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="M12 9v4"/><path d="M12 17h.01"/><path d="m21.73 18-8-14a2 2 0 0 0-3.46 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3Z"/></svg>';

  class UecpValidateBubble extends HTMLElement {
    connectedCallback() {
      if (!this.innerHTML) this._build();
    }

    setValidate(data) {
      this._data = data || null;
      this._build();
    }

    _build() {
      const data = this._data || decodeValidateAttr(this.getAttribute('data-validate'));
      if (!data || !data.message) { this.innerHTML = ''; return; }
      this._data = data;

      const needsFix = !!data.needsFix;
      const statusClass = needsFix ? 'err' : 'ok';
      const label = needsFix ? 'Auto-Validate — Fix Needed' : 'Auto-Validate';
      const icon = needsFix
        ? ERR_SVG
        : (window.UECP && window.UECP.icon ? window.UECP.icon('ic-check', 11) : '');
      const esc = (window.UECP && window.UECP.escapeHtml) ? window.UECP.escapeHtml : function (t) { return String(t == null ? '' : t); };

      this.innerHTML =
        '<div class="validate-card">' +
          '<div class="validate-head ' + statusClass + '">' +
            '<span class="validate-icon ' + statusClass + '">' + icon + '</span>' +
            '<span class="validate-name">' + esc(label) + '</span>' +
            '<svg class="validate-chevron" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="m9 18 6-6-6-6"/></svg>' +
          '</div>' +
          '<div class="validate-content"><pre>' + esc(data.message) + '</pre></div>' +
        '</div>';

      const self = this;
      this.querySelector('.validate-head').addEventListener('click', function () {
        self.classList.toggle('open');
      });
    }
  }
  customElements.define('uecp-validate-bubble', UecpValidateBubble);
})();
