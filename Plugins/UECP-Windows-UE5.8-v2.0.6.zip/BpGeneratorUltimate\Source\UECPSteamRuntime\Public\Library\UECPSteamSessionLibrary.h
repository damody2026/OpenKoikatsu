// Copyright 2026, BlueprintsLab, All rights reserved
#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "UECPSteamSessionTypes.h"
#include "UECPSteamSessionLibrary.generated.h"

UENUM(BlueprintType)
enum class EUECPSteamSessionState : uint8
{
	NoSession   UMETA(DisplayName = "No Session"),
	Creating    UMETA(DisplayName = "Creating"),
	Pending     UMETA(DisplayName = "Pending"),
	Starting    UMETA(DisplayName = "Starting"),
	InProgress  UMETA(DisplayName = "In Progress"),
	Ending      UMETA(DisplayName = "Ending"),
	Ended       UMETA(DisplayName = "Ended"),
	Destroying  UMETA(DisplayName = "Destroying"),
};

UCLASS()
class UECPSTEAMRUNTIME_API UUECPSteamSessionLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Session",
		meta = (WorldContext = "WorldContextObject", AdvancedDisplay = "SessionName"))
	static EUECPSteamSessionState GetSteamSessionState(
		const UObject* WorldContextObject, FName SessionName);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Session",
		meta = (WorldContext = "WorldContextObject", AdvancedDisplay = "SessionName"))
	static bool IsInSteamSession(const UObject* WorldContextObject, FName SessionName);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Session",
		meta = (WorldContext = "WorldContextObject", AdvancedDisplay = "SessionName"))
	static FString GetSteamResolvedConnectString(
		const UObject* WorldContextObject, FName SessionName);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Session",
		meta = (WorldContext = "WorldContextObject", AdvancedDisplay = "SessionName"))
	static bool TravelToSteamSession(
		const UObject* WorldContextObject, FName SessionName);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Session",
		meta = (WorldContext = "WorldContextObject"))
	static bool HostTravelToMap(const UObject* WorldContextObject, const FString& MapName);

	UFUNCTION(BlueprintPure, Category = "UECP|Steam|Session",
		meta = (WorldContext = "WorldContextObject", AdvancedDisplay = "SessionName"))
	static int32 GetSteamSessionOpenSlots(const UObject* WorldContextObject, FName SessionName);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Session",
		meta = (WorldContext = "WorldContextObject", AdvancedDisplay = "SessionName,bWasInvited"))
	static bool RegisterSteamSessionPlayer(
		const UObject* WorldContextObject, FUECPSteamID PlayerSteamId,
		FName SessionName, bool bWasInvited = false);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Session",
		meta = (WorldContext = "WorldContextObject", AdvancedDisplay = "SessionName"))
	static bool UnregisterSteamSessionPlayer(
		const UObject* WorldContextObject, FUECPSteamID PlayerSteamId, FName SessionName);

	UFUNCTION(BlueprintCallable, Category = "UECP|Steam|Session",
		meta = (WorldContext = "WorldContextObject", AdvancedDisplay = "SessionName"))
	static bool SendSteamSessionInvite(
		const UObject* WorldContextObject, FUECPSteamID FriendSteamId, FName SessionName);
};
